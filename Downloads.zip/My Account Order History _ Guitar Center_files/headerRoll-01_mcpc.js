  const GCI = window.GCI || {},
        el = document.getElementById('promoScroll');
  let down = false, startX, scrollX;

  const setCursor = () =>
    el.style.cursor = el.scrollWidth > el.clientWidth ? 'grab' : 'default';

  setCursor();
  addEventListener('resize', setCursor);

  el.addEventListener('mousedown', e => {
    if (el.scrollWidth <= el.clientWidth) return;
    down = true;
    startX = e.pageX - el.offsetLeft;
    scrollX = el.scrollLeft;
    el.style.cursor = 'grabbing';
    document.body.style.userSelect = 'none';
  });
  ['mouseup','mouseleave'].forEach(evt =>
    el.addEventListener(evt, () => {
      down = false;
      setCursor();
      document.body.style.userSelect = '';
    })
  );
  el.addEventListener('mousemove', e => {
    if (!down) return;
    e.preventDefault();
    el.scrollLeft = scrollX - ((e.pageX - el.offsetLeft - startX) * 2);
  });
	el.addEventListener('touchstart', e => {
    if (el.scrollWidth <= el.clientWidth) return;
    down = true;
    startX = e.touches[0].pageX - el.offsetLeft;
    scrollX = el.scrollLeft;
    el.style.cursor = 'grabbing';
  });
  el.addEventListener('touchmove', e => {
    if (!down) return;
    // Prevent vertical page scroll while dragging horizontally
    e.preventDefault(); // note: requires { passive: false } on this listener
    el.scrollLeft = scrollX - ((e.touches[0].pageX - el.offsetLeft - startX) * 2);
  }, { passive: false });

  el.addEventListener('touchend', () => {
    down = false;
    setCursor();
  });