
/*jslint browser: true, multivar: true */

if (window.__AudioEyePerformance) {
    window.__AudioEyePerformance.loaderJsStartTime = performance.now();
}

if (!window.__AudioEyeSiteHash) {
    window.__AudioEyeSiteHash = 'f199ac50a6ee548596386803955219cc';
}

var aecb = "2026-09-14";
var pscb = '';

function loadStaticScript(path) {
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = "https://wsv3cdn.audioeye.com/static-scripts/v2/2026-09-14/".replace("__BROWSER_JS_VERSION__", window.__audioEyeContext.browserJsVersion) + path;
    document.body.appendChild(script);
}

var loaderFunction = function (tries) {
    window.__AudioEyeLoaderStartTime = new Date().getTime();
    // Singleton pattern: if the loader has already run, do not overwrite.
    if (window.AudioEye && window.AudioEye.version !== undefined) {
        return;
    }

    // declare define here so that when jquery is imported in startupRoutine.js it will
    // find this define instead of any global define that a customer might use
    var define = function(){};

    window.AudioEye = Object.assign({}, window.AudioEye || {});

    var options = {};
    var protocol = "https:";
    var device = "desktop";
    var site_id = null;


    
    var options = {"live-monitoring":{"limit":0.001,"service":true,"includeHashFragment":false,"allowedQueryKeys":[]},"help":{"service":true,"aria-label":{"en":"Help Menu. Press enter or use question mark key to turn on or off."},"tooltip-title":{"en":"Help"},"tooltip-keycommand":{"en":"(press ?)"}},"admin":{"service":true,"aria-label":{"en":"AudioEye portal"},"at-message":{"en":"AudioEye portal login"},"cancel":{"en":"Cancel"},"popup_content_opening":{"en":"Opening the Admin Panel requires the page to reload"},"popup_content_closing":{"en":"Closing the Admin Panel requires the page to reload"},"popup_title":{"en":"Confirm reload"},"reload":{"en":"Reload"},"tooltip-title":{"en":"Admin Panel"}},"rotor":{"service":true,"aria-label":{"en":"Page Elements Menu. Press enter or use d key to turn on or off."},"tooltip-title":{"en":"Page Elements Menu"},"tooltip-keycommand":{"en":"(press D)"},"skipto_rotor-link":false},"helpers":{"service":true},"toolbar":{"service":true,"color":{"background":"#252930","foreground":"#96a0ab"},"theme":"light","defaultVTKTab":"report","at-message":{"en":"AudioEye Toolbar. Explore the tools below or press escape to quit the toolbar."},"aria-label":{"en":"AudioEye Toolbar. Explore the tools below or press escape to quit the toolbar."}},"helpdesk":{"service":true,"at-message":{"en":"The AudioEye Help Desk to report accessibility and usability related issues."},"aria-label":{"en":"AudioEye Help Desk. To report accessibility and usability related issues, press enter or use h key to turn on or off."},"tooltip-title":{"en":"Help Desk"},"tooltip-keycommand":{"en":"(press H)"}},"launcher":{"service":true,"position":"right-lower","cta-color":null,"theme-color":"#602ECC","pre-opt-in-messaging":{"at-message":{"en":"This website is AudioEye enabled and is being optimized for accessibility. Additionally, free web personalization tools have been provided via the AudioEye Toolbar, which may be enabled from the Accessibility Statement link found on this page."}},"opt-in":true,"at-message":{"en":"This website is AudioEye enabled and is being optimized for accessibility. To open the AudioEye Toolbar, press shift + =. The toolbar contains the following"},"aria-label":{"en":"Accessibility options"},"tooltip-title":{"en":"Explore your accessibility options."},"preview-mode-message":{"en":"AudioEye is in preview mode. Some functionality will be limited."},"preview-mode-modal-close":{"en":"Close"},"preview-mode-modal-title":{"en":"Preview Mode"},"at-messages":{"admin":{"en":"AudioEye portal login"},"voice":{"en":"The Voice (beta) tool to control and interact with this site using your voice."},"player":{"en":"The Player tool to listen to this site read aloud. The Player is not intended as a substitute for your screen reader."},"reader":{"en":"The Reader tool to customize the visual display of this site."},"toolbar":{"en":"AudioEye Toolbar. Explore the tools below or press escape to quit the toolbar."},"helpdesk":{"en":"The AudioEye Help Desk to report accessibility and usability related issues."},"launcher":{"en":"This website is AudioEye enabled and is being optimized for accessibility. To open the AudioEye Toolbar, press shift + =. The toolbar contains the following"},"lite-reader":{"en":"AudioEye Visual Toolkit"}}},"pc_preset":"custom-mode","site-menu":{"service":true,"selectors":{"main-menu":{"label":{"en":"Main Menu"},"link":true,"selector":".header-layout .rightNav","search-algorithm":"default"},"aside-menu":{"label":{"en":""},"link":false,"selector":"","search-algorithm":"default"},"other-menu":{"label":{"en":""},"link":false,"selector":"","search-algorithm":"default"},"footer-menu":{"label":{"en":""},"link":false,"selector":"","search-algorithm":"default"},"utility-menu":{"label":{"en":""},"link":false,"selector":"","search-algorithm":"default"},"additional-menus":[{"label":{"en":""},"selector":"","link":false,"search-algorithm":"default"},{"link":false,"label":{"en":""},"selector":"","search-algorithm":"default"},{"link":false,"label":{"en":""},"selector":"","search-algorithm":"default"},{"link":false,"label":{"en":""},"selector":"","search-algorithm":"default"},{"link":false,"label":{"en":""},"selector":"","search-algorithm":"default"},{"link":false,"label":{"en":""},"selector":"","search-algorithm":"default"},{"link":false,"label":{"en":""},"selector":"","search-algorithm":"default"}]},"aria-label":{"en":"Site Menu. Press enter or use n key to turn on or off."},"tooltip-title":{"en":""},"tooltip-keycommand":{"en":"(press N)"},"search-algorithms":{"default":"Default"},"label":{"en":""}},"compliance":{"service":true,"auto-remediations":true,"smart-remediations":true,"manual-remediations":true,"live-monitoring-limit":"0.01","spaOptIn":false,"edge-remediations":false,"skip-remediations":"","skipto_main-content-link":true,"tab-triggers-outline":false,"skipto_main-link-text":{"en":"Skip to Main Content"},"aria-landmarks":{"banner":"header","search":"#search-form-wrap","content":"#bodyContentContainer","complementary":"","contentinfo":"footer"},"aria-live":{"polite":"","assertive":"","live":"","alert":""},"new_window_text":{"en":"Opens a New Window."},"accessible-carousel-link-text":{"en":"Accessible Carousel"},"accessible-carousel-link-label":{"en":"Accessible Carousel"}},"lite-reader":{"service":true,"aria-label":{"en":"AudioEye Visual Toolkit"},"at-message":{"en":"AudioEye Visual Toolkit"},"tooltip-title":{"en":"Visual Toolkit"},"tooltip-keycommand":{"en":"(Press T)"}},"certification":{"service":true,"version":"3","versionlist":{"3":"Partner Pro","4":"Pro Commitment Statement","5":"Managed"},"step":"1","tooltip-title":{"en":"Commitment Statement"},"tooltip-keycommand":{"en":"(press B)"},"aria-label":{"en":"AudioEye Commitment Statement. Press enter or use b key to turn on or off."},"at-message":{"en":"The AudioEye Commitment Statement to explain the ongoing web accessibility and usability enhancements for this website."}},"user-settings":{"service":true,"aria-label":{"en":"Settings Menu. Press enter or use s key to turn on or off."},"tooltip-title":{"en":"Settings"},"tooltip-keycommand":{"en":"(press S)"}},"carousels":[{"carousel":"#category-promo-slider-fluid ","slides":"#category-promo-slider-fluid .owl-carousel .owl-item","link":true,"click-proxy":false,"next_slide":{"en":"Next Slide"},"prev_slide":{"en":"Previous Slide"},"slide_count":{"en":"Slide {{num}} of {{total}}"}},{"link":true,"slides":"#category-promo-slider .carousel .firstLoaded","carousel":"#category-promo-slider .carousel","next_slide":{"en":"Next Slide"},"prev_slide":{"en":"Previous Slide"},"click-proxy":false,"slide_count":{"en":"Slide {{num}} of {{total}}"}},{"link":true,"slides":".bestdealsection .owl-carousel .owl-item ","carousel":".bestdealsection .owl-carousel","next_slide":{"en":"Next Slide"},"prev_slide":{"en":"Previous Slide"},"click-proxy":false,"slide_count":{"en":"Slide {{num}} of {{total}}"}},{"link":true,"slides":"#globalPencilBanner .owl-carousel .owl-item:not(cloned)","carousel":"#globalPencilBanner .owl-carousel","next_slide":{"en":"Next Slide"},"prev_slide":{"en":"Previous Slide"},"click-proxy":false,"slide_count":{"en":"Slide {{num}} of {{total}}"}},{"link":true,"slides":".carousel-cell","carousel":".flickity-slider","next_slide":{"en":"Next Slide"},"prev_slide":{"en":"Previous Slide"},"click-proxy":false,"slide_count":{"en":"Slide {{num}} of {{total}}"}},{"link":true,"slides":".swiper-slide","carousel":".rich-relevance-product .swiper-wrapper","next_slide":{"en":"Next Slide"},"prev_slide":{"en":"Previous Slide"},"click-proxy":false,"slide_count":{"en":"Slide {{num}} of {{total}}"}},{"link":true,"slides":".swiper-slide:not(.swiper-slide-duplicate)","carousel":"#pdp-layout .carousel-banner","next_slide":{"en":"Next Slide"},"prev_slide":{"en":"Previous Slide"},"click-proxy":false,"slide_count":{"en":"Slide {{num}} of {{total}}"}},{"link":true,"slides":".embla__slide","carousel":"#pdp-gallery ","next_slide":{"en":"Next Slide"},"prev_slide":{"en":"Previous Slide"},"click-proxy":false,"slide_count":{"en":"Slide {{num}} of {{total}}"}},{"link":true,"slides":".owl-item","carousel":".slot-specific-sku-wrap ","next_slide":{"en":"Next Slide"},"prev_slide":{"en":"Previous Slide"},"click-proxy":false,"slide_count":{"en":"Slide {{num}} of {{total}}"}},{"link":true,"slides":".swiper-slide","carousel":".client-render .swiper-wrapper","next_slide":{"en":"Next Slide"},"prev_slide":{"en":"Previous Slide"},"click-proxy":false,"slide_count":{"en":"Slide {{num}} of {{total}}"}},{"link":true,"slides":".owl-item","carousel":".carousel-wrap","next_slide":{"en":"Next Slide"},"prev_slide":{"en":"Previous Slide"},"click-proxy":false,"slide_count":{"en":"Slide {{num}} of {{total}}"}},{"link":true,"slides":".product","carousel":".home-hero-slide","next_slide":{"en":"Next Slide"},"prev_slide":{"en":"Previous Slide"},"click-proxy":false,"slide_count":{"en":"Slide {{num}} of {{total}}"}}],"external-links":{"service":true,"interface":{"popup_title":{"en":"Confirm Navigation"},"popup_content2":{"en":"You are navigating away from the <span class=\"notranslate\">[[site-name]]<\/span> website. <span class=\"notranslate\">[[site-name]]<\/span> does not own, operate, or control the link or its content. <span class=\"notranslate\">[[site-name]]<\/span> is not responsible for the content of the external website. Privacy and security policies of the external website may differ from those practiced by <span class=\"notranslate\">[[site-name]]<\/span>."},"popup_content":{"en":"By activating 'Continue' below, you acknowledge the previous statement and will be taken to the external website. If you want to remain on this website, activate 'Cancel'."},"popup_content3":{"en":"By activating 'Continue' below, you will open a new window of AudioEye. If you want to remain on the same page, activate 'Cancel'."},"cancel":{"en":"Cancel"},"continue":{"en":"Continue"}}},"persist-settings":{"service":false,"persist":false},"excludes":"","timers":"","tabsets":{"tabset":"","tabs":"","active-tab":"","content":""},"iframes":{"allowed-origins":[],"searchAndInject":false,"unsafe-sources":["gateway.answerscloud.com","cc.hostedpci.com"],"unsafeIframeSelectors":[]},"live-monitoring-limit":"0.01","content-modifiers-version":"2","ga-account":"","startup_modules":["launcher","compliance"],"languages":{"aliases":{"en":["en"],"zh-cn":["zh"],"sv-se":["sv"],"ru-ru":["ru"],"pt-pt":["pt"],"pl-pl":["pl"],"no-no":["no"],"nl-nl":["nl"],"ko-kr":["ko"],"ja-jp":["jp","ja"],"it-it":["it"],"hu-hu":["hu"],"fr-fr":["fr"],"es":["es"],"el-gr":["el"],"de-de":["de"],"da-dk":["da"],"cs-cz":["cs"],"ca":["ca"],"ar-sa":["ar"]},"supported":{"auto":"Automatic","en":"English","en-gb":"English (UK)","zh-tw":"Chinese (Taiwan)","zh-hk":"Chinese (Hong Kong)","zh-cn":"Chinese (China)","sv-se":"Swedish","ru-ru":"Russian","pt-pt":"Portuguese (Portugal)","pt-br":"Portuguese (Brazil)","pl-pl":"Polish","no-no":"Norwegian","nl-nl":"Dutch","ko-kr":"Korean","ja-jp":"Japanese","it-it":"Italian","hu-hu":"Hungarian","fr-fr":"French (France)","fr-ca":"French (Canada)","fi-fi":"Finnish","es":"Spanish","es-mx":"Spanish (Mexico)","el-gr":"Greek","de-de":"German","da-dk":"Danish","cs-cz":"Czech","ca":"Catalan","ar-sa":"Arabic"},"supported-translated":{"auto":"Automatic","en":"English","zh-tw":"\u7e41\u9ad4\u4e2d\u6587","zh-hk":"\u4e2d\u6587\uff08\u9999\u6e2f\uff09","zh-cn":"\u7b80\u4f53\u4e2d\u6587","sv-se":"Svenska","ru-ru":"\u0420\u0443\u0441\u0441\u043a\u0438\u0439","pt-pt":"Portugu\u00eas","pt-br":"Portugu\u00eas","pl-pl":"Polski","no-no":"Norsk","nl-nl":"Nederlands","ko-kr":"\ud55c\uad6d\uc5b4","ja-jp":"\u65e5\u672c\u8a9e","it-it":"Italiano","hu-hu":"Hungarian","fr-fr":"Fran\u00e7ais","fr-ca":"Fran\u00e7ais","fi-fi":"suomi","es-mx":"Espa\u00f1ol","en-gb":"English","el-gr":"\u0395\u03bb\u03bb\u03b7\u03bd\u03b9\u03ba\u03ac","de-de":"Deutsch","da-dk":"Dansk","cs-cz":"\u010cesky","ca":"Catal\u00e0","ar-sa":"\u0627\u0644\u0639\u0631\u0628\u064a\u0629","es":"Spanish"},"primary":"auto","detected":"en"},"off-limits":null,"toolbar-promo":false,"consentManagementConfig":{"service":false,"cookieConsentConfig":null},"whiteLabel":{"enabled":false,"link":null,"linkText":null}},
        site_id = "5aa26fc6-6c52-5c8b-ba85-61219724e482",
        encrypted_site_id = "heZYdtgMVw9M2Lm7535a4LMImmTipEasB0UIjlUiACAMZVmplmGbhv9PWVgBBk4t";
        
    AudioEye.site_id = site_id;
    AudioEye.encrypted_site_id = encrypted_site_id;
    AudioEye.site_name = "guitarcenter.com";
    AudioEye.base_url = "guitarcenter.com\/m";
    AudioEye.analytics_url =  "https://analytics.audioeye.com/v1/send";
    AudioEye.last_publish = "2026-09-10T05:36:15.783Z";

    // Unit Test Mode
    options.testmode = (window.audioeye_test_mode) ? window.audioeye_test_mode : false;

    // Make options accessible by other modules
    AudioEye.productConfig = options;

    AudioEye.cb = aecb;
    AudioEye.pscb = pscb;
    AudioEye.device = device;
    AudioEye.version = "3.0" + (aecb ? "-" + aecb : "");
    AudioEye.protocol = protocol;
    AudioEye.client_url = "https:\/\/wsv3cdn.audioeye.com\/v2";
    AudioEye.static_scripts_base_url = "https://wsv3cdn.audioeye.com/static-scripts/v2/2026-09-14".replace("__BROWSER_JS_VERSION__", window.__audioEyeContext.browserJsVersion);

    AudioEye.assets_url = "https:\/\/assets.audioeye.com\/m";

        AudioEye.gtm_url = "https:\/\/wsv3cdn.audioeye.com\/bootstrap.js?h=f199ac50a6ee548596386803955219cc";
    AudioEye.voice_url = "https:\/\/assets.audioeye.com\/m";
    AudioEye.voice_client_entry = "https:\/\/vs.audioeye.com\/m\/";
    AudioEye.build = "prod\/m";
    AudioEye.portal_url = "portal.audioeye.com";
    AudioEye.portal_preview = false;
    AudioEye.site_version = null;
    AudioEye.loaderVersion = 2;
    AudioEye.a11yTestingReportTo = 'https://analytics.audioeye.com/v2/report';
    AudioEye.excludedFixes = ["6572da6e-2478-4d13-b538-62d0f77a5d19","35d1ac7b-eacd-4c55-9aeb-7a9070d7aa68","ea142916-0154-4a8f-a8ab-13eb0b913a57","b631c34a-49e2-40c4-8cb3-c2560823bbb6","3ac5c4b4-8034-4ccc-924d-d059116eb01d","831d31b2-20fa-4e3b-8cd4-0df0cabd4cbe","3e68a57c-3363-4c2f-87fc-4b8ba05f3f56","5e4c8418-7030-45ee-96c3-7b37b5e0fceb","dec9482e-409f-42a8-9476-b97ef985b6d6","436a1694-a8dd-4f9a-a37c-4fc8216d1ab4","715ac55c-4836-41dd-8174-b80d571d73fc","1ccaa9fe-7c10-4b5b-a46b-3488ab33d96b","b199d7a5-e07b-4813-a444-673bc65692ab","c89306df-0712-4f6d-af99-7eef8733c7f2","09faba12-0883-4dba-909a-e88b2ca6e7ae","c1c8ae87-b541-40e8-b847-3c36a35e7428","82dfb339-3fd1-4d48-86bf-b42123bec2ed","37973787-fd4f-478d-addf-ffee7191a880","6cdfca7d-172d-4e0c-84ba-8844ce27709a","2fef6d46-15a0-43ee-9df0-b995a9500195","a56710c2-69f1-479f-a497-ff8676e2a990","02d077c4-e4d8-4c4c-83c2-db19d71759cb","d140a193-7562-4758-b9e1-12a4b8980064","fb5e49f1-fd4e-46e8-90e5-215569718df5","9562a349-926d-4cd4-ae53-0f1e1fbd36e8","87254492-1714-49f4-81ac-7488398c98ff","17cafec1-6f1a-49f8-bc54-f642c6d95ed1","3728a789-3786-4d56-befb-44d9da225738","26d52685-d99a-4f16-ae40-f49980eb7b2c","ae7e1f3b-d0ba-4b32-b185-950b22f3c493","d3119037-c6c5-4206-a1aa-0d566d0df207","6c18040b-b889-497a-b0fa-82550d53b57b","3c81faf7-c91e-478a-91f9-c258869d7cad","53a65df8-f132-4d95-86b0-32bab9b1af32","7fe66893-110a-40a4-8cf1-c2c625da67ef","5b52e98f-2ed9-4092-a565-c493057d75c9","7e1aef8f-7522-4079-b85c-ff15af4e6832","4164f8ce-bc0f-4f24-a68e-da988946047e","aed758f3-ef70-4878-93c9-299515725546","426233dc-de0a-44bf-b59a-cfecb1a9dd6a","3c8db406-fb2f-48b5-a281-f629341b4da4","da37602d-393e-426d-9c65-a05244312975","e2c93ec3-c862-495c-9e6f-4771edb3b4f9","7a6399fe-6b12-4f75-8229-0dd08691d7c0","1439c03b-611e-4512-bedc-131e8415633a","8cc57942-8dac-4125-bdd8-e3a6a1b81355","35a1ce19-7923-446e-b33e-0a1427b33419","de1497c0-a4a6-4a0d-8272-69a1ae18874f","BadTag_Blink_Detect","Heading_H1_Multiple","Heading_H1_Missing","Aria_Label_TextContent_MisMatch","FormField_Name_Missing","Link_Name_Missing","Link_Img_Alt_Redundant","Img_Name_TooLong","Aria_DescribedBy_Invalid","Link_Href_Missing","Checkbox_GroupLabel_Missing","Heading_Sequence_Wrong","Form_LegendDescription_Missing","Img_Name_ShouldBe_Empty","Link_Name_Redundant","Html_AriaHidden_Tabable","Button_Name_Missing","Element_TabIndex_Positive","Aria_Landmarks_Complementary_Multiple","Aria_Landmarks_Main_Multiple","Img_Name_Redundant","Aria_Role_Menu_Invalid","FormField_Autocomplete_Missing","FormField_Hidden_Autocomplete","HtmlList_ChildElem_LI_Missing","Iframe_Name_Duplicate","Heading_Name_Empty"];
    AudioEye.smartRemediations = [];
AudioEye.autoSmartRemediations = [];

    AudioEye.a11yRulesFactories = [];



    /* Built Files */
    /* Serving build => prod */

    /**
 * ============================================================================
 * DO NOT MIGRATE THIS FILE TO TYPESCRIPT.
 *
 * `loader.js.php` reads this file from disk via PHP `require()` (search for
 * `ae_require_legacy.js` in loader.js.php) and inlines its contents into the
 * served bootstrap response. PHP looks up the file by literal `.js` filename;
 * renaming it to `.ts` causes a PHP fatal error at request time, breaking the
 * entire AudioEye bootstrap and all downstream scripts. webpack does not
 * bundle this file, so the TS toolchain wouldn't catch the breakage.
 *
 * If you need to update the loader path, update both this filename and
 * `loader.js.php:~403` together.
 * ============================================================================
 *
 * This is necessary as legacy support for some helpers and remediations that
 * depend on 'AudioEye.require()' calls to function.
 * That the time of writing, this library only needs to support the following
 * types of calls:
 *  AudioEye.require('lib/mutations'
    AudioEye.require(['ae_options']...
    AudioEye.require('lib/mutations'
    AudioEye.require(['ae_options']...
    AudioEye.require(["utilities"], function(util)...
    AudioEye.require(['utilities'], function(u) {
 */
(() => {
  if (!window.AudioEye) {
    return;
  }

  const log = (str) => {
    if (!window.console?.log) {
      return;
    }

    console.log(str);
  };

  // Stub the AudioEye.require function for old helpers and remediations
  // @param dependency {array|string}
  // @param callback {fn} - called if it is passed in
  // @returns {object} - returns dependency always
  window.AudioEye.require = (dependency, rawCallback) => {
    try {
      // stub with empty function if no callback passed
      const callback = typeof rawCallback === 'function' ? rawCallback : () => {};

      // Create an object to store dependencies in
      // These will be referenced later when a call to define defines them
      if (!AudioEye.require._definedDeps) {
        AudioEye.require._definedDeps = {};
      }

      // Create an object to store callback functions in
      // The callbacks will be called when define defines their requested
      // dependency.
      if (!AudioEye.require._callbacks) {
        AudioEye.require._callbacks = {};
      }

      // ensure dep is the string name of the dependency
      const dep = Array.isArray(dependency) ? dependency[0] : dependency;

      // The only known calls to this function look for the following
      // dependencies: 'ae_options', 'lib/mutations', and 'utilities'. All
      // other params will be rejected
      const possibleDeps = ['ae_options', 'lib/mutations', 'utilities'];
      if (!possibleDeps.includes(dep)) {
        throw new Error(`AudioEye.require was called with "${dep}", which is not supported.`);
      }

      switch (dep) {
        case 'ae_options': {
          callback(AudioEye.productConfig);
          return AudioEye.productConfig;
        }

        case 'lib/mutations':
        case 'utilities': {
          // the requested library is already defined, pass it to the callback
          // and return it as well.
          if (AudioEye.require._definedDeps[dep]) {
            callback(AudioEye.require._definedDeps[dep]);
            return AudioEye.require._definedDeps[dep];
          }

          // Set the callback for this dependency. The callback will be
          // called when the platform defines the requested library.
          if (!AudioEye.require._callbacks[dep]) {
            AudioEye.require._callbacks[dep] = [];
          }
          AudioEye.require._callbacks[dep].push(callback);
        }
        // no default
      }
    } catch (e) {
      log('Unable to satisfy call to AudioEye.require(). See next error for more info.');
      throw e;
    }
  };

  // Either set the factory to an object to be used later, or immediately pass
  // it to any awaiting callbacks.
  window.AudioEye.define = (dep, factory) => {
    if (!AudioEye.require._definedDeps) {
      AudioEye.require._definedDeps = {};
    }

    AudioEye.require._definedDeps[dep] = factory;

    // nothing has required anything yet
    if (!AudioEye.require._callbacks) {
      return;
    }

    // nothing has required this lib yet
    if (Array.isArray(AudioEye.require._callbacks[dep])) {
      // pass the factory to each callback
      AudioEye.require._callbacks[dep].forEach((cb) => {
        cb(factory);
      });

      // remove the callbacks to prevent duplicate calls
      AudioEye.require._callbacks[dep] = [];
    }
  };
})();

    loadStaticScript("startup.bundle.js");


    // Determine startup routine
    AudioEye.mode = (function () {

        var extension = false;
        if(!site_id && extension){
            return 'anonymous'
        }

        return 'standard';
    })();

    var loaderRunStartup = function(tries) {
        if (!AudioEye.runStartup) {
            var wait = 100;
            if (tries > 50) {
                wait = wait * tries;
            }
            setTimeout(function() {
                loaderRunStartup(++tries)
            }, wait);
            return;
        }

        AudioEye.runStartup(AudioEye.mode, {
            'portal_url': 'portal.audioeye.com',
            'interface': "<div id=\"ae_app\" data-nosnippet>\n        <!--\n        Layout, Style or Voice Helpers\n    -->\n    <div id=\"ae_helpers\" class=\"ae-module\" style=\"display: none;\">\n\n    \n    <\/div>\n    \n\n        <!--\n        Compliance\n    -->\n    <div id=\"ae_compliance\" class=\"ae-module\" style=\"display: none;\">\n\n        <!-- For autoSmartRem addNewWindowWarnings div is referenced in an aria-describedby -->\n        <div id=\"audioeye_new_window_message\" style=\"display:none\">Opens in new window<\/div>\n        <div id=\"audioeye_pdf_message\" style=\"display:none\">PDF Download<\/div>\n        <div id=\"audioeye_word_message\" style=\"display:none\">Word Download<\/div>\n        <div id=\"audioeye_excel_message\" style=\"display:none\">Excel Download<\/div>\n        <div id=\"audioeye_powerpoint_message\" style=\"display:none\">PowerPoint Download<\/div>\n        <div id=\"audioeye_document_message\" style=\"display:none\">Document Download<\/div>\n\n                    <\/div>\n    \n    <!--\n        Versioning Control Panel if versioning = true !\n    -->\n        \n    <!--\n        Launcher\n    -->\n    <span id=\"ae_placeholder_launcher\" style=\"display: none;\" aria-hidden=\"true\"><\/span>\n\n    <!-- Toolbar -->\n\n    <span id=\"ae_placeholder_toolbar\" style=\"display: none;\" aria-hidden=\"true\"><\/span>\n\n    <!--\n        Site Menu\n    -->\n    <span id=\"ae_placeholder_site-menu\" style=\"display: none;\" aria-hidden=\"true\"><\/span>\n\n    \n    <!--\n        Generic Aria Live message container\n    -->\n    <div class=\"ae-blurb-noaudio\" id=\"ae_enabled_messages\" aria-relevant=\"additions\" aria-live=\"assertive\"><\/div>\n\n    \n        <!-- Symbol definitions -->\n    <svg style=\"position: absolute; width: 0; height: 0; overflow: hidden;\" version=\"1.1\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\">\n        <defs>\n            <symbol id=\"icon-close-carousel\" viewBox=\"0 0 32 32\">\n                <path fill=\"#ffffff\" style=\"fill: var(--color1, #ffffff)\" d=\"M28.992 0l-12.992 12.992-12.992-12.992-3.008 3.008 12.992 12.992-12.992 12.992 3.008 3.008 12.992-12.992 12.992 12.992 3.008-3.008-12.992-12.992 12.992-12.992-3.008-3.008z\"><\/path>\n            <\/symbol>\n        <\/defs>\n    <\/svg>\n\n<\/div><!-- end #ae_app -->".replace(/__BROWSER_JS_VERSION__/g, window.__audioEyeContext.browserJsVersion),
            'container_id': "5719",
            'site_id': site_id,
            'version_id': null,
            'is_disable_ae': false,
            'is_working_version_request': false,
            'monitor': false,
            'live_monitor_endpoint_url': "https://analytics.audioeye.com/v1/report",

                        'perf_endpoint_url': '',
            'loader_timing_endpoint_url': "https:\/\/zalywzdew6.execute-api.us-west-2.amazonaws.com\/prod\/v0\/timing",
            'product_config': options,
            'device': device,
            'testmode': window.AEUnitTests,
            'site_hash': "f199ac50a6ee548596386803955219cc"        });
    };

    // Execute startup routine
    loaderRunStartup(1);
    
    window.AudioEye = Object.assign(window.AudioEye || {}, AudioEye);
};

loaderFunction(1);