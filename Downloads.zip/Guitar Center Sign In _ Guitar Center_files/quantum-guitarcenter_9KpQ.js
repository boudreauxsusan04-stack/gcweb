/* Copyright 2015-2026 Quantum Metric, Inc. All rights reserved. For US patents see https://www.quantummetric.com/legal/patents/. For EULA see https://www.quantummetric.com/legal/eula. t3 7902b822627e9a3c645a202cc0104326f7464202 */
(function() {
var setInterval = window['__zone_symbol__setInterval'] || window.setInterval;
var clearInterval = window['__zone_symbol__clearInterval'] || window.clearInterval;
var setTimeout = window['__zone_symbol__setTimeout'] || window.setTimeout;
var console = window['console'];
var clearTimeout = window['__zone_symbol__clearTimeout'] || window.clearTimeout;
var MutationObserver = window['__zone_symbol__MutationObserver'] || window.MutationObserver;
var queueMicrotask = window['__zone_symbol__queueMicrotask'] || window.queueMicrotask;
var Promise = window['__zone_symbol__Promise'] || window.Promise; var aa=typeof Object.defineProperties=="function"?Object.defineProperty:function(a,b,c){if(a==Array.prototype||a==Object.prototype)return a;a[b]=c.value;return a};function da(a){a=["object"==typeof globalThis&&globalThis,a,"object"==typeof window&&window,"object"==typeof self&&self,"object"==typeof global&&global];for(var b=0;b<a.length;++b){var c=a[b];if(c&&c.Math==Math)return c}throw Error("Cannot find global object");}var ea=da(this),fa="Int8 Uint8 Uint8Clamped Int16 Uint16 Int32 Uint32 Float32 Float64".split(" ");
ea.BigInt64Array&&(fa.push("BigInt64"),fa.push("BigUint64"));function ha(a,b){if(b)for(var c=0;c<fa.length;c++)ia(fa[c]+"Array.prototype."+a,b)}function ja(a,b){b&&ia(a,b)}function ia(a,b){var c=ea;a=a.split(".");for(var d=0;d<a.length-1;d++){var e=a[d];if(!(e in c))return;c=c[e]}a=a[a.length-1];d=c[a];b=b(d);b!=d&&b!=null&&aa(c,a,{configurable:!0,writable:!0,value:b})}ja("globalThis",function(a){return a||ea});
ja("String.prototype.matchAll",function(a){return a?a:function(b){if(b instanceof RegExp&&!b.global)throw new TypeError("RegExp passed into String.prototype.matchAll() must have global tag.");var c=new RegExp(b,b instanceof RegExp?void 0:"g"),d=this,e=!1,f={next:function(){if(e)return{value:void 0,done:!0};var g=c.exec(d);if(!g)return e=!0,{value:void 0,done:!0};g[0]===""&&(c.lastIndex+=1);return{value:g,done:!1}}};f[Symbol.iterator]=function(){return f};return f}});
ja("Object.fromEntries",function(a){return a?a:function(b){var c={};if(!(Symbol.iterator in b))throw new TypeError(""+b+" is not iterable");b=b[Symbol.iterator].call(b);for(var d=b.next();!d.done;d=b.next()){d=d.value;if(Object(d)!==d)throw new TypeError("iterable for fromEntries should yield objects");c[d[0]]=d[1]}return c}});
ja("String.prototype.replaceAll",function(a){return a?a:function(b,c){if(b instanceof RegExp&&!b.global)throw new TypeError("String.prototype.replaceAll called with a non-global RegExp argument.");return b instanceof RegExp?this.replace(b,c):this.replace(new RegExp(String(b).replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g,"\\$1").replace(/\x08/g,"\\x08"),"g"),c)}});
function ka(a,b,c){a instanceof String&&(a=String(a));for(var d=a.length-1;d>=0;d--){var e=a[d];if(b.call(c,e,d,a))return{nf:d,Ci:e}}return{nf:-1,Ci:void 0}}ja("Array.prototype.findLastIndex",function(a){return a?a:function(b,c){return ka(this,b,c).nf}});ha("findLastIndex",function(a){return a?a:function(b,c){return ka(this,b,c).nf}});function la(a){for(var b="",c=0;c<a.length;c++)b+=String.fromCharCode(a[c]);return b}var ma=la([83,72,65,45,50,53,54]),na=la([65,69,83,45,67,66,67]),oa=la([82,83,65,45,79,65,69,80]),pa=la([82,83,65,45,79,65,69,80,45,50,53,54]);
const qa={utm_source:-56,utm_medium:-57,utm_campaign:-58,utm_term:-59,utm_content:-60,utm_id:-61},ra=/cvv|cvc|month|year|birth|cid|csc|cvn|sensitive|security|ccnumber|card.*identification|verification|^aba$|^tin$|routing|ssn|itin|account.*number|acct.*num|card.*num|card.*#|card.*no|cc.*num|nummer|n.m.ro|credito|\u4fe1\u7528\u5361|\uce74\ub4dc|\u30ab\u30fc\u30c9\u756a|\u041d\u043e\u043c\u0435\u0440.*\u043a\u0430\u0440\u0442\u044b/i,sa=[{re:{p:"/b/ss/([^/]+)/(\\d+)/([^/]+)/.+",f:""},rep:"/b/ss/$1/$2/$3/{id}"},
{re:{p:"/akam/.+",f:""},rep:"/akam/{pixel}"},{re:{p:"(http[s]?://)[^\\.]+\\.safeframe\\.googlesyndication\\.com",f:""},rep:"$1REPLACED.safeframe.googlesyndication.com"}],ta=/zoom|toggle|prev|next|forward|backward|qty|down|up|right|left|arrow|plus|minus|increase|decrease|carousel|quantity|chevron/i,ua=()=>{},va=new Set("button fieldset optgroup option select textarea input".split(" ")),wa=new Set("onabort onautocomplete onautocompleteerror onblur oncancel oncanplay oncanplaythrough onchange onclick onclose oncontextmenu oncuechange ondblclick ondrag ondragend ondragenter ondragleave ondragover ondragstart ondrop ondurationchange onemptied onended onerror onfocus oninput oninvalid onkeydown onkeypress onkeyup onload onloadeddata onloadedmetadata onloadstart onmousedown onmouseenter onmouseleave onmousemove onmouseout onmouseover onmouseup onmousewheel onpause onplay onplaying onprogress onratechange onreset onresize onscroll onseeked onseeking onselect onshow onsort onstalled onsubmit onsuspend ontimeupdate ontoggle onvolumechange onwaiting onwheel".split(" ")),
y=Object.freeze({NONE:0,Ne:1,Se:2,Je:4,ERROR:8,Te:16,Hi:32,ud:64}),xa=Object.freeze({Kh:"config",Th:"sampling",gg:"api"});function ya(a,b,c,d){b&&c&&b!=c&&(d[b.toUpperCase()]&&d[c.toUpperCase()]?(a=d[c.toUpperCase()]/d[b.toUpperCase()]*a,a=B(a*100)/100):a="QM%20Conversion:%20"+b+"%20to%20"+c);return a}
function za(a){var b=RegExp("\\D","g"),c=RegExp("(?:([,.]?(?:[0-9]+[,.]?)+[0-9]*))([^_\\-0-9]|$)").exec(a);if(c&&!(c.length<2)&&(a=c[1],a.length>0&&a[a.length-1]=="."&&(a=a.substring(0,a.length-1)),c=!1,a.lastIndexOf(",")!=a.length-3&&a.lastIndexOf(".")!=a.length-3||a.length==2||(c=!0),a=a.replace(b,"")))return b=parseFloat(a),Math.floor(c?b:b*100)}function Aa(a,b){return a?Object.getOwnPropertyDescriptor(a,b)||Aa(Object.getPrototypeOf(a),b):null}
async function Ba(a){let b="";const c=window.TextDecoder&&new window.TextDecoder;try{const d=a.getReader();for(;;){const {value:e,done:f}=await d.read();if(f)break;a="";if(c)a=c.decode(e);else for(let g=0;g<e.length;g++)a+=String.fromCharCode(parseInt(e[g],10));b+=a}}catch(d){}return b}function E(a,b,c){return typeof b==="string"?b in a?a[b]:c:Array.isArray(b)&&typeof a!=="undefined"?b.length===0?a:a?E(a[b[0]],b.slice(1),c):c:c}
function Ca(a,b,c){try{if(typeof b=="string")return a[b]=c,!0;if(!Array.isArray(b))return console.warn("QM: cannot call `set` when path is not an array"),!1;let d=-1,{length:e}=b,f=e-1;for(;a!=null&&++d<e;){const g=b[d];let h=c;if(d!=f){const k=a[g];h=typeof k=="object"?k:isFinite(b[d+1])?[]:{}}a[g]=h;a=a[g]}return!0}catch(d){return!1}}
function Da(a,b){try{if(typeof b=="string")return delete a[b],!0;if(!Array.isArray(b))return console.warn("QM: cannot call `unset` when path is not an array"),!1;const c=b.pop(),d=E(a,b,null);if(!d)return!1;delete d[c];return!0}catch(c){return!1}}const Ea=()=>{let a=1;return()=>a++},Fa=(a,b=a.length)=>{const c=Array(b);for(let d=0;d<a.length&&d<b;++d)c[d]=a[d];return c};function B(a,b=0){return Number(`${Math.round(Number(`${a}e${b}`))}e-${b}`)}
const Ha=a=>a.reduce((b,c)=>{if(typeof c==="string")return b.global.add(c),b;b.selected.push(c);return b},{global:new window.Set,selected:[]}),Ia=()=>crypto.randomUUID().replace(/-/g,""),Ja=a=>Object.entries(a).reduce((b,c)=>{const d=c[0];c=c[1];d.startsWith("event:")?b.E.push(c):b[d]=c;return b},{E:[]}),Ka=a=>typeof a==="string"&&a!=="s"&&a!=="exp",La=a=>{if(!a||typeof a!=="object")return!1;for(const b in a)if(Ka(b))return!0},Ma=(a,b,c)=>{if(!a||typeof a!=="string")return a;b.forEach(d=>{c.Array.from(a.matchAll(d)).reverse().forEach(e=>
{e.indices.forEach((f,g,h)=>{f&&!g^h.length>1&&(a=a.slice(0,f[0])+"*****"+a.slice(f[1]))})})});return a},Pa=a=>a===null||a===void 0?"":a=a.toString().replace(/"|\r?\n|\r|\t|\\/g,"").replace(/[\u0000-\u001F]+/g,"").replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g,"").trim(),Qa=a=>a.split(/;\s*/).reduce((b,c)=>{const d=c.indexOf("="),e=c.slice(0,d).trim();c=c.slice(d+1).trim();e&&(b[e]=c);return b},{}),Ra=a=>{let b=0;for(;a.parentNode;)++b,a=a.parentNode,a.nodeType===11&&(a=a.host);return b},Sa=a=>{let b=
5381;for(const c of a)b=(b<<5)+b+c.codePointAt(0);return b>>>0};function Ta(a){if(typeof a==="string"&&a.length>0){try{return new URL(a)}catch(b){}try{return new URL(a,window.location.origin)}catch(b){}}throw Error(`Invalid URL: ${a}`);}
function Ua(a,b,c){if(c.protocol.startsWith("data:"))return c.toString();if(c.search!==""){for(var d="_";c.searchParams.has(d);)d+="_";c.searchParams.set(d,"");c.searchParams.delete(d)}if(a.size&&c.search!==""){d=c.searchParams;let e=new URLSearchParams;for(let [f,g]of d.entries())a.has(f.toLowerCase())&&(g="*****"),e.append(f,g);c.search=e.toString()}a=c.toString();for(c=0;c<b.length;++c)try{const e=b[c];a=a.replace(e[0],e[1])}catch(e){}return a};function Va(a){try{return typeof window.QuantumMetricOnNewPageTitle=="function"?window.QuantumMetricOnNewPageTitle(a):a}catch(b){}}
class Wa{constructor(a,b){const c=Ta(window.location.href);this.timestamp=a.g.Z.W();this.navigationType=b;this.Ja=c;this.M=Ua(a.D.aa.ac,a.D.aa.fc,c);a:{a=this.M;try{var d=typeof window.QuantumMetricOnNewPageUrl=="function"?window.QuantumMetricOnNewPageUrl(a):a;break a}catch(e){}d=void 0}this.qb=d;this.K=document.title;this.B=""}be(){this.K!==document.title?(this.K=document.title,this.B=Va(this.K)):this.B||(this.B=Va(this.K));return this.B}};const Xa=(a,b)=>{try{return new RegExp(a,b)}catch(c){}},I=a=>a.reduce((b,c)=>{const d=b.find(e=>e.f===c.f);if(!d)return b.push({...c}),b;d.p=d.p+"|"+c.p;return b},[]).flatMap(b=>Xa(b.p,b.f)||[]),J=(a,b)=>{for(let c=0;c<b.length;c++)if(b[c].test(a))return!0;return!1};function Ya(a,b=-1){a.M=b>=0?b:a.ca.now();return a.M}
class Za{constructor(a,b,c=null){this.J=a;this.ca=a.ta;this.origin=c;this.K=b;this.Xb=!1;this.B={};this.ea=this.duration=this.M=0;this.O=this.J.g.Z.W();this.qa=[1,16,4,2,8,64];this.B.t="s";this.B["@"]=["w"];let d,e;if((d=this.J.D)==null?0:(e=d.config)==null?0:e.mode)this.B.mode=this.J.D.config.mode;this.J.xi=window.screen?window.screen.width:void 0;this.J.wi=window.screen?window.screen.height:void 0;this.B.x=this.J.xi;this.B.y=this.J.wi;this.J.jc=window.innerWidth||document.documentElement.clientWidth||
document.body.clientWidth;this.J.Mb=window.innerHeight||document.documentElement.clientHeight||document.body.clientHeight;this.B.w=this.J.jc;this.B.h=this.J.Mb}Bd(){return this.qa.includes(this.K.navigationType)}Me(a){this.duration=a}Ld(){}lf(a){a&&(this.Xb=!0);this.B.re=this.J.Na;this.B.re===!1&&(this.B.rr=this.J.ui);this.B[")"]=this.J.rc>=5242880?"max-page-size-exceeded":this.J.Ub;this.B.s=this.J.rc;a=this.K.be();J(this.K.qb,this.J.D.aa.Vf)?this.B.pt=this.K.qb:this.B.pt=a;this.B.url=this.K.qb;this.B.ourl=
this.K.M;this.J.customElements.size&&(this.B.cea=this.J.g.G.Array.from(this.J.customElements));if(a=window.navigator.connection||window.navigator.mozConnection||window.navigator.webkitConnection)a.effectiveType&&(this.B.ce=a.effectiveType),a.downlink&&(this.B.cd=B(a.downlink)),a.rtt&&(this.B.cr=a.rtt);this.Le();this.B.z=this.J.je;this.J.frameId&&(this.B.QF=this.J.frameId);this.B.o=window.screen.orientation.angle;this.Bd()&&!this.Xb?(this.B.nt=this.K.navigationType,this.B.spa_d=this.duration?parseInt(this.duration,
10):null,a=this.ca.timeOrigin&&this.ca.getEntriesByType("navigation")[0]?this.J.g.Z.yb+this.M:this.O,this.B.pto=B(a),this.origin&&(this.B.r=this.origin.qb)):(this.B.nt=32,$a(this.J,this.B),this.B.n={type:cb(this.J,"type"),redirectCount:cb(this.J,"redirectCount")},document.referrer&&(a=Ua(this.J.D.aa.ac,this.J.D.aa.fc,Ta(document.referrer)),this.B.r=a,this.J.fa.set("lastUrl",Ta(a).toString())));this.J.Yc&&(this.B.ctx=this.J.Yc);this.B.vctx=this.J.Di;this.B.f=document.hasFocus();return this.B}sd(a){this.B.c=
a}Le(){this.B.els=this.ea}};function db(a){return a.B[a.Ua]}function eb(a){if(a.Ua>0){if(db(a))return!0;a.Ua=0}return!1}function fb(a){if(eb(a))return Ya(db(a));a.M=a.J.ta.now();return a.M}function gb(a){return hb(a,a.eb,a.K)}function hb(a,b,c){a.Ua=a.J.g.Z.W();b=new Za(a.J,b,c);b.Ld(a.ca);a.ca="";a.B[a.Ua]=b;a.M>=0&&(Ya(b,a.M),a.M=-1);return a.Ua}function ib(a){a.eb=new Wa(a.J,32);const b=hb(a,a.eb,a.K);a.get(b).Xb=!0;return b}
function jb(a,b){delete a.B[b];if(a.Ua===b){b=Object.keys(a.B);let c=Number.parseInt(b[0],void 0);if(b.length>1)for(let d=1;d<b.length;d++){let e=Number.parseInt(b[d],void 0);e>c&&(c=e)}a.Ua=c||0}}function kb(a){return a.K?a.K.Ja:null}function lb(a,b){a.K=a.eb;a.eb=b;return gb(a)}
function mb(a,b){const c=a.eb,d=b.Ja.pathname===c.Ja.pathname&&b.Ja.search===c.Ja.search&&b.Ja.hash!==c.Ja.hash;if(b.navigationType===4&&d||J(b.Ja.href,a.J.D.aa.Bi)||b.navigationType===16&&!a.J.D.config.monitorAllHashChanges)return!1;a=c.Ja.origin===b.Ja.origin&&c.Ja.pathname===b.Ja.pathname&&c.Ja.search===b.Ja.search&&c.Ja.hash===b.Ja.hash;return b.navigationType===1||!a&&c.qb!==b.qb?!0:!1}
class nb{constructor(a){this.J=a;this.eb=new Wa(a,32);this.K=null;this.B={};this.Ua=0;this.ca="";this.M=-1;this.ea=!1}Bd(a){return eb(this)?(a=this.get(a))?a.Bd():!1:!1}Xb(a){return this.get(a)?this.get(a).Xb:!1}get(a){return this.B[a]}Ld(a){eb(this)?db(this).Ld(a):this.ca=a}Me(a){eb(this)&&db(this).Me(a)}Le(a){eb(this)&&(db(this).ea=a)}sd(a,b){this.get(a).sd(b)}lf(a){var b=this.B[a];jb(this,a);a=b.lf(!this.ea);this.ea=!0;b=this.J.g.Z.W()-1E4;for(let d of Object.keys(this.B))if(d<=b){delete this.B[d];
var c=Number.parseInt(d,void 0);this.Ua===c&&(this.Ua=0)}return a}be(){return this.eb.be()}};const ob=Ea();function pb(a,b){return function(...c){try{b.ma.get(this)||sb(b,this)}catch(d){}return a.apply(this,c)}}function sb(a,b){var c=b.effect.target;const d=b.effect.getKeyframes(),e=b.effect.getTiming(),f=ob();c=c?a.$.da(c):null;a.ma.set(b,f);b.effect&&a.ma.set(b.effect,f);a.log({t:"wa",v:"c",I:c,i:f,a:[d,e]});tb(a,b,f)}
function ub(a){const b=Object.getOwnPropertyDescriptor(Element.prototype,"animate"),c=Object.getOwnPropertyDescriptor(Animation.prototype,"play"),d=Object.getOwnPropertyDescriptor(Animation.prototype,"pause"),e=Object.getOwnPropertyDescriptor(Animation.prototype,"reverse"),f=Object.getOwnPropertyDescriptor(Animation.prototype,"cancel"),g=Object.getOwnPropertyDescriptor(Animation.prototype,"finish"),h=Object.getOwnPropertyDescriptor(Animation.prototype,"updatePlaybackRate"),k=Object.getOwnPropertyDescriptor(Animation.prototype,
"currentTime"),l=Object.getOwnPropertyDescriptor(Animation.prototype,"effect"),m=Object.getOwnPropertyDescriptor(Animation.prototype,"startTime"),n=Object.getOwnPropertyDescriptor(Animation.prototype,"playbackRate"),x=Object.getOwnPropertyDescriptor(window,"Animation"),r=Object.getOwnPropertyDescriptor(KeyframeEffect.prototype,"setKeyframes"),q=Object.getOwnPropertyDescriptor(KeyframeEffect.prototype,"target"),w=Object.getOwnPropertyDescriptor(KeyframeEffect.prototype,"composite"),D=Object.getOwnPropertyDescriptor(KeyframeEffect.prototype,
"pseudoElement"),C=Object.getOwnPropertyDescriptor(window.AnimationEffect.prototype,"updateTiming");if(b&&b.configurable){const t=b.value;function p(...u){const z=t.apply(this,u);try{const A=ob(),W=a.$.da(this);a.ma.set(z,A);a.ma.set(z.effect,A);a.log({t:"wa",v:"c",I:W,i:A,a:u})}catch(A){}return z}if(a.J.D.config.temp.preserveNativeAnimationToString)try{const u=t.toString();Object.defineProperty(p,"toString",{value:function(){return u},writable:!0,configurable:!0})}catch(u){}Object.defineProperty(Element.prototype,
"animate",{...b,value:p})}if(c&&c.configurable){const t=c.value;Object.defineProperty(Animation.prototype,"play",{...c,value:pb(function(...p){p=t.apply(this,p);try{const u=a.ma.get(this);if(!u)return p;a.log({t:"wa",v:"p",i:u})}catch(u){}return p},a)})}if(d&&d.configurable){const t=d.value;Object.defineProperty(Animation.prototype,"pause",{...d,value:pb(function(...p){p=t.apply(this,p);try{const u=a.ma.get(this);if(!u)return p;a.log({t:"wa",v:"s",i:u})}catch(u){}return p},a)})}if(e&&e.configurable){const t=
e.value;Object.defineProperty(Animation.prototype,"reverse",{...e,value:pb(function(...p){p=t.apply(this,p);try{const u=a.ma.get(this);if(!u)return p;a.log({t:"wa",v:"r",i:u})}catch(u){}return p},a)})}if(f&&f.configurable){const t=f.value;Object.defineProperty(Animation.prototype,"cancel",{...f,value:pb(function(...p){p=t.apply(this,p);try{const u=a.ma.get(this);if(!u)return p;a.log({t:"wa",v:"x",i:u})}catch(u){}return p},a)})}if(g&&g.configurable){const t=g.value;Object.defineProperty(Animation.prototype,
"finish",{...g,value:pb(function(...p){p=t.apply(this,p);try{const u=a.ma.get(this);if(!u)return p;a.log({t:"wa",v:"f",i:u})}catch(u){}return p},a)})}if(h&&h.writable){const t=h.value;Object.defineProperty(Animation.prototype,"updatePlaybackRate",{...h,value:pb(function(p,...u){const z=this.currentTime;u=t.call(this,p,...u);try{const A=a.ma.get(this);if(!A)return u;const W=this.currentTime;a.log({t:"wa",v:"a",i:A,p:"playbackRate",n:p});z!==W&&a.log({t:"wa",v:"a",i:A,p:"currentTime",n:W});this.playState!==
"running"&&a.log({t:"wa",v:"s",i:A});this.playState==="running"&&a.log({t:"wa",v:"p",i:A})}catch(A){}return u},a)})}if(k&&k.configurable){const t=k.set;Object.defineProperty(Animation.prototype,"currentTime",{...k,set:pb(function(p){const u=t.call(this,p);try{const z=a.ma.get(this);if(!z)return u;a.log({t:"wa",v:"a",i:z,p:"currentTime",n:p})}catch(z){}return u},a)})}if(l&&l.configurable){const t=l.set;Object.defineProperty(Animation.prototype,"effect",{...l,set:pb(function(p){const u=this.effect,
z=t.call(this,p);try{const A=a.ma.get(this);if(!A)return z;a.ma.set(p,A);a.ma.delete(u);const W=p.target?a.$.da(p.target):null,F=[p.getKeyframes(),p.getTiming()];a.log({t:"wa",v:"e",i:A,I:W,a:F});this.effect.pseudoElement&&a.log({t:"wa",v:":",i:A,n:this.effect.pseudoElement})}catch(A){}return z},a)})}if(m&&m.configurable){const t=m.set;Object.defineProperty(Animation.prototype,"startTime",{...m,set:pb(function(p){p=t.call(this,p);try{const u=a.ma.get(this);if(!u)return p;a.log({t:"wa",v:"a",i:u,p:"currentTime",
n:this.currentTime})}catch(u){}return p},a)})}if(n&&n.configurable){const t=n.set;Object.defineProperty(Animation.prototype,"playbackRate",{...n,set:pb(function(p){const u=t.call(this,p);try{const z=a.ma.get(this);if(!z)return u;a.log({t:"wa",v:"a",i:z,p:"playbackRate",n:p})}catch(z){}return u},a)})}if(x&&x.configurable){const t=window.Animation;Object.defineProperty(window,"Animation",{...x,value:function(...p){p=new t(...p);try{const u=ob(),z=p.effect&&p.effect.target?a.$.da(p.effect.target):"",
A=p.effect?[p.effect.getKeyframes(),p.effect.getTiming()]:[];a.ma.set(p,u);p.effect&&a.ma.set(p.effect,u);a.log({t:"wa",v:"c",I:z,i:u,a:A,p:"c"});p.effect&&p.effect.pseudoElement&&a.log({t:"wa",v:":",i:u,n:p.effect.pseudoElement})}catch(u){}return p}})}if(r&&r.configurable){const t=r.value;Object.defineProperty(KeyframeEffect.prototype,"setKeyframes",{...r,value:function(...p){const u=t.apply(this,p);try{const z=a.ma.get(this);if(!z)return u;a.log({t:"wa",v:"k",i:z,a:p})}catch(z){}return u}})}if(q&&
q.configurable){const t=q.set;Object.defineProperty(KeyframeEffect.prototype,"target",{...q,set:function(p){const u=t.call(this,p);try{const z=a.ma.get(this);if(!z)return u;const A=p?a.$.da(p):null;a.log({t:"wa",v:"@",i:z,I:A})}catch(z){}return u}})}if(w&&w.configurable){const t=w.set;Object.defineProperty(KeyframeEffect.prototype,"composite",{...w,set:function(p){const u=t.call(this,p);try{const z=a.ma.get(this);if(!z)return u;a.log({t:"wa",v:"=",i:z,n:p})}catch(z){}return u}})}if(D&&D.configurable){const t=
D.set;Object.defineProperty(KeyframeEffect.prototype,"pseudoElement",{...D,set:function(p){const u=t.call(this,p);try{const z=a.ma.get(this);if(!z)return u;a.log({t:"wa",v:":",i:z,n:p})}catch(z){}return u}})}if(C&&C.configurable){const t=C.value;Object.defineProperty(window.AnimationEffect.prototype,"updateTiming",{...C,value:function(...p){const u=t.apply(this,p);try{const z=a.ma.get(this);a.log({t:"wa",v:"u",i:z,a:p})}catch(z){}return u}})}}
function tb(a,b,c){const d=b.playbackRate,e=b.playState;a.log({t:"wa",v:"a",i:c,p:"currentTime",n:b.currentTime});d!==1&&a.log({t:"wa",v:"a",i:c,p:"playbackRate",n:d});e==="paused"&&a.log({t:"wa",v:"s",i:c})}class vb{constructor(a,b,c){this.J=a;this.$=c;this.ma=new b.WeakMap}log(a){K(this.J,a)}};function wb(a,b){return typeof a.reportURL==="string"&&a.reportURL.length>0?a.reportURL:a.ingestBaseURL+"/horizon/"+b}function xb(a){return typeof a.hashResourceURL==="string"&&a.hashResourceURL.length>0?a.hashResourceURL:typeof a.ingestBaseURL==="string"&&a.ingestBaseURL.length>0?a.ingestBaseURL+"/resource-loader":""};class yb{constructor(){this.reject=this.resolve=null;this.promise=new Promise((a,b)=>{this.resolve=a;this.reject=b})}};const zb=/content:\s+"?(.+?)"?;/,Ab=/[^\u0000-\u00ff]/,Cb=(a,b,c=0)=>{if(c>10)return[];let d=[];try{if(!b.cache.has(a)||b.cache.get(a).length!==a.cssRules.length){const e=a.cssRules;for(let f=0;f<e.length;++f){const g=e[f],h=b.fi(g).replace(zb,Bb);if(g instanceof window.CSSImportRule){let k=[];try{g.styleSheet&&g.styleSheet.cssRules&&(k=Cb(g.styleSheet,b,c+1))}catch(l){k=[h]}d=d.concat(k)}else d.push(h)}b.cache.set(a,d)}}catch(e){b.cache.set(a,[])}return b.cache.get(a)},Bb=(a,b)=>Ab.test(b)?`content: "\\${b.charCodeAt(0).toString(16)}";`:
a;const Db=a=>a.cssText,Eb=a=>{var b=a.cssText;if(a instanceof window.CSSStyleRule&&(b.includes("grid-template:")&&a.style.gridTemplateAreas||a.style.all)){b=a.selectorText;a=a.style;var c="";for(let d=0;d<a.length;++d){const e=a[d],f=a.getPropertyValue(e),g=a.getPropertyPriority(e);c+=`${e}:${f}${g?" !important":""};`}return`${b} { ${c} }`}if(a instanceof window.CSSMediaRule&&b.includes("grid-template:")){b="";for(c=0;c<a.cssRules.length;c++)b+=Eb(a.cssRules[c]);return`@media ${a.conditionText} { ${b} }`}if(a instanceof
window.CSSSupportsRule&&b.includes("grid-template:")){b="";for(c=0;c<a.cssRules.length;c++)b+=Eb(a.cssRules[c]);return`@supports ${a.conditionText} { ${b} }`}if(window.CSSLayerBlockRule&&a instanceof window.CSSLayerBlockRule&&b.includes("grid-template:")){b="";for(c=0;c<a.cssRules.length;c++)b+=Eb(a.cssRules[c]);return`@layer ${a.name} { ${b} }`}return b},Fb=a=>Eb(a),Gb=a=>Eb(a),Hb=a=>Eb(a).replace(/(?<=\[[^=\]"]*)(?<!\\)(:)/g,"\\:");function Ib(a,b){const c=a.L.D.config;return typeof c.hashResourceURL==="string"&&c.hashResourceURL.length>0?`${c.hashResourceURL}/${b}`:`${xb(c)}/${b}/${a.L.sub}`}async function Jb(a,b){b=(new TextEncoder).encode(b);const {readable:c,writable:d}=new window.CompressionStream("deflate"),e=d.getWriter();e.write(b);e.close();return new Uint8Array(await (new a.L.g.G.wa.contentWindow.Response(c)).arrayBuffer())}
async function Kb(a,b,c){const d={"Content-Type":"application/json"};let e=c;if(a.L.D.config.enableCompression&&"CompressionStream"in window&&"TextEncoder"in window)try{e=await Jb(a,c),d["Content-Encoding"]="deflate"}catch(f){}return a.L.g.G.wa.contentWindow.fetch(Ib(a,b),{method:"POST",headers:d,body:e,credentials:"omit"}).catch(f=>{L(a.L.ba,"rl-failure",{msg:f.message},"error")})}function Lb(a,b,c){c=c.map(d=>({hash:d,data:b[d],contentType:"text/css"}));Kb(a,"hashes",a.L.g.G.stringify(c))}
function Mb(a,b){const c=Object.keys(b);c.length!==0&&Kb(a,"hash-check",a.L.g.G.stringify(c)).then(async function(d){if(d.status==200&&(d=await d.json(),d.length))return Lb(a,b,d)})}function Nb(a,b,c){a.K[b]=c;a.B||(a.B=setTimeout(async()=>{try{const d={...a.K};a.K=Object.create(null);Mb(a,d)}catch(d){}finally{a.B=null}},a.L.D.config.resourceUploadDelay))}class Ob{constructor(a){this.K=Object.create(null);this.B=null;this.L=a}};const Pb=a=>new Promise(b=>{function c(l){e||(e=!0,clearTimeout(f),f=null,a.removeEventListener("load",h,!1),a.removeEventListener("error",k,!1),b(l))}function d(){if(a.sheet)return c("polling");g++;g<10?f=setTimeout(d,500):c(!1)}let e=!1,f,g=0;const h=()=>{c(a.sheet?"node.addEventListener":!1)},k=()=>c(!1);a.addEventListener("load",h,!1);a.addEventListener("error",k,!1);f=setTimeout(d,500)});const Qb=/\//g,Rb=Ea();function Sb(a){a.L.fb.lb==="Safari"&&parseInt(a.L.fb.version,10)<17?a.B=Hb:a.L.fb.lb==="Safari"&&(a.B=Gb);a.L.fb.lb==="Chrome"&&(a.B=Fb)}async function Tb(a){return(await Ub(a)).replace(Qb,"~")}
async function Vb(a,b){const c=a.register(b);let d=c.Md;d||b.ownerNode||(d=c.Md=Rb());b.ownerNode&&a.register(b.ownerNode,c);var e=Cb(b,{fi:a.B,cache:a.M});if(!e.length)return{v:"",i:d};e=e.join("");if(!xb(a.L.D.config)||a.L.D.aa.Pg&&b.ownerNode&&a.L.g.ia.matchesSelector(b.ownerNode,a.L.D.aa.Pg))return c.yi=e,{v:e,i:d};c.hash=await Tb(e);(b.ownerNode?a.L.D.aa.md||a.L.D.aa.ae&&a.L.g.ia.matchesSelector(b.ownerNode,a.L.D.aa.ae):a.L.D.aa.md)&&Nb(a.ca,c.hash,e);return{h:c.hash,i:d}}
async function Wb(a,b){const c=a.L.g.G.contentWindow.document,d=c.adoptNode(b.cloneNode(!0));d.setAttribute("crossorigin","anonymous");d.removeAttribute("onload");d.addEventListener("error",()=>{a.L.xa("CORS_LINK",encodeURIComponent(b.href))});c.head.appendChild(d);if(!await Pb(d))return{v:""};const e=await Vb(a,d.sheet);c.head.removeChild(d);return e}async function Xb(a,b){if(await Pb(b)){var c=await Yb(a,b);a=a.L;c={t:"SDR",S:c};c.I=a.$.B(b).da;c.I&&K(a,c)}}
async function Yb(a,b){if(a.L.D.aa.fe&&a.L.g.ia.matchesSelector(b,a.L.D.aa.fe))return{v:""};if(!b.sheet)return Xb(a,b),{v:""};try{var c=!b.sheet.cssRules}catch(d){c=!0}return c?Wb(a,b):Vb(a,b.sheet)}function Zb(a,b){const c=a.register(b);c.Wd||(c.Wd=new yb,a.K.push(b));return c.Wd.promise}
function $b(a){const b=a.K;a.K=[];const c=[];b.forEach(d=>{const e=a.ma.get(d).Wd;c.push(e.promise);a.bb(d).then(e.resolve).catch(f=>{K(a.L,{t:"dbg",msg:"CSS serialization failed, stylesheet skipped",err:f&&f.message||String(f)});e.resolve({v:""})})});return Promise.all(c)}
class ac{constructor(a){this.L=a;this.ma=new this.L.g.G.WeakMap;this.K=[];this.M=new this.L.g.G.WeakMap;this.B=Db;this.ca=new Ob(a)}register(a,b={}){this.ma.has(a)||this.ma.set(a,b);return this.ma.get(a)}unregister(a){this.M.delete(a);delete this.register(a).Wd;a.ownerNode&&this.unregister(a.ownerNode)}bb(a){return this.is(a,"CSSStyleSheet")?Vb(this,a):this.is(a,"HTMLLinkElement")?Yb(this,a):Promise.resolve({v:""})}is(a,b){const c=(a.ownerNode?a.ownerNode.ownerDocument:a.ownerDocument||document).defaultView,
d=this.L.g.G.pd(a);return c&&a instanceof c[b]||d===`[object ${b}]`}};function bc(a,b){try{const c=a({test:[{age:100,old:!0,s:'[id="t"]'}]});return c!='{"test":[{"age":100,"old":true,"s":"[id=\\"t\\"]"}]}'?!1:b(c).test[0].age==100?!0:!1}catch(c){return!1}}
const cc=(a,b)=>Array.isArray(b)||b===null||b===void 0||typeof b==="number"||typeof b==="string"||typeof b==="boolean"?b:Object.fromEntries(Object.keys(b).sort().map(c=>[c,cc(c,b[c])])),dc=a=>{if(a===null||a===void 0)return!0;a=typeof a;return a==="boolean"||a==="number"||a==="string"},ec=a=>a.replace(/~1/g,"/").replace(/~0/g,"~"),M=Symbol(),fc=(a,b,c)=>{if(b.length===0&&c(a))return a;if(a===null||typeof a!=="object")return M;if(b.length===0)for(var d in a){var e=fc(a[d],b,c);if(e!==M)return e}const [f,
...g]=b;for(const k in a){if(k!==f){d=fc(a[k],b,c);if(d===M)continue;return d}a:{var h=a[k];d=g;e=c;if(d.length===0&&!e(h)){d=M;break a}if(d.length===0){d=h;break a}for(const l of d){if(typeof h!=="object"||h===null||!(l in h)){d=M;break a}h=h[l]}d=e(h)?h:M}if(d===M){d=fc(a[k],b,c);if(d===M)continue;return d}return d}return M};function hc(a){const b={HTMLElement:null,Element:null,Node:null,Document:null,DocumentFragment:null,ShadowRoot:null,MutationObserver:null,JSON:null,XMLHttpRequest:null,EventTarget:null,Event:null,Window:null,Date:null,Array:null,WeakMap:null,Set:null},c=a.wa.contentWindow;for(var d of Object.keys(b))b[d]=c[d];const e=(Object.getOwnPropertyDescriptor(b.Element.prototype,"innerHTML")||{}).get;a.innerHTML=v=>e.call(v);const f=(Object.getOwnPropertyDescriptor(b.HTMLElement.prototype,"innerText")||{}).get;
a.innerText=v=>f.call(v);const g=(Object.getOwnPropertyDescriptor(b.Element.prototype,"children")||Object.getOwnPropertyDescriptor(b.HTMLElement.prototype,"children")||{}).get;a.children=v=>{try{return g.call(v)}catch(H){}};const h=(Object.getOwnPropertyDescriptor(b.Element.prototype,"shadowRoot")||{}).get||function(){return null};a.shadowRoot=v=>h.call(v);const k=(Object.getOwnPropertyDescriptor(b.Document.prototype,"adoptedStyleSheets")||{}).get;if(k)if(b.ShadowRoot){const v=(Object.getOwnPropertyDescriptor(b.ShadowRoot.prototype,
"adoptedStyleSheets")||{}).get;a.adoptedStyleSheets=H=>{if(ic(a,H))return v.call(H);if(H.nodeType===9)return k.call(H)}}else a.adoptedStyleSheets=v=>{if(v.nodeType===9)return k.call(v)};const l=b.Element.prototype.matches;a.matches=(v,H)=>H&&H.length>0?l.call(v,H):!1;const m=b.Element.prototype.querySelector,n=b.Document.prototype.querySelector,x=b.DocumentFragment.prototype.querySelector;a.ea=(v,H)=>H?v.nodeType===9?n.call(v,H):v.nodeType===11?x.call(v,H):m.call(v,H):null;const r=b.Element.prototype.querySelectorAll,
q=b.Document.prototype.querySelectorAll,w=b.DocumentFragment.prototype.querySelectorAll;a.pb=(v,H)=>H?v.nodeType===9?q.call(v,H):v.nodeType===11?w.call(v,H):r.call(v,H):q.call(document,null);const D=b.Document.prototype.createNodeIterator;a.O=(v,H,Ga,Na)=>{D.call(v,H,Ga,Na)};const C=(Object.getOwnPropertyDescriptor(b.Node.prototype,"isConnected")||{}).get;C&&(a.isConnected=v=>C.call(v));const t=(Object.getOwnPropertyDescriptor(b.Node.prototype,"parentNode")||{}).get;a.parentNode=v=>t.call(v);const p=
(Object.getOwnPropertyDescriptor(b.Node.prototype,"parentElement")||Object.getOwnPropertyDescriptor(b.HTMLElement.prototype,"parentElement")||{}).get;a.parentElement=v=>p.call(v);const u=(Object.getOwnPropertyDescriptor(b.Node.prototype,"childNodes")||{}).get;a.childNodes=v=>u.call(v);Object.getOwnPropertyDescriptor(b.Node.prototype,"firstChild");Object.getOwnPropertyDescriptor(b.Node.prototype,"lastChild");const z=(Object.getOwnPropertyDescriptor(b.Node.prototype,"textContent")||{}).get;a.textContent=
v=>z.call(v);const A=b.Node.prototype.appendChild;a.appendChild=(v,H)=>A.call(v,H);const W=(Object.getOwnPropertyDescriptor(b.Node.prototype,"nextSibling")||{}).get;a.nextSibling=v=>W.call(v);Object.getOwnPropertyDescriptor(b.Node.prototype,"previousSibling");const F=(Object.getOwnPropertyDescriptor(b.Node.prototype,"nodeName")||{}).get;a.nodeName=v=>F.call(v);const R=b.Element.prototype.contains||b.HTMLElement.prototype.contains;a.contains=(v,H)=>R.call(v,H);const ba=b.Node.prototype.getRootNode;
a.getRootNode=v=>ba.call(v);a.MutationObserver=b.MutationObserver;if(b.EventTarget){const v=b.EventTarget.prototype.addEventListener;a.addEventListener=(H,Ga,Na,qb,rb)=>{try{return v.call(H,Ga,Na,qb,rb)}catch(wc){return H.addEventListener(Ga,Na,qb,rb)}}}else{const v=b.Window.prototype.addEventListener,H=b.Node.prototype.addEventListener;a.addEventListener=(Ga,Na,qb,rb,wc)=>Ga instanceof Window?v.call(Ga,Na,qb,rb,wc):H.call(Ga,Na,qb,rb,wc)}const G=(Object.getOwnPropertyDescriptor(b.Event.prototype,
"target")||{}).get;a.K=v=>G.call(v);const ca=(Object.getOwnPropertyDescriptor(b.Event.prototype,"composed")||{}).get;a.qa=v=>ca.call(v);const S=b.Event.prototype.composedPath;a.la=v=>S.call(v);const X=(Object.getOwnPropertyDescriptor(b.Element.prototype,"tagName")||{}).get;a.tagName=v=>v&&v.nodeType===1?(v=X.call(v),typeof v=="string"?v:""):"";const N=Object.getOwnPropertyDescriptor(c,"parent").get;N&&(a.M=v=>N.call(v));const ab=c.Object.prototype.toString;a.pd=v=>ab.call(v);const bb=Object.getOwnPropertyDescriptor(c.Document.prototype,
"cookie");a.ra.set=v=>bb.set.call(document,v);a.ra.get=()=>bb.get.call(document);jc(a);a.createElement=v=>c.document.createElement(v);const Oa=Object.getOwnPropertyDescriptor(b.Document.prototype,"readyState");Oa&&typeof Oa.get==="function"&&(a.readyState=v=>Oa.get.call(v));if(d=c.Date.now)a.W=d;a.Array=b.Array;a.Date=b.Date;a.Set=b.Set}
function kc(a){a.Va=new window.MutationObserver(function(b){if(!b.every(d=>d.removedNodes.length===0)&&(b=!1,a.isConnected(a.B)||(document.documentElement.appendChild(a.B),b=!0),a.isConnected(a.wa)||(a.B.appendChild(a.wa),b=!0),b)){hc(a);lc(a);a.ua.La("clean-iframe-re-attached");var c=a.Array.from(a.ca.values());b=a.W();a.ca.clear();for(const {gi:d,ms:e,Sa:f,bi:g}of c){c=Math.max(0,e-(b-g));try{a.setTimeout(d,c,...f)}catch(h){}}}});a.Va.observe(document.documentElement,{childList:!0});a.Va.observe(a.B,
{childList:!0,subtree:!0})}function jc(a){a.Storage.setItem=a.wa.contentWindow.Storage.prototype.setItem;a.Storage.getItem=a.wa.contentWindow.Storage.prototype.getItem;a.Storage.removeItem=a.wa.contentWindow.Storage.prototype.removeItem}function mc(a){const b=a.wa.contentWindow,c=a.stringify=b.JSON.stringify,d=a.Ra=b.JSON.parse,e=b.structuredClone||(f=>f);bc(c,d)||(a.stringify=f=>c(e(f)))}
function lc(a){a.wa.contentWindow!==window&&(a.setTimeout=(b,c,...d)=>{const e=()=>{a.ca.delete(f);b.apply(window,d)},f=a.contentWindow.setTimeout(e,c);a.ca.set(f,{Pi:e,gi:b,ms:c,Sa:d,bi:a.W()});return f},a.clearTimeout=b=>{a.contentWindow.clearTimeout(b);a.ca.delete(b)})}
function nc(a){a.wa=document.createElement("iframe");a.wa.style.display="none";a.B.appendChild(a.wa);try{a.wa.contentWindow.scroll(0,0)}catch(b){Object.defineProperties(a.wa,{contentWindow:{value:window},contentDocument:{value:document}}),a.wa.setAttribute("data-qm-cross-origin","")}}
function oc(a){try{const b=a.wa.contentWindow;if(b&&b.MutationObserver===a.MutationObserver)return b}catch(b){}a.wa&&a.wa.parentNode&&a.wa.parentNode.removeChild(a.wa);nc(a);hc(a);mc(a);a.ua.La("clean-iframe-re-attached");return a.wa.contentWindow}function ic(a,b){return window.ShadowRoot?a.pd(b).indexOf("ShadowRoot")>-1:!1}
class pc{constructor(a){this.Set=this.Date=this.Array=this.MutationObserver=this.Ra=this.stringify=this.wa=this.Va=this.B=null;this.Storage={setItem:null,getItem:null,removeItem:null};this.ra={set:null,get:null};this.ua=a;this.ca=new Map;this.setTimeout=setTimeout.bind(globalThis);this.clearTimeout=clearTimeout.bind(globalThis);this.B=document.createElement("b");this.B.style.position="absolute";this.B.style.left="-1000px";this.B.tabIndex=-1;this.B.ariaHidden="true";document.documentElement.appendChild(this.B);
nc(this);hc(this);kc(this);jc(this);mc(this);lc(this)}get contentWindow(){return oc(this)}get WeakMap(){return this.contentWindow.WeakMap}innerHTML(a){return a.innerHTML}innerText(a){return a.innerText}children(a){return a.children}shadowRoot(a){return a.shadowRoot}adoptedStyleSheets(a){return a.adoptedStyleSheets}ea(a,b){return a.querySelector(b)}pb(a,b){return a.querySelectorAll(b)}O(a,b,c,d){a.createNodeIterator(b,c,d)}isConnected(a){var b=a.isConnected;b===void 0&&(b=document,b=b===null?!this.contains(document.documentElement,
a):this.contains(b.documentElement||b,a));return b}parentNode(a){return a.parentNode}parentElement(a){return a.parentElement}childNodes(a){return a.childNodes}textContent(a){return a.textContent}appendChild(a,b){return a.appendChild(b)}matches(a,b){return b&&b.length>0&&a.matches?a.matches(b):!1}nextSibling(a){return a.nextSibling}contains(a,b){return a.contains(b)}getRootNode(a){return a.getRootNode()}addEventListener(a,b,c,d,e){return a.addEventListener(b,c,d,e)}pd(a){return Object.prototype.toString.call(a)}K(a){return a.target}qa(a){return a.composed}la(a){return a.composedPath()}tagName(a){return a.tagName}nodeName(a){return a.nodeName}M(a){return a.parent}createElement(a){return window.document.createElement(a)}readyState(a){return a.readyState}W(){return Date.now()}}
;/*

 Compile predicate definitions into functions

 @param {*} predicate
 @returns
 @suppress {missingProperties}
 @suppress {missingProperties} */
const rc=a=>{const {operator:b}=a;if(b==="and")return qc(a.contents.map(rc));if(b==="or")return sc(a.contents.map(rc));if(b==="not")return tc(rc(a.contents));if(b==="contains")return uc(a);if(b==="equals")return vc(a);if(b==="starts_with")return xc(a);if(b==="ends_with")return yc(a);if(b==="regex")return zc(a);if(b==="default")return Ac();throw Error(`Unrecognized operator "${b}"`);},qc=a=>b=>a.every(c=>c(b)),sc=a=>b=>a.some(c=>c(b)),tc=a=>b=>!a(b),uc=a=>b=>b[a.facet].includes(a.value),vc=a=>b=>b[a.facet]===
a.value,xc=a=>b=>b[a.facet].startsWith(a.value),yc=a=>b=>b[a.facet].endsWith(a.value),zc=a=>{const b=new RegExp(a.value);return c=>b.test(c[a.facet])},Ac=()=>()=>!0;const Bc=a=>a[a.length-1],Cc=a=>"value"in a?{pred:rc(a.pred),value:a.value}:{pred:rc(a.pred),rules:a.rules.map(Cc)},Dc=(a,b)=>"value"in a?a.value:a.rules.reduce((c,d)=>d.pred(b)?c.concat(d.value):c,[]);function Ec(a){var b={url:window.location.href};const c={};for(const d in a.B){const e=a.B[d].find(f=>f.pred(b))||Bc(a.B[d]);c[d]=Dc(e,b)}return c}
class Fc{constructor(a,b,c,d,e,f,g="",h){this.K=a;this.M=b;this.ea=c;this.aa=d;this.O=e;this.ca=f;this.sub=g||"";this.G=h;this.fa=null;this.config={};b={};for(const k in a)a=k,b[a]=this.K[a].map(Cc);this.B=b}sc(){this.config=this.O({...this.M,...Ec(this),...this.ea},this.sub);this.ca(this.config,this.aa,this.fa,this.G)}};function Gc(a){a.B=Hc(a).then(b=>{b.Wf?a.Z.yb+=b.od:L(a.ba,"clock-sync-failed",{reason:b.error},"warn")}).catch(b=>{L(a.ba,"clock-sync-error",{error:b.message},"error")}).finally(()=>{})}
async function Hc(a){try{const b=wb(a.D.config,a.sub);if(!b)return Ic("no-report-url","No reportURL configured");let c;try{c=(new URL("/horizon/d",b)).href}catch(e){return Ic("invalid-report-url",`Cannot parse reportURL: ${b}`)}const d=await Jc(a,c);d.Wf&&(a.od=d.od,a.roundTripTime=d.roundTripTime);return d}catch(b){return Ic("unexpected-error",b.message)}}function Ic(a,b){return{Wf:!1,od:0,roundTripTime:0,error:`${a}: ${b}`}}
async function Jc(a,b){const c=new AbortController,d=setTimeout(()=>c.abort(),1E3);try{const e=a.Z.Ta.contentWindow,f=e.fetch,g=e.performance,h=g.now(),k=await f(b,{method:"HEAD",signal:c.signal,credentials:"omit",cache:"no-store"}),l=g.now();clearTimeout(d);if(!k.ok)return Ic("http-error",`HTTP ${k.status}`);const m=k.headers.get("Date");if(!m)return Ic("no-date-header","Missing Date header");const n=(new Date(m)).getTime();return isNaN(n)?Ic("invalid-date",`Invalid Date: ${m}`):{Wf:!0,od:n-(g.timeOrigin+
(h+l)/2),roundTripTime:l-h}}catch(e){return clearTimeout(d),e.name==="AbortError"?Ic("timeout","Timeout after 1000ms"):e.name==="TypeError"&&e.message.includes("fetch")?Ic("network-error",e.message):e.message&&e.message.toLowerCase().includes("cors")?Ic("cors-error",e.message):Ic("fetch-error",e.message)}}class Kc{constructor(a,b,c,d){this.Z=a;this.D=b;this.ba=c;this.sub=d;this.roundTripTime=this.od=0;this.B=Promise.resolve();Gc(this)}};function Lc(a){const b=window.performance,c=b&&typeof b.now==="function",d=b&&typeof b.timeOrigin==="number";a.yb=d?b.timeOrigin:0;a.W=c&&d?()=>Math.floor(a.yb+b.now()):a.Ta.W}function Mc(a,b,c,d){a.B=new Kc(a,b,c,d)}function Nc(a){return a.B?a.B.B:Promise.resolve()}class Oc{constructor(a){this.Ta=a;this.W=Date.now;this.yb=0;this.B=null}};function Pc(a){a.timeout&&(clearTimeout(a.timeout),a.timeout=null);a.timeout=setTimeout(()=>{a.B.forEach((b,c)=>{Qc(a,c)});Rc(a);Pc(a)},1E3)}function Sc(a,b){a.J.D.aa.Be&&b&&!a.B.has(b)&&(a.B.set(b,{tb:new window.Set,gb:null}),a.timeout||Pc(a))}
function Qc(a,b){Tc(a,b);try{const c=a.J.g.Z.W(),d=a.B.get(b);d.tb.forEach(e=>{const f=Uc(a.J.$,e);let g;typeof f.Ce=="undefined"&&(f.Ce=c);const h=(c-f.Ce)/1E3;a.J.g.G.isConnected(e)&&a.J.g.ia.matchesSelector(e,a.J.D.aa.Be)?!f.Ae&&h>=a.J.D.config.spinnerMaxSeconds&&(g=`${Vc(a.J,e,0,0)}: Load exceeded ${a.J.D.config.spinnerMaxSeconds} seconds`,f.Ae=!0,delete f.Ce,d.tb.delete(e)):(f.Ae||(h>=a.J.D.config.spinnerMaxSeconds?(g=`${Vc(a.J,e,0,0)}: Load exceeded ${a.J.D.config.spinnerMaxSeconds} seconds`,
f.Ae=!0):h>=a.J.D.config.spinnerMinimumThreshold&&(g=`${Vc(a.J,e,0,0)}: ${B(h,0)} spin seconds`,f.Ae=!0)),delete f.Ce,d.tb.delete(e));g&&Wc(a.J,-22,g)})}catch(c){}}function Xc(a,b){const c=a.B.get(b);c&&(a.K(c),c.gb=setTimeout(()=>{Qc(a,b)},300))}function Yc(a){a.timeout&&(clearTimeout(a.timeout),a.timeout=null);a.B.forEach(a.K);a.B.clear()}function Rc(a){const b=[];a.B.forEach((c,d)=>{a.J.g.G.isConnected(d)||b.push(d)});b.forEach(c=>{a.B.delete(c)})}
function Tc(a,b){const c=a.B.get(b);c&&a.J.g.ia.querySelectorAll(b,a.J.D.aa.Be).forEach(d=>{c.tb.add(d)})}class Zc{constructor(a){this.J=a;this.B=new window.Map;this.timeout=null}K(a){a.gb&&(clearTimeout(a.gb),a.gb=null)}};class $c{constructor(a,b){this.L=b;this.B=a}transform(a,b){if(!a.hasAttribute(b))return null;const c=a.getAttribute(b),d=this.B.find(({Od:e,Fa:f})=>e===b&&this.L.g.ia.matchesSelector(a,f));return d?{name:d.dh||b,value:c.replace(d.rb,d.ue)}:{name:b,value:c}}};const ad=/[^\s]/g,O=a=>typeof a!=="string"?a:a?a.replace(ad,"*"):"";async function bd(a,b,c){var d=b.src||(b.srcset?b.srcset.split(", ")[0]:"");try{var e=Ta(d)}catch(h){return}d=Ua(a.J.D.aa.ac,a.J.D.aa.fc,e).slice(-a.J.Ni);let f=null;e={};if(!a.J.Za(b)){const h=new $c(a.J.D.aa.Ab,a.J);var g=["id","title","alt"];for(const k of g){if(!b[k])continue;if(cd(a.J,b,k))continue;if(g=h.transform(b,k))e[g.name]=g.value}Object.keys(e).length>0&&(b=a.J.g.G.stringify(e,cc),f={hash:await Ub(b),value:e})}P(a.J.R,{id:c,ja:2,flags:0,ka:a.J.g.Z.W()},d,f)}
function dd(a,b){if(b.complete&&b.naturalHeight===0){const c=b.loading==="lazy",d=a.J.ta.getEntriesByName(b.src).length>0;c&&!d||bd(a,b,-62)}else a.J.ta.getEntriesByName(b.src).forEach(c=>{c.duration>a.J.D.config.slowLoadingImageThreshold&&bd(a,b,-63)})}class ed{constructor(a){this.J=a;this.Ec=this.Ec.bind(this);this.B=this.B.bind(this)}B(a){bd(this,a.target,-62)}Ec(a){dd(this,a.target)}};const fd=[/^(query|mutation)\s+?([\w\d]+)/,/^(query|mutation).*?{\s*?([\w\d]+)/,/^(?!query|mutation)\{([\w\d]+)[\s{(]+/];function gd(a,b){return Object.keys(b).find(c=>a.has(c))}function hd({pi:a,qe:b}){return[a,b].filter(c=>c).join("/")}function id(a){if(typeof a==="string")try{return JSON.parse(a)}catch(b){}else if(typeof a==="object")return a}
function jd(a,[b,c]){if(a=id(a))if(b=gd(b,a))for(b=a[b],Array.isArray(b)||(b=[b]),a=0;a<b.length;a++){var d=gd(c,b[a]);if(!d)continue;d=parseInt(b[a][d],10);if(!isNaN(d))return d}}function kd(a,[b,c]){if(a=id(a)){if(b=gd(b,a))for(let d=0;d<fd.length;d++){const e=fd[d].exec(a[b]);if(e&&!(e.length<=1)){if(e.length===2)return{qe:e[1]};const [f,g]=e.slice(1);if(g&&f)return{qe:g,pi:f};return}}if(c=gd(c,a))return{qe:a[c]}}};const ld=[{path:/(graphql|gql)/i,parse:function(a,b,c){const d=new window.Set(["query"]),e=new window.Set(["operationName"]),f=new window.Set(["error","errors"]),g=new window.Set(["status","code","errorCode"]);a={};b&&(b=jd(b,[f,g]))&&(a.status=b);c&&(c=kd(c,[d,e])||{},c.qe&&Object.assign(a,{...c,path:hd(c)}));return a}}];function md(a,b=[]){a.B=[].concat(b,ld)}function nd(a,b){const c=b.origin+b.pathname;let d=a.cache.get(c);d||(d=a.B.find(e=>b.href.match(e.path)))&&a.cache.set(c,d);return d}
function od(a,b,c,d){if(b&&b.href&&(a=nd(a,b)))return d=a.parse(b.href,d,c),c=d.path,d=d.status,a={},d&&(a.status=d),c&&(a.url=`${b.origin}${b.pathname}${b.pathname.endsWith("/")?"":"/"}${c}${b.search}`),a}class pd{constructor(){this.B=[];this.cache=new window.Map}};let qd;const rd=String.fromCharCode(115,104,111,112,105,102,121),sd=String.fromCharCode(113,109,45)+rd,td=sd+String.fromCharCode(45,99,104,101,99,107,111,117,116);window.addEventListener(sd,()=>{window!==window.top&&(ud(),qd=document.body.appendChild(document.createElement(td)))},{once:!0});
window.addEventListener(sd,a=>{if(window!==window.top){var {name:b,context:c,data:d}=a.detail;switch(b){case "page_viewed":document.title=c.document.title;qd.setAttribute("title",c.document.title);history.pushState("","",c.window.location.pathname);qd.removeAttribute("input-id");break;case "input_focused":case "input_changed":qd.setAttribute("input-id",d.element.id)}}});
function ud(){const a=new Worker(URL.createObjectURL(new Blob(["onmessage=e=>setTimeout(p=>p.postMessage(null),e.data,e.ports[0])"])));setTimeout=(b,c,...d)=>{const e=new MessageChannel;e.port1.onmessage=()=>{b instanceof Function&&b(...d)};a.postMessage(0|c,[e.port2]);return 0}}
class vd{constructor(a){var b=window[String.fromCharCode(81,117,97,110,116,117,109,77,101,116,114,105,99,83,104,111,112,105,102,121,65,112,105)];this.B=a;if(this.oa=b){if(!/checkout/.test(this.oa.init.context.window.location.pathname))return this.B.stop();ud();this.B.start();setTimeout(()=>this.start(),50)}}start(){let a=document.createElement(td);this.oa.analytics.subscribe("page_viewed",b=>{document.title=b.context.document.title;a.setAttribute("title",b.context.document.title);a.removeAttribute("input-id");
history.pushState("","",b.context.window.location.pathname)});this.oa.analytics.subscribe("input_focused",b=>{a.setAttribute("input-id",b.data.element.id)});this.oa.analytics.subscribe("input_changed",b=>{a.setAttribute("input-id",b.data.element.id)});this.oa.analytics.subscribe("all_events",b=>{K(this.B,{t:"shp",I:b.name});wd(this.B.oa,rd,{name:b.name,data:b.data})});document.body.appendChild(a)}};const xd=a=>a.reduce((b,c)=>b+String.fromCharCode(c),"");const yd={mode:null,dataLayerPaths:[],captureWebStorage:[],publishInterval:3500,sendInterval:1E3,sendRetries:10,proxyIngest:!1,ingestParamsCallback:"",reportURL:"",hashResourceURL:"",ingestBaseURL:xd([104,116,116,112,115,58,47,47,105,110,103,101,115,116,46,113,117,97,110,116,117,109,109,101,116,114,105,99,46,99,111,109]),hashUploadPercent:1,resourceUploadDelay:2E3,urlMonitorBlacklist:[],ingestURLProvider:null,sessionTimeoutMinutes:30,maxSessionDuration:0,cookieDomain:null,sessionCookieName:"QuantumMetricSessionID",
sessionVar:null,userCookieName:"QuantumMetricUserID",sessionStoreNamespace:"QM_S",userStoreNamespace:"QM_U",sessionPersistenceMediums:["cookie","localStorage"],userPersistenceMediums:["cookie","localStorage"],publicKeyString:null,dataScrubRE:[],dataScrubWhiteList:["[data-qm-allow]"],dataScrubBlackList:["*"],scrubDocumentTitlePatterns:[],dataEncryptWhiteList:["[data-qm-allow]"],encryptScrubList:["[data-qm-encrypt]"],maskSensitiveWindowDialogs:[],maskSensitiveJSErrors:[],encryptSensitiveWindowDialogs:[],
excludeDOMList:[],apiDefinitions:[],xhrHookWhiteListDetails:[],xhrHookBlackListDetails:[],xhrPerformanceWhitelistDetails:[],xhrPerformanceSlow:3E3,encryptXHR:!0,checkBlankPages:!0,pbpThreshold:3E3,xhrHookWhiteList:[],xhrHookBlackList:[],xhrErrorBlacklist:[{p:"appdynamics",f:"i"},{p:"aws-origin",f:"i"},{p:"bam",f:"i"},{p:"bam-cell",f:"i"},{p:"cdnbasket",f:"i"},{p:"cdnwidget",f:"i"},{p:"chtbl",f:"i"},{p:"clarity",f:"i"},{p:"clearbit",f:"i"},{p:"demdex",f:"i"},{p:"doubleclick",f:"i"},{p:"facebook",f:"i"},
{p:"google",f:"i"},{p:"google-analytics",f:"i"},{p:"hotjar",f:"i"},{p:"instagram",f:"i"},{p:"iperceptions",f:"i"},{p:"litix",f:"i"},{p:"omtrdc",f:"i"},{p:"pinterest",f:"i"},{p:"snowplowanalytics",f:"i"},{p:"tealium",f:"i"},{p:"tvpixel",f:"i"},{p:"yimg",f:"i"},{p:"linkedin",f:"i"}],dataScrubXHRRegExes:[{p:'"firstName":"?([^,"}]+)"?,?',f:"i"},{p:'"lastName":"?([^,"}]+)"?,?',f:"i"},{p:'"cvv_code":"?([^,"}]+)"?,?',f:"i"},{p:'"cvvCode":"?([^,"}]+)"?,?',f:"i"},{p:'"expiration_date":"?([^,"}]+)"?,?',f:"i"},
{p:'"expirationDate":"?([^,"}]+)"?,?',f:"i"},{p:'"account_no":"?([^,"}]+)"?,?',f:"i"},{p:'"routingNumber":"?([^,"}]+)"?,?',f:"i"},{p:'"date_of_birth":"?([^,"}]+)"?,?',f:"i"},{p:'"dateOfBirth":"?([^,"}]+)"?,?',f:"i"},{p:'"countryOfBirth":"?([^,"}]+)"?,?',f:"i"},{p:'"new_password":"?([^,"}]+)"?,?',f:"i"},{p:'"gender":"?([^,"}]+)"?,?',f:"i"},{p:'"accountNo":"?([^,"}]+)"?,?',f:"i"},{p:'"accountNumber":"?([^,"}]+)"?,?',f:"i"},{p:'"confirm_password":"?([^,"}]+)"?,?',f:"i"},{p:'"confirmPassword":"?([^,"}]+)"?,?',
f:"i"},{p:'"addr_Line1":"?([^,"}]+)"?,?',f:"i"},{p:'"addr_Line2":"?([^,"}]+)"?,?',f:"i"},{p:'"addrLine1":"?([^,"}]+)"?,?',f:"i"},{p:'"addrLine2":"?([^,"}]+)"?,?',f:"i"},{p:'"password":"?([^,"}]+)"?,?',f:"i"},{p:'"dob":"?([^,"}]+)"?,?',f:"i"},{p:'"newPassword":"?([^,"}]+)"?,?',f:"i"},{p:'"loginToken":"?([^,"}]+)"?,?',f:"i"},{p:'"card_number":"?([^,"}]+)"?,?,?',f:"i"},{p:'"address":"?([^,"}]+)"?,?',f:"i"},{p:'"name":"?([^,"}]+)"?,?',f:"i"},{p:'"nationality":"?([^,"}]+)"?,?',f:"i"},{p:'"routing_number":"?([^,"}]+)"?,?',
f:"i"},{p:'"account_number":"?([^,"}]+)"?,?',f:"i"},{p:'"givenName":"?([^,"}]+)"?,?',f:"i"},{p:'"familyName":"?([^,"}]+)"?,?',f:"i"}],visibleURL:xd([104,116,116,112,115,58,47,47,101,120,116,101,114,110,97,108,46,113,117,97,110,116,117,109,109,101,116,114,105,99,46,99,111,109,47,118,105,115,105,98,108,101,47,108,97,116,101,115,116,47,98,111,111,116,115,116,114,97,112,46,98,117,110,100,108,101,46,106,115]),visibleQueryParamName:"qm-visible",surveyPreview:{url:xd([104,116,116,112,115,58,47,47,101,120,
116,101,114,110,97,108,46,113,117,97,110,116,117,109,109,101,116,114,105,99,46,99,111,109,47,115,117,114,118,101,121,45,112,114,101,118,105,101,119,47,108,97,116,101,115,116,47,115,117,114,118,101,121,45,112,114,101,118,105,101,119,46,98,117,110,100,108,101,46,106,115]),queryParamName:"qm_action",queryParamValue:"survey_preview"},bookmarkToolbarURL:xd([104,116,116,112,115,58,47,47,101,120,116,101,114,110,97,108,46,113,117,97,110,116,117,109,109,101,116,114,105,99,46,99,111,109,47,105,110,116,101,
114,97,99,116,105,111,110,115,45,114,101,99,111,114,100,101,114,47,108,97,116,101,115,116,47,98,117,110,100,108,101,46,106,115]),bookmarkToolbarQueryParamName:"qm-bookmark-toolbar-id",bookmarkServiceURL:xd([104,116,116,112,115,58,47,47,114,108,46,113,117,97,110,116,117,109,109,101,116,114,105,99,46,99,111,109,47,117,47,114,101,112,108,97,121]),excludeRageRE:[{p:"\\bzoom\\b",f:"i"},{p:"\\btoggle\\b",f:"i"},{p:"\\bprev\\b",f:"i"},{p:"\\bnext\\b",f:"i"},{p:"\\bforward\\b",f:"i"},{p:"\\bbackward\\b",
f:"i"},{p:"\\bqty\\b",f:"i"},{p:"\\bdown\\b",f:"i"},{p:"\\bup\\b",f:"i"},{p:"\\bright\\b",f:"i"},{p:"\\bleft\\b",f:"i"},{p:"\\barrow\\b",f:"i"},{p:"\\bplus\\b",f:"i"},{p:"\\bminus\\b",f:"i"},{p:"\\bincrease\\b",f:"i"},{p:"\\bdecrease\\b",f:"i"},{p:"\\bcarousel\\b",f:"i"},{p:"\\bquantity\\b",f:"i"},{p:"\\bchevron\\b",f:"i"}],excludeRageCSS:[],rageScrollWheelWindow:2500,rageScrollWheelDirChanges:3,rageScrollWheelMinDistance:50,rageScrollWheelIgnoreDelay:5E3,rageScrollTouchWindow:2500,rageScrollTouchDirChanges:3,
rageScrollTouchMinDistance:150,rageScrollTouchIgnoreDelay:5E3,rageScrollTouchJitter:3,replaceURLRegExes:[],enableWorkerCompression:!0,enableCompression:!0,urlTransforms:[],monitorAllHashChanges:!1,maskInputs:!1,abnSegmentCookie:"",ignoreChangesList:[],blacklistedURLs:[],whitelistedURLs:[],disableFormSubmitFields:!1,scrubInputAttributes:["defaultValue","placeholder"],forceDeferFetchAborts:!1,monitorXHRSetCookies:!1,maxXHRDataLength:20480,excludeXHRHeaderRegEx:[{p:"Authorization",f:"i"}],percentSampling:100,
enabledCookie:"QuantumMetricEnabled",logReqCookiesForXHR:!1,spinnerMaxSeconds:6,spinnerMinimumThreshold:3,spinnerSelectorList:["[class*=spinner]:not([class*=hide]):not([class*=hidden]):not([class*=inactive]):not([class*=disabled])","[class*=loading]:not([class*=hide]):not([class*=hidden]):not([class*=inactive]):not([class*=disabled])","[class*=loader]:not([class*=hide]):not([class*=hidden]):not([class*=inactive]):not([class*=disabled])"],stripHTMLComments:!1,maxNumOOBEventsPerHit:5E3,targetCurrency:"USD",
startOffset:0,startImmediatePathPatterns:[],allowClearCookies:!1,captureCookiesReplay:!0,waitForSessionIdPathPatterns:[],startWithoutParentPathPatterns:[],maxIframeSyncRetries:10,waitForParentMaxRetries:20,waitForParentRetryDelay:250,maxWaitForSessionIdRetries:2E4,queryParamForSessionId:"",queryParamForUserId:"",nestedStitchingQueryParams:[],logResourcePercent:0,autoDetectSDK:!1,customWebviewUserAgentPatterns:[],maxResourcesPerHit:500,allowedResourceTypes:"css img script link iframe xmlhttprequest fetch".split(" "),
maxStoredEventLength:255,hookPrompt:!0,blockFrequentReloads:[],domChangedThrottleDuration:100,spaTransitionStartMarkerName:"QuantumMetricTransitionStart",spaTransitionStopMarkerName:"QuantumMetricTransitionStop",spaLocationChangedTimeout:1E3,ignoreAttributes:"data-city data-postal-code data-email data-accountnumber data-phone data-address data-address1 data-last-name data-first-name data-user-firstname data-user-lastname data-user-email data-addressone data-addresstwo data-postalcode data-countrycode taxidnumber accountnumber lastname middlename firstname address address1 address2 city statecode zip ssn taxId consumerID birthdate personalemail businessemail idnumber email user-info password data-user-phonenumber data-user-birthdate account-number account-alias".split(" "),
transformAttributesForNodesList:[],webVitalsSnapshotBuffer:1E3,resourcePathBlacklist:[{p:"googleads.g.doubleclick.net",f:"i"}],sampleReplay:0,replayEnabled:!0,hookFetch:!0,sameSiteFlag:"None",disableErrorHooking:!1,xhrEncryptWhiteListDetails:[],xhrEncryptBlackListDetails:[],encryptNodeAttributes:[],syncEndpointsWithSDK:[],maskSensitiveQueryParams:"user userid user-id username alias clientid accountnumber invoicenumber id accountid customer_id customerid authcode authtoken bankclearingcode bankcountry ordertoken token passcode password vin confirmationno confirmation-number confirmationnumber confirmation dateofbirth email email_address emailaddress emailid loginemail loginid login_hint loginhint title name fname sname gname first_name firstname last_name lastname surname location address address1 address2 orderemail password phone phonenumber phone_number po postcode referrerid routingnumber state transactionid transid txtpassword txtuserid utm_email ssn".split(" "),
forceElementCSSUpload:["[data-fela-type]","[data-emotion]"],forceElementCSSInline:[],ignoreElementCSSSerialization:[],reportFailedImages:!0,slowLoadingImageThreshold:2500,useFallbackSDKSync:!1,imageTrackingIgnoreList:'img[alt*="tracking"] img[alt*="pixel"] img[alt*="beacon"] img[alt*="analytics"] img[alt*="spy"] img[alt*="tracker"] img[alt*="conversion"] img[alt*="1x1"] img[src*="utm_"] img[src*="google-analytics.com/"] img[src*="doubleclick.net/"] img[src*="facebook.com/tr/"] img[height="1"][width="1"] img[height="0"][width="0"] img[src=""] img[src*="blank.gif"]'.split(" "),
waitForNativeCapture:!0,elementVeinAttributes:"aria-label data-testid alt title data-id id name class data-component-id data-aura-class aria-describedby data-key slot".split(" "),temp:{cleanAPIUrls:!0,isPivot:!1},maxMDELength:20480,maxSDKWaitTime:6E3,clickTextMapping:[],excludeLegacyHttp:[{p:"^",f:""}],sdkCommTimeout:3E3,sdkCommRetryCount:5,sdkCommRetryDelay:500,zones:[],console:{error:[{re:{p:".*",f:""}}]},flutterViews:[{root:"flutter-view",attr:"flt-view-id",render:"flt-glass-pane S# canvas"}]},
zd={};function Ad(a){if(!a.M){const b=new URLSearchParams(window.location.search),c=a.B.fa.get("isRecording",!1);a.K=b.get(a.B.D.config.bookmarkToolbarQueryParamName)||c;a.K&&(zd.hashUploadPercent=100,zd.percentSampling=100,zd.sampleReplay=100,zd.publishInterval=500)}}function Bd(a,b){const c=b.action;if(c)switch(c){case "recorder-cleanup":a.M=!0;Cd(a.B);setTimeout(()=>{window.close()},350);break;default:console.warn("QM: Unknown recorder action")}else console.warn("QM: Missing recorder action:",b)}
class Dd{constructor(a){this.B=a;this.K=this.M=!1}start(){if(this.K){var a=document.createElement(this.B.xe);a.src=this.B.D.config.bookmarkToolbarURL;a.crossOrigin="anonymous";document.head.appendChild(a);this.B.fa.set("isRecording",!0);this.B.oa.getSessionVar("sst",null)||this.B.oa.setSessionVar("sst",this.B.g.Z.W())}}};const Ed=["log","warn","error","info","debug"];function Fd(a){const b=[],c={ab:5120};a=a.map(d=>Gd(d,new Set,c,b,null));for(let d=0;d<b.length;d++){const e=b[d];c.ab>0?Hd(e.Xh,e.source,e.Wh,c,b,e.root):e.root.na.truncated=!0}return a}function Gd(a,b,c,d,e){if(b.has(a))return new Id("[Circular Reference]");const f=Jd.handlers.find(g=>g.mb(a))||Kd;if(f===Ld||f===Md){if(f.BASE_LENGTH>c.ab)return Nd(e);c.ab-=f.BASE_LENGTH;c=new f;d.push({Xh:c,source:a,Wh:b,root:e||c});return c}b=new f(a);d=b.nb();if(d>c.ab)return Nd(e);c.ab-=d;return b}
function Hd(a,b,c,d,e,f){c=(new Set(c)).add(b);if(Array.isArray(b)){var g=a.na.v;for(var h=0;h<b.length;h++){if(d.ab<1){f.na.truncated=!0;break}--d.ab;var k=void 0;try{k=b[h]}catch(l){g.push(new Id("[Unserializable]"));continue}a=Gd(k,c,d,e,f);a!==null&&g.push(a)}}else for(g in k=a.na.v,b){if(!Object.prototype.hasOwnProperty.call(b,g))continue;a=g.length+4;if(a>d.ab){f.na.truncated=!0;break}d.ab-=a;try{h=b[g]}catch(l){k[g]=new Id("[Unserializable]");continue}a=Gd(h,c,d,e,f);a!==null&&(k[g]=a)}}
function Nd(a){if(a===null)return new Id("[Truncated]");a.na.truncated=!0;return null}function Od(a){Jd.handlers.find(b=>b===a)||Jd.handlers.push(a)}class Jd{}Jd.handlers=[];class Pd{constructor(){this.na={t:"",v:void 0}}static mb(){return!1}bb(){return this.na}ph(){return this.bb()}Gb(a){return String(this.na.v).search(a)!==-1}nb(){return Pd.BASE_LENGTH+String(this.na.v).length}}Pd.BASE_LENGTH=26;
class Id extends Pd{static mb(a){return typeof a==="string"}constructor(a){super();this.na={t:"string",v:a.length>500?a.substring(0,500)+"...":a}}Gb(a,b){let c=!1;a=this.na.v.replaceAll(a,d=>{c=!0;return b||d});c&&b&&(this.na.v=a);return c}nb(){return Id.BASE_LENGTH+this.na.v.length}}Id.BASE_LENGTH=21;class Qd extends Pd{static mb(a){return typeof a==="number"}constructor(a){super();this.na={t:"number",v:Number.isFinite(a)?a:String(a)}}nb(){return Qd.BASE_LENGTH+String(this.na.v).length}}
Qd.BASE_LENGTH=20;class Rd extends Pd{static mb(a){return typeof a==="boolean"}constructor(a){super();this.na={t:"boolean",v:a}}nb(){return Rd.BASE_LENGTH}}Rd.BASE_LENGTH=25;
class Sd extends Pd{static mb(a){return Object.prototype.toString.call(a)==="[object Error]"}constructor(a){super();var b=a.stack||"";b=b.length>500?`${b.substring(0,500)} ...`:b;const c={};a.message&&(c.m=a.message);c.s=b;this.na={t:"error",v:c}}Gb(a,b){const c=this.na.v.m;if(!c)return!1;let d=!1;a=c.replaceAll(a,e=>{d=!0;return b||e});d&&b&&(this.na.v.m=a);return d}nb(){return Sd.BASE_LENGTH+(this.na.v.m?this.na.v.m.length:0)+Math.min(this.na.v.s.length,500)}ph(){const a={};this.na.v.m&&(a.m=this.na.v.m);
return{t:this.na.t,v:a}}}Sd.BASE_LENGTH=33;class Td extends Pd{static mb(a){return typeof a==="bigint"}constructor(a){super();a=a.toString();this.na={t:"bigint",v:a.length>500?a.substring(0,500)+"...":a}}nb(){return Td.BASE_LENGTH+this.na.v.length}}Td.BASE_LENGTH=21;class Ud extends Pd{static mb(a){return a===null||a===void 0}constructor(a){super();this.na={t:"nullish",v:a===null?"null":"undefined"}}}Ud.BASE_LENGTH=22;
class Kd extends Pd{static mb(){return!0}constructor(a){super();this.na={t:"unsupported",v:String(a)}}}
class Md extends Pd{static mb(a){return!!a&&typeof a==="object"}constructor(){super();this.na={t:"object",v:{}};this.B=null}bb(){if(this.B)return this.B;const a=this.na.v,b={t:"object",v:{}};this.na.truncated&&(b.truncated=!0);for(const c in a)Object.prototype.hasOwnProperty.call(a,c)&&(b.v[c]=a[c].bb());return this.B=b}Gb(a,b){const c=this.na.v;let d=!1;for(const e in c)Object.prototype.hasOwnProperty.call(c,e)&&c[e].Gb(a,b)&&(d=!0);return d}nb(){const a=this.na.v;let b=Md.BASE_LENGTH;for(const c in a)Object.prototype.hasOwnProperty.call(a,
c)&&(b+=c.length+4+a[c].nb());return b}}Md.BASE_LENGTH=21;
class Ld extends Pd{static mb(a){return Array.isArray(a)}constructor(){super();this.na={t:"array",v:[]};this.B=null}bb(){if(this.B)return this.B;const a=this.na.v,b={t:"array",v:[]};this.na.truncated&&(b.truncated=!0);for(let c=0;c<a.length;c++)b.v.push(a[c].bb());return this.B=b}Gb(a,b){const c=this.na.v;let d=!1;for(let e=0;e<c.length;e++)c[e].Gb(a,b)&&(d=!0);return d}nb(){const a=this.na.v;let b=Ld.BASE_LENGTH;for(let c=0;c<a.length;c++)b+=a[c].nb()+1;return b}}Ld.BASE_LENGTH=20;Od(Ud);Od(Id);
Od(Qd);Od(Td);Od(Rd);Od(Sd);Od(Ld);Od(Md);Od(Kd);function Vd(a){if(!a.ea){a.ea=!0;var b=window.console;Ed.forEach(c=>{const d=Aa(b,c);if(d&&d.configurable){var e=d.value;Object.defineProperty(b,c,{value:(...f)=>{const g=e.apply(b,f);try{if(!a.M&&a.ca.has(c)){a.M=!0;try{Wd(a,c,f)}finally{a.M=!1}}}catch(h){a.xa("CONSOLE_HOOK_ERROR",h.message)}return g},writable:d.writable,enumerable:d.enumerable,configurable:d.configurable})}})}}
function Wd(a,b,c){if(!(a.B.length>=5E3)){var d=Math.min(c.length,5);if(d!==0){var e=[];for(let f=0;f<d;f++)e.push(c[f]);c=Fd(e);a.B.push({method:b,Sa:c});a.K===null&&(a.K=a.G.setTimeout(()=>Xd(a),0))}}}function Xd(a){const b=a.G.W();let c=0;for(const d of a.B)if(a.Xd(d.method,d.Sa),c++,a.G.W()-b>=30)break;a.B.splice(0,c);a.B.length>0?a.K=a.G.setTimeout(()=>Xd(a),0):(a.G.clearTimeout(a.K),a.K=null)}
class Yd{constructor(a){this.G=a.G;this.xa=a.xa;this.Xd=a.Xd;this.B=[];this.K=null;this.M=!1;this.ca=new Set;this.ea=!1;Vd(this)}flush(){this.K!==null&&(this.G.clearTimeout(this.K),this.K=null);if(this.B.length!==0){var a=this.G.W(),b=0;for(const c of this.B)if(this.Xd(c.method,c.Sa),b++,this.G.W()-a>=90)break;this.B.length=0}}};function Zd(a){let b=new Uint8Array(a.length*2);for(let c=0;c<a.length;c++){let d=a.charCodeAt(c),e=c*2;b[e]=d>>8&255;b[e+1]=d&255}return b}function $d(a){a=new Uint8Array(a);let b="";for(let c=0;c<=a.length;c+=65E3)b+=String.fromCharCode.apply(null,a.slice(c,c+65E3));return btoa(b)}function ae(a){a=atob(a).split("").map(b=>b.charCodeAt(0));return new Uint8Array(a)}function be(a){return a.replace(/\+/g,"-").replace(/\//g,"_").replace(/=/g,"")};class ce{constructor(a){this.M=a;this.K=this.B=null;this.iv=new Uint8Array(16);this.importKey()}async importKey(){if(this.M&&!this.K){be($d(this.M));var a=this;this.B=new Promise(b=>{try{de().importKey("raw",this.M,na,!1,["encrypt"]).then(c=>{a.K=c;b()}).catch(()=>{b()})}catch(c){b()}})}}async encrypt(a){!this.K&&this.B&&await this.B;try{!this.K&&this.B&&(await this.B,this.B=null);if(this.K){const b=Zd(a);return await de().encrypt({name:na,iv:this.iv},this.K,b)}return new ArrayBuffer(0)}catch(b){return new ArrayBuffer(0)}}}
;function de(){return window.crypto&&window.crypto.subtle}function Ub(a){a=(new TextEncoder).encode(a);return crypto.subtle.digest("SHA-256",a).then(b=>btoa(String.fromCharCode.apply(null,new Uint8Array(b,0,8))))}
async function ee(a){if(window.crypto&&window.crypto.subtle){a.supports=!0;if(!a.B||a.B.length!=32){a.B=new Uint8Array(32);crypto.getRandomValues(a.B);try{var b=JSON.parse(atob(a.K)).map(ae)}catch(c){}a.ca=await (new fe(b)).encrypt(a.B);a.le=await ge(a,a.K)}a.M=new ce(a.B);a.ea&&(a.O(),a.ea=!1)}}async function ge(a,b){return b&&a.supports?(a=await crypto.subtle.digest("SHA-256",Zd(b.toString().toLowerCase())),$d(a)):""}
async function he(a,b){a=await a.encrypt(b).catch(()=>"*");return a==="*"?"":a}function ie(a){return a.ca&&a.K?"v2:"+$d(a.ca):""}class je{constructor(a,b,c){a&&(this.J=c,this.K=a,this.M=this.ca=this.B=null,this.O=b,this.le="",this.ea=!0,this.supports=!1,this.qa=ee(this))}async encrypt(a){if(!a||a.trim().length==0)return"";if(!this.K||!this.supports)return"*";try{if(this.M||await this.qa,a&&typeof a=="string"&&this.M){try{var b=await this.M.encrypt(a)}catch(c){}return $d(b)}}catch(c){}return"*"}};class fe{constructor(a){this.M=a;this.K=this.B=null;this.importKey()}async importKey(){try{if(this.M&&!this.K){var a={kty:"RSA",alg:pa,ext:!1,key_ops:["encrypt"],e:"AQAB",n:be($d(this.M[0]))},b=this;this.B=new Promise((c,d)=>{try{de().importKey("jwk",a,{name:oa,hash:{name:ma}},!1,["encrypt"]).then(e=>{b.K=e;c(e)}).catch(e=>{d(e)})}catch(e){d(e)}})}}catch(c){}}async encrypt(a){!this.K&&this.B&&await this.B;try{if(!this.K&&this.B&&(await this.B,this.B=null),this.K)try{return await de().encrypt({name:oa},
this.K,a)}catch(b){return new ArrayBuffer(0)}}catch(b){return new ArrayBuffer(0)}}};class ke{constructor(a,b,c){this.J=a;this.M=c;this.Ta=b;this.B=this.B.bind(this);this.K=this.K.bind(this);this.J.tf||window.addEventListener("storage",this.K);window.addEventListener("pagehide",this.B)}K(a){a.key==="QEventChannel"&&a.newValue&&this.M(this.Ta.Ra(a.newValue))}B(){try{this.Ta.Storage.removeItem.call(window.localStorage,"QEventChannel")}catch(a){}}Ve(){window.removeEventListener("storage",this.K);window.removeEventListener("pagehide",this.B)}};class le{constructor(){this.J=null}};function me(...a){for(var b={},c=0;c<a.length;++c){var d=Q(a[c]),e;for(e in d)b[e]=d[e]}return b}function Q(a){var b=a.Oa;return b?b:a.Oa=a.ga()}function T(a,b){Q(a)[b]&&(a.qa=void 0,a.K(b))}function ne(a,b,c){a.ea(b,c)}class U extends le{constructor(){super();this.qa=void 0;this.Oa=null}evaluate(){var a=this.qa;return a!==void 0?a:this.qa=this.B()}B(){return null}ga(){return{}}K(){}ca(){}M(){}ea(){}};class oe extends U{};class pe extends oe{constructor(a,b,...c){super();this.O=b;this.Sa=c}B(){if(this.O==qe)return!this.Sa[0].evaluate();if(this.O==re){for(var a=0;a<this.Sa.length;++a)if(!this.Sa[a].evaluate())return!1;return!0}for(a=0;a<this.Sa.length;++a)if(this.Sa[a].evaluate())return!0;return!1}ga(){return me(...this.Sa)}K(a){for(var b=0;b<this.Sa.length;++b)T(this.Sa[b],a)}}var qe=0,re=1;class se extends le{evaluate(){return!1}};class te extends oe{constructor(a,b,c){super();this.value=b;this.O=c}B(){return this.O.evaluate(this.value.evaluate())}ga(){return Q(this.value)}K(a){T(this.value,a)}};class ue extends U{constructor(a,b,c){super();this.O=b;this.value=c}B(){var a=this.O.evaluate();return a?{Ka:a,value:this.value.B()}:{Ka:a,value:""}}ga(){return me(this.O)}K(a){T(this.O,a);T(this.value,a)}ea(a,b){this.O.ea(a,b)}ca(){this.O.ca()}M(){this.O.M()}};class ve extends oe{constructor(a,b){super();this.event=b}B(){return this.event.evaluate().Ka}ga(){return Q(this.event)}K(a){T(this.event,a)}};class we extends oe{constructor(a,b){super();this.R=a;this.O=b}B(){var a=this.O;return this.R.ib.some(function(b){return b.id==a})}ga(){return{eventinfo:!0,event:!0}}};class xe extends U{constructor(a,b){super();this.event=b}B(){return this.event.evaluate().value}ga(){return Q(this.event)}K(a){T(this.event,a)}};class ye extends U{B(){return{Ka:!0,value:""}}ga(){return{eventinfo:!0}}};class ze extends U{constructor(a,b,c){super();this.key=b;this.value=c}B(){return this.value.evaluate()[this.key]}ga(){return Q(this.value)}K(a){T(this.value,a)}};class Ae extends U{constructor(a,b){super();this.value=b}B(){for(var a=this.value.evaluate(),b=0,c=0;c<a.length;++c)try{b+=parseFloat(a[c])}catch(d){}return b}ga(){return Q(this.value)}K(a){T(this.value,a)}};class Be extends U{constructor(a,b){super();this.value=b}B(){return this.value}};class Ce extends U{constructor(a,b,c,d){super();this.src=b;this.la=new RegExp(b);this.O=c;this.value=d}B(){var a=this.la.exec(this.value.evaluate());return a?(a=a[this.O])?a:"":""}ga(){return Q(this.value)}K(a){T(this.value,a)}};class De extends U{constructor(a,b){super();this.value=b}B(){try{return parseFloat(this.value.evaluate())}catch(a){return NaN}}ga(){return Q(this.value)}K(a){T(this.value,a)}};class Ee extends U{constructor(a,b,c){super();this.R=a;this.O=c;this.value=b}B(){try{var a=this.value.evaluate();var b=za(a);if(this.O){var c=this.O.evaluate();if(c){let d=ya(b,c,this.R.J.D.config.targetCurrency,this.R.J.Td);if(typeof d==="string"){this.R.J.xa("currency_conversion",d);return}b=d}}}catch(d){return}return typeof b==="number"?B(b):void 0}ga(){return Object.assign({},Q(this.value),this.O?Q(this.O):{})}K(a){T(this.value,a);this.O&&T(this.O,a)}};class Fe extends se{constructor(a,b){super();this.B=b}evaluate(a){return!this.B.evaluate(a)}}class Ge extends se{constructor(a,b){super();this.value=b}evaluate(a){return a==this.value}}class He extends se{constructor(a,b){super();this.value=b}evaluate(a){return a&&a!="undefined"?a.indexOf(this.value)!=-1:!1}}
class Ie extends se{constructor(a,b,c){super();this.B=b;this.value=c}evaluate(a){return typeof a!=="string"?!1:this.B===Je?a.startsWith(this.value):this.B===Ke?a.includes(this.value):this.B===Le?a.endsWith(this.value):!1}}var Je=0,Ke=1,Le=2;class Me extends se{constructor(a,b,c){super();this.start=b;this.end=c}evaluate(a){return this.start<=a&&a<=this.end}}
class Ne extends se{constructor(a,b,c){super();this.B=b;this.value=c}evaluate(a){return this.B==Oe?a<this.value:this.B==Pe?a<=this.value:this.B==Qe?a>=this.value:a>this.value}}var Oe=0,Pe=1,Qe=2;class Re extends se{evaluate(a){return!!a}}class Se extends se{evaluate(a){return a!=null&&a.length!=0}}class Te extends se{constructor(a,b){super();this.key=b}evaluate(a){return a[this.key]!==void 0}}
class Ue extends se{constructor(a,b){super();this.Fa=b}evaluate(a){try{if(!(a instanceof Element))return!1}catch(b){}return this.J.g.ia.matchesSelector(a,this.Fa)}}class Ve extends se{constructor(a,b,c){super();this.key=b;this.B=c}evaluate(a){try{var b=a[this.key];b||this.key!="value"||(b=a.innerText);b=b?b.trim().toLowerCase():b;return b===(this.B?this.B.toLowerCase():this.B)}catch(c){return a[this.key]===this.B}}}class We extends se{evaluate(a){return a!==void 0&&a!==null}};class Xe extends U{constructor(a){super();this.R=a;this.J=a.J}};class Ye extends Xe{B(){return this.R.Af}ga(){return{formSubmitted:!0}}}class Ze extends Xe{B(){return this.R.yf.filled?this.R.yf.name:null}ga(){return{form:!0}}}class $e extends Xe{constructor(a,b){super(a);this.Fa=b}B(){var a=this.R.Af;if(!a)return null;a=a.elements;for(var b=0;b<a.length;++b)if(this.J.g.ia.matchesSelector(a[b],this.Fa))return a[b].value;return null}ga(){return{formSubmitted:!0}}};class af extends Xe{constructor(a,b){super(a);this.O=b;this.la={eventinfo:!0,event:!0}}B(){for(var a=this.O,b=this.R.ib,c=b.length-1;c>=0;--c){var d=b[c];if(d.id==a)return d.value}}ga(){return this.la}}class bf extends Xe{constructor(a,b){super(a);this.O=b}B(){for(var a=this.O,b=this.R.ib,c=b.length-1;c>=0;--c){var d=b[c];if(d.id==a)return d.timeStamp}}ga(){return{eventinfo:!0,event:!0}}}class cf extends Xe{B(){return this.R.ob&&this.R.ob.s}ga(){return{eventinfo:!0}}}
class df extends Xe{B(){var a=this.R.ob;if(a)return a.e+B(this.J.Fc/1E3)}ga(){return{eventinfo:!0,engagement:!0}}};class ef extends oe{constructor(a,b){super();this.R=a;this.Fa=b}B(){if(this.R.xf)return this.J.g.ia.matchesSelector(this.R.xf,this.Fa)}ga(){return{fieldFilled:!0}}};class ff extends Xe{B(){return this.R.Xg}ga(){return{clicked:!0}}};class gf extends Xe{B(){return this.R.$b}ga(){return{clicked:!0}}};class hf extends oe{constructor(a,b){super();this.R=a;this.Fa=b}B(){return!!this.R.J.g.ia.querySelector(document,this.Fa)}ga(){return{pageready:!0,dom:!0,eventinfo:!0}}};class jf extends Xe{constructor(a,b){super(a);this.Fa=b}B(){var a=this.J.g.ia.querySelector(document,this.Fa);if(a)return a.nodeName!="INPUT"&&a.nodeName!="SELECT"&&a.nodeName!="TEXTAREA"||!a.value?this.J.g.G.textContent(a):a.value}ga(){return{dom:!0,pageready:!0,eventinfo:!0,clicked:!0,formSubmitted:!0,fieldFilled:!0}}};class kf extends Xe{constructor(a,b){super(a);this.Fa=b}B(){var a=this.J.g.ia.querySelector(document,this.Fa);if(a)return a.value}ga(){return{dom:!0,pageready:!0,clicked:!0,formSubmitted:!0,eventinfo:!0}}};class lf extends oe{constructor(a,b){super();this.R=a;this.O=b}B(){return this.R.J.ra.get(this.O)}ga(){return{eventinfo:!0}}};class mf extends U{constructor(a,b){super();this.R=a;this.O=b}B(){return this.R.J.ra.get(this.O)}ga(){return{eventinfo:!0}}};const nf=async(a,b,c)=>{if(typeof c==="string")return c;a=((a.reqHeaders||"").toLowerCase().split("\r\n").find(d=>d.startsWith("content-type"))||"").slice(14);return c instanceof window.FormData||a.startsWith("multipart/form-data")?await (new Request("",{method:b,body:c})).text():c instanceof Uint8Array?c instanceof Uint8Array&&(a.startsWith("application/json")||a.startsWith("text/"))?String.fromCodePoint.apply(null,c):c:c},of=a=>a.split("\r\n").reduce((b,c)=>{if(c==="")return b;const [d,e]=c.split(/:\s*/);
b[d.toLowerCase()]=e;return b},{});class pf extends U{constructor(a,b){super();this.R=a;this.O=b}B(){var a="";try{if(typeof this.O==="object"&&this.O!==null&&this.O.hasOwnProperty("fn")){const b=this.R.J,c=b.oa,d={api:c,utils:{get:E,set:Ca,JSON:{parse:b.g.G.Ra,stringify:b.g.G.stringify},getSessionVar:c.getSessionVar.bind(c),setSessionVar:c.setSessionVar.bind(c),currencyConvertFromToValue:c.currencyConvertFromToValue.bind(c)},userID:b.za,sessionID:b.ha};if(this.R.Kd){const e=this.R.Kd;let f=e.qresponse;try{f=this.R.J.g.G.Ra(f)}catch(h){}let g=
e.qrequest;try{g=this.R.J.g.G.Ra(g)}catch(h){}d.http={response:f,request:g,status:e.qstatus,method:e.qmethod,url:e.qurl,duration:e.qduration};e.qreqheaders&&(d.http.requestHeaders=of(e.qreqheaders));e.qrespheaders&&(d.http.responseHeaders=of(e.qrespheaders))}this.R.Jd&&(d.lastClicked=this.R.Jd);return this.O.fn.call(d)}a=window[this.J.rg](this.O)}catch(b){console.error("QTM: JSEvent: ",b,this.O),L(this.J.ba,"JSValue:eval-error",{eventId:this.R.Ye,message:b.message,stack:b.stack?b.stack.toString().substring(0,
500):""},"error")}return a}ga(){return{pageready:!0,eventinfo:!0}}};class qf extends pf{ga(){return{pageready:!0,eventinfo:!0,dom:!0,clicked:!0,xhr:!0}}};class rf extends Xe{constructor(a,b){super(a);this.O=new RegExp(b)}B(){if(this.R.Ia)return this.O.test(this.R.Ia.responseURL)?this.R.Ia.data:void 0}ga(){return{xhr:!0}}};class sf extends Xe{constructor(a,b){super(a);this.O=new RegExp(b)}B(){if(this.R.Ia&&this.O.test(this.R.Ia.qurl))return this.R.Ia.qresponse}ga(){return{xhr:!0}}};function tf(a){const b={};return a&&typeof a==="string"?a.split("\r\n").slice(0,-1).reduce((c,d)=>{const [e,f]=d.split(": ");d=e.toLowerCase();d in c||(c[d]=[]);c[d].push(...f.split(/, */g));return c},b):b}function uf(a,b){return b&&a.name in b?a.la?b[a.name].some(c=>a.la.evaluate(c)):!0:!1}
class vf extends Xe{constructor(a,b,c,d){super(a);this.O=new RegExp(b);this.name=c;this.la=d}B(){const a=this.R.Ia;if(a&&this.O.test(a.responseURL)){var b=a.Lf;if(!b){const c=a.getAllResponseHeaders();c&&(b=tf(c),a.Lf=b)}return uf(this,b)}}ga(){return{xhr:!0}}};class wf extends vf{B(){const a=this.R.Ia;if(a&&this.O.test(a.responseURL)){var b=a.Mf;if(!b){const c=a.reqHeaders;c&&(b=tf(c),a.Mf=b)}return uf(this,b)}}};const xf=/^\d+$/;class yf extends U{constructor(a,b,c){super();this.key=b;this.la=this.key.split(".");this.O=c}B(){var a=this.O.evaluate();if(a&&typeof a=="string")try{for(var b=this.la,c=0;c<b.length;c++){let e=b[c];if(!xf.test(e)&&a.indexOf(e)<0)return}var d=JSON.parse(a);for(c=0;c<b.length&&(d=d[b[c]],d!==void 0);c++);return d}catch(e){}}ga(){return Q(this.O)}K(a){T(this.O,a)}};class zf extends yf{constructor(a,b,c,d){super(a,b,d);this.value=c}B(){var a=super.B();if(typeof a!=="undefined")return a==this.value}};class Af extends U{constructor(a,b,c,d){super();this.O=b;this.value=c;this.Wa=d}B(){const a=this.O.evaluate();return a?{Ka:a,value:this.value.B(),Wa:this.Wa.B()}:{Ka:a,value:"",Wa:null}}ga(){return me(this.O)}K(a){T(this.O,a);T(this.value,a);T(this.Wa,a)}ea(a,b){this.O.ea(a,b)}ca(){this.O.ca()}M(){this.O.M()}};class Bf extends U{transform(){}};class Cf extends U{constructor(a,b,...c){super();this.value=b;this.O=c}B(){const a=this.value.evaluate();return this.O.reduce((b,c)=>c.transform(b),a)}ga(){const a=this.O.reduce((b,c)=>Object.assign(b,Q(c)),{});return Object.assign(a,Q(this.value))}K(a){T(this.value,a);this.O.forEach(b=>T(b,a))}};class Df extends Bf{constructor(a,b){super();this.O=b}transform(a){typeof a!=="string"&&(a=String(a));return this.O==="u"?a.toUpperCase():this.O==="l"?a.toLowerCase():a}}class Ef extends Bf{constructor(a,b,c){super();this.rb=Xa(b.p,b.f);this.ue=c}transform(a){typeof a!=="string"&&(a=String(a));return this.rb?a.replace(this.rb,this.ue):""}}class Ff extends Bf{constructor(a){super();this.R=a}transform(a){if(typeof a==="string")try{return this.R.J.g.G.Ra(a)}catch(b){}}}
class Gf extends Bf{constructor(a,...b){super();this.R=a;this.keys=b}transform(a){if(typeof a==="object"&&a!==null)return this.keys.reduce((b,c)=>{if(Array.isArray(c)){var d=c[0];c=c[1]}else d=c;d=a[d];d!==void 0&&(b[c]=d);return b},{})}}class Hf extends Bf{constructor(a,b){super();this.target=b}transform(a){if(typeof a==="object"&&a!==null){var b=this.target.evaluate();if(typeof b==="object"&&b!==null)return{...a,...b}}}ga(){return Q(this.target)}K(a){T(this.target,a)}};class If extends U{constructor(a,b,c,d){super();this.object=b;this.path=c;this.la=c.split("/").slice(1).map(ec);this.O=d}B(){var a=this.object.evaluate();if(a===void 0)return!1;a=this.path===""?a:E(a,this.la,M);return a==M?!1:this.O?this.O.evaluate(a):!0}ga(){return Q(this.object)}K(a){T(this.object,a)}};class Jf extends U{B(){return window}ga(){return{eventinfo:!0,pageready:!0}}};class Kf extends If{B(){var a=this.object.evaluate();if(a!==void 0){a=this.path===""?a:E(a,this.la,M);if(!this.O)return a===M?void 0:a;if(a!=M&&this.O.evaluate(a))return a}}};class Lf extends U{constructor(a,b,c,d){super();this.O=b;this.path=c;this.ua=c.split("/").slice(1).map(ec);this.la=d}B(){const a=this.O.evaluate();if(a===void 0)return!1;const b=this.la?c=>this.la.evaluate(c):()=>!0;return this.path===""?b(a):fc(a,this.ua,b)!==M}ga(){return Q(this.O)}K(a){T(this.O,a)}};class Mf extends U{constructor(a,b,c,d){super();this.O=b;this.path=c;this.ua=c.split("/").slice(1).map(ec);this.la=d}B(){var a=this.O.evaluate();if(a===void 0)return!1;const b=this.la?c=>this.la.evaluate(c):()=>!0;if(this.path===""&&b(a))return a;a=fc(a,this.ua,b);return a!==M?a:void 0}ga(){return Q(this.O)}K(a){T(this.O,a)}};class Nf extends vf{constructor(a,b,c){super(a,b,c,null)}B(){const a=this.R.Ia;if(a&&this.O.test(a.responseURL)){var b=a.Lf;if(!b){const c=a.getAllResponseHeaders();c&&(b=tf(c),a.Lf=b)}return b[this.name]}}};class Of extends wf{constructor(a,b,c){super(a,b,c,null)}B(){const a=this.R.Ia;if(a&&this.O.test(a.responseURL)){var b=a.Mf;if(!b){const c=a.reqHeaders;c&&(b=tf(c),a.Mf=b)}return b[this.name]}}};class Pf extends U{constructor(a,b,c,...d){super();this.ua=b;this.la=Math.max(Math.min(c,d.length-1),0);this.O=d}B(){var a=this.O.map(e=>e.evaluate());let b=!1,c="",d=null;this.ua===Qf&&a.every(e=>e.Ka)&&(b=!0,c=a[this.la].value,d=a[this.la].Wa);this.ua===Rf&&a.some(e=>e.Ka)&&(a=a.find(e=>e.Ka)||{Ka:!1,value:""},b=!0,c=a.value,d=a.Wa);b?this.O.forEach(e=>{e.M()}):this.O.forEach(e=>{e.ca()});return{Ka:b,value:c,Wa:d}}ga(){return this.O.reduce((a,b)=>({...Q(b),...a}),{})}K(a){this.O.forEach(b=>T(b,
a))}ea(a,b){this.O.forEach(c=>{c.ea(a,b)})}ca(){this.O.forEach(a=>{a.ca()})}M(){this.O.forEach(a=>{a.M()})}}var Qf=0,Rf=1;class Sf extends Xe{constructor(a,b){super(a);this.O=new RegExp(b)}B(){if(this.R.Ia&&this.O.test(this.R.Ia.qurl))return this.R.Ia}ga(){return{xhr:!0}}};class Tf extends U{constructor(a,b){super();this.R=a;this.Fa=b}B(){return this.R.J.g.ia.querySelector(document,this.Fa)}};class Uf extends U{constructor(a,b){super();this.R=a;this.element=b}B(){const a=this.element.evaluate();if(a)return this.R.J.g.G.innerHTML(a)}};class Vf extends U{constructor(a,b,c){super();this.element=b;this.Od=c}B(){const a=this.element.evaluate();if(a)return a.getAttribute(this.Od)}};class Wf extends U{constructor(a,b){super();this.href=b}B(){const a=this.href.evaluate();try{return new URL(a)}catch(b){}}ga(){return Q(this.href)}K(a){T(this.href,a)}};class Xf extends Wf{constructor(a,b,c){super(a,b);this.ua=c}B(){const a=super.B();if(a)return a[this.ua]}};class Yf extends Xf{constructor(a,b,c,d){super(a,b,"searchParams");this.la=c;this.O=d}B(){var a=super.B();if(a&&(a=a.getAll(this.la))&&a.length!==0)return this.O?a.find(b=>this.O.evaluate(b)):a.map(encodeURIComponent).join("&")}};class Zf extends Xe{B(){if(!this.R.mc)return"";const a=this.R.mc.args;return a.length===0?"":"["+a.join(",")+"]"}ga(){return{console:!0}}};class $f extends U{constructor(a,b,c,d){super();this.R=a;this.method=b;this.rb=Xa(c,d?"i":"");a.Xe.add(b)}B(){if(!this.R.mc)return!1;const {method:a,args:b}=this.R.mc;return a!==this.method?!1:b.some(this.rb.test.bind(this.rb))}ga(){return{console:!0}}};class ag extends U{constructor(a,b){super();this.O=b}B(){return{Ka:this.O.evaluate(),Ug:!0}}ga(){return me(this.O)}K(a){T(this.O,a)}ea(a,b){this.O.ea(a,b)}ca(){this.O.ca()}M(){this.O.M()}};const bg=(a,b)=>{if(typeof b==="number"||typeof b==="string"||typeof b==="boolean"||b===null)return b;if("$p"in b)return b=b.$p.split("/").slice(1).map(ec),E(a,b,M);throw Error(`Unsupported descriptor "${JSON.stringify(a)}"`);},cg=(a,b)=>c=>{const d=bg(c,a);if(d===M)return!1;c=bg(c,b);return c===M?!1:d===c};
class dg extends U{constructor(a,b){super();this.R=a;Sa(JSON.stringify(b,cc));if(b.o==="eq")a=cg(...b.a);else throw Error(`unsupported operation "${b.o}"`);this.O=a;this.state={me:-1,qc:-1}}B(){const a=this.R.ib||[],b=a.slice(this.state.qc+1).some(this.O);b&&(this.state.me=this.state.qc,this.state.qc=a.length-1);return b}ga(){return{timeline:!0}}ca(){this.state.qc=this.state.me}M(){this.state.me=this.state.qc}ea(a,{ib:b}){b=b.findLastIndex(({id:c})=>a.id===c);this.state={me:b,qc:b}}};class eg extends U{constructor(a,b,c,...d){super();this.la=b;this.O=d}B(){const a=this.O.map(c=>c.evaluate());let b=!1;this.la===fg&&a.every(c=>c.Ka)&&(b=!0);this.la===gg&&a.some(c=>c.Ka)&&(b=!0);b?this.O.forEach(c=>{c.M()}):this.O.forEach(c=>{c.ca()});return{Ka:b,Ug:!0}}ga(){return this.O.reduce((a,b)=>({...Q(b),...a}),{})}K(a){this.O.forEach(b=>T(b,a))}ea(a,b){this.O.forEach(c=>{c.ea(a,b)})}ca(){this.O.forEach(a=>{a.ca()})}M(){this.O.forEach(a=>{a.M()})}}var fg=0,gg=1;var hg={LogicalClause:pe,ValueClause:te,EventClause:ve,SessionEventClause:we,EventValue:xe,NE:ag,E:ue,MDE:Af,HE:ye,MAE:Pf,MNE:eg,Not:Fe,Is:Ge,Contains:He,StrCmp:Ie,Between:Me,Compare:Ne,IsTrue:Re,IsNotNull:Se,HasKey:Te,KeyValue:Ve,Matches:Ue,Exists:We,DV:ze,Sum:Ae,V:Be,RE:Ce,PF:De,CV:Ee,FormSubmitted:Ye,FormFieldFilled:Ze,FormFieldSubmittedValue:$e,FieldFilledNode:ef,SEventValue:af,EventTimestamp:bf,FirstHit:cf,SessionEngagementTime:df,ElementClicked:ff,ElementClickedNode:gf,CookiePresent:lf,CookieValue:mf,
JSValue:pf,JSValueEx:qf,XHR:Sf,XHRRequest:rf,XHRResponse:sf,XHRResponseHeader:vf,XHRRequestHeader:wf,XHRResponseHeaderValue:Nf,XHRRequestHeaderValue:Of,JSONPath:yf,JSONPathValue:zf,ObjPath:If,ObjPathValue:Kf,ObjSearch:Lf,ObjSearchValue:Mf,WV:Jf,SelectorPresent:hf,SelectorElement:Tf,SelectorHtml:Uf,SelectorAttribute:Vf,SelectorText:jf,SelectorValue:kf,URLValue:Wf,URLPropValue:Xf,URLParamsValue:Yf,VXF:Cf,XFCC:Df,XFRR:Ef,XFJPar:Ff,XFPK:Gf,XFMG:Hf,ConsoleMatch:$f,Console:Zf,Timeline:dg};
const ig=new window.Map([[-56,{ja:2}],[-57,{ja:2}],[-58,{ja:2}],[-59,{ja:2}],[-60,{ja:2}],[-61,{ja:2}],[-65,{ja:2}],[-82,{ja:1,Ca:1}],[-83,{ja:1,Ca:1}],[-84,{ja:1,Ca:1}],[-85,{ja:1,Ca:1}],[-86,{ja:1,Ca:1}],[-87,{ja:1,Ca:1}],[-88,{ja:1,Ca:1}]]);
function P(a,b,c,d=null,e=!1){b.id!==0&&(c=Pa(c).substring(0,a.J.D.config.maxStoredEventLength));if(b.di&&!c)return!1;if(b.kd&&!a.ob)return a.M.push({event:b,value:c,bc:d}),!1;var f=b.id;b.pe&&(f=b.pe);var g={i:f,f:b.flags,v:c,t:b.ka?b.ka:a.J.g.Z.W()},h=d?d.hash:c;jg(a,b)&&(h=Sa(h));if(f!==0&&a.K.has(`${f}:${h}`)||c===null&&a.K.has(`${f}:`)||f!==0&&a.B[f]&&(a.B[f].x===1||a.B[f][h]))return!1;b.Ca?b.Ca==2&&(a.B[f]||(a.B[f]={}),a.B[f][h]=1):(kg(a,b),a.B[f]={x:1});if(b.ja)b.ja===2&&a.K.add(`${f}:${h}`);
else{if(a.qa[f])return!1;a.qa[f]=1}if(b.id!=0){h={id:f,value:c,timeStamp:b.ka};d!==null&&(h.hash=d.hash);a.ib.push(h);f=a.la;try{f.Ta.Storage.setItem.call(window.localStorage,"QEventChannel",f.Ta.stringify(h))}catch(k){}}d!==null&&(g.h=d.hash,g.ev=d.value);(b.flags&64)>0?a.J.fa.set("cv",c):(b.flags&128)>0&&a.ob&&(a.ob.abn=c);(b.flags&1)>0&&a.J.fa.set("cv",null);lg(a,b,g,c,e).catch(ua);return!0}
function mg(a,b){var c=b.t;const d=b.v;if(!c||!d)return b;b=[a];for(let e=0;e<d.length;++e)b.push(mg(a,d[e]));c=new hg[c](...b);c.J=a.J;return c}function kg(a,b){var c=b.id,d;for(d in b.kh)b.kh.hasOwnProperty(d)&&delete a.ea[d][c];delete a.Qb[c]}
function ng(a,b,c,d=null){var e=b.id;b.pe&&(e=b.pe);if(a.qa[e]!==1){if(e<0&&ig.has(e)){var f=ig.get(e);f.ja!==void 0&&(b.ja=f.ja);f.Ca!==void 0&&(b.Ca=f.Ca)}if(b.kd&&b.event){f=b.event;var g=null,h=f.ga();for(k in h)h.hasOwnProperty(k)&&(g=k);T(f,g);var k=f.evaluate();k.Ka&&(c=Pa(k.value))}return a.K.has(`${e}:${d?d.hash:c}`)||c===null&&a.K.has(`${e}:`)?!1:P(a,b,c,d)}}function og(a){for(var b=0;b<a.M.length;b++)ng(a,a.M[b].event,a.M[b].value,a.M[b].bc)}
function pg(a,b){var c=null;a.ib.forEach(function(d){d.id==b&&(c=d)});return c}
async function qg(a,b,c){let d=null;const e=a.ea[b];if(e){var f=!1,g;for(g in e)try{if(e.hasOwnProperty(g)){var h=e[g];d=g;if(!h.kd||a.ob){var k=h.event;T(k,b);h.ka=!h.ka||h.ka<c?c:h.ka;a.Ye=g;var l=k.evaluate();a.Ye=null;l.Ka&&(l.Wa&&(l.Wa={hash:await Ub(a.J.g.G.stringify(l.Wa,cc)),value:l.Wa}),P(a,h,l.value,l.Wa,l.Ug)&&(f=!0))}}}catch(n){if(!a.ua){a.ua=!0;console.error(`Error evaluating Quantum Event${d?` (id: ${d})`:""}: `,n);var m=Error();rg(a.J,"EventEngine--"+n+":"+b+":EventId="+d+"\n"+(m.stack?
m.stack.toString():""))}}if(f){for(g in a.Qb)a.Qb.hasOwnProperty(g)&&a.Qb[g]&&T(a.Qb[g].event,"event");b!=="timeline"&&qg(a,"timeline",a.J.g.Z.W())}}}
function sg(a,b){const c=new Set;a.ob=b;b.E.forEach(function(d){d={id:d.i,value:d.v,timeStamp:d.t,Ai:d.c,hash:d.h};a.ib.push(d);var e=d.id,f=a.O[e];f&&c.add(f);!f&&e<0&&ig.has(e)&&(f=Object.assign(d,ig.get(e)));if(f&&!f.ja||!f)f&&kg(a,f),a.qa[e]=1;f&&f.ja===2&&a.K.add(`${e}:${d.hash||d.Ai||d.value}`)});for(const d of c)ne(d.event,d,{ib:a.ib});og(a);qg(a,"eventinfo",a.J.Jb)}
function tg(a,b){a.Xg=(b.id?"#"+b.id:b instanceof window.HTMLElement&&a.J.g.G.innerText(b))||a.J.g.G.textContent(b);a.$b=b;a.Jd=b;a.J.oa.lastClicked=b;qg(a,"clicked",a.J.g.Z.W());a.Jd=null}function ug(a,b){a.xf=b;a.J.oa.lastField=b;qg(a,"fieldFilled",a.J.g.Z.W())}function vg(a,b){a.mc=b;qg(a,"console",a.J.g.Z.W());a.mc=null}function jg(a,b){return!!(!a.J.D.config.temp.isPivot&&b.flags&131102||b.flags&256)}
async function lg(a,b,c,d,e=!1){if(jg(a,b)){const f=await he(a.J.pa,d);f?(c.qenc=f,c.v=await ge(a.J.pa,d),c.c=Sa(d)):c.v=O(d)}a.J.Ha.La(`event-engine:${b.id}`,c);e?wg(a.J,{i:c.i,t:c.t,f:0,v:""}):V(a.J,"E",c)}
class xg{constructor(a,b){this.ob=this.Ye=null;this.ib=[];this.J=a;this.ea={};this.Qb={};this.O={};this.mc=this.Kd=this.Ia=this.yf=this.Af=this.xf=this.Jd=this.$b=this.Xg=null;this.Xe=new Set;this.K=new Set;this.B={};this.M=[];this.qa={};this.ua=!1;this.ca={};this.Oa=b;this.la=new ke(this.J,this.J.g.G,this.cb.bind(this));this.load(this.J.Ea,this.Oa)}Ve(){this.la.Ve()}load(a,b){if(b=b.events)for(let d=0;d<b.length;++d){let e;try{e=b[d];if(!e)continue;if(this.ca[e.u]&&this.ca[e.u]==="n")continue;if(!this.ca[e.u]&&
!(new RegExp(e.u)).test(a)){this.ca[e.u]="n";continue}this.ca[e.u]="y";const f=e.i;var c=e.m;const g={id:f,pe:e.oid,Ca:c===2||c==="2"?2:c?1:0,ja:e.s,flags:e.f,kd:e.sessionInfoReq,Ji:e.evalAlways?!e.evalAlways:!0,di:e.excludeBlank,Ki:0,event:mg(this,e.v)};if(g.ja==2||g.ja==0)g.kd=!0;g.Ca>0&&g.ja==2&&(g.Ca=2);const h=g.kh=Q(g.event);for(const k in h){if(!h.hasOwnProperty(k))continue;let l=this.ea[k];l||(l=this.ea[k]={});l[f]=g}this.Qb[f]=g;this.O[f]=g}catch(f){console.error(`QM: failed to load event${e&&
e.i?` (id: ${e.i})`:""}:`,f)}}}bg(){qg(this,"pageready",this.J.Jb);qg(this,"dom",this.J.Jb)}kb(){qg(this,"engagement",this.J.g.Z.W())}cb(a){this.ib.push(a)}};function yg(a,b){"persist"in a.B||(a.B.persist=[]);a.B.persist.push(b)}class zg{constructor(){this.B={}}La(a,b){a in this.B&&this.B[a].forEach(c=>c(b))}};function Ag(a,b){a.B={};try{const c=Bg(a);for(let d=0;d<c.length;d++){const e=a.Ta.Storage.getItem.call(window[c[d]],b);if(e){a.B=a.Ta.Ra(e);break}}}catch(c){}Cg(a,a.B)&&a.clear()}function Dg(a){try{window.addEventListener("storage",b=>{b.key==a.K&&Ag(a,a.K)})}catch(b){}}function Cg(a,b){if(b=E(b,["exp"],!1))if(b=new a.Ta.Date(b),a.J.g.Z.W()>b.getTime())return!0;return!1}function Bg(a){return a.J.D.config[a.ca].filter(b=>b=="localStorage"||b=="sessionStorage")}
function Eg(a,b,c=null,d=!0){try{const e=a.Ta.stringify(a.B),f=Bg(a);for(let g=0;g<f.length;g++)a.Ta.Storage.setItem.call(window[f[g]],c||a.K,e);d&&a.M.La("persist",b)}catch(e){}}
class Fg{constructor(a,b,c,d){this.J=a;this.K=b;this.ca=c;this.B=null;this.M=new zg;this.Ta=d;Ag(this,this.K);Dg(this)}get(a,b){Cg(this,this.B)&&this.clear();return E(this.B,a,b)}set(a,b){if(typeof a!=="string")throw Error("path must be a string");Ca(this.B,a,b);Eg(this,{t:"set",path:a,value:b});return!0}jb(a){Da(this.B,a)&&Eg(this,{t:"set",path:a,value:null})}import(a){this.B={...this.B,...a};Eg(this,"import")}clear(){this.B={};Eg(this,"clear")}archive(a){Eg(this,"archive",a,!1)}restore(a){Ag(this,
a);Eg(this,"restore",this.K,!0)}};function Gg(a,b,c){return new Promise(function(d,e){function f(r){x||(x=!0,d({ke:r}))}async function g(){try{await navigator.storage.getDirectory(),f(!1)}catch(r){const q=(r instanceof Error&&typeof r.message==="string"?r.message:String(r)).includes("unknown transient reason");f(q)}}function h(){const r=String(Math.random());try{const q=indexedDB.open(r,1);q.onupgradeneeded=w=>{w=w.target.result;try{w.createObjectStore("t",{autoIncrement:!0}).put(new Blob),f(!1)}catch(D){(D instanceof Error&&typeof D.message===
"string"?D.message:String(D)).includes("are not yet supported")?f(!0):f(!1)}finally{w.close(),indexedDB.deleteDatabase(r)}};q.onerror=()=>f(!1)}catch(q){f(!1)}}async function k(){var r;if(typeof((r=navigator.storage)==null?void 0:r.getDirectory)==="function")await g();else if(navigator.maxTouchPoints!==void 0)h();else a:{r=window.openDatabase;const q=window.localStorage;try{r(null,null,null,null)}catch(w){f(!0);break a}try{q.setItem("test","1"),q.removeItem("test")}catch(w){f(!0);break a}f(!1)}}function l(){navigator.webkitTemporaryStorage.queryUsageAndQuota(function(r,
q){r=Math.round(q/1048576);q=Math;var w=q.round;let D,C,t;var p=(t=window==null?void 0:(D=window.performance)==null?void 0:(C=D.memory)==null?void 0:C.jsHeapSizeLimit)!=null?t:1073741824;f(r<w.call(q,p/1048576)*2)},function(r){e(Error("detectIncognito somehow failed to query storage quota: "+r.message))})}function m(){const r=window.webkitRequestFileSystem;r(0,1,function(){f(!1)},function(){f(!0)})}async function n(){var r;if(typeof((r=navigator.storage)==null?void 0:r.getDirectory)==="function")try{await navigator.storage.getDirectory(),
f(!1)}catch(q){r=(q instanceof Error&&typeof q.message==="string"?q.message:String(q)).includes("Security error"),f(r)}else{const q=indexedDB.open("inPrivate");q.onerror=w=>{q.error&&q.error.name==="InvalidStateError"&&w.preventDefault();f(!0)};q.onsuccess=()=>{indexedDB.deleteDatabase("inPrivate");f(!1)}}}let x=!1;(async function(){a?await k():b?self.Promise!==void 0&&self.Promise.allSettled!==void 0?l():m():c?await n():navigator.msSaveBlob!==void 0?f(window.indexedDB===void 0):f(!1)})().catch(e)})}
;function L(a,b,c,d="info"){b={t:"m",ctx:a.kf(),sub:a.sub,n:b,v:c,l:d};a.log(b)}function Hg(a){a.B===null&&(a.B=a.G.setTimeout(()=>{a.flush()},a.ca))}
class Ig{constructor({G:a,D:b,sub:c,kf:d}){this.G=a;this.M="";this.sub=c;this.kf=d;this.buffer=[];this.K=0;this.B=null;this.ca=b.config.publishInterval||3500;b.config.ingestBaseURL&&(this.M=b.config.ingestBaseURL.replace(/\/+$/,"")+"/lgs/api/v1/logs")}log(a){if(!this.M)return!1;const b=this.G.stringify(a).length;this.K+b>=6E4&&this.flush();this.buffer.push(a);this.K+=b;Hg(this);return!0}flush(){this.B!==null&&(this.G.clearTimeout(this.B),this.B=null);if(this.buffer.length&&this.M){var a=this.buffer;
this.buffer=[];this.K=0;window.navigator.sendBeacon(this.M,this.G.stringify(a))}}};const Jg=":checked :empty :host :invalid :last-child :modal :nth-child(n) :only-child :read-only".split(" ").sort(),Kg={'"':"&quot;",">":"&gt;",":":"&#58;","\u00a7":"&sect;","[":"&#91;","]":"&#93;","&":"&amp;"},Lg=/:|>|"|\u00a7|\[|]|&/g;
function Mg(a,b,c){if(b===document)return"html";var d=new $c(c.Yh,a.L);const e=Y(a.L,b).toLowerCase();var f=a.L.g.G.parentNode(b);let g=a.L.g.G.parentElement(b),h=">";g||(g=f&&f.host)&&(h=">\u00a7>");f=g?a.L.g.G.Array.from(a.L.g.G.children(g)):[b];const k=f.indexOf(b);let l=e;var m={};for(let n=0;n<c.Ag.length;++n){const x=c.Ag[n];if(b.hasAttribute(x)&&!cd(a.L,b,x))switch(x){case "class":if(b.classList.length===0)continue;const {name:r,value:q}=d.transform(b,x);if(r==="class"){a.B.setAttribute("class",
q);m[r]=a.L.g.G.Array.from(a.B.classList).sort().join(" ").replace(Lg,function(C){return Kg[C]});continue}m[r]=q.replace(Lg,function(C){return Kg[C]});break;default:const {name:w,value:D}=d.transform(b,x);m[w]=D.replace(Lg,function(C){return Kg[C]})}}Object.entries(m).sort(([n],[x])=>n<x?-1:1).forEach(([n,x])=>{l+=`[${n}="${x}"]`});for(d=0;d<Jg.length;++d)switch(m=Jg[d],m){case ":checked":b.checked===!0&&(l+=m);break;case ":empty":a.L.g.ia.matchesSelector(b,":empty")&&(l+=m);break;case ":host":b.shadowRoot&&
(l+=m);break;case ":invalid":try{b.validity&&!b.validity.valid&&(l+=m)}catch(n){}break;case ":last-child":f.length-1===k&&(l+=m);break;case ":modal":e==="dialog"&&a.L.g.supports.Gf&&a.L.g.ia.matchesSelector(b,":modal")&&(l+=m);break;case ":nth-child(n)":l+=`:nth-child(${k+1})`;break;case ":only-child":f.length===1&&(l+=m);break;case ":read-only":["input","textarea"].includes(e)&&a.L.g.ia.matchesSelector(b,m)&&(l+=m)}return g?`${Mg(a,g,c)}${h}${l}`:l}
function Ng(a,b){return Mg(a,b,{Ag:a.L.D.config.elementVeinAttributes,Yh:a.L.D.aa.Ab})}class Og{constructor(a){this.L=a;this.B=a.g.G.createElement("div")}};const Pg=/(?:\s{2,}|\n|\t|\r)/g;
function Qg(a,b){const c=a.L;let d="";d=(c.g.G.tagName(b).toLowerCase()==="slot"?b.assignedNodes():[b]).reduce((e,f)=>{if(e.length>100)return e;if(f.nodeType===3){var g=a.L,h=g.g.G.textContent(f);f.nodeType===3&&(Rg(g,f)||Sg(g,f))&&(h=O(h));return`${e} ${h}`}for(f=document.createTreeWalker(f,window.NodeFilter.SHOW_TEXT);f.nextNode()&&e.length<100;){g=f.currentNode;h=Y(c,c.g.G.parentNode(g));if(h==="style"||h==="script")continue;h=c.g.G.textContent(g);if(Rg(c,g)||Sg(c,g))h=O(h);h.length&&(e=`${e} ${h}`)}return e},
"");d=d.replace(Pg," ").trim().substring(0,100);return Pa(d)}class Tg{constructor(a){this.L=a}};const Ug=new Map,Vg=/,(?!(?:[^[\]]+\])|(?:[^()]+\)))\s*/g,Wg=/(?:^|\s)S#(?:\s|$)/,Xg=a=>{Ug.has(a)||Ug.set(a,a.split(Vg));return Ug.get(a)},Yg=(a,b,c="")=>{if(a.parentRule){const d=b.Array.from(a.parentRule.cssRules).indexOf(a);c=c?`${d} ${c}`:d+"";return Yg(a.parentRule,b,c)}a=b.Array.from(a.parentStyleSheet.cssRules).indexOf(a);return c?`${a} ${c}`:a+""};function Zg(a,b){a.B.push(b);return a.B.length-1}function $g(a){return a.mode[a.mode.length-1]}function ah(a,b){const c=$g(a);if(b.nodeType!==1)var d=null;else d=a.ma.get(b)||{},d=d.jd===!1?!1:a.oe||d.jd===!0?!0:a.Ob(b);if(d)a.mode.push("scrub");else{const e=a.ma.get(b)||{};b=e.encrypt===!0?!0:e.encrypt===!1?!1:a.Nb(b);c==="scrub"&&d===!1?b?a.mode.push("encrypt"):a.mode.push(null):b&&c!=="scrub"?a.mode.push("encrypt"):c==="encrypt"&&b===!1?a.mode.push(null):a.mode.push(c)}}
class bh{constructor(a){this.G=a.G;this.ma=a.ma;this.oe=a.oe;this.ee=a.ee;this.ze=a.ze;this.ye=a.ye;this.url=a.url;this.He=a.He;this.Ob=a.Ob;this.Nb=a.Nb;this.wb=a.wb;this.supports=a.supports;this.Db=a.Db;this.da=a.da;this.mode=[null];this.Ib=0;this.namespaceURI=null;this.B=[];this.De=[]}};const ch=new Set(["INPUT","TEXTAREA","SELECT","OPTION","OUTPUT"]),eh=(a,b)=>{const c=[];for(let d=0;d<a.length;++d){const e=dh(a[d],b);e!==null&&c.push(e)}return c},fh=(a,b)=>{const c=b.namespaceURI;ah(b,a);var d=$g(b);const e=b.ma.get(a)||{};var f=!1;let g=null;a instanceof window.HTMLElement||a.namespaceURI==="http://www.w3.org/1999/xhtml"||(g=a.namespaceURI);const h=g?b.G.tagName(a):b.G.tagName(a).toUpperCase(),k={n:h,q:b.Db(a).da};h==="SCRIPT"&&(f=!0);!e.$c&&h==="DIALOG"&&b.supports.Gf&&b.G.matches(a,
":modal")&&(k.m=!0);!e.$c&&a.hasAttribute("popover")&&b.supports.gh&&b.G.matches(a,":popover-open")&&(k.pop=!0);var l=!1;if(h==="STYLE"&&a.sheet)try{l=a.sheet.cssRules.length>0}catch(m){}(l||h==="LINK")&&b.De.push({node:a,sb:k});g!==c&&(b.namespaceURI=g,k.N=g);b.Kf=h;k.a=f?[]:eh(a.attributes,b);b.Kf=null;h==="IFRAME"&&typeof b.Cc==="string"&&k.a.push({2:{n:"qframe",v:b.Cc}});f={};if(h==="INPUT"){l=a.type.toLowerCase();if(l==="checkbox"||l==="radio"){const m=a.getAttribute("checked"),n=a.checked;m!==
null&&n===!1&&(f.checked=!1);m===null&&n===!0&&(f.checked=!0)}if(l==="date"||l==="datetime-local"||l==="month"||l==="number"||l==="time"||l==="week"){for(const m of k.a)if(m[2].n.toLowerCase()==="type"){m[2].v="text";break}k.a.push({2:{n:"data-qm-original-type",v:l}})}}(h==="STYLE"&&!g||h==="LINK")&&a.disabled&&(f.disabled=!0);Object.keys(f).length&&(k.po=f);"value"in a&&ch.has(h)&&dc(a.value)&&(d==="scrub"?k.vm=O(a.value):d==="encrypt"?(k.vm=O(a.value),k.ve=Zg(b,a.value)):k.v=a.value);(d=b.G.shadowRoot(a))&&
!e.$c&&(k.sr=dh(d,b));d=b.G.childNodes(a);d.length&&!e.$c&&(h==="TITLE"&&b.ye&&(d=[document.createTextNode(b.url)]),k.C=eh(d,b));h!=="SLOT"||e.$c||b.G.getRootNode(a).slotAssignment!=="manual"||(a=a.assignedNodes({flatten:!0}).map(m=>b.ee(m)).filter(Boolean),a.length&&(k.sn=a));b.namespaceURI=c;b.mode.pop();return k},gh=(a,b)=>{const c=$g(b),d={q:b.Db(a).da};a.nodeValue&&(c==="scrub"?d.vm=O(a.nodeValue):c==="encrypt"?(d.vm=O(a.nodeValue),d.ve=Zg(b,a.nodeValue)):d.v=a.nodeValue);return d},hh=(a,b)=>
{const c={q:b.Db(a).da};b.De.push({node:a,sb:c});a=b.G.childNodes(a);a.length&&(c.C=eh(a,b));return c},dh=(a,b)=>{var c=a.nodeType;if(c===1||c===3||c===8||c===9||c===11)b.Db(a).da=b.da();var d=b.He[c];d&&(c===1&&b.Ib++,d(a,b));switch(a.nodeType){case 1:return{1:fh(a,b)};case 2:{c=$g(b);d=b.ma.get(a.ownerElement)||{};let f=a.name,g=a.value,h=f.toLowerCase();if(b.wb.has(f)||wa.has(h)||d.wb&&d.wb.includes(f)||b.Kf==="IFRAME"&&(h==="sandbox"||h==="srcdoc"))a=null;else{b.Kf==="IFRAME"&&f==="src"&&(f="data-original-src");
var e=d.Yf||[];for(const {Od:k,rb:l,ue:m,dh:n}of e)f===k&&(n&&(f=n,h=f.toLowerCase()),g=g.replace(l,m));e={n:f};if(h==="integrity")e.v="";else{if(g){let k=!0;h==="data-select-value"||h==="placeholder"||h==="value"||h==="label"?c==="scrub"?(e.vm=O(g),k=!1):c==="encrypt"&&(e.vm=O(g),e.ve=Zg(b,g),k=!1):d.$d&&d.$d.includes(f)&&(e.vm=O(g),e.ve=Zg(b,g),k=!1);k&&(e.v=g)}a.namespaceURI&&(e.N=a.namespaceURI)}a=e}}return a===null?null:{2:a};case 3:return{3:b.G.tagName(b.G.parentNode(a))==="SCRIPT"?{v:" "}:
gh(a,b)};case 4:return{4:gh(a,b)};case 5:return{5:{}};case 6:return{6:{p:a.publicId,s:a.systemId}};case 7:return{7:{t:a.target,d:a.data}};case 8:return{8:b.ze?{v:"",q:b.Db(a).da}:gh(a,b)};case 9:return{9:hh(a,b)};case 10:return b={n:a.name,p:a.publicId,s:a.systemId},a.li&&(b.is=a.li),{a:b};case 11:return b=hh(a,b),b.sa=a.slotAssignment,{b};case 12:return c={p:a.publicId,s:a.systemId},a=b.G.childNodes(a),a.length&&(c.C=eh(a,b)),{c}}};class ih{constructor(){this.gh=this.Gf=!0;try{document.documentElement.matches(":modal")}catch(a){this.Gf=!1}try{document.documentElement.matches(":popover-open")}catch(a){this.gh=!1}}};class jh{constructor(){this.B={}}addEventListener(a,b,c={}){let d=this.B[a];d||(d=this.B[a]=[]);({once:a=!1}=c);d.push({Dg:b,once:a})}removeEventListener(a,b){const c=this.B[a];c&&(this.B[a]=c.filter(function({Dg:d}){return d!=b}))}La(a,b){const c=this.B[a];c&&c.forEach(({Dg:d,once:e})=>{d(b);e&&this.removeEventListener(a,d)})}};const kh=new jh;class lh{constructor(a){this.G=a}matchesSelector(a,b){if(a.nodeType!==1)return!1;if(!a.getRootNode)return this.G.matches(a,b);b=Xg(b);for(const c of b){a:{b=a;const d=c.split(Wg);for(let e=d.length-1;e>=0;--e){if(!this.G.matches(b,d[e])){b=!1;break a}b=this.G.getRootNode(b).host;if(!b&&e!==0){b=!1;break a}}b=!0}if(b)return!0}return!1}querySelector(a,b){return this.querySelectorAll(a,b)[0]}querySelectorAll(a,b){var c=Xg(b);b=[];const d=[];for(const e of c){c=e.split(Wg);if(c.length<2){d.push(e);continue}let f=
[...this.G.pb(a,c[0])];for(let g=1;g<c.length;++g){const h=c[g];f=[].concat(...f.map(k=>this.G.shadowRoot(k)?[...this.G.pb(this.G.shadowRoot(k),h)]:[]))}b=b.concat(f)}d.length>0&&(b=b.concat([...this.G.pb(a,d.join(","))]));return b}closest(a,b){return b?Xg(b).map(c=>({node:a,hf:c.split(Wg)})).sort((c,d)=>d.hf.length-c.hf.length).map(({node:c,hf:d})=>{var e=c;c=d.length-1;a:for(;e;){let f=e.closest(d[c]);if(!f){e=e.getRootNode?e.getRootNode().host:null;continue}--c;for(e=f;c>=0;){e=e.getRootNode?e.getRootNode().host:
null;if(!e)return null;if(!this.G.matches(e,d[c])){c=d.length-1;continue a}--c}e=f;break}return e}).reduce((c,d)=>{if(!d)return c;if(!c)return{node:d,depth:Ra(d)};const e=Ra(d);return e>c.depth?{node:d,depth:e}:c},{node:null,depth:0}).node:null}};class mh{constructor(a,b){this.G=a;this.D=b}domain(){try{var a=this.D.config.cookieDomain;if(a!==null&&a!==void 0)return this.D.config.cookieDomain;var b=this.G.Storage.getItem.call(window.sessionStorage,"qmd");if(b!==null&&b!==void 0)return this.D.config.cookieDomain=b;const c=window.location.host.split(":")[0].split(".");a=null;for(b=2;b<=c.length;b++){const d=c.slice(Math.max(c.length-b,0)).join(".");this.set({["qm-rc"]:"",domain:d});if(this.getAll().indexOf("qm-rc")>-1){a=d;break}}if(a!==null)return this.jb({["qm-rc"]:"",
domain:a}),this.G.Storage.setItem.call(window.sessionStorage,"qmd",a),this.D.config.cookieDomain=a}catch(c){}return window.location.hostname}set(a){a.path="/";if(!a.domain){var b=this.domain();a.domain=b}b=[];for(let c in a)a.hasOwnProperty(c)&&b.push(`${c}=${a[c]}`);window.location.protocol=="https:"&&(b.push("secure"),b.push(`samesite=${this.D.config.sameSiteFlag}`));b.push("");this.G.ra.set(b.join(";"))}jb(a){this.set({...a,expires:"Thu, 01 Jan 1970 00:00:00 GMT"})}get(a){var b=this.getAll();b=
Object.entries(Qa(b));for(let [c,d]of b)if(decodeURIComponent(c)===a)return decodeURIComponent(d);return null}getAll(){return this.G.ra.get()}};class nh extends Error{constructor(a){super(a)}}class oh extends Error{constructor(a){super(a)}}class ph extends Error{constructor(){super()}}
function qh(a,b){const c=new URL(wb(a.D.config,a.sub),window.location.href);for(const [f,g]of Object.entries(b))c.searchParams.set(f,g);a:if(b=a.D.config,b.proxyIngest&&(b=b.ingestParamsCallback)){try{var d=window[b];if(typeof d!=="function")break a;var e=d()}catch(f){L(a.ba,"ingest:params-callback-error",{callback:b,message:f&&f.message},"warn");break a}if(e)if(d=a.G.pd(e),d!=="[object URLSearchParams]")console.warn('QM: ingest params callback "'+b+'" must return a URLSearchParams object but returned '+
d+". Additional ingest params will not be applied."),L(a.ba,"ingest:params-callback-type",{callback:b,type:d},"warn");else try{a=0;for(const f of e.entries()){if(a++>=1E3)break;const g=f[0];g&&!c.searchParams.has(g)&&c.searchParams.set(g,f[1])}}catch(f){}}return c}function rh(a,b,c){return window.navigator.sendBeacon(qh(a,b).href,c)}
function sh(a,b,c,d,e){a.B>0&&(c.E=a.B);const f=qh(a,c);var g={};e&&(g["Content-Type"]=e);const h=a.G.contentWindow;g=new h.Request(f.href,{method:b,headers:g,body:d,credentials:"omit"});return h.fetch(g).then(k=>{if(k.status!==200){const l=f.searchParams;throw new nh("XHR_STATUS="+k.status+"-for-"+l.get("b")+"-"+l.get("S")+"-"+l.get("u")+"-"+`Q:${l.get("Q")||"-"}`+"-"+k.status||"NA");}a.B=0;return k}).catch(k=>new Promise((l,m)=>{if(a.B<a.D.config.sendRetries)++a.B,setTimeout(()=>{sh(a,b,c,d,e).then(l).catch(m)},
1500*a.B);else{var n=d?d.byteLength||d.size||d.length||"?":0;m(new oh(k instanceof nh?k.message:`FETCH_ERROR=${k.name}:${k.message}-SIZE=${n}`))}}))}function th(a,b,c){return sh(a,"PATCH",b,c,"application/json")}class uh{constructor(a,b,c,d){this.G=a;this.D=b;this.sub=c;this.ba=d;this.B=0}get(a){return sh(this,"GET",a)}};function vh(a){a.M=0;a.B=!1}async function wh(a,b){b=(new TextEncoder).encode(b);const {readable:c,writable:d}=new window.CompressionStream("deflate"),e=d.getWriter();e.write(b);e.close();return new Uint8Array(await (new a.G.contentWindow.Response(c)).arrayBuffer())}
class xh{constructor(a,b,c,d,e){this.J=a;this.D=c;this.G=e;this.ca=d;this.K=this.M=0;this.ea=b;this.B=!1}async send(a,b){this.B=!0;const c=this,d=this.M++;let e=a;const f=a.length,g=this.ea(d,b);g.S=this.K;g.b=f;g.z=2;if(this.D.config.enableCompression&&"CompressionStream"in window&&"TextEncoder"in window&&!c.J.$a)try{e=await wh(this,e),g.z=1}catch(h){}if(c.J.$a)a=rh(c.ca,g,e),c.B=!1,a||c.J.xa("DATA_LOSS",`sendBeacon failed to send ${f/1E3}kb on unload`);else return sh(c.ca,"POST",g,e,"text/plain").then(async h=>
{c.B=!1;if(d===0&&!g.Q){h=await h.text();if(h==="<>")throw new ph;return h}c.K+=f},h=>{c.B=!1;throw h;})}};const yh=a=>a.toLowerCase().split("/").filter(b=>b);function zh(a){window.addEventListener("message",async b=>{var c=b.data;if(c&&typeof c=="object"&&c.namespace==="quantum"&&c.messageId!==void 0){const {method:e,url:f,body:g,messageId:h,response:k,error:l}=c;var d=yh(f);if(d[d.length-1]==="connect"||c.scope===a.sub)if(a.B.size>50&&L(a.ba,"MessageHandler: high message count",{size:a.B.size},"warn"),k){if(g&&!g.ack&&L(a.ba,"MessageHandler:missing ack",{method:e,url:f},"error"),c=a.B.get(h))l?c.reject(l):c.resolve(g),a.B.delete(h)}else{d=b.source;let m=
void 0,n=void 0;try{n=await Ah(a,{method:e,url:f,body:g,context:{frame:()=>Bh(a,b),sender:d,scope:c.scope}})}catch(x){m=x}n===void 0&&m===void 0||d.postMessage({messageId:h,method:e,url:f,body:n,response:!0,error:m,namespace:"quantum",scope:a.sub},"*")}}},!1)}function Ch(a,b,c){a=a.G.pb(b,"iframe, frame");for(const d of a)if(d.contentWindow===c)return d;return null}
function Bh(a,b){return new Promise(c=>{const d=(e=0)=>{if(e>a.Hb)c(null);else{var f=Ch(a,document,b.source);if(f)return c(f),f;for(const g of a.dc)if(f=Ch(a,g,b.source))return c(f),f;setTimeout(d,a.Kb,e+1)}};d()})}async function Ah(a,b){const c=b.method;var d=b.url;const e=b.body;b=b.context;if(typeof c!=="string"||typeof d!=="string")throw Error("MessageHandler:400");d=yh(d);a=E(a.Ma,[c.toUpperCase(),...d],null);if(a===null)throw Error("MessageHandler:404");return await a(e,b)}
class Dh{constructor(a={}){this.ba=a.ba;this.sub=a.sub;this.G=a.G;this.Ma=a.Ma;this.dc=a.dc;this.Hb=a.Hb||5;this.Kb=a.Kb||500;this.B=new Map;zh(this)}Ga(a,{method:b,url:c,body:d}){const e=Ia(),f=new yb;this.B.set(e,f);const g=(h=0)=>{try{a.postMessage({messageId:e,method:b,url:c,body:d,namespace:"quantum",scope:this.sub},"*")}catch(k){L(this.ba,"MessageHandler: unable to post message",{message:k.message,url:c,method:b},"error")}setTimeout(()=>{if(this.B.get(e)){const k=h+1;k>this.Hb?(f.reject(Error("MessageHandler:timeout")),
this.B.delete(e)):g(k)}},this.Kb)};g();return f.promise}};function Eh(a){typeof a.Pa.handleAndroidMessage==="undefined"&&(a.Pa.handleAndroidMessage=b=>{window.dispatchEvent(new CustomEvent("qm-android-sdk-message",{detail:{message:b}}))});window.addEventListener("qm-android-sdk-message",b=>{({detail:{message:b}}=b);const c=a.G.Ra(b);if(c&&typeof c=="object"&&c.namespace==="quantum"&&c.messageId!==void 0){const {method:d,url:e,body:f,messageId:g,response:h,error:k}=c;b=yh(e);if(b[b.length-1]==="connect"||c.scope===a.sub)if(a.B.size>50&&L(a.ba,"AndroidHandler:high message count",
{size:a.B.size}),h){if(f.ack||L(a.ba,"AndroidHandler:missing ack",{method:d,url:e}),b=a.B.get(g))k?b.reject(k):b.resolve(f),a.B.delete(g)}else(async()=>{let l=void 0,m=void 0;try{m=await Fh(a,{method:d,url:e,body:f,context:{scope:c.scope}})}catch(n){l=n.message}m===void 0&&l===void 0||a.Pa.postMessage(a.G.stringify({messageId:g,method:d,url:e,body:m,response:!0,error:l,namespace:"quantum",scope:a.sub}))})()}else L(a.ba,"AndroidHandler:invalid message")})}
async function Fh(a,b){const c=b.method;var d=b.url;const e=b.body;b=b.context;if(typeof c!=="string"||typeof d!=="string")throw Error("AndroidHandler:400");d=yh(d);a=E(a.Ma,[c.toUpperCase(),...d],null);if(a===null)throw Error("AndroidHandler:404");return await a(e,b)}
class Gh{constructor(a={}){this.ba=a.ba;this.sub=a.sub;this.G=a.G;this.Ma=a.Ma;this.Pa=a.Pa;this.timeout=a.timeout||3E3;this.B=new Map;Eh(this)}Ga({method:a,url:b,body:c}){const d=Ia(),e=new yb;this.B.set(d,e);this.Pa.postMessage(this.G.stringify({messageId:d,method:a,url:b,body:c,namespace:"quantum",scope:this.sub}));setTimeout(()=>{this.B.get(d)&&(e.reject(Error("AndroidInterface:timeout")),this.B.delete(d))},this.timeout);return e.promise}};class Hh{constructor(a={}){this.Pa=a.Pa;this.ba=a.ba;this.sub=a.sub;this.timeout=a.timeout||3E3}Ga({method:a,url:b,body:c}){const d=Ia(),e=new yb;if(!this.Pa)return e.reject(Error("IosInterface:404")),e.promise;this.Pa[d]=({body:f,error:g})=>{g?e.reject(g):e.resolve(f);delete this.Pa[d]};this.Pa.postMessage({messageId:d,scope:this.sub,method:a,url:b,body:c});setTimeout(()=>{this.Pa[d]&&e.reject(Error("IosInterface:timeout"))},this.timeout);return e.promise}};function Ih(a){a.channel.addEventListener("to-sdk",b=>{if(b&&typeof b=="object"&&b.namespace==="quantum"&&b.messageId!==void 0){var {method:c,url:d,body:e,messageId:f,response:g,error:h}=b;a.B.size>50&&L(a.ba,"VocHandler: high message count",{size:a.B.size},"warn");if(g){if(e&&!e.ack&&L(a.ba,"VocHandler:missing ack",{method:c,url:d},"error"),b=a.B.get(f))h?b.reject(h):b.resolve(e),a.B.delete(f)}else(async()=>{let k=void 0,l=void 0;try{l=await Jh(a,{method:c,url:d,body:e,context:{}})}catch(m){k=m.message}l===
void 0&&k===void 0||a.channel.La("to-voc",{messageId:f,method:c,url:d,body:l,response:!0,error:k,namespace:"quantum",scope:a.sub})})()}})}async function Jh(a,b){const c=b.method;var d=b.url;const e=b.body;b=b.context;if(typeof c!=="string"||typeof d!=="string")throw Error("VocHandler:400");d=yh(d);a=E(a.Ma,[c.toUpperCase(),...d],null);if(a===null)throw Error("VocHandler:404");return await a(e,b)}function Kh(a){try{delete window[a.oc]}catch(b){}}
function Lh(a){Kh(a);a.B.forEach(b=>{b.reject(Error("VocInterface:destroyed"))});a.B.clear();a.connected=!1}
class Mh{constructor(a={}){this.ba=a.ba;this.sub=a.sub;this.Ma=a.Ma;this.channel=a.channel;this.oc=a.oc;this.timeout=a.timeout||3E3;this.B=new Map;this.connected=!1;Ih(this);try{const b=this.channel;Object.defineProperty(window,this.oc,{value:{addEventListener:b.addEventListener.bind(b),removeEventListener:b.removeEventListener.bind(b),emit:b.La.bind(b)},configurable:!0,enumerable:!1})}catch(b){L(this.ba,"VocInterface: unable to expose channel",{message:b.message},"error")}}Ga({method:a,url:b,body:c}){const d=
Ia(),e=new yb;this.B.set(d,e);this.channel.La("to-voc",{messageId:d,method:a,url:b,body:c,namespace:"quantum",scope:this.sub});setTimeout(()=>{this.B.get(d)&&(e.reject(Error("VocInterface:timeout")),this.B.delete(d))},this.timeout);return e.promise}}function Nh(a,b){a.B.forEach(c=>{c.connected&&c.Ga(b).catch(()=>{})})}class Oh{constructor(){this.B=new Set;this.counter=0}add(a){this.B.add(a)}};class Ph{sample(a,b){const c=d=>{if(Math.random()<a)try{d()}catch(e){}};return b?c(b):c}};const Qh=(a,b)=>{switch(b){case "n":a=parseFloat(a);break;case "i":a=parseInt(a,10);break;case "s":a=`${a}`;break;case "b":a=a==="true"?!0:a==="false"?!1:a===1||a==="1"?!0:a===0||a==="0"?!1:!!a;break;case "d":b=new Date(a);isNaN(b.getTime())||(a=b.toISOString().slice(0,10));break;case "dt":b=new Date(a),isNaN(b.getTime())||(a=b.toISOString())}return a};const Rh={namespace:"alloy",tenant:null,prefix:null,mapping:{}},Sh=a=>{if(a.mapping){const {datastreamId:b,map:c,namespace:d}=a.mapping;a.datastreamId=b;a.mapping=c||Rh.mapping;a.namespace=d||Rh.namespace}return a};function Th(a){if(a.K!==null&&a.ha!==null&&a.za!==null){a.M={ecid:a.K,qmUserIdCookie:a.za,qmSessionIdCookie:a.ha,qmSessionReplayLink:a.J.oa.getReplay()};for(const [b,c,d,e]of a.buffer)try{Uh(a,b,c,d,e)}catch(f){console.warn("Could not send buffered event")}a.buffer=[]}}function Vh(a,b=0){const c=window[a.B.config.namespace];c?(a.ca=c,c("getIdentity").then(d=>{a.K=d.identity.ECID;Th(a)})):b>10?a.disabled=!0:setTimeout(()=>{Vh(a,b++)},500)}function Wh(a,b){a.ha=b;Th(a)}
function Xh(a,b){a.za=b;Th(a)}function Uh(a,b,c,d,e){if(a.M===null)a.buffer.push([b,c,d,e]);else{var f=Yh(a);c=Zh(a,c,d,e);d=[a.ea,a.B.config.prefix,"qmMetadata"].filter(Boolean);Ca(b.xdm,d,{...a.M,...f,...c});a.B.config.datastreamId&&(b.edgeConfigOverrides={datastreamId:a.B.config.datastreamId});a.ca("sendEvent",b).catch(g=>{console.warn("QM: Unable to send mapped data to Adobe:",g.message);L(a.J.ba,"ADOBE:send-failure",{message:g.message})})}}
function Yh(a){a=a.J.Ea;const b=new URL(a);return{url:`${b.origin}${b.pathname}`,urlFull:a,urlPath:b.pathname,urlParameters:b.searchParams.toString()}}function Zh(a,b,c,d){a=a.J.df[b.toString()]||"UNKNOWN";return{eventName:d?"":a,eventValue:d?"":c.toString(),errorName:d?a:"",errorValue:d?c.toString():""}}
function $h(a,{object:b,hh:c,handle:d,event:e,hi:f=null,recursive:g=!1}){for(const k of c){const {q:l,a:m,"a-":n,t:x,v:r,s:q,p:w}=k;r!==void 0?c=r:l.startsWith("$")?(c=f,c=E(c,l.substring(2).split("."),M)):(c=e,c=E(c,l.split("."),M));if(c===null||c==="")continue;if(c===M){L(a.J.ba,"ADOBE:mapping-failure",{item:d,key:l,issue:"key not found"});continue}var h=void 0;if(x==="a"){if(q===void 0&&w===void 0){L(a.J.ba,"ADOBE:schema-failure",{item:d,key:l,issue:"schema|primitive missing for array handling"});
continue}if((q||w)&&!Array.isArray(c)){L(a.J.ba,"ADOBE:array-failure",{item:d,key:l,issue:"Cannot create mapped array from a non-array event value"});continue}if(w)h=c.map(D=>Qh(D,w));else if(q){h=[];for(const D of c)try{c={},$h(a,{object:c,hh:q,handle:d,event:e,hi:D,recursive:!0}),h.push(c)}catch(C){L(a.J.ba,"ADOBE:array-mapping-failure",{item:d,key:l,message:C.message})}}}else h=Qh(c,x);typeof n==="string"?c=[...n.split(".")].filter(D=>D):(c=g?[]:[a.ea,a.B.config.prefix],c=c.concat(...m.split(".")).filter(D=>
D));Ca(b,c,h)}}class ai{constructor(a,b){this.J=a;this.B=new Fc(b,Rh,{},{},Sh,ua);this.B.sc();this.za=this.ha=this.K=this.M=this.ca=null;this.disabled=!1;this.buffer=[]}get ea(){const a=this.B.config.tenant;return a?a.startsWith("_")?a:`_${a}`:a}};function bi(a){a.Da.forEach(b=>{b.hb.forEach((c,d)=>{c.interval&&(ci(a,b,c),a.K.add(d))})})}function di(a){a.K.forEach(b=>{for(const [,c]of a.Da)if(c.hb.has(b)){b=c.hb.get(b);b.hd=a.J.g.G.W();ei(a,c,b);break}});a.K.clear()}
function fi(a,b){a.B.get(b)&&(a.J.D.config.zones.forEach(c=>{const {sel:d,name:e,threshold:f}=c;c=a.J.g.ia.querySelectorAll(b,d);c.length>1&&!e.includes("#")&&!e.includes("[")&&L(a.J.ba,"zones: multiple nodes found with non-placeholder name",{sel:d,name:e,count:c.length},"warn");(c.length>1&&!e.includes("#")&&!e.includes("[")?[c[0]]:c).forEach((g,h)=>{var k=e;if(k.includes("#"))k=k.replace("#",h+1);else if(k.includes("[")){a:{k=k.split("[").pop().split("]").shift();let l=g.getAttribute(k);if(!l){const m=
g.querySelector(`[${k}]`);if(m&&(l=m.getAttribute(k),!l)){k=!1;break a}}k=l}k||(L(a.J.ba,"zones: unable to get zone name from attribute",{sel:d,name:e},"warn"),k=`${k}[${h+1}]`)}h=Ng(a.J.g.rd,g);a.Da.has(k)||a.Da.set(k,{name:k,threshold:f,hb:new Map,We:0,ge:0,dd:!1,cf:h,rh:d,he:null});k=a.Da.get(k);k.hb.has(g)||(h={cf:h,interval:null,hd:null,Va:null,isIntersecting:!1},k.hb.set(g,h),gi(a,g,k,h))})}),a.Da.forEach(c=>{const d=[];c.hb.forEach((e,f)=>{a.J.g.G.isConnected(f)||c.dd||(ci(a,c,e),e.Va&&(e.Va.disconnect(),
e.Va=null),d.push(f))});d.forEach(e=>{c.hb.delete(e)})}))}function hi(a){const b=[],c=[];a.Da.forEach((d,e)=>{d.dd&&(b.push({n:e,t:d.ge,c:d.We,ev:d.cf,ss:d.rh,d:d.he}),c.push({n:e,t:d.ge,c:d.We,ev:d.cf,ss:d.rh,d:d.he}));d.dd=!1});b.length>0&&V(a.J,"z",b);c.length>0&&K(a.J,{t:"z",z:c})}
function ii(a,b){try{let c=a.B.get(b);c||(a.B.set(b,{gb:null}),c=a.B.get(b));c.gb||(c.gb=setTimeout(()=>{fi(a,b);c.gb=null},300));a.M===null&&(a.M=setInterval(()=>{hi(a)},a.J.D.config.publishInterval))}catch(c){L(a.J.ba,"zones: error finding zones in document",{error:c},"error")}}function ci(a,b,c){c.interval&&(clearInterval(c.interval),c.interval=null);ji(a,b,c)}function ki(a){a.Da.forEach(b=>{b.hb.forEach(c=>{ci(a,b,c)})});hi(a)}
function li(a){a.Da.forEach(b=>{b.hb.forEach(c=>{c.Va&&(c.Va.disconnect(),c.Va=null);c.interval&&(clearInterval(c.interval),c.interval=null)})});a.Da.clear();a.B.forEach(b=>{b.gb&&(clearTimeout(b.gb),b.gb=null)});a.B.clear();a.M!==null&&(clearInterval(a.M),a.M=null);a.K.clear()}
function gi(a,b,c,d){!d.Va&&window.IntersectionObserver&&(d.Va=new window.IntersectionObserver(e=>{e.forEach(f=>{try{({isIntersecting:f}=f);if(f&&!d.isIntersecting&&(d.hd=a.J.g.G.W(),ei(a,c,d),c.he===null)){const [,g]=mi(a.J,document);c.he=g}!f&&d.isIntersecting&&(ci(a,c,d),a.K.delete(b));d.isIntersecting=f}catch(g){L(a.J.ba,"zones: error observing zone",{error:g},"error")}})},{root:null,threshold:c.threshold}),d.Va.observe(b))}
function ei(a,b,c){c.interval||(c.interval=setInterval(()=>{ji(a,b,c)},a.J.D.config.publishInterval))}function ji(a,b,c){c.hd&&(a=a.J.g.G.W(),b.ge+=B(a-c.hd),b.dd=!0,c.hd=a)}class ni{constructor(a){this.J=a;this.Da=new Map;this.B=new Map;this.M=null;this.K=new Set;this.J.g.G.addEventListener(document,"visibilitychange",()=>{document.hidden?bi(this):di(this)},!0)}};function oi(a){let b=[],c=null;return a===null||a===void 0?function(d){if(this.L.Na)try{pi(this,d)}catch(e){}finally{this.Ha.La("mutations-observed",d)}}:function(d){this.L.Na&&(b.push(d),c||(c=setTimeout(()=>{const e=b.flat();b=[];c=null;try{pi(this,e)}catch(f){}finally{this.Ha.La("mutations-observed",e)}},a)))}};function pi(a,b){a.K=a.L.g.Z.W();const c=new Set;c.add(document);a.D.aa.rf.length>0&&(b=qi(a,b));const {cc:d,...e}=ri(a,b),f=a.ca.bind(a,e);d.forEach(g=>{if(f(g)){var h=g.target;if(g.type==="attributes"){const k=h.getAttribute(g.attributeName),l=si(a.L,h,g.attributeName,k);let m;a.G.tagName(h).toUpperCase()==="LINK"&&h.href&&h.rel.toLowerCase().includes("stylesheet")&&a.G.isConnected(h)&&g.attributeName==="href"&&(m=a.L.g.Aa.bb(h).then(n=>{n.h&&(l.v=`${xb(a.D.config)}/hashes/${a.L.sub}/${n.h}`)}));
l&&K(a.L,l,void 0,m)}else if(g.type==="characterData")(g=ti(a.L,h))&&K(a.L,g);else if(g.type==="childList"&&g.action==="added")if(g.node.nodeType===3&&a.G.tagName(g.target)==="STYLE"){a.L.g.Aa.unregister(g.target.sheet);const k={t:"SR",I:a.L.$.da(g.target)};g=a.L.g.Aa.bb(g.target.sheet).then(l=>{k.v=l});K(a.L,k,void 0,g)}else h=a.L.addedNodes(g.node),K(a.L,h),ui(a.L,g.node);else if(g.type==="childList"&&g.action==="removed")if(g.node.nodeType===3&&a.G.tagName(g.target)==="STYLE"){a.L.g.Aa.unregister(g.target.sheet);
const k={t:"SR",I:a.L.$.da(g.target)};g=a.L.g.Aa.bb(g.target.sheet).then(l=>{k.v=l});K(a.L,k,void 0,g)}else(g=a.L.removedNodes(g.node))&&K(a.L,g)}});c.forEach(g=>{Xc(a.L.g.tb,g);ii(a.L.g.Da,g)});vi(a.L)}function wi(a){const b=a.B.takeRecords();a.M(b);a.B.disconnect();a.B=null;a.observe(document);a.L.dc.forEach(c=>{a.observe(c)})}function qi(a,b){const c=[];b.forEach(d=>{let e=!1;d.target.nodeType===1&&a.L.g.ia.matchesSelector(d.target,a.D.aa.rf)&&(e=!0);e||c.push(d)});return c}
function ri(a,b){const c=new Map,d=new Map,e=new Map,f=new a.G.WeakMap;b=b.reduce((g,h)=>{var k=h.target;if(h.type==="attributes"){var l=h.attributeName;c.has(k)||c.set(k,{});var m=c.get(k);if(!(l in m)){var n=h.oldValue;k=k.getAttribute(l);m[l]=n!==k}g.push(h);return g}if(h.type==="characterData")return d.has(k)||d.set(k,h.oldValue!==k.nodeValue),g.push(h),g;e.has(k)||e.set(k,new Map);k=e.get(k);for(m of h.addedNodes)k.has(m)||k.set(m,{Ue:0,te:0,first:null,finished:!1}),n=k.get(m),n.first===null&&
(n.first=h.addedNodes.length?"add":"remove"),xi(a,m,f),n.Ue++,g.push({type:h.type,target:h.target,action:"added",node:m});for(l of h.removedNodes)k.has(l)||(k.set(l,{Ue:0,te:0,first:null,finished:!1}),a.$.Pf.set(l,a.$.da(l))),m=k.get(l),m.first===null&&(m.first=h.addedNodes.length?"add":"remove"),xi(a,l,f),m.te++,g.push({type:h.type,target:h.target,action:"removed",node:l});return g},[]);return{Zh:c,$h:d,ai:e,zi:f,cc:b}}
function xi(a,b,c){if(c.get(b)!==1){c.set(b,1);var d=a.G.childNodes(b)||[];for(let e=0;e<d.length;++e)xi(a,d[e],c);if(b.nodeType===1&&(d=a.G.shadowRoot(b)))for(c.set(d,1),d=a.G.childNodes(d)||[],b=0;b<d.length;++b)xi(a,d[b],c)}}
class yi{constructor(a,b,c,d,e,f){this.L=a;this.G=b;this.Ha=c;this.ba=d;this.D=e;this.$=f;this.M=oi(e.config.mutationThrottle);this.B=null;this.K=0}observe(a=document){this.B||(this.B=new this.G.MutationObserver(b=>{this.L.ya===y.NONE&&this.M(b)}),this.Ha.addEventListener("clean-iframe-re-attached",()=>{wi(this);L(this.ba,"cleanIframeReattached",!0)},{once:!0}));this.B.observe(a,{childList:!0,attributes:!0,characterData:!0,subtree:!0,attributeOldValue:!0,characterDataOldValue:!0})}ca({Zh:a,$h:b,ai:c,
zi:d},e){var f=e.target;if(e.type==="attributes"){if(this.G.tagName(f).toLowerCase()==="script"||this.G.tagName(f).toLowerCase()==="iframe"&&e.attributeName==="srcdoc"||e.attributeName==="muted"||this.D.aa.ad.length>0&&this.L.g.ia.matchesSelector(f,this.D.aa.ad))return!1;b=a.get(f);e=e.attributeName;(f=b[e]&&!d.has(f))&&(b[e]=!1);return f}if(e.type==="characterData")return(d=b.get(f)&&!d.has(f))&&b.set(f,!1),d;if(d.has(f))return!1;f=c.get(f).get(e.node);if(f.finished)return!1;if(f.Ue!==f.te)return f.finished=
!0;if(f.first==="add")return f.finished=!0,!1;f.te=0;return!0}};const zi=(a,b,c,d)=>{b.$e=a.dataScrubRE.length>0?I(a.dataScrubRE):[ra];b.Vf=I(a.scrubDocumentTitlePatterns);b.Bi=I(a.urlMonitorBlacklist);b.Cg=I(a.blacklistedURLs);b.nd=I(a.startImmediatePathPatterns);b.ag=I(a.waitForSessionIdPathPatterns);b.th=I(a.startWithoutParentPathPatterns);b.ld=a.dataScrubBlackList.includes("*");b.Ze=a.dataScrubBlackList.join(",");b.Vd=a.dataScrubWhiteList.join(",");b.Pb=a.encryptScrubList.join(",");b.Ud=a.dataEncryptWhiteList.join(",");b.Df=I(a.maskSensitiveWindowDialogs);
b.Ig=I(a.encryptSensitiveWindowDialogs);b.$g=I(a.maskSensitiveJSErrors);a.excludeDOMList&&a.excludeDOMList.length>0&&(b.ad=a.excludeDOMList.join(","));b.Gh=I(a.xhrHookWhiteListDetails);b.Eh=I(a.xhrHookBlackListDetails);b.Hh=I(a.xhrPerformanceWhitelistDetails);b.Fh=I(a.xhrHookWhiteList);b.Dh=I(a.xhrHookBlackList);b.Ch=I(a.xhrErrorBlacklist);b.af=a.dataScrubXHRRegExes.reduce((f,g)=>{const h="d"+(g.f.includes("g")?g.f:g.f+"g");(g=Xa(g.p,h))&&f.push(g);return f},[]);c=I(a.excludeRageRE);b.Kg=c.length?
c:[ta];b.ef=a.excludeRageCSS.join(",");b.Sf=I(a.replaceURLRegExes.map(f=>({...f,f:f.f.includes("g")?f.f:f.f+"g"})));c=sa.concat(a.urlTransforms);var e=[];for(let f=0;f<c.length;f++){const {re:g,rep:h}=c[f],k=Xa(g.p,g.f);k&&e.push([k,h])}b.fc=e;b.rf=a.ignoreChangesList.join(",");b.ff=I(a.excludeXHRHeaderRegEx);b.Be=a.spinnerSelectorList.join(",");b.md=(new Date).getTime()%100<a.hashUploadPercent;b.Ab=[];for(c=0;c<a.transformAttributesForNodesList.length;++c){const {sel:f,attr:g,re:{p:h,f:k},rep:l,
newAttr:m}=a.transformAttributesForNodesList[c];(e=Xa(h,k))&&b.Ab.push({Fa:f,Od:g,rb:e,ue:l,dh:m})}b.Tf=I(a.resourcePathBlacklist);c=Ha(a.ignoreAttributes);b.Qg=c.global;b.oh=c.selected;b.Bh=I(a.xhrEncryptWhiteListDetails);b.Ah=I(a.xhrEncryptBlackListDetails);for(c=0;c<yd.forceElementCSSUpload.length;++c)e=yd.forceElementCSSUpload[c],a.forceElementCSSUpload.includes(e)||a.forceElementCSSUpload.push(e);b.ae=a.forceElementCSSUpload.join(",");b.Pg=a.forceElementCSSInline.join(",");b.fe=a.ignoreElementCSSSerialization.join(",");
b.ac=new window.Set(a.maskSensitiveQueryParams.map(f=>f.toLowerCase()));b.zh=I(a.whitelistedURLs);d=d.Array.from(new window.Set(a.imageTrackingIgnoreList.concat(yd.imageTrackingIgnoreList)));b.sf=d.join(",");d=[];for(c=0;c<a.blockFrequentReloads.length;++c){const {re:f,count:g}=a.blockFrequentReloads[c];(e=Xa(f.p,f.f))&&d.push({re:e,count:g})}b.Qd=d;b.uh=I(a.syncEndpointsWithSDK);a.sessionPersistenceMediums.indexOf("localStorage")<0&&a.sessionPersistenceMediums.indexOf("sessionStorage")<0&&a.sessionPersistenceMediums.push("localStorage");
b.ei=I(a.excludeLegacyHttp);b.ci=I(a.customWebviewUserAgentPatterns)};const Ai=a=>{a={...a};if(a.ingestURLProvider)try{const {medium:d,path:e}=a.ingestURLProvider;if(d==="window")var b=E(window,e,void 0);else if(d==="localStorage"||d==="sessionStorage")b=window[d].getItem(e);typeof b==="string"&&b.length>0&&(a.ingestBaseURL=b)}catch(d){}if(typeof a.ingestBaseURL==="string"&&a.ingestBaseURL.length>0)try{var c=new URL(a.ingestBaseURL,window.location.origin);a.ingestBaseURL=c.href.replace(/\/+$/,"")}catch(d){}b=new window.Set(a.excludeXHRHeaderRegEx.map(d=>d.p+"|"+d.f));
c=Fa(yd.excludeXHRHeaderRegEx);for(let d=0;d<c.length;++d){const e=c[d];b.has(e.p+"|"+e.f)||a.excludeXHRHeaderRegEx.push(e)}return a};class Bi{constructor(a,b,c){this.B=[];this.K=c;a=Object.entries(a).flatMap(([d,e])=>e.map(f=>[d,f]));for(const [,d]of a){const {surveyUrl:e,eventDetails:f}=d;({i:a}=f);b.addEventListener(`event-engine:${a}`,()=>this.load(e));this.B.push(f)}}load(a){a=new URL(a,window.location.href);a.searchParams.set("interface-handle",this.K());const b=document.createElement("script");b.async=!0;b.src=a.href;document.head.appendChild(b)}};function Ci(a){window.addEventListener("message",async b=>{if((b=b.data)&&typeof b=="object"&&b.namespace==="quantum_flutter"&&b.messageId!==void 0){var {method:c,url:d,body:e,messageId:f,response:g,error:h}=b;a.B.size>50&&L(a.ba,"FlutterMessageHandler: high message count",{size:a.B.size},"warn");if(g){if(e&&!e.ack&&L(a.ba,"FlutterMessageHandler:missing ack",{method:c,url:d},"error"),b=a.B.get(f))h?b.reject(h):b.resolve(e),a.B.delete(f)}else{let k=void 0,l=void 0;try{l=await Di(a,{method:c,url:d,
body:e,context:{scope:b.scope,view:b.view}})}catch(m){k=m}l===void 0&&k===void 0||window.postMessage({messageId:f,method:c,url:d,body:l,response:!0,error:k,namespace:"quantum_flutter_web",scope:a.sub},"*")}}},!1)}
async function Di(a,b){var c=b.method,d=b.url;const e=b.body;b=b.context;if(typeof c!=="string"||typeof d!=="string")throw Error("FlutterMessageHandler:400");d=yh(d);c=E(a.Ma,[c.toUpperCase(),...d],null);if(c===null)throw Error("FlutterMessageHandler:404");d[d.length-1]==="child-ready"&&(a.Sd++,a.Jf.resolve());return await c(e,b)}
class Ei{constructor(a){this.ba=a.ba;this.sub=a.sub;this.Ma=a.Ma;this.Hb=a.Hb||5;this.Kb=a.Kb||500;this.B=new Map;Ci(this);this.Jf=new yb;this.Sd=0}Ga({method:a,url:b,body:c}){if(!this.Sd)return Promise.resolve();const d=Ia(),e=new yb;this.B.set(d,e);const f=(g=0)=>{try{window.postMessage({messageId:d,method:a,url:b,body:c,namespace:"quantum_flutter_web",scope:this.sub},"*")}catch(h){L(this.ba,"FlutterMessageHandler: unable to post message",{message:h.message,url:b,method:a},"error")}setTimeout(()=>
{if(this.B.get(d)){const h=g+1;h>this.Hb?(e.reject(Error("FlutterMessageHandler:timeout")),this.B.delete(d)):f(h)}},this.Kb)};f();return e.promise}disconnect(){this.B.clear();this.Sd=0;this.Jf=new yb}}var Fi=new Set("b T rn a L nsc C F B".split(" "));const Gi={ack:!0};
class Hi{constructor(a){this.L=a}sc(){return{GET:{v1:{connect:()=>({...Gi,config:this.L.g.G.stringify({flutter:this.L.Xa,exchange_rates:this.L.Td,server_config:{ingestBaseURL:this.L.D.config.ingestBaseURL}}),enabled:Ii(this.L)}),disconnect:()=>{this.L.g.Xa.disconnect();return Gi}}},POST:{v1:{"child-ready":()=>{const a=async()=>{await this.L.g.bd.Ga({method:"POST",url:"/v1/set-context",body:this.L.getContext()})};this.L.ha&&this.L.Ba?a():this.L.Ha.addEventListener("start-event",a,{once:!0});return Gi},
event:async(a,b)=>{b=b.view;var c=this.L.g.Xa.hc.get(b||0);if(!c||!c.canvas)return L(this.L.ba,"flutter-missing-view",b,"error"),Gi;b=c.canvas;c=c.da;const d=a.t;if(!Fi.has(d)||!c)return Gi;if(d==="L")return b=Ng(this.L.g.rd,b.parentElement),b+=`>div:last-child:nth-child(1):only-child>\u00a7>${a.ev}`,a.I=[c,a.I],a.ev=b,K(this.L,{t:"b",I:a.I,v:a.v}),K(this.L,a),Gi;if(d==="T"||d==="nsc"||d==="C"||d==="F"||d==="B")a.I=[c,a.I];d==="rn"&&(a.c=[c,a.c]);d==="a"&&(a.p=a.p.startsWith("<")?a.p:[c,a.p],b=a.j?
a.j[0].E:null)&&(b=this.L.g.G.stringify(b),c=await he(this.L.pa,b),a.j[0].E=c||O(b));K(this.L,a);return Gi},oob:(a,b)=>{var c=a.k;a=a.v;if(c!==null&&a!==null)switch(c){case "s":b=a.delta;a=a.isV;b&&(this.L.Lb+=a?b/this.L.Mb:b/this.L.jc,V(this.L,"s",this.L.Lb));break;case "qc":b=b.view;c=this.L.g.Xa.hc.get(b||0);if(!c||!c.canvas){L(this.L.ba,"flutter-missing-view",b,"error");break}b=c.canvas;c=Ng(this.L.g.rd,b.parentElement);c+=`>div:last-child:nth-child(1):only-child>\u00a7>${a.ev}`;a.ev=c;(b=Ji(this.L,
b.parentElement)||"")&&(b+=`>div S# ${a.P}`);a.P=b;++this.L.ec;V(this.L,"c",this.L.ec);Ki(this.L);V(this.L,"qc",a);break;case "k":if(a=a.charsTyped)this.L.Zb+=a,V(this.L,"k",this.L.Zb)}return Gi},encrypt:async a=>{if(!this.L.pa||!this.L.pa.supports||!this.L.zb)throw Error("FlutterHandler:encryption-unavailable");var b;a=(b=a.v)!=null?b:"";b=await he(this.L.pa,a);if(!b&&a)throw Error("FlutterHandler:encryption-unavailable");return{v:b,...Gi}},"trigger-event":async a=>{const {id:b,v:c,f:d,j:e}=a;if(a=
e)a=this.L.g.G.Ra(a),a={hash:await Ub(this.L.g.G.stringify(a,cc)),value:a};const f=this.L.R.Qb[b]||{id:b,flags:d,ka:this.L.g.Z.W()};ng(this.L.R,f,c,a);return Gi},stop:async a=>{if(this.L.ya!==y.NONE)return Gi;a=a.endSession;await Li(this.L,!1);a&&(Mi(this.L),this.L.we=!0,this.L.ha=void 0);return Gi},start:async()=>{if(this.L.ya===y.NONE)return Gi;await Li(this.L,!0);return Gi}}}}}};function Ni(a){let b=[];a.D.config.flutterViews.forEach(c=>{const {root:d,attr:e,render:f}=c;a.M.querySelectorAll(document,d).forEach(g=>{var h=a.find(g);if(!h||!h[1].canvas){h=a.M.querySelector(g,f);var k=g.getAttribute(e);a.hc.set(+k,{root:g,id:k,canvas:h});h&&b.push(k)}})});return b.length?b:null}function Oi(a,b){for(const {root:c}of a.hc.values())if(c.contains(b))return!0;return!1}
async function Pi(a,b,c){if(c){var d=a.hc.get(+b),e=d.canvas;if(b=a.L.$.da(e)){d.da=a.L.da();d={1:{n:"DIV",C:[],sr:{b:{C:[c],S:[{v:"div{position:absolute;pointer-events:none;z-index:0;width:calc(var(--w)*1px);height:calc(var(--h)*1px);}.cl{pointer-events:all;}",i:"flutter-injected"}],q:d.da}},a:[{2:{n:"style",v:e.style.cssText}}],q:a.L.da()}};if(e=c.E)delete c.E,(a=await he(a.L.pa,a.G.stringify(e)))&&(d.E=a);return{t:"%",I:b,j:d}}}}
class Qi{constructor(a,b,c,d,e,f){this.D=a;this.M=b;this.G=c;this.B=e;this.L=f;this.hc=new Map;this.K=this.ready=!1;d.addEventListener("html-snapshot",this.ea.bind(this));d.addEventListener("mutations-observed",this.ca.bind(this))}find(a){for(const b of this.hc.entries())if(b[1].root===a)return b;return null}async ea(){this.K||(this.K=!0,await this.B.Jf.promise,this.L.ya!==y.NONE?this.K=!1:(this.ready=!0,this.B.Ga({method:"GET",url:"/v1/snapshot",body:{}}).then(async({html:a})=>{for(const b in a){const c=
await Pi(this,b,a[b]);c&&K(this.L,c)}}).catch(ua).finally(()=>{this.K=!1})))}ca(a){if(this.B.Sd&&a.some(c=>c.addedNodes.length>0)){var b=Ni(this);b&&this.ready&&this.B.Ga({method:"GET",url:"/v1/snapshot",body:{}}).then(async({html:c})=>{for(const d of b){const e=await Pi(this,d,c[d]);e&&K(this.L,e)}}).catch(ua)}}disconnect(){this.hc.clear();this.B.disconnect()}};function Uc(a,b){a=a.B(b);a.Ac||(a.Ac={});return a.Ac}function Ri(a,b,c=!1){var d,e=a.$.get(b);e&&(c?d=e.Ac:e.Ac&&e.Ac.ri&&a.K.delete(b),d?a.$.set(b,{Ac:d}):a.$.delete(b));if(d=a.G.childNodes(b))for(e=0;e<d.length;++e)Ri(a,d[e],c);b.nodeType===1&&(b=a.G.shadowRoot(b))&&Ri(a,b,c)}class Si{constructor(a){this.G=a;this.$=new a.WeakMap;this.K=new a.Set;this.Pf=new a.WeakMap}B(a){let b=this.$.get(a);b||(b={},this.$.set(a,b));return b}da(a){return this.B(a).da}};const Ti="copyWithin fill pop push shift splice unshift".split(" ");function Ui(a,b){if(a.B.length===0)a.B.push(b);else{var c=a.B[a.B.length-1];c[1].length>0||c[1].length===0&&b[1].length===0?(c[0]=c[0].concat(b[0]),c[1]=c[1].concat(b[1])):a.B.push(b)}}async function Vi(a,b){a.M=!0;const c=a.B.shift();c[1].length?await b(c):b(c);a.B.length>0?setTimeout(()=>Vi(a,b),0):(a.M=!1,a.La("done",!0))}function Wi(a,b){a.M||Vi(a,b)}function Xi(a,b){a.K.done&&a.K.done.push(b)}function Yi(a,b){a.K.done&&(a.K.done=a.K.done.filter(c=>b!==c))}
class Zi{constructor(){this.B=[];this.M=!1;this.K={done:[]}}La(a,b){this.K[a].forEach(c=>{c(b)})}}
function $a(a,b){var c=window.location.href.indexOf("about:srcdoc")>-1;if(a.ta.timing&&!c){let d=b.p={};const e=$i(a);if(e){c=aj(a)?a.g.Z.yb:e.navigationStart;b.pto=B(c);for(const g in a.qa)if(a.qa.hasOwnProperty(g)){d[a.qa[g]]=null;try{let h=e[g];typeof h==="number"&&(h>0?(aj(a)||(h=Math.max(h-c,0)),h<14E6?d[a.qa[g]]=Math.max(B(h),0):a.xa("hit_network_timing_offset",{url:encodeURIComponent(b.url),value:h,key:g})):a.Bc.push(g))}catch(h){}}let f=!1;a.Yg.forEach((g,h)=>{h!==0&&(h=d[a.qa[a.Yg[h-1]]]||
0,g=d[a.qa[g]],g!==null&&h!==null&&g<h&&(f=!0))});if(f){d={};for(const g in a.qa)a.qa.hasOwnProperty(g)&&(d[a.qa[g]]=null);b.p=d;return}}try{if(a.ta.getEntriesByType){if(!d[a.qa["first-paint"]]){const f=new window.PerformanceObserver(g=>{g=g.getEntries();for(let k=0;k<g.length;k++){var h=g[k];h.name=="first-paint"&&(h=B(h.startTime),h<14E6&&bj(a,h)&&cj(a,"mt",65536,{u:h}),f.disconnect())}});f.observe({type:"paint",buffered:!0})}if(!d[a.qa["first-contentful-paint"]]){const f=new window.PerformanceObserver(g=>
{g=g.getEntries();for(let k=0;k<g.length;k++){var h=g[k];h.name=="first-contentful-paint"&&(h=B(h.startTime),h<14E6&&bj(a,h)&&cj(a,"mt",65536,{v:h}),f.disconnect())}});f.observe({type:"paint",buffered:!0})}}}catch(f){}}}
function cb(a,b){if(!a.ta)return null;let c=null;a.ta&&a.ta.navigation&&b in a.ta.navigation&&(c=a.ta.navigation[b]);if(c==void 0&&a.ta.getEntriesByType){const d=a.ta.getEntriesByType("navigation");for(let e=0;e<d.length;++e){const f=d[e];if(b in f&&f.hasOwnProperty(b))return f[b]}}switch(b){case "type":return a.Mh[c];default:return c}}function K(a,b,c=!1,d=null){a.ub&&(a.Na||c)&&(dj(a,b),a.Vb?(a.Jc.push(b),d&&a.Ic.push(d)):(d&&a.ea.push(d),a.O.push(b),ej(a,a.O,a.ea)))}
function Vc(a,b,c,d){const e=new $c(a.D.aa.Ab,a);let f=a.D.config.elementVeinAttributes.reduce((g,h)=>{if(g||cd(a,b,h))return g;h=e.transform(b,h);return h===null?g:h.value},null);f||(f=`${c}x${d}`);return`${b.nodeName}[${f}]`}function Wc(a,b,c="",d=0,e=a.g.Z.W()){V(a,"E",{i:b,f:d,v:c,t:e})}
function cd(a,b,c){for(let d=0;d<a.D.config.ignoreAttributes.length;d++){const e=a.D.config.ignoreAttributes[d];if(typeof e==="string"){if(e===c)return!0}else if(e.attrs.indexOf(c)!==-1&&a.g.ia.matchesSelector(b,e.sel))return!0}return!1}function Cd(a){Mi(a);a.we=!0;Z(a,function(){fj(a,gb(a.M),!0,!1)})}
function rg(a,b){if(!a.Wc&&!a.ug){a.ug=!0;Wc(a,-39,"QuantumError: "+Pa(b.toString()));gj(a);try{a.ba&&L(a.ba,"QUANTUM_ERROR",{error:b.toString().substring(0,1E3),h:a.Ba,s:a.ha,u:a.Ea,v:"7902b8226"},"error"),wd(a.oa,"error",{error:b.toString(),version:"7902b8226",session:a.ha,hit:a.Ba,pageURL:a.Ea})}catch(c){}}}
function wg(a,b){var c=b.f;if(b.i!==0&&(c&512)<=0&&(c&1024)<=0&&(c&2048)<=0&&(c&4096)<=0&&(c&65536)<=0&&typeof b.i!=="undefined"&&typeof b.v!=="undefined"&&typeof b.t!=="undefined"&&(a.Ad.push({i:b.i,v:b.v.toString().substring(0,a.D.config.maxStoredEventLength),t:b.t,h:b.h,c:b.c}),a.R&&a.R.ob!==null)){for(b=0;b<a.Ad.length;++b)c=a.Ad[b],a.fa.set(`event:${Ia()}`,c);a.Ad=[]}}
function V(a,b,c){if(a.ub)if(b=="E"){if(!(a.Wg++>a.D.config.maxNumOOBEventsPerHit)){a.Sb=!0;var d;b in a.ca?d=a.ca.E:a.ca.E=d=[];d.push(c);wd(a.oa,c.i,c);K(a,{...c,t:"oe"},!0);b=a.g.nc;d={id:c.i,value:c.v,ts:c.t,i:c.i,v:c.v,ev:c.ev};if(!b.disabled&&b.B.config.mapping){var e=b.B.config.mapping;for(const [g,h]of Object.entries(e))try{if(d.i.toString()!==g)continue;var f=b.J.Jg.includes(d.i);e={xdm:{producedBy:"quantum-metric"},type:`qm.${f?"error":"event"}`};$h(b,{object:e.xdm,hh:h,handle:g,event:d});
Uh(b,e,g,d.value,f)}catch(k){console.warn("Could not map event:",g)}}wg(a,c)}}else{switch(b){case "qc":case "x":f=[];b in a.ca?f=a.ca[b]:a.ca[b]=f=[];f.push(c);break;case "mt":f={};b in a.ca?f=a.ca[b]:a.ca[b]=f={};Object.assign(f,c);K(a,{v:c,t:"mt"},!0);break;case "qr":f=[];b in a.ca?f=a.ca[b]:a.ca[b]=f=[];f.push(...c);K(a,{v:c,t:"qr"},!0);break;default:a.ca[b]=c}a.Sb=!0}}function Y(a,b){return a.g.G.nodeName(b).toLowerCase()}function Rg(a,b){return(b=a.g.G.parentNode(b))?a.Za(b):!1}
function Sg(a,b){b=a.g.G.parentNode(b);if(!b||!a.D.aa.Pb)return!1;b.nodeType===11&&(b=b.host);return a.Wb(b)}
function mi(a,b){let c=0,d=0,e=0,f=0;if(b)try{b==document?a.yg?(c=document.documentElement.scrollLeft||document.body.scrollLeft,d=document.documentElement.scrollTop||document.body.scrollTop,e=document.documentElement.scrollWidth||document.body.scrollWidth,f=document.documentElement.scrollHeight||document.body.scrollHeight):(c=document.body.scrollLeft,d=document.body.scrollTop,e=document.body.scrollWidth,f=document.body.scrollHeight):(c=b.scrollLeft,d=b.scrollTop,e=b.scrollWidth,f=b.scrollHeight)}catch(g){}return[c,
d,e,f]}
function si(a,b,c,d){var e=a.$.da(b);if(e===void 0)return null;let f={t:"T",I:e,n:c,v:d};var g=c.toLowerCase();e=!1;if(cd(a,b,c))return null;(g=g=="data-select-value"||g=="placeholder"||g=="value"||g=="label")&&a.Za(b)&&(d=O(d),e=!0);if(g&&!e&&a.D.aa.Pb&&!hj(a,b)&&a.g.ia.matchesSelector(b,`${a.D.aa.Pb},input,select`)){const h=d;e=he(a.pa,h).then(k=>{f.v=k||O(h)}).catch(ua);d=" ";a.ea.push(e);e=!0}if(g=(new $c(a.D.aa.Ab,a)).transform(b,f.n))f.n=g.name,d=e?d:g.value;if(!e)for(e=0;e<a.D.config.encryptNodeAttributes.length;++e){const {sel:h,attrs:k}=
a.D.config.encryptNodeAttributes[e];a.g.ia.matchesSelector(b,h)&&k.forEach(l=>{if(l===c){var m=d;l=he(a.pa,m).then(n=>{f.v=n||O(m)}).catch(ua);a.ea.push(l)}})}f.v=d;return f}function ti(a,b){var c=a.$.da(b);if(c===void 0)return null;var d=b.data,e=a.g.G.parentNode(b),f={t:"t",I:c,v:d};e&&(c=ij(a,e),c==="scrub"&&(d=O(d)),c==="encrypt"&&(d=he(a.pa,b.data).then(g=>{g&&(f.etn="1");f.v=g||O(b.data)}).catch(ua),a.ea.push(d),d=" "));f.v=d;return f}
function ui(a,b){if(b&&b.nodeType===1){var c=Y(a,b);if(c=="option"&&b.selected){c=a.$.da(b);if(c===void 0)return;K(a,{t:"_",I:c})}else if(c=="input"&&b.checked){c=a.$.da(b);if(c===void 0)return;a.$.B(b).fd=!0;K(a,{t:"_",I:c})}if(b=a.g.G.children(b))for(c=0;c<b.length;++c)ui(a,b[c])}}function vi(a){a.R&&!a.vc&&(a.vc=setTimeout(()=>{var b=a.R;qg(b,"dom",b.J.g.Z.W());a.vc=null},a.D.config.domChangedThrottleDuration))}
function Ii(a){var b=!0;if(![a.B.va].includes(a.K))return!0;var c=a.ra.get(a.D.config.enabledCookie);c?c==="false"&&(b=!1):a.D.config.percentSampling<100&&(c=!0,a.D.config.percentSampling<100&&(c=a.g.Z.W()%100<a.D.config.percentSampling),c||(b=!1),a.ra.set({[a.D.config.enabledCookie]:b}));return b}
function Ji(a,b,c=50){try{const h=new $c(a.D.aa.Ab,a);if(c==0||!b)return"";const k=ic(a.g.G,a.g.G.parentNode(b));if(!a.$.B(b).sh){var d=Y(a,b),e=a.g.G.parentElement(b);if(!e)if(k)e=a.g.G.parentNode(b).host;else return d=="html"?"html":"";if(k&&a.g.G.parentNode(b).mode==="closed")return Ji(a,e,c-1);var f=k?a.g.G.shadowRoot(e).children:a.g.G.children(e);const l=k?" S# ":" > ";function m(){for(var r=0,q=0,w=f.length;q<w&&r<=1&&q<100;q++)a.g.G.tagName(f[q]).toLowerCase()==d&&(r+=1);if(r==1)return Ji(a,
e,c-1)+l+d}function n(){var r=0,q=b.classList;if(q.length!==0){var {name:w,value:D}=h.transform(b,"class");q=D.split(" ");for(let u=0;u<q.length;u++){for(var C=`${d}[${w}~="${q[u].trim()}"]`,t=0,p=f.length;t<p&&r<=1&&t<c;t++)a.g.ia.matchesSelector(f[t],C)&&(r+=1);if(r==1)return Ji(a,e,c-1)+l+C}}}function x(){for(var r=0,q=0,w=f.length;q<w&&q<100;q++)if(f[q]==b){r=q+1;break}return Ji(a,e,c-1)+l+d+":nth-child("+r+")"}var g=function(){var r=a.g.G.getRootNode(b);if(d=="head"||d=="body"||d=="html")return d;
const q=ic(a.g.G,r);if(b.id&&!/"|'|&|object /.test(b.id)&&a.g.G.pb(r,`[id="${b.id}"]`).length===1){const {name:w,value:D}=h.transform(b,"id"),C=`[${w}="${D}"]`,t=a.g.G.pb(r,C).length===1;if(q&&t)return Ji(a,r.host,c-1)+" S# "+C;if(t)return C}if(b.attributes&&b.attributes.name){const {name:w,value:D}=h.transform(b,"name");r=`${d}[${w}="${D}"]`;return q?Ji(a,e,c-1)+l+r:r}}()||m()||n()||x();a.$.B(b).sh=g}return a.$.B(b).sh}catch(h){a.xa("stable_selector",h.message)}}
function Ki(a){a.Gc?(a.Gc=!1,jj(a)):a.Bb||((kj(a),a.Rc)?[a.B.va].includes(a.K)?a.Bb=setTimeout(b=>{a.Bb=null;let c=b-a.Rc;c>6E4&&(c=6E4);a.Fc+=c;V(a,"e",B(a.Fc/1E3));a.Rc=b;lj(a);mj(a)},500,a.g.Z.W()):a.ya===y.NONE&&(a.Bb=1,nj(a,{method:"POST",url:"/v1/engaged",body:{}}).finally(()=>{a.Bb=setTimeout(()=>{a.Bb=null},500)})):a.Rc=a.Jb)}
async function Li(a,b){[a.B.va].includes(a.K)?(a.ra.set({[a.D.config.enabledCookie]:b}),b?(await a.stop(y.NONE),await fj(a,gb(a.M),!1),oj(a,{method:"POST",url:"/v1/reset",body:{}})):a.stop(y.Ne)):nj(a,{method:"POST",url:"/v1/enable-session",body:{enabled:b}})}function Mi(a){a.ra.jb({[a.D.config.sessionCookieName]:""});a.fa.clear()}
function pj(a,b,c){const d=a.xd[b];var e=a.R.Xe.has(b);const f=a.uf>=1E3;if(e||!f&&d){var g=c.map(k=>k.bb());if(e){const k=a.g.G.stringify;vg(a.R,{method:b,args:c.map(l=>k(l.ph()))})}var h=!1;if(d&&(e=d.mi,d.replace.forEach(({rb:k,ti:l})=>{c.forEach(m=>{m.Gb(k,l)&&(h=!0)})}),!h))a:for(const k of e)for(const l of c)if(l.Gb(k,"")){h=!0;break a}h&&!f&&(a.uf++,K(a,{t:"co",m:b,a:g}))}}
function qj(a){var b=a.D.config.console||{};a.xd={};Object.entries(b).forEach(([c,d=[]])=>{const e=[],f=[];d.forEach(g=>{if(g.re){var h=g.re.f||"g";h=h.includes("g")?h:h+"g";var k=g.re.p;g.rep?(h=Xa(k,h))&&e.push({rb:h,ti:g.rep}):Xa(k,h)&&f.push({p:k,f:h})}});d=I(f);if(e.length||d.length)a.xd[c]={replace:e,mi:d}});a.uf=0;b=Ed.filter(c=>a.xd[c]||a.R.Xe.has(c));a.g.console.ca=new Set(b)}function rj(a){const b=a.g.G.stringify({ekey:ie(a.pa),kid:a.pa.le||""});V(a,"ekey",{ekey:b})}
function sj(a){var b=a.ca.form;b||(a.ca.form=b={});a.Sb=!0;return b}function dj(a,b){if(!b.hasOwnProperty("d")){const c=b.t=="s",d=a.g.Z.W();c?(b.d=d,a.Tc=d):a.Tc>0?(b.d=d-a.Tc,a.Tc=d):b.d=1}}async function ej(a,b,c=a.ea){!a.Ub||b.length===0&&c.length===0||(Ui(a.Xc,[[...b],[...c]]),b.length=0,c.length=0,Wi(a.Xc,async function(d){const e=d[0];d=d[1];d.length&&await Promise.all(d);e.forEach(f=>tj(a,f))}))}
function tj(a,b){if(a.ub){var c=b.t=="s";dj(a,b);a.zd&&(b.ekey=ie(a.pa),b.kid=a.pa.le||"",a.zd=!1);c?a.ua.unshift(b):a.ua.push(b)}}
function uj(a,b){a.uc||(a.uc=vj(a));var c={G:a.g.G,ma:a.uc,oe:a.D.aa.ld,He:{[1]:(f,g)=>{if(a.ed(f)){var h=f.localName;!a.customElements.has(h)&&window.customElements.get(h)&&(a.customElements.add(h),K(a,{t:"CE",n:h}))}a.$.B(f).Ge=!0;switch(a.g.G.tagName(f).toUpperCase()){case "INPUT":if(g=f.type.toLowerCase(),g==="checkbox"||g==="radio")a.$.B(f).fd=f.checked;case "SELECT":case "TEXTAREA":wj(a,f);break;case "IMG":if(!(!a.D.config.reportFailedImages||a.D.aa.sf&&a.g.ia.matchesSelector(f,a.D.aa.sf))){g=
a.g.Rg;var k=f.ownerDocument.location.href;h=f.complete;var l=f.srcset?f.srcset.split(", "):[];const m=l.length===1?l[0].split(" ")[0]:"";l=f.src!==k;k=!!f.src||m!==k;h=(f.src||f.srcset)&&l&&k&&h;f.removeEventListener("error",g.B);f.removeEventListener("load",g.Ec);h&&dd(g,f);g.J.g.G.addEventListener(f,"error",g.B);g.J.g.G.addEventListener(f,"load",g.Ec)}break;case "IFRAME":f=a.$.B(f),f.Cc?g.Cc=f.Cc.toString():g.Cc=null}},[11]:f=>{xj(a,f.host);Sc(a.g.tb,f.host)}},ee:a.cb.bind(a),wb:a.D.aa.Qg,Ob:a.Ob.bind(a),
Nb:f=>!!a.zb&&a.Nb(f),ze:a.D.config.stripHTMLComments,ye:J(a.Ea,a.D.aa.Vf),url:a.Ea,supports:a.g.supports,Db:a.$.B.bind(a.$),da:a.da};c=new bh(c);c.mode=[ij(a,b)];const {sb:d,Ib:e}={sb:dh(b,c),Ib:c.Ib};b=c.B.length?he(a.pa,a.g.G.stringify(c.B)):null;c.De.forEach(({node:f,sb:g})=>{f.nodeType===11?(f=(a.g.G.adoptedStyleSheets(f)||[]).map(h=>Zb(a.g.Aa,h)),Promise.all(f).then(h=>{g.S=h})):(a.g.G.tagName(f)==="STYLE"&&Zb(a.g.Aa,f.sheet).then(h=>{g.S=h;g.C=[]}),a.g.G.tagName(f)==="LINK"&&f.getAttribute("href")&&
f.rel.toLowerCase().includes("stylesheet")&&Zb(a.g.Aa,f).then(h=>{if(h.v!==""){for(let k=0;k<g.a.length;++k){const l=g.a[k];l[2].n==="href"&&(l[2].n="data-original-src");l[2].n==="data-original-src"&&l[2].v.startsWith("data:")&&(l[2].v="")}g.S=h}}))});b=Promise.all([b,$b(a.g.Aa)]).then(f=>{d.E=f[0]});return{sb:d,Ib:e,Og:b}}function yj(a,b){a=a.g.G.parentNode(b);if(!a)return null;if(a.nodeType===1)return a;if(a.nodeType===11)return a.host}
function ij(a,b){if(!b)return null;if(b.nodeType===3||b.nodeType===8)b=yj(a,b);const {Za:c,Wb:d}=a.$.B(b);return c!==null&&c!==void 0||d!==null&&d!==void 0?c?"scrub":d&&c===!1?"encrypt":d?ij(a,yj(a,b))==="scrub"?"scrub":"encrypt":null:a.D.aa.ld?"scrub":ij(a,yj(a,b))}function zj(a,b,c,d){(b=si(a,b,c,d))&&K(a,b)}function hj(a,b){return a.D.aa.Ud&&a.g.ia.matchesSelector(b,a.D.aa.Ud)?!0:!1}function Aj(a){const b=a.D.config.sessionTimeoutMinutes*60*1E3;return new a.g.G.Date(a.g.Z.W()+b)}
function Bj(a,b){if(b){const c=Aj(a);a.D.config.sessionPersistenceMediums.forEach(d=>{try{switch(d){case "cookie":a.ra.set({[a.D.config.sessionCookieName]:b,expires:c.toUTCString()});break;default:const f=a.fa.get("s");f&&f!==b&&a.fa.clear();a.fa.set("s",b);var e=a.fa;e.B.exp=c.getTime();Eg(e,"exp")}}catch(f){}})}}function Z(a,b){try{++a.Pc,b(),--a.Pc}catch(c){Cj(a,c)}}
function lj(a){if([a.B.va].includes(a.K)&&a.eg===null){a.eg=setTimeout(()=>{a.eg=null},1E3);a.Ke&&a.g.G.clearTimeout(a.Ke);var b=a.D.config.sessionTimeoutMinutes*60*1E3;Bj(a,a.ha);a.Ke=a.g.G.setTimeout(function(){Z(a,function(){a.Gc=!0;a.Tb&&a.Tb.disconnect();a.Kc&&clearTimeout(a.Kc);a.Oa&&clearTimeout(a.Oa)})},b)}}function jj(a){[a.B.lc].includes(a.K)?nj(a,{method:"POST",url:"/v1/new-session",body:{}}):[a.B.td,a.B.vd].includes(a.K)||Cd(a)}
function kj(a){if([a.B.va].includes(a.K)){if(a.D.config.maxSessionDuration>0){a.Hd!==null&&(wd(a.oa,"max-session-duration-exceeded",{sessionID:a.Hd}),a.Hd=null);const {ni:b,oi:c}=Dj(a);if(b>a.D.config.maxSessionDuration)return a.Hd=a.ha,gj(a),jj(a),!0;a.Oa&&(clearTimeout(a.Oa),a.Oa=null);a.Oa=setTimeout(()=>{kj(a)},c)}return!1}}
function mj(a){[,e]=a.Cd;var b=document.documentElement.scrollHeight;if(b!=0){var c=e+a.Mb;c>a.Uc&&(a.Uc=c,V(a,"sd",a.Uc));var d=a.g.Z.W();c=d-a.xc;if(c>1E3){a.xc=d;d=Math.floor(e/b*10);var e=Math.floor((e+a.Mb)/b*10);e==10&&(e=9);for(b=d;b<=e&&!(a.Eb[b]+=c,b<0||b>10);b++);a.Eb.totalTime+=c;Ej(a)}}}
async function nj(a,b){const {method:c,url:d}=b;if(!a.Re&&([y.ud,y.NONE].includes(a.ya)||![a.B.td,a.B.vd].includes(a.K))){if([a.B.td].includes(a.K))return a.g.Nd.Ga(b).catch(e=>{L(a.ba,"sdkcomm: (android) issue sending message to parent",{message:e.message,method:c,url:d},"error")});if([a.B.vd].includes(a.K))return a.g.ie.Ga(b).catch(e=>{L(a.ba,"sdkcomm: (ios) issue sending message to parent",{message:e.message,method:c,url:d},"error")});if([a.B.lc].includes(a.K)){const e=window.opener!==null&&window!==
window.opener?window.opener:a.g.G.M(window);return a.g.zc.Ga(e,b).catch(f=>{L(a.ba,"sdkcomm: (iframe) issue sending message to parent",{message:f.message,method:c,url:d},"error")})}L(a.ba,"sdkcomm: unable to send message to unknown parent context",{method:c,url:d,mode:a.K},"error")}}
async function fj(a,b,c=!0,d=!0){a.M.Ua!==b?jb(a.M,b):!a.Ie&&a.Bg&&(a.Ie=!0,ej(a,a.O,a.ea),a.Xc.M&&await new Promise(e=>{const f=()=>{Yi(a.Xc,f);e()};Xi(a.Xc,f)}),Fj(a),c&&(a.Tb&&a.Tb.disconnect(),a.Lc&&a.Lc(),ki(a.g.Da),a.$a||a.g.console.flush(),Ej(a,!0),Gj(a),gj(a)),Ri(a.$,document.documentElement,!0),a.uc=null,a.ua=[],a.O.length=0,a.O=[],a.Jc.length=0,a.Ic.length=0,a.ca={},a.Sb=!1,vh(a.Oc),vh(a.Dd),a.Ba=void 0,[a.B.va].includes(a.K)&&(a.ha=void 0,a.za=void 0),a.Yb=!1,a.Id=void 0,a.Ub=null,a.Hc=
[],a.ec=0,a.xh=0,a.Vc=0,a.Lb=0,a.Zb=0,a.Cb&&(clearTimeout(a.Cb),a.Cb=null),a.vc&&(clearTimeout(a.vc),a.vc=null),a.Oa&&(clearTimeout(a.Oa),a.Oa=null),a.Nc&&(clearTimeout(a.Nc),a.Nc=null),a.Tc=0,a.mg=0,a.Cd=[0,0],a.Rb=null,a.Gc=!1,a.Jb=void 0,a.$a=void 0,a.Wc=void 0,a.Rc=0,a.Sc=null,a.Bb&&clearTimeout(a.Bb),a.Bb=null,a.Fc=0,Hj(a),a.Nf=0,a.la.B=0,a.Wg=0,a.Zf=0,a.Bc=[],Ij(a),Yc(a.g.tb),li(a.g.Da),a.g.cc.K=0,a.da=Ea(),c=null,a.R!==null&&(c=a.R.Ia,a.R.Ve()),await Jj(a,b,d,c),a.Ie=!1)}
function Kj(a,b,c,d){Ki(a);const e=a.$.da(b);e!==void 0&&(a.Sc=b,K(a,{t:"O",I:e,x:c,y:d}))}function Lj(a,b,c,d){Ki(a);b=a.$.da(b);b!==void 0&&(a.Sc=null,K(a,{t:"X",I:b,x:c,y:d}))}function Mj(a,b,c){return J(c,a.D.aa.Kg)||a.D.aa.ef&&a.g.ia.matchesSelector(b,a.D.aa.ef)?!1:!0}function Nj(a,b){return a.replace(b,function(c){let d="";for(let e=0;e<c.length;++e)d+="*";return d})}
function Oj(a,b){const c=a.g.Z.W();b=Pa(b);for(let d=0;d<a.D.aa.$g.length;++d)b=Nj(b,a.D.aa.$g[d]);c-a.Qc<100?Wc(a,-4,b):a.Eg[b]||(Wc(a,-18,b),a.Eg[b]=1)}
function Pj(a,b,c,d){var e=Y(a,b);if(e==="select"){var f=a.g.G.Array.from(b.selectedIndex<0?b.options:b.selectedOptions,k=>Pj(a,k,c,d)).join(" ").trim();if(f!=="")return f}f=a.g.ia.matchesSelector(b,a.D.aa.Ze)||a.g.ia.matchesSelector(b,a.D.aa.Pb);e=e=="input"||e=="textarea";const g=hj(a,b)||a.D.aa.Vd&&a.g.ia.matchesSelector(b,a.D.aa.Vd);if((f||e)&&!g)return Vc(a,b,c,d);f=b;for(var h of a.D.config.clickTextMapping){const {target:k,parent:l}=h;if(!a.g.ia.matchesSelector(b,k))continue;e=a.g.ia.closest(b,
l);if(e!==null){f=e;break}}h=Qg(a.Sh,f);return h.length?h:Vc(a,b,c,d)}function gj(a){a.Qe&&Qj(a)}
function Rj(a,b,c,d){if(b&&!Oi(a.g.Xa,b)){Ki(a);++a.ec;V(a,"c",a.ec);tg(a.R,b);var e=a.$.da(b);if(Y(a,b)=="input"){var f=a.$.B(b);!!f.fd!=b.checked&&(zj(a,b,"checked",b.checked),f.fd=b.checked)}var g=Vc(a,b,c,d);f=Pj(a,b,c,d);K(a,{t:"b",I:a.Na?e:null,v:f},!0);var h=a.g.Z.W(),k=!1;a.$b==b&&h-a.Qc<2E3&&a.g.cc.K<a.Qc?++a.tg==3&&(g&&Mj(a,b,g)&&(k=!0,Wc(a,-5,f)),a.dg=10):a.tg=0;k||(a.$b==b&&Math.abs(a.Qf-c)<30&&Math.abs(a.Uf-d)<30&&h-a.Qc<2E3?++a.dg==3&&g&&Mj(a,b,g)&&Wc(a,-2,f):a.dg=0);a.$b=b;a.Qc=h;a.Qf=
c;a.Uf=d;a.$a&&a.xh++==1&&(Wc(a,-9,f),gj(a));g=Ji(a,b)||"";k=b.getBoundingClientRect();h=c-(k.left+window.pageXOffset);var l=d-(k.top+window.pageYOffset);h=k.width==0?0:Math.min(100,h/k.width*100);l=k.height==0?0:Math.min(100,l/k.height*100);var m=a.g.Z.W()-a.Jb;k=Ng(a.g.rd,b);h={t:"H",n:f,x:B(h),y:B(l),tc:m,ts:a.g.Z.W()};g.length?h.P=g:a.xa("STABLE_PATH",`Could not generate stable selector: ${a.cb(b)}`);k.length?h.ev=k:a.xa("ELEMENT_VEIN",`Could not generate element vein: ${a.cb(b)}`);V(a,"qc",h);
a.Sb=!0;c={t:"L",I:a.Na?e:null,P:g||"",ev:k,x:c,y:d,v:f};if(a.D.config.zones){d=[];for(const n of a.D.config.zones)if(e=a.g.ia.closest(b,n.sel)){f=null;for(const [,x]of a.g.Da.Da)if(x.hb.has(e)){f=x;break}if(f){d.push(f.name);f=a.g.Da;for(const [,x]of f.Da)if(x.hb.has(e)){x.We++;x.dd=!0;break}}}d.length&&(c.z=d)}K(a,c,!0)}}function Qj(a){a.Rb&&(Sj(a,a.Rb),Tj(a,a.Rb));a.$a&&Uj(a);Vj(a);Wj(a)}
function Xj(a,b,c,d){if(!d)return 0;b=Math.abs(b-d[0])/a.jc;a=Math.abs(c-d[1])/a.Mb;return Math.sqrt(b*b+a*a)}function Yj(){return window.innerWidth||document.documentElement.clientWidth||document.body.clientWidth}function Zj(a,b){return a.D.config.temp.cleanAPIUrls===!1?b:ak(a,b)}function Ej(a,b=!1){var c=a.xc-a.Xf;if(c>=3E4||c>0&&b)for(a.Xf=a.xc,b=a.Eb.totalTime,c=0;c<10;c++)V(a,"sd"+c,B(a.Eb[c]/b*100))}
function bk(a,b,c=!1){c&&Ki(a);var d;[c,d]=mi(a,b);if(b===document){b="";var e=Xj(a,c,d,a.Cd);e&&(a.Lb+=e,V(a,"s",a.Lb));a.Cd=[c,d];if(a.je&&(e=c,a.je&&e>0)){var f=Yj();a.Lg==f?a.Sg!=e&&a.jc==f&&a.Jh++==5&&Wc(a,-6,Zj(a,a.Ea)):a.Lg=f;a.Sg=e}mj(a)}else if(b=a.$.da(b),b===void 0)return;K(a,{t:"S",I:b,x:c,y:d})}
function ck(a,b){const c=b.pageX,d=b.pageY,e=b.clientX;b=b.clientY;const f=a.g.Z.W();if(f-a.Fg<100)a.vf&&clearTimeout(a.vf),a.vf=setTimeout(function(){K(a,{t:"m",x:c,y:d})},100);else{var g=Xj(a,e,b,a.Hg);g&&(a.Vc+=g,V(a,"m",a.Vc));a.Hg=[e,b];a.Fg=f;K(a,{t:"m",x:c,y:d})}}
async function dk(a,b){if(b.type!=="hidden"){if(!a.Qa(b)){var c=a.Ya(b);c.state===1&&(c.state=2,++c.Mg,ek(a,b,c));!b.value&&c.filled?(c.filled=!1,ek(a,b,c)):b.value&&!c.filled&&(c.filled=!0,ek(a,b,c));if(c=fk(a,b)){c=a.Ya(c);var d=c.Gg;c.Gg=b;d!=b&&(d&&ek(a,d,a.Ya(d)),ek(a,b,a.Ya(b)))}}c=a.$.da(b);if(c!==void 0&&a.Na){c={t:"C",I:c};if(b.getAttribute("type")==="checkbox"||b.getAttribute("type")==="radio")c.v=b.checked.toString();else{d=gk(b);if(a.Qa(b)&&b.value.length>0){d="****";var e=!0}else[d,e]=
hk(d,a.Za(b))||[];e||hj(a,b)?c.v=d:a.zb?((b=await a.pa.encrypt(d))&&b!=="*"&&(c.qenc=b),c.v=O(d)):ik(a,b)?c.v=O(d):c.v=d}K(a,c)}}}
function jk(a,b){if(typeof b.selectionStart=="number"&&typeof b.selectionEnd=="number")return[b.selectionStart,b.selectionEnd-b.selectionStart];var c=document.selection.createRange();if(!c||a.g.G.parentNode(c)&&a.g.G.parentNode(c)!=b)return[0,0];a=b.value.length;var d=b.createTextRange();d.moveToBookmark(c.getBookmark());c=b.createTextRange();c.collapse(!1);if(d.compareEndPoints("StartToEnd",c)>-1)return[a,0];b=b.value.replace(/\r\n/g,"\n");var e=-d.moveStart("character",-a);e+=b.slice(0,e).split("\n").length-
1;if(d.compareEndPoints("EndToEnd",c)>-1)return[e,a-e];a=-d.moveEnd("character",-a);a+=b.slice(0,a).split("\n").length-1;return[e,a-e]}function kk(a,b,c){if(!a.Qa(b)){var d=a.$.da(b);if(d!==void 0)try{c||(c=jk(a,b)),a.$.B(b).Rf=c,K(a,{t:"*",I:d,s:c[0],l:c[1]})}catch(e){}}}function lk(a,b){Ki(a);if(!a.Qa(b)){var c=Y(a,b);if(c=="input"||c=="textarea")if(c=a.$.B(b),c.xb!=b.value&&(c.xb=b.value,dk(a,b)),c.da!==void 0)try{var d=jk(a,b);c.Rf&&c.Rf[0]==d[0]&&c.Rf[1]==d[1]||kk(a,b,d)}catch(e){}}}
function mk(a,b){var c=a.Ya(b);c.state=1;c.zf=a.g.Z.W();c.eh=!1;a.Rb=b;setTimeout(function(){Sj(a,b)},10)}function nk(a,b){a.Ya(b).state=0;a.Rb==b&&(a.Rb=null);var c=b.value;if(!a.Qa(b)&&a.ah.test(c)&&!a.ng&&!a.Za(b)){a.ng=!0;const d=ok(a,b),e=a.zb&&d?256:0;(e?a.pa.encrypt(c):Promise.resolve(ik(a,b)?O(c):c)).then(f=>Wc(a,-8,f,e)).catch(ua)}setTimeout(function(){Sj(a,b)},1E3);ug(a.R,b);Tj(a,b)}
function gk(a){const b=a.getAttribute("type");a=b=="checkbox"||b=="radio"?a.checked.toString():a.value;return a==null?"":a}function Sj(a,b){if(!Oi(a.g.Xa,b)){var c=a.$.B(b),d=gk(b);d!=c.xb&&(c.xb=d,dk(a,b))}}
function pk(a){if(!a.jg){function e(f){return function(g){if(g){g=g.toString().replace(/"|\r?\n|\r|\t/g,"").replace(a.Ih,"").trim();for(var h=0;h<a.D.aa.Df.length;++h){const m=a.D.aa.Df[h];if(m.test(g)){g=Nj(g,m);break}}h=J(g,a.D.aa.Ig);g=[g,h]}else g=["",!1];const [k,l]=g;a&&a.R&&P(a.R,{id:f,ja:1,Ca:1,flags:l?256:0,ka:a.g.Z.W()},k)}}var b=window.alert;window.alert=function(...f){Z(a,function(){e(-23)(f[0])});return b.apply(window,f)};var c=window.confirm;window.confirm=function(...f){Z(a,function(){e(-47)(f[0])});
return c.apply(window,f)};if(a.D.config.hookPrompt&&!window.location.href.indexOf("capacitor:")==0){var d=window.prompt;window.prompt=function(...f){Z(a,function(){e(-48)(f[0])});return d.apply(window,f)}}a.jg=!0}}function qk(a,b="input"){b=a.g.G.pb(document,b);for(var c=0;c<b.length;++c)a.fh(b[c]);a.$.K.forEach(a.fh.bind(a))}function hk(a,b=!1){return b?[O(a),!0]:[a,!1]}function ik(a,b){const c=a.D.aa.Pb;return!!c&&a.g.ia.matchesSelector(b,c)}
function rk(){return window.innerHeight||document.documentElement.clientHeight||document.body.clientHeight}function sk(a,b,c,d){Ki(a);c=a.$.da(c);if(c!==void 0&&d.touches!==void 0){for(var e=[],f=0;f<d.touches.length;++f){var g=d.touches[f];e.push({p:[g.pageX,g.pageY],r:[g.radiusX,g.radiusY],a:g.rotationAngle,f:g.force})}K(a,{t:b,I:c,T:e})}}
function tk(a,b){if(b.getAttribute){var c=b.getAttribute("id");if(c){try{var d=a.g.G.pb(document,'label[for="'+c.replace(/"/g,'\\"')+'"]')}catch(f){}if(d&&d.length>0&&(d=a.g.G.textContent(d[0])||a.g.G.innerText(d[0]))&&(d=d.trim(),d.length<30))return d}if((d=b.getAttribute("title"))||(d=b.getAttribute("name")))return d;if(d=b.getAttribute("placeholder"))return"'"+d+"'";if(Y(a,b)=="form"&&b.querySelector){var e=a.g.G.ea(b,"input[type=submit]");e&&(d=e.value);if(d)return"|"+d}if(d=c)return"#"+d;if(d=
b.getAttribute("class"))return"."+d;if(d=b.getAttribute("action"))return"!"+d}return(d=a.cb(b))?"@"+d:""}function fk(a,b){for(b=a.g.G.parentNode(b);b;){if(b.nodeName.toLowerCase()=="form"||b==document)return b;b=a.g.G.parentNode(b)}return null}function ok(a,b){return ij(a,b)==="encrypt"?!0:a.Nb(b)}function Tj(a,b){var c=a.Ya(b);if(!c.eh){var d=a.g.Z.W();c.Ng=(c.Ng||0)+(d-c.zf);ek(a,b,c);c.state==1?c.zf=d:c.eh=!0}}
async function ek(a,b,c){if(!a.Qa(b)&&!a.Za(b)){var d=fk(a,b);if(d){var e=a.Ya(d);e.Zg||uk(a,d,e);d={c:c.Mg||0,"?":!!c.filled,d:b==e.Gg,t:c.Ng||0};var f=b.value||"";f&&f.length>100&&(f=f.substring(0,99));if(a.zb){b=await a.pa.encrypt(f);const g=await ge(a.pa,f);b&&b!=="*"&&(d.qenc=b);d.v=g||O(f)}else ik(a,b)?d.v=O(f):d.v=f;a.D.config.disableFormSubmitFields||c.xb&&c.xb==d.v||(b=sj(a),(f=b.f)||(b.f=f={}),(b=f[e.id])||(f[e.id]=b={}),b[c.name]=d,c.xb=d.v);a=a.R;a.yf=c;qg(a,"form",a.J.g.Z.W())}}}
function uk(a,b,c){c.id=++a.mg;if(!a.D.config.disableFormSubmitFields){var d=sj(a),e=d.F;e||(d.F=e=[]);c.Zg=!0;b=b.getAttribute&&Zj(a,b.getAttribute("action"))||"";e.push({i:c.id,n:c.name,a:b,ts:a.g.Z.W()})}}function Cj(a,b,c=!0){var d=b.toString();b.stack&&(d+="\n"+b.stack.toString());rg(a,d);c&&(a.ya=y.ERROR,a.ua=[],a.ca={})}
function vk(a){if(!a.$a){ej(a,a.O,a.ea);a.Lc&&a.Lc();a.$a=a.g.Z.W();Ej(a,!0);Gj(a);ki(a.g.Da);var b=a.R.$b;if(b){const d=Pj(a,b,a.Qf,a.Uf);var c=Ji(a,b)||"";b=wk(a,b);V(a,"out",{t:"OUT",u:b||"",n:d,P:c||"",ts:a.g.Z.W()})}a.Wc=a.g.Z.W();K(a,{t:"f"});a.ba.flush();gj(a)}}
async function xk(a,b){const c={flags:0,id:-65,ka:a.g.Z.W(),ja:2,kd:!0},d={blockedURI:b.blockedURI,columnNumber:b.columnNumber,disposition:b.disposition,documentURI:b.documentURI,effectiveDirective:b.effectiveDirective,lineNumber:b.lineNumber,originalPolicy:b.originalPolicy,referrer:b.referrer,sample:b.sample,sourceFile:b.sourceFile,statusCode:b.statusCode};var e=a.g.G.stringify(d,cc);e=await Ub(e);P(a.R,c,b.effectiveDirective,{hash:e,value:d})}
function yk(a,b,c=!1){var d=Uc(a.$,b);if(!d.ji&&(d.ji=!0,d={wheel:function(e){const f=a.g.G.W();({deltaY:e}=e);const g=a.D.config;zk(a,a.Ph,e,f,{window:g.rageScrollWheelWindow,bf:g.rageScrollWheelDirChanges,Ff:g.rageScrollWheelMinDistance,Tg:g.rageScrollWheelIgnoreDelay})},click:function(e){if(Ak(e)){let g=e.pageX;var f=e.pageY;e.pointerType===""&&(f=e.target.getBoundingClientRect(),g=f.left+window.scrollX+f.width/2,f=f.top+window.scrollY+f.height/2);Rj(a,Bk(a,e),g,f)}},dblclick:function(e){Rj(a,
Bk(a,e),e.pageX,e.pageY)},contextmenu:function(e){var f=Bk(a,e),g=e.pageX;e=e.pageY;Ki(a);f=a.$.da(f);f!==void 0&&K(a,{t:"R",I:f,x:g,y:e})},mousedown:function(e){var f=Bk(a,e),g=e.pageX;e=e.pageY;Ki(a);f=a.$.da(f);f!==void 0&&K(a,{t:"D",I:f,x:g,y:e})},mouseup:function(e){var f=Bk(a,e),g=e.pageX;e=e.pageY;Ki(a);f=a.$.da(f);f!==void 0&&K(a,{t:"U",I:f,x:g,y:e})},pointerup:function(e){var f=Bk(a,e);if(Ak(e)&&f!=document){var g=e.pageX;e=e.pageY;var h=Y(a,f);h=va.has(h)&&f.disabled;var k=f.closest&&f.closest("[disabled]");
k=k&&va.has(Y(a,k));f.nodeType==1&&(h||k)&&(f=Pj(a,f,g,e),Wc(a,-49,f))}},keypress:function(e){e=Bk(a,e);a.g.G.tagName(e)&&(Oi(a.g.Xa,e)||lk(a,e))},keyup:function(e){const f=Bk(a,e);e instanceof KeyboardEvent&&f&&a.g.G.tagName(f)&&!Oi(a.g.Xa,f)&&(++a.Zb,V(a,"k",a.Zb),lk(a,f))},paste:function(e){e=Bk(a,e);var f={flags:0,s:2,id:-28,ka:a.g.Z.W()};P(a.R,f,Vc(a,e,0,0))},cut:function(e){Ck(a,Bk(a,e))},copy:function(e){Ck(a,Bk(a,e))},touchstart:function(e){var f=Bk(a,e);a.kb.Fb=null;sk(a,"!",f,e)},touchmove:function(e){var f=
Bk(a,e);if(e.touches!==void 0)if(e.touches.length!==1)a.kb.Fb=null;else{var g=e.touches[0].clientY;if(a.kb.Fb===null)a.kb.Fb=g;else{var h=a.kb.Fb-g;a.kb.Fb=g;g=a.D.config;Math.abs(h)<g.rageScrollTouchJitter||zk(a,a.kb,h,a.g.G.wa.contentWindow.Date.now(),{window:g.rageScrollTouchWindow,bf:g.rageScrollTouchDirChanges,Ff:g.rageScrollTouchMinDistance,Tg:g.rageScrollTouchIgnoreDelay})}}sk(a,"@",f,e)},touchend:function(e){var f=Bk(a,e);a.kb.Fb=null;sk(a,"#",f,e)},touchcancel:function(e){var f=Bk(a,e);a.kb.Fb=
null;sk(a,"$",f,e)}},Dk(a,b,{scroll:function(e){e=a.g.G.K(e);a.g.G.tagName(e)&&bk(a,e,!1)},select:function(e){e=a.g.G.K(e);var f=Y(a,e);f!="input"&&f!="textarea"||kk(a,e)},play:function(e){Ek(a,a.g.G.K(e),!0)},pause:function(e){Ek(a,a.g.G.K(e),!1)},reset:function(e){e=a.g.G.K(e);Y(a,e)!="form"||a.Qa(e)||(e=a.$.da(e),e!==void 0&&K(a,{t:"E",I:e}))},change:function(e){e=a.g.G.K(e);var f=Y(a,e);f!="input"&&f!="textarea"&&f!="select"&&f!="option"||Sj(a,e)},submit:function(e){e=a.g.G.K(e);if(Y(a,e)=="form"){if(!a.D.config.disableFormSubmitFields){var f=
a.Ya(e);f.Zg||uk(a,e,f);if(!a.D.config.disableFormSubmitFields){var g=sj(a),h=g.S;h||(g.S=h={});h[f.id]=a.g.Z.W()}f=a.R;f.Af=e;qg(f,"formSubmitted",f.J.g.Z.W())}e=a.$.da(e);e!==void 0&&K(a,{t:"SU",I:e});Qj(a)}},focus:function(e){a.Na&&(e=e.composedPath?e.composedPath():[e.target],(e.find(f=>ic(a.g.G,f))||document)===b&&e.filter((f,g)=>g===0||ic(a.g.G,f)).forEach(f=>{ic(a.g.G,f)&&(f=f.host);if(f){var g=Y(a,f);g!="input"&&g!="textarea"||mk(a,f);f=a.$.da(f);f!==void 0&&K(a,{t:"F",I:f})}}))},blur:function(e){a.Na&&
(e=e.composedPath?e.composedPath():[e.target],(e.find(f=>ic(a.g.G,f))||document)===b&&e.filter((f,g)=>g===0||ic(a.g.G,f)).forEach(f=>{ic(a.g.G,f)&&(f=f.host);if(f){var g=Y(a,f);g!="input"&&g!="textarea"||nk(a,f);f=a.$.da(f);f!==void 0&&K(a,{t:"B",I:f})}}))},mouseover:function(e){((e.composedPath?e.composedPath():[e.target]).find(f=>ic(a.g.G,f))||document)===b&&Kj(a,Bk(a,e),e.pageX,e.pageY)},mouseout:function(e){((e.composedPath?e.composedPath():[e.target]).find(f=>ic(a.g.G,f))||document)===b&&Lj(a,
Bk(a,e),e.pageX,e.pageY)}}),!c)){Dk(a,b,d);a.g.G.addEventListener(window,"focus",function(){setTimeout(()=>{K(a,{t:"wf"})},0)},!0);let e=null;a.g.G.addEventListener(window,"blur",function(){e===null&&(e=setTimeout(()=>{e=null;var f=document.activeElement;Y(a,f)=="iframe"&&(V(a,"c",++a.ec),tg(a.R,f),f={flags:0,id:-1,ka:a.g.Z.W(),ja:1,Ca:1},P(a.R,f,""),Qj(a));K(a,{t:"wb"})},0))},!0);a.g.G.addEventListener(window,"unhandledrejection",function(f){try{a.D.config.disableErrorHooking||Oj(a,"Unhandled rejection (promise: "+
f.promise+", reason: "+f.reason+").")}catch(g){}},!0)}}
function Fk(a){a.zg||(a.zg=!0,document.addEventListener&&a.g.G.addEventListener(document,"mousemove",function(b){Z(a,function(){ck(a,b)})},!1),window.addEventListener&&(a.g.G.addEventListener(window,"load",function(){Z(a,function(){K(a,{t:"~"})})},!1),a.g.G.addEventListener(window,"DOMContentLoaded",function(){Z(a,function(){K(a,{t:"`"})})},!1),a.g.G.addEventListener(window,"resize",function(){Z(a,function(){Ki(a);a.jc=Yj();a.Mb=rk();K(a,{t:"+",w:a.jc,h:a.Mb});bk(a,document)})},!1),a.g.G.addEventListener(window,
"pagehide",()=>{Z(a,function(){vk(a)})},!1),a.g.G.addEventListener(window,"pageshow",b=>{Z(a,()=>{oc(a.g.G);b.persisted&&a.$a&&(a.$a=void 0,fj(a,ib(a.M)))})},!1),a.g.G.addEventListener(window,"orientationchange",function(){Z(a,function(){try{const b=window.screen.orientation.angle;Ki(a);K(a,{t:"/",o:b});Wc(a,-41,b);bk(a,document)}catch(b){}})},!1),a.g.G.addEventListener(window,"scroll",function(){Z(a,function(){bk(a,document,!0)})},!1),a.g.G.addEventListener(window,"securitypolicyviolation",b=>{Z(a,
function(){xk(a,b)})},!1),"ReportingObserver"in window&&(new window.ReportingObserver((b,c)=>{for(const {body:d}of b)xk(a,{blockedURI:d.blockedURL,columnNumber:d.columnNumber,disposition:d.disposition,documentURI:d.documentURL,effectiveDirective:d.effectiveDirective,lineNumber:d.lineNumber,originalPolicy:d.originalPolicy,referrer:d.referrer,sample:d.sample,sourceFile:d.sourceFile,statusCode:d.statusCode});c.disconnect()},{types:["csp-violation"],buffered:!0})).observe()),yk(a,document))}
function Ek(a,b,c){b=a.$.da(b);b!==void 0&&K(a,{t:"M",I:b,p:c})}function Ck(a,b){var c={flags:0,s:2,id:-29,ka:a.g.Z.W()};P(a.R,c,Vc(a,b,0,0))}function Ak(a){return a.isTrusted!==!1||a.forwardedTouchEvent&&a.forwardedTouchEvent==1||a.isIonicTap&&a.isIonicTap==1?!0:!1}function Dk(a,b,c){for(const d of Object.keys(c))a.g.G.addEventListener(b,d,function(e){Z(a,function(){c[d](e)})},!0)}function Bk(a,b){return!a.g.G.qa(b)||a.tf?a.g.G.K(b):(a=a.g.G.la(b))&&a.length?a[0]:null}
function Gk(a,b){return b?Y(a,b)==="select"?b:Gk(a,a.g.G.parentNode(b)):null}function $i(a){return aj(a)?a.ta.getEntriesByType("navigation")[0]:a.ta.timing}function aj(a){return!!a.ta.timeOrigin&&!!a.ta.getEntriesByType("navigation")[0]}function Hk(a){a.qg=document.visibilityState==="visible";if(!a.qg&&a.ta){var b=$i(a);b=aj(a)?a.g.Z.yb:b.navigationStart;a.pg=a.g.Z.W()-b}}
function Ik(a,b,c){if(!b||b==-5){if(b!=-5){if(a.Pc>0)throw Error(c);rg(a,c+"\n"+Error().stack.toString())}a.ya=y.ERROR;a.ua=[];a.ca={}}}function Jk(a,b,c=!0){if(b instanceof ph)Ik(a,-5,"conn4");else if(b instanceof nh)Cj(a,b,c);else if(b instanceof oh)Cj(a,`Maximum retries reached:${b.message}`,c);else throw b;}
function Kk(a,b,c=!1){try{var d=b.split("/");if(d.length!==3||b.indexOf("DOCTYPE")>-1)throw Error("Invalid session response");[a.B.va].includes(a.K)&&(a.ha=d[0],a.za=d[1]);a.Ba=d[2];a.Ha.La("start-event",{ha:a.ha,za:a.za,Ba:a.Ba,url:a.M.eb.qb});kh.La("capture-ready",a)}catch(e){Ik(a,!1,`BSR:${b}`)}Wh(a.g.nc,a.ha);Xh(a.g.nc,a.za);Lk(a);Mk(a,c);a.we&&oj(a,{method:"POST",url:"/v1/set-context",body:a.getContext()}).then(()=>oj(a,{method:"POST",url:"/v1/reset",body:{}})).then(()=>{a.we=!1});a.Mc.length&&
(cj(a,"qr",4096,a.Mc),a.Mc=[])}function Nk(a){a.Id||(a.Id=setTimeout(function(){Ok(a)},a.D.config.publishInterval))}function Wj(a){if(a.ua.length!=0&&a.Yb){var b=a.Oc.M==0&&a.Yb;if(a.ha&&a.Ba||b)if(!a.Oc.B||a.$a)b=a.g.G.stringify(a.ua),a.Oc.send(b).then(c=>{c&&(Kk(a,c,!!a.ha),a.Ba&&wd(a.oa,"start",{sessionID:a.ha,userID:a.za,hitID:a.Ba,url:a.M.eb.qb}))}).catch(c=>{Jk(a,c)}),a.Nf++,a.ua=[]}Nk(a)}
function Pk(a){a.Kc&&clearTimeout(a.Kc);a.Kc=setTimeout(function(){Z(a,function(){V(a,"p",1);a.Kc=null;a.Gc||Pk(a)})},3E4)}function Vj(a){if(a.Sb&&a.Ba&&(!a.Dd.B||a.$a)){var b=a.g.G.stringify(a.ca);a.Dd.send(b).catch(c=>{Jk(a,c)});a.ca={};Pk(a);a.Sb=!1}}
function Lk(a){try{Bj(a,a.ha),Qk(a,a.za)}catch(f){}try{if(a.D.config.sessionVar)for(var b=window,c=a.D.config.sessionVar.split("."),d=0;d<c.length;d++){var e=c[d];if(d==c.length-1)b[e]=a.ha;else if(b=b[e],!b){console.error(" - QM (extra) session failed - "+e+".  Object path doesn't exist: "+a.D.config.sessionVar);break}}}catch(f){}Rk(a)}
function Mk(a,b=!1){const c=async()=>{Sk(a,a.D.config.sampleReplay,!0);try{await Tk(a)}catch(w){a.xa("network_interceptor_bridge_error",w.message)}if(a.D.config.abnSegmentCookie){var e=a.ra.get(a.D.config.abnSegmentCookie);if(e&&e&&Uk(a)!=e){var f={flags:128,id:-100,ka:a.g.Z.W()};P(a.R,f,e)}}try{var g=window.doNotTrack||window.navigator.doNotTrack||window.navigator.msDoNotTrack;if(g){e=!1;switch(typeof g){case "number":g==1&&(e=!0);break;case "string":e=g.charAt(0)==="1"||g==="yes"}if(e){const w=
{flags:0,id:-45,ka:a.g.Z.W(),Ca:0};P(a.R,w,"")}}}catch(w){}P(a.R,{id:-9998,Ca:0,flags:512,ja:2,ka:a.g.Z.W()},"1.35.41");K(a,{t:"git",v:"7902b8226"});[a.B.va].includes(a.K)&&P(a.R,{id:-9997,Ca:0,ja:0,flags:1024,ka:a.g.Z.W()},"web");if(window.location&&typeof window.location.search=="string")var h=window.location.search;if(h!==void 0&&h.indexOf("utm_")!==-1){g=a.g.Z.W();h=new URLSearchParams(h);for(const [w,D]of h.entries())h=qa[w],h!==void 0&&P(a.R,{id:h,ja:2,flags:0,ka:g},D)}cb(a,"type")!="reload"||
a.yc?cb(a,"type")!="back_forward"||a.yc?!a.yc&&a.Oe&&(h={flags:0,id:-30,ja:!0,ka:a.g.Z.W()},P(a.R,h,a.Ea),a.yc=!0,a.Oe=!1):(h={flags:0,id:-30,ja:!0,ka:a.g.Z.W()},P(a.R,h,a.Ea),a.yc=!0):(h={flags:0,id:-10,ja:!0,ka:a.g.Z.W()},P(a.R,h,a.Ea),a.yc=!0);h=a.fa.get("slr",null);h===null&&(h=a.D.config.logResourcePercent?a.g.Z.W()%100<a.D.config.logResourcePercent:!1,a.fa.set("slr",h));a.jh=h;a.vg||(a.vg=!0,Vk(a),Wk(a),a.D.config.spaTransitionStartMarkerName&&a.D.config.spaTransitionStopMarkerName&&Xk(a));
a.ke&&(h={flags:0,id:-26,ka:a.g.Z.W(),ja:0},P(a.R,h,""));if(a.D.config.checkBlankPages)try{if(typeof window.sessionStorage==="object"&&a.ta){var k=window.location.hostname;if(document.referrer&&document.referrer.includes(k)){var l=a.g.G.Storage.getItem.call(window.sessionStorage,"qm_last_page"),m=a.g.G.Storage.getItem.call(window.sessionStorage,"qm_last_period");if(m){var n=a.g.Z.W(),x=n-parseInt(m,10)-(a.ta&&a.ta.timing.navigationStart?n-a.ta.timing.navigationStart:5E3);if(x>a.D.config.pbpThreshold&&
x<6E4){var r=cb(a,"type")=="reload";k=!1;l&&l.indexOf(document.referrer)>=0&&(k=!0);l="Gap";r&&(l+=" Reload");k&&(l+=" Ref_Match");var q={flags:0,s:1,id:-27,ka:a.g.Z.W()};P(a.R,q,l)}}}a.g.G.Storage.setItem.call(window.sessionStorage,"qm_last_page",document.location.toString());a.g.G.Storage.removeItem.call(window.sessionStorage,"qm_last_period")}}catch(w){}!a.ra.get(a.D.config.sessionCookieName)&&a.gf&&(r={flags:0,id:-55,ka:a.g.Z.W(),ja:0},P(a.R,r,""));a.gf||(r={flags:0,id:-33,ka:a.g.Z.W(),ja:0},
P(a.R,r,""));a.fa.set("eSync",!0);Qj(a)};if(b){b=a.fa.get("eSync",!1);var d=a.fa.get([],{});if(b&&La(d)&&(b=Ja(d),a.Hf||Yk()||!document.referrer&&!a.D.config.temp.enableKVS)){sg(a.R,b);c();return}a.D.config.temp.enableKVS?a.la.get({s:a.ha,Q:5}).then(e=>{Z(a,async function(){let f,g,h=await e.text();h=h.replace(/[\u0000-\u001F\f]/gm,"");if(h==="")sg(a.R,{E:[]});else{try{f=a.g.G.Ra(h)}catch(k){g=k.toString()}Ik(a,f,"BEI-"+g+"-"+h);a.fa.import(f);f=Ja(f);sg(a.R,f)}c()})}).catch(()=>{Z(a,function(){sg(a.R,
{E:[]});c()})}):(sg(a.R,{E:[]}),c())}else sg(a.R,{E:[]}),c()}function oj(a,{method:b,url:c,body:d},e=ua){const f=[],g=[];a.Pd.forEach(h=>{try{if(a.g.G.isConnected(h)){const k=a.g.zc.Ga(h.contentWindow,{method:b,url:c,body:d}).then(l=>{e(l,h)}).catch(l=>{L(a.ba,"sdkcomm: issue sending message to child",{message:l.message,method:b,url:c},"error")});g.push(k)}else f.push(h)}catch(k){f.push(h)}});f.forEach(h=>{a.Pd.delete(h)});return Promise.all(g)}
function cj(a,b,c,d){P(a.R,{id:0,flags:c,ja:1,Ca:null,ka:a.g.Z.W()},d);V(a,b,d)}function Hj(a){a.Oc=new xh(a,a.mf.bind(a),a.D,a.la,a.g.G);a.Dd=new xh(a,a.Fi.bind(a),a.D,a.la,a.g.G);a.wg=new xh(a,a.Ei.bind(a),a.D,a.la,a.g.G)}function Ok(a){Z(a,function(){a.Id=void 0;Wj(a);Vj(a)})}function Gj(a){V(a,"e",B(a.Fc/1E3));V(a,"c",a.ec);V(a,"m",a.Vc);V(a,"s",a.Lb);V(a,"k",a.Zb)}function Zk(a,b){return!J(b,a.D.aa.Eh)&&J(b,a.D.aa.Gh)}function $k(a,b){return J(b,a.D.aa.Fh)||!J(b,a.D.aa.Dh)}
function ak(a,b){if(b){try{var c=new URL(b,window.location.href);c.search="";b=c.href}catch(d){}for(c=0;c<a.D.aa.Sf.length;c++)b=b.replace(a.D.aa.Sf[c],"");return b}return""}function al(a,b){return typeof b!=="string"?null:b.split("\r\n").reduce((c,d)=>{if(!d)return c;const e=d.split(":")[0];for(let f=0;f<a.D.aa.ff.length;++f)if(a.D.aa.ff[f].test(e))return c;return c+d+"\r\n"},"")}function bl(a,b){return J(b,a.D.aa.Bh)?!1:J(b,a.D.aa.Ah)?!0:a.D.config.encryptXHR}
async function cl(a,b){var c=null;try{c=b.qresponse&&b.qresponse.length?b.qresponse:b.responseType==""||b.responseType=="text"?b.responseText:b.response,b.responseType==="blob"&&b.getResponseHeader("Content-Type")==="application/json"&&(c=await c.text().then(a.g.G.Ra)),b.responseType==="arraybuffer"&&b.getResponseHeader("Content-Type").startsWith("application/json")&&(c=String.fromCodePoint.apply(null,new Uint8Array(c))),typeof c=="object"&&(c=a.g.G.stringify(c))}catch(d){}return c}
function dl(a,b,c){return!a.ha||a.Vb?new Promise(d=>a.Hc.push({de:b,data:c,resolve:d})):a.wg.send(c,{de:b}).then(()=>!0).catch(d=>{Jk(a,d,!1);return!1})}
async function el(a,b,c,d,e,f,g){try{if(!(c.indexOf("data:")>-1)){var h=g.qend||a.g.Z.W(),k=!1;if(c&&typeof c==="string"&&$k(a,c)){var l=od(a.g.oa,Ta(c),f,g.response);l&&(l.url&&(c=l.url),l.status&&(b=l.status));c=Ua(a.D.aa.ac,a.D.aa.fc,Ta(c));if(!(c.indexOf("quantummetric.com")>=0)||a.D.config.temp.isPivot){var m=await cl(a,g)||"";try{var n=g.getAllResponseHeaders()}catch(C){}var x=al(a,n),r=al(a,g.reqHeaders);f=await nf(g,e,f);g.qrequest=f;g.qurl=c;g.qstatus=b;g.qreqheaders=g.reqHeaders;g.qrespheaders=
n;g.qresponse=m;g.qmethod=e;g.qduration=h-d;"responseURL"in g||(g.responseURL=c);if(Zk(a,c)&&a.Na){var q={t:"xhr",m:e,u:c,st:b,s:d,r:h-d},w=f?f.toString():"";n=l=!1;w.length>a.D.config.maxXHRDataLength?l=!0:w=Ma(w,a.D.aa.af,a.g.G);m.length>a.D.config.maxXHRDataLength?n=!0:m=Ma(m,a.D.aa.af,a.g.G);const C=bl(a,c);if(C){const t=await he(a.pa,x);t?q.resHeaders_enc=t:q.resHeaders=O(x||"");if(w&&!w.startsWith("QM: "))if(l)q.req="QM: Too much data ("+w.length+") to encrypt request";else{const p=Ia(),u=await he(a.pa,
w);u?(q.req_enc={h:p,enc:!0},dl(a,p,u)):(q.req={h:p,enc:!1},dl(a,p,O(w)))}if(m&&!m.startsWith("QM: "))if(n)q.res="QM: Too much data ("+m.length+") to encrypt response";else{const p=Ia(),u=await he(a.pa,m);u?(q.res_enc={h:p,enc:!0},dl(a,p,u)):(q.res={h:p,enc:!1},dl(a,p,O(m)))}}else{q.resHeaders=x;if(w&&!w.startsWith("QM: "))if(l)q.req="QM: XHR Req data too long ("+w.length+")";else{const t=Ia();q.req={h:t,enc:!1};dl(a,t,w)}if(m&&!m.startsWith("QM: "))if(n)q.res="QM: XHR Res data too long ("+m.length+
")";else{const t=Ia();q.res={h:t,enc:!1};dl(a,t,m)}}k=!0;a.D.config.logReqCookiesForXHR&&(new RegExp(window.location.hostname,"i")).test(c)&&(r||(r=""),r+="cookie: "+a.ra.getAll()+"\r\n");if(r)if(C){const t=await he(a.pa,r);t?q.reqHeaders_enc=t:q.reqHeaders=O(r)}else q.reqHeaders=r;wd(a.oa,"api",q,g);K(a,q)}var D=J(c,a.D.aa.Hh);J(c,a.D.aa.Ch)||(b>=500?Wc(a,-3,Zj(a,c)):b==403||b==401?Wc(a,-13,Zj(a,c)):b==404?Wc(a,-14,Zj(a,c)):b>=400?Wc(a,-15,Zj(a,c)):b==310?Wc(a,-16,Zj(a,c)):b>=300?Wc(a,-17,Zj(a,c)):
b==0&&g&&g.qtimedOut&&Wc(a,-11,Zj(a,c)));D&&(q={m:e,u:Zj(a,c),c:b,st:b,s:f?f.length:0,S:m?m.length:0,r:h-d,ts:B(a.g.Z.W()/1E3)},V(a,"x",q),h-d>a.D.config.xhrPerformanceSlow&&a.Rh++<=3&&Wc(a,-7,Zj(a,c)),k||(q.t="xhr",K(a,q,!0),wd(a.oa,"api",q,g)));a.R&&(g.data=f?f.toString():"",setTimeout(function(){var C=a.R;C.Ia=g;C.Kd=g;qg(C,"xhr",C.J.g.Z.W());C.Kd=null},0),k||D||wd(a.oa,"api",{m:e,u:c,st:b,r:h-d},g))}}}}catch(C){a.xa("xhr_listener_error",C.message.slice(-256))}}
function fl(a,b){b=Qa(b);a=Qa(a.ra.getAll());var c="",d;for(d in a)a.hasOwnProperty(d)&&(b[d]&&b[d]==a[d]||(c+="set-cookie: "+d+"="+decodeURIComponent(a[d])+"\r\n"));return c}function gl(a,b,c,d){b={t:"pc",I:a.$.da(b),p:c,v:d};K(a,b)}function hl(a){if(!a.nh){a.nh=!0;var b=Aa(window.HTMLStyleElement.prototype,"disabled");b.configurable&&Object.defineProperty(window.HTMLStyleElement.prototype,"disabled",{...b,set:function(c){try{gl(a,this,"disabled",c)}catch(d){}return b.set.call(this,c)}})}}
function il(a,b,c="",d=null,e=0,f=null,g=null){return new Promise((h,k)=>{try{if(typeof b=="object"&&b.constructor&&b.constructor.name==="Response"&&!b.Uh){let l={response:""};l._qmResponseType=b.type;l.getAllResponseHeaders=function(){let m="";if(b.headers&&typeof b.headers.entries=="function"){const n=b.headers.entries();let x=0,r=n.next();for(;!r.done&&x<1E3;)m+=`${r.value[0]}: ${r.value[1]}\r\n`,r=n.next(),x++}a.D.config.monitorXHRSetCookies&&g&&(m+=fl(a,g));return m};f&&(l.reqHeaders=f);if(b.text&&
typeof b.clone==="function"){const m=b.clone();if(b.type==="opaque"||b.type==="opaqueredirect")return l.response="QM: Unable to track opaque response",el(a,m.status,b.Vh,e,c,d,l),h();m.text().then(function(n){l.response=n;el(a,m.status,m.url,e,c,d,l)}).catch(n=>{n.name==="AbortError"&&(l.response=a.ig,el(a,m.status,m.url,e,c,d,l))}).finally(h)}b.Uh=1}}catch(l){k(l)}})}
function jl(a){if(a.Dc===null&&window.fetch&&a.D.config.hookFetch&&!a.sg){a.sg=!0;var b=window._o_Fetch||window.fetch;window.fetch=function(c,...d){const [e,...f]=d;a.g.G.pd(c)==="[object URL]"&&(c=String(c));try{if(a.If)return a.xa("recursive_fetch",window.location.href),a.g.G.contentWindow.fetch.call(this,c,...d);a.If=!0;var g=a.g.Z.W();let x;try{x=c instanceof Request?c:new Request(c,e);var h=x.method,k=null,l=null,m=null;function z(A){var W=null;try{if(A)if(W="",typeof A.entries=="function"){const F=
A.entries();let R=F.next();for(A=0;!R.done&&A<1E3;)W+=`${R.value[0]}: ${R.value[1]}\r\n`,R=F.next(),A++}else for(let F in A)A.hasOwnProperty(F)&&(W+=`${F}: ${A.get?A.get(F):A[F]}\r\n`)}catch(F){}return W}if(typeof c==="string")typeof e==="object"&&(k=e.body,l=z(x.headers));else if(typeof c==="object"&&c.constructor&&c.constructor.name==="Request"&&typeof c.clone==="function"){var n=c.clone();e&&e.body&&typeof e.body=="string"&&e.body.length?k=e.body:window.ReadableStream&&n.body instanceof window.ReadableStream?
Ba(n.body).then(A=>k=A).catch(ua):n.text().then(function(A){k=A}).catch(ua);l=z(e&&e.headers||n.headers)}a.D.config.monitorXHRSetCookies&&(m=a.ra.getAll())}catch(z){}let r=!1,q=!1,w=!1,D,C=e&&e.signal&&e.signal instanceof AbortSignal;try{C&&(D=new AbortController,e.signal.addEventListener("abort",function(){q=!0;p()}),e.signal=D.signal)}catch(z){}let t=!1;const p=()=>{t||!q||r&&!w||(D.abort(),t=!0)};let u=b.call(this,c,...d);try{u.then(function(z){try{if(a.D.config.forceDeferFetchAborts&&(r=!0),!z.qmre_f){z.qmre_f=
1;let A=z.clone();(z.type==="opaque"||z.type==="opaqueredirect")&&x&&x.url&&(A.Vh=x.url);il(a,A,h,k,g,l,m).finally(()=>{w=!0;p()})}}catch(A){}C&&["arrayBuffer","blob","formData","json","text"].forEach((A=>W=>{const F=A[W];A[W]=function(...R){r=!0;return F.call(this,...R)}})(z));return z}).catch(z=>{z.name==="AbortError"&&x&&(z={response:"",getAllResponseHeaders:function(){let A="";a.D.config.monitorXHRSetCookies&&m&&(A+=fl(a,m));return A}},l&&(z.reqHeaders=l),z.response=a.ig,el(a,-1,x.url,g,h,k,z))})}catch(z){}return u}finally{a.If=
!1}};window._o_Fetch&&(window.QuantumMetricFetch=window.fetch)}}function kl(a,b,c){var d=a.$.B(b),e=d.url,f=d.method,g=a.g.Z.W();if(b.readyState===4)el(a,b.status,e,g,f,c,b);else{var h=function(){Z(a,function(){e=e||b.responseURL;b.readyState==4&&(b.qresponse=b.response,el(a,b.status,e,g,f,c,b),b.removeEventListener&&b.removeEventListener("readystatechange",h))})};b.addEventListener&&a.g.G.addEventListener(b,"readystatechange",h,!1)}}
function ll(a){function b(m,n,...x){var r=this;Z(f,function(){var q=f.$.B(r);q.method=m;q.url=n});return g.call(this,m,n,...x)}function c(m,...n){var x=this;Z(f,function(){x.addEventListener("abort",function(){x.qaborted=!0},!1);x.addEventListener("error",function(){x.qnetworkError=!0},!1);x.addEventListener("timeout",function(){x.qnetworkError=!0;x.qtimedOut=!0},!1)});Z(f,()=>{setTimeout(function(){kl(f,x,m)},0)});return h.call(this,m,...n)}function d(m,n,...x){try{this.reqHeaders=(this.reqHeaders||
"")+(m+": "+n+"\r\n")}catch(r){}return k.call(this,m,n,...x)}function e(...m){var n=this;Z(f,function(){n.qaborted=!0});return l.call(this,...m)}var f=a;if(a.Dc===null){a=window.XMLHttpRequest.prototype;var g=a.open,h=a.send,k=a.setRequestHeader,l=a.abort;if(g&&h&&k&&(a.open=b,a.send=c,a.setRequestHeader=d,a.abort=e,a.open!=b))try{Object.defineProperty(a,"open",{value:b,writable:!0,enumerable:!0,configurable:!0}),Object.defineProperty(a,"send",{value:c,writable:!0,enumerable:!0,configurable:!0}),
Object.defineProperty(a,"setRequestHeader",{value:d,writable:!0,enumerable:!0,configurable:!0}),Object.defineProperty(a,"abort",{value:e,writable:!0,enumerable:!0,configurable:!0})}catch(m){}}}
function ml(a){if(a.ha!==void 0)return a.ha;for(let b=0;b<a.D.config.sessionPersistenceMediums.length;b++){const c=a.D.config.sessionPersistenceMediums[b];try{switch(c){case "cookie":const d=Qa(a.ra.getAll())[a.D.config.sessionCookieName],e=typeof d==="string"?d.trim():null;if(e&&e.length<=100)return e;break;default:const f=a.fa.get("s",!1);if(f&&f.length<=100)return f}}catch(d){}}return null}
function nl(a){a.Jb=a.g.Z.W();if([a.B.va].includes(a.K))try{a.Gd&&(a.ha=a.Gd,a.Gd=void 0,a.fa.restore(`QM:s:${a.ha}`));a.ha=ml(a);a:{for(let c=0;c<a.D.config.userPersistenceMediums.length;c++){const d=a.D.config.userPersistenceMediums[c];try{switch(d){case "cookie":const e=Qa(a.ra.getAll())[a.D.config.userCookieName];if(e&&e.length<=100){var b=e.trim();break a}break;default:const f=a.kc.get("u",!1);if(f&&f.length<=100){b=f;break a}}}catch(e){}}b=null}a.za=b;a.fa.get("s",null)&&a.fa.get("s")!==a.ha&&
a.fa.clear()}catch(c){}}function Qk(a,b){if(b){const c=new a.g.G.Date(a.g.Z.W()+31536E6);a.D.config.userPersistenceMediums.forEach(d=>{try{switch(d){case "cookie":a.ra.set({[a.D.config.userCookieName]:b,expires:c.toUTCString()});break;default:a.kc.set("u",b);var e=a.kc;e.B.exp=c.getTime();Eg(e,"exp")}}catch(f){}})}}function Rk(a){if(a.Hc.length>0){const b=a.Hc;a.Hc=[];for(const c of b)dl(a,c.de,c.data).then(c.resolve)}}
function ol(a,b){if(a.ub)try{const f=a.ta.timing.domInteractive-a.ta.timing.requestStart;let g=[];a:for(let h=0;h<b.length&&!(a.Zf>a.D.config.maxResourcesPerHit);h++){const k=b[h],l=k.initiatorType;if(a.D.config.allowedResourceTypes.indexOf(l)>-1){const m={};try{let n=Ua(a.D.aa.ac,a.D.aa.fc,Ta(k.name));const x=xb(a.D.config),r=wb(a.D.config,a.sub);if(x&&n.indexOf(x)>-1||r&&n.indexOf(r)>-1||n.indexOf("quantummetric.com")>-1&&!a.D.config.temp.isPivot||J(n,a.D.aa.Tf))continue a;for(const w in a.cg)if(a.cg.hasOwnProperty(w)){const D=
a.cg[w];m[D]=null;if(typeof k[w]!=="undefined"){let C=k[w];if(typeof C=="number"){if(a.Lh.indexOf(w)>-1&&(C-=a.jf,C>14E6))continue a;C=Math.max(B(C),0)}m[D]=C}}m.st=[];if(k.serverTiming){const w=k.serverTiming;for(var c=0;c<w.length;c++){const D=w[c];try{m.st.push({d:D.description,n:D.name,v:D.duration})}catch(C){}}}m.cr=l!=="xmlhttprequest"&&k.requestStart<f?1:0;m.xo=!n.match(a.lg);if(l=="script"){c=!1;var d=a.g.G.ea(document,"script[src='"+k.name+"']");!d||d.getAttribute("async")==null&&d.getAttribute("defer")==
null||(c=!0);var e=c?1:0}else e=null;m.as=e;m.co=l=="css"||l=="script"?k.decodedBodySize>k.transferSize*1.1?1:0:null;let q=E(k,["duration"],!1);q!=0?q=q<10?1:0:q=null;m.c=q;n&&n.length>1024&&(n=n.substring(0,1024));m.p=n;g.push(m);a.Zf++}catch(n){}}}g.length&&(a.ub?cj(a,"qr",4096,g):a.Mc=a.Mc.concat(g))}catch(f){console.error("QM:: could not process resource timings:",f)}}
function Vk(a){if(a.ta.getEntriesByType)try{a.bh=new window.PerformanceObserver(function(b){const c=a.D.aa.ei;b=b.getEntries();var d=b.filter(e=>{const f=e.nextHopProtocol.startsWith("http/"),g=c.some(h=>h.test(e.name));return f&&!g});if(d.length>0){const e=d.length.toString();d=d.map(f=>ak(a,Ua(a.D.aa.ac,a.D.aa.fc,Ta(f.name)))).filter(f=>!J(f,a.D.aa.Tf));d={hash:Ia(),value:{violations:d}};P(a.R,{flags:0,id:-67,ka:a.g.Z.W(),ja:0},e,d)}a.jh&&ol(a,b)}),a.bh.observe({type:"resource",buffered:!0})}catch(b){}}
function Xk(a){try{a.Vg=new window.PerformanceObserver(function(b){b=b.getEntries();for(let c=0;c<b.length;c++){const d=b[c],e=d.name;e==a.D.config.spaTransitionStartMarkerName&&(a.M.Ld(a.D.config.spaTransitionStopMarkerName),a.Pe=!0,a.jf=fb(a.M),a.Cb&&clearTimeout(a.Cb),a.D.config.temp.stopLoggingSpaMarkers||L(a.ba,"spaMarker",!0));if(e==a.D.config.spaTransitionStopMarkerName){const f=a.ta.getEntriesByName(String(a.D.config.spaTransitionStartMarkerName));a.Pe=!1;f&&f.length&&eb(a.M)&&setTimeout(()=>
{Z(a,function(){a.M.Me(d.startTime-f[f.length-1].startTime);fj(a,a.M.Ua,!0)})},0)}}}),a.Vg.observe({type:"mark",buffered:!0})}catch(b){}}
function pl(a){if(!a.Tb){var b,c="pointerdown keydown click touchstart visibilitychange pagehide".split(" "),d=g=>b=B(g.startTime,3),e=new window.PerformanceObserver(g=>g.getEntries().forEach(d)),f=g=>{g.isTrusted&&b&&document.visibilityState!=="hidden"&&(e.takeRecords().forEach(d),cj(a,"mt",65536,{[a.qa["largest-contentful-paint"]]:b}),a.Tb.disconnect())};e.observe({type:"largest-contentful-paint",buffered:!0});c.forEach(g=>a.g.G.addEventListener(window,g,f,{once:!0}));a.Tb={disconnect(){e.disconnect();
c.forEach(g=>window.removeEventListener(g,f))}}}}function bj(a,b){const c=$i(a).loadEventEnd||Infinity;return b<a.pg&&b<c}
function ql(a){pl(a);const b=new Promise(d=>{let e;const f=new window.PerformanceObserver(g=>{let h=null;for(const k of g.getEntries())bj(a,k.processingStart)&&(h=k.processingStart-k.startTime);clearTimeout(e);d(h);f.disconnect()});f.observe({type:"first-input",buffered:!0});e=setTimeout(()=>{d(null);f.disconnect()},200)}),c=new Promise(d=>{if(!window.PerformanceObserver.supportedEntryTypes.includes("layout-shift"))return d(null);let e;const f=new window.PerformanceObserver(g=>{let h=0;for(const k of g.getEntries())!k.hadRecentInput&&
bj(a,k.startTime)&&(h+=k.value);clearTimeout(e);d(h);f.disconnect()});f.observe({type:"layout-shift",buffered:!0});e=setTimeout(()=>{d(null);f.disconnect()},200)});Promise.all([b,c]).then(([d,e])=>{d={"first-input-delay":d?B(d,3):null,"cumulative-layout-shift":e?B(e,3):null};e={};for(const f in d)d.hasOwnProperty(f)&&(e[a.qa[f]]=d[f]);cj(a,"mt",65536,e)}).catch(()=>{})}
function Wk(a){if(!a.Lc)try{const b=new window.Map,c=({interactionId:e,duration:f,target:g})=>{if(e){f=B(f,0);var h=b.get(e);h&&f<h.duration||(g=Ji(a,g),b.set(e,{duration:f,Fa:g}))}},d=new window.PerformanceObserver(e=>{e.getEntries().forEach(c)});d.observe({type:"event",buffered:!0,durationThreshold:16});a.Lc=()=>{d.takeRecords().forEach(c);var e=[...b.values()].sort((h,k)=>h.duration-k.duration);if(e.length!==0){var {duration:f,Fa:g}=e[Math.min(e.length-1,Math.ceil(.98*e.length)-1)];f>0&&(e={v:f,
sel:g},V(a,"inp",e),K(a,{t:"inp",v:e},!0));b.clear()}}}catch(b){}}function rl(a){if(a.Bc&&a.Bc.length)try{let b={};const c=$i(a),d=aj(a)?a.g.Z.yb:c.navigationStart;let e=[];a.Bc.forEach(f=>{let g=c[f];typeof g==="number"&&(aj(a)||(g=Math.max(g-d,0)),g>0&&g<14E6?b[a.qa[f]]=B(g):e.push(f))});cj(a,"mt",65536,b);a.Bc=e}catch(b){}}async function sl(a){var b=a.ra.getAll();(b=await he(a.pa,b))&&K(a,{t:"c",encrypted_cookies:b})}
function tl(a){if(!a.fb){a.fb={};try{var b=function(){var c=window.navigator.userAgent,d=c.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i)||[];if(/trident/i.test(d[1])){var e=/\brv[ :]+(\d+)/g.exec(c)||[];return"IE "+(e[1]||"")}if(d[1]==="Chrome"&&(e=c.match(/\b(OPR|Edge)\/(\d+)/),e!=null))return e.slice(1).join(" ").replace("OPR","Opera");d=d[2]?[d[1],d[2]]:[window.navigator.appName,window.navigator.appVersion,"-?"];(e=c.match(/version\/(\d+)/i))!=null&&d.splice(1,1,e[1]);return d.join(" ")}().split(" ");
b.length==2&&(a.fb.lb=b[0],a.fb.version=b[1])}catch(c){}}return a.fb}async function ul(a){try{const b=tl(a),{ke:c}=await Gg(b.lb==="Safari",b.lb==="Chrome"||b.lb==="Edge"||b.lb==="Opera",b.lb==="Firefox");a.ke=c}catch(b){}}async function vl(a){if(window.navigator.storage&&window.navigator.storage.estimate){var b=await navigator.storage.estimate();b.usage/b.quota<.95||P(a.R,{flags:0,id:-68,ka:a.g.Z.W(),ja:0},"")}}
function wl(a,b){a.D.config.captureCookiesReplay?a.D.config.allowClearCookies?a.M.sd(b,a.ra.getAll()):setTimeout(()=>{sl(a)},1E3):a.M.sd(b,"");if(!a.M.Bd(b)){var c=$i(a),d=c.domComplete;c=aj(a)?a.g.Z.yb:c.navigationStart;d=B(c+d+a.D.config.webVitalsSnapshotBuffer,0);d=a.g.Z.W()-d;setTimeout(()=>{ql(a)},Math.abs(Math.min(d,0)))}b=a.M.lf(b);a.Yb=!0;tj(a,b);[,b]=mi(a,document);b!=0&&bk(a,document);[a.B.lc].includes(a.K)||a.g.se.start()}
function wk(a,b,c=0){return b&&a.g.G.tagName(b)&&a.g.G.tagName(b).toLowerCase()=="a"&&b.getAttribute("href")?b.getAttribute("href"):a.g.G.parentNode(b)&&c++<10?wk(a,a.g.G.parentNode(b),c):null}
function Uj(a){a.ua=a.ua.map(b=>{switch(b.t){case "T":if(b.n==="qframe")return b;case "r":case "a":case "t":return null;case "]":case "[":case "}":case "*":case "C":case "F":case "B":case "_":return null;case "SA":case "CE":case "sc":return null;case "as":case "SI":case "SD":case "SR":return null;case "DO":case "po":return null;case "co":return null;case "O":case "X":case "R":case "D":case "U":case "m":case "!":case "@":case "#":case "$":return null;case "S":return null;case "M":return null;case "xhr":return b.req=
b.res="Omitted due to page unload",delete b.req_enc,delete b.res_enc,delete b.reqHeaders,delete b.resHeaders,delete b.reqHeaders_enc,delete b.resHeaders_enc,b;default:return b}}).filter(Boolean)}
function zk(a,b,c,d,e){c>0?(d-b.wf>e.window&&(b.Yd=0,b.Zc=0),b.wf=d,b.gd==1&&b.Yd++,b.Zc+=Math.abs(c),b.gd=-1):c<0&&(d-b.Bf>e.window&&(b.Fe=0,b.qd=0),b.Bf=d,b.gd==-1&&b.Fe++,b.qd+=Math.abs(c),b.gd=1);Math.abs(c)&&b.Fe>=e.bf&&b.Yd>=e.bf&&b.qd>=e.Ff&&b.Zc>=e.Ff&&(!b.ne||d-b.ne>=e.Tg)&&(c={flags:0,id:-64,ka:a.g.Z.W(),ja:1,Ca:1},P(a.R,c,""),b.ne=d)}
function xl(){var a=document.doctype,b="";a&&(b="<!DOCTYPE",a.name&&(b+=" "+a.name.toString()),a.publicId&&(b+=' PUBLIC "'+a.publicId.toString()+'"'),a.systemId&&(b+=' "'+a.systemId.toString()+'"'),b+=">");return b}function yl(a,b){const c=Aa(b,"checked");c&&c.configurable&&Object.defineProperty(b,"checked",{...c,set:function(d){const e=c.set.call(this,d);try{const f=a.$.B(b);if(f.fd===d)return e;f.fd=d;gl(a,b,"checked",d)}catch(f){}return e}})}function zl(a,b){try{Sj(a,b)}catch(c){}}
function Al(a,b){const c=a.g.G.pb(b,"option");for(let e=0;e<c.length;e++)Bl(a,c[e]);const d=Aa(b,"selectedIndex");Object.defineProperty(b,"selectedIndex",{...d,set(e){e=d.set.call(this,e);zl(a,b);return e}})}
function wj(a,b){const c=Uc(a.$,b);if(!c.ii){b.type.toLowerCase()!=="checkbox"&&b.type.toLowerCase()!=="radio"||yl(a,b);b.nodeName.toLowerCase()==="select"&&Al(a,b);var d=!0,e=!0,f=Aa(b,"value");f&&!f.configurable&&(e=!1);if(f&&e)try{Object.defineProperty(b,"value",{configurable:!0,set:function(g){g=f.set.call(this,g);zl(a,b);return g},get:function(){return f.get.apply(this)}}),d=!1}catch(g){}d&&(c.ri=!0,a.$.K.add(b));b.addEventListener("input",()=>{zl(a,b)});c.ii=!0}}
function Bl(a,b){let c=Aa(b,"selected");Object.defineProperty(b,"selected",{...c,set(d){c.set.call(this,d);(d=Gk(a,b))&&zl(a,d)}})}async function Cl(a,b){const c=a.$.da(b);if(b=a.g.G.adoptedStyleSheets(b)){b=Dl(a,b);const d={t:"as",I:c,S:[]};b.then(e=>{d.S=e});K(a,d)}}
async function El(a,b,c,d){b=a.$.da(b);const e={},f=[];d.forEach((k,l)=>{a.g.Aa.is(k,"CSSStyleSheet")&&(f.push(k),e[l]=f.length-1)});const g=Dl(a,f),h={t:"asm",I:b,m:c,a:[]};g.then(k=>{const l=d.map((m,n)=>n in e?{at:"s",a:k[e[n]]}:{at:"p",a:m});h.a=l});K(a,h)}
function Fl(a,b){const c=Uc(a.$,b);if(!c.ki){var d=Aa(b,"adoptedStyleSheets");if(d&&d.configurable){Object.defineProperty(b,"adoptedStyleSheets",{set:function(e){e=d.set.call(this,e);try{Cl(a,b)}catch(f){}return e},get:function(){return d.get.apply(this)},enumerable:d.enumerable,configurable:!0});for(const e of Ti){if(!(e in Array.prototype))continue;const f=Aa(b.adoptedStyleSheets,e);if(f&&!f.configurable)continue;const g=f&&typeof f.value==="function"?f.value:Array.prototype[e];try{Object.defineProperty(b.adoptedStyleSheets,
e,{value:function(...h){const k=g.apply(this,h);try{El(a,b,e,h)}catch(l){}return k},configurable:!0,enumerable:f?f.enumerable:!1,writable:f?f.writable:!0})}catch(h){}}c.ki=!0}}}function Gl(a,b=window){Uc(a.$,b).si||(Uc(a.$,b).si=!0,a.g.G.addEventListener(b,"toggle",c=>{if(a.ya===y.NONE&&c.newState!==c.oldState){var d=a.$.da(c.target);d&&(d={t:"po",I:d,o:c.newState==="open"},c.source&&(d.s=a.$.da(c.source)),K(a,d))}},{capture:!0}))}
function xj(a,b){const c=a.$.B(b);b=a.g.G.shadowRoot(b);c.qh||(Fl(a,b),yk(a,b,!0),Gl(a,b),c.qh=!0,a.dc.add(b),b&&b.slotAssignment==="manual"&&b.addEventListener("slotchange",d=>{const e=a.cb(d.target);e&&(d=(d.target.assignedNodes({flatten:!0})||[]).map(f=>a.cb(f)).filter(Boolean),K(a,{t:"sc",I:e,A:d}))}));a.g.cc.observe(b)}function Dl(a,b){const c=[];for(let d=0;d<b.length;++d)try{c.push(Zb(a.g.Aa,b[d]))}catch(e){}b=Promise.all(c);a.ea.push(b);$b(a.g.Aa);return b}
function Hl(a,b,{method:c,url:d,body:e},f=ua){return a.g.zc.Ga(b,{method:c,url:d,body:e}).then(f).catch(g=>{L(a.ba,"sdkcomm: issue sending message to child",{message:g.message,method:c,url:d},"error")})}
async function Il(a){var b=document.documentElement;const c=new Si(a.g.G);var d=new bh({ma:new WeakMap,oe:!1,He:{},wb:new Set,Ob:()=>!1,Nb:()=>!1,ze:!1,ye:!1,url:a.Ea,G:a.g.G,supports:a.g.supports,Db:c.B.bind(c),ee:a.cb.bind(a),da:Ea()});const {sb:e}={sb:dh(b,d),Ib:d.Ib},f=new ac({g:{ia:a.g.ia,G:a.g.G},D:{aa:{fe:"*",ae:"",md:!1},config:{hashResourceURL:""}},fb:{lb:a.fb.lb}});d.De.forEach(({node:k,sb:l})=>{k.nodeType===11?(k=a.g.G.adoptedStyleSheets(k).map(m=>Zb(f,m)),Promise.all(k).then(m=>{l.S=m})):
(a.g.G.tagName(k)==="STYLE"&&Zb(f,k.sheet).then(m=>{l.S=m;l.C=[]}),a.g.G.tagName(k)==="LINK"&&k.getAttribute("href")&&Zb(f,k))});b=$b(f);const g=await Promise.all(a.g.G.Array.from(a.Pd).map((k,l)=>{const m=new yb;Hl(a,k.contentWindow,{method:"POST",url:"/v1/page-freeze",body:{id:l}},n=>{m.resolve({dom:n&&n.dom,qf:n&&n.qf,hoveredElement:n&&n.hoveredElement})});return Promise.race([m.promise,new Promise(n=>{setTimeout(n,5E3,{})})])}));d=g.find(k=>k.hoveredElement);const h=a.Sc&&[c.da(a.Sc)];h&&d&&d.hoveredElement&&
h.push(...d.hoveredElement);return b.then(()=>({json:e,iframes:g,hoveredElement:h}))}
function vj(a){const b=new a.g.G.WeakMap,c=a.D.aa.ld;a.zb&&(a.g.ia.querySelectorAll(document,a.D.aa.Pb).forEach(d=>{a.$.B(d).Ge!==!0&&(b.set(d,{encrypt:!0}),a.$.B(d).Wb=!0)}),a.g.ia.querySelectorAll(document,a.D.aa.Ud).forEach(d=>{if(a.$.B(d).Ge!==!0){b.has(d)||b.set(d,{});var e=b.get(d);e.encrypt=!1;a.$.B(d).Wb=e.encrypt}}),a.D.config.encryptNodeAttributes.forEach(d=>{const {sel:e,attrs:f}=d;a.g.ia.querySelectorAll(document,e).forEach(g=>{b.has(g)||b.set(g,{});g=b.get(g);g.$d=g.$d?g.$d.concat(f):
f})}));c||a.g.ia.querySelectorAll(document,a.D.aa.Ze).forEach(d=>{if(a.$.B(d).Ge!==!0){b.has(d)||b.set(d,{});var e=b.get(d);e.jd=!0;a.$.B(d).Za=e.jd}});a.g.ia.querySelectorAll(document,a.D.aa.Vd).forEach(d=>{if(a.$.B(d).Ge!==!0){b.has(d)||b.set(d,{});var e=b.get(d);e.jd=!1;a.$.B(d).Za=e.jd}});a.D.aa.oh.forEach(d=>{const {sel:e,attrs:f}=d;a.g.ia.querySelectorAll(document,e).forEach(g=>{b.has(g)||b.set(g,{});g=b.get(g);g.wb=g.wb?g.wb.concat(f):f})});a.D.aa.Ab.forEach(d=>{a.g.ia.querySelectorAll(document,
d.Fa).forEach(e=>{b.has(e)||b.set(e,{});e=b.get(e);e.Yf?e.Yf.push(d):e.Yf=[d]})});a.D.aa.ad&&a.g.ia.querySelectorAll(document,a.D.aa.ad).forEach(d=>{b.has(d)||b.set(d,{});b.get(d).$c=!0});return b}function Jl(a,b){b<25E3||setTimeout(()=>{a.xa("DOM_SIZE",b)},1)}
async function Kl(a){const {sb:b,Ib:c,Og:d}=uj(a,document);a.uc=null;var e=a.g.G.adoptedStyleSheets(document)||[];e=Promise.all(e.map(f=>a.g.Aa.bb(f))).then(f=>{b.S=f});Jl(a,c);a.M.Le(c);await Promise.all([d,e]);return`${xl()}<html><head></head><body><!--QMJSONHTML:${a.g.G.stringify(b).replace(/--\x3e/g,"QMCOMMENTEND->")}--></body></html>`}
function Ll(a){Z(a,function(){if(a.rc<5242880){if(a.rc===0)try{const b={elements:document.querySelectorAll("*").length,htmlLength:document.documentElement.outerHTML.length,children:document.body.childNodes.length,session:a.ha,hit:a.Ba,url:a.Ea};L(a.ba,"htmlSyncZeroSize",b);K(a,{t:"dbg",msg:"htmlSyncZeroSize",data:b},!0)}catch(b){}else dl(a,a.Ub,a.Ed).then(b=>{b&&K(a,{t:"dbg",msg:"htmlSyncSucceeded",data:{hash:a.Ub}},!0)});a.Ed=""}else a.xa("ZSYNC_2LG",{htmlSize:a.rc,pageURL:a.Ea})})}
function Ml(a){a.xg||(a.xg=!0,window.addEventListener("error",b=>{const c=b.message,d=b.filename,e=b.lineno,f=b.colno;b=b.error;const g=[];c&&g.push(c);d&&g.push(d);e&&g.push(e);f&&g.push(f);b&&b.stack&&g.push(b.stack);Oj(a,g.toString())}))}
function Nl(a){if(!a.og&&(a.og=!0,window.HTMLDialogElement!=void 0)){const b=window.HTMLDialogElement.prototype.showModal;window.HTMLDialogElement.prototype.showModal=function(){try{const c=a.$.da(this);K(a,{t:"DO",I:c});ej(a,a.O,a.ea)}catch(c){}return b.call(this)}}}function Ol(a,b,c,d,e){c={t:"SI",i:d,v:c,p:e};b.ownerNode?c.I=a.$.da(b.ownerNode):(d=a.g.Aa.register(b),c["I+"]=d.Md);if(c.I||c["I+"])a.g.Aa.unregister(b),K(a,c),ej(a,a.O,a.ea)}
function Pl(a,b,c,d){c={t:"SD",i:c,p:d};b.ownerNode?c.I=a.$.da(b.ownerNode):(d=a.g.Aa.register(b),c["I+"]=d.Md);if(c.I||c["I+"])a.g.Aa.unregister(b),K(a,c),ej(a,a.O,a.ea)}
function Ql(a){if(!a.wh&&(a.wh=!0,typeof window.CSSStyleSheet!=="undefined")){var b=window.CSSStyleSheet.prototype.insertRule;b&&(window.CSSStyleSheet.prototype.insertRule=function(e,f){const g=b.call(this,e,f);try{a.ya===y.NONE&&Ol(a,this,e,f)}catch(h){}return g});var c=window.CSSStyleSheet.prototype.deleteRule;c&&(window.CSSStyleSheet.prototype.deleteRule=function(e){const f=c.call(this,e);try{a.ya===y.NONE&&Pl(a,this,e)}catch(g){}return f});var d=window.CSSStyleSheet.prototype.replaceSync;d&&(window.CSSStyleSheet.prototype.replaceSync=
function(e){const f=d.call(this,e);try{if(a.ya===y.NONE){e={t:"SR",v:{v:e}};if(this.ownerNode)e.I=a.$.da(this.ownerNode);else{const g=a.g.Aa.register(this);e["I+"]=g.Md}if(e.I||e["I+"])a.g.Aa.unregister(this),K(a,e),ej(a,a.O,a.ea)}}catch(g){}return f});"CSSStyleRule CSSMediaRule CSSSupportsRule CSSStartingStyleRule CSSPageRule CSSLayerBlockRule".split(" ").forEach(e=>{const f=window[e]&&window[e].prototype.insertRule;f&&(window[e].prototype.insertRule=function(h,k){const l=f.call(this,h,k);try{a.ya===
y.NONE&&Ol(a,this.parentStyleSheet,h,k,Yg(this,a.g.G))}catch(m){}return l});const g=window[e]&&window[e].prototype.deleteRule;g&&(window[e].prototype.deleteRule=function(h){const k=g.call(this,h);try{a.ya===y.NONE&&Pl(a,this.parentStyleSheet,h,Yg(this,a.g.G))}catch(l){}return k})})}}
function Rl(a,b){const c=new Wa(a,b);if(b===4||b===1)a.Oe=!0;if(c.navigationType===64||mb(a.M,c)){const d=lb(a.M,c);a.fa.set("lastUrl",kb(a.M).toString());a.jf=fb(a.M);a.Pe||(a.stop(y.Se),a.Cb&&clearTimeout(a.Cb),a.Cb=setTimeout(function(){fj(a,d,!0)},c.navigationType===64?0:a.D.config.spaLocationChangedTimeout))}}
function Sl(a){function b(k){try{Rl(c,k)}catch(l){}}if(!a.fg){a.fg=!0;var c=a,d=a.g.G;d.addEventListener(window,"hashchange",function(){Rl(c,16)},!1);var e=window.history,f=e.go;a=e.pushState;var g=e.replaceState;e.go=function(...k){k=f.apply(e,k);b(1);return k};var h=(k,l)=>(...m)=>{try{return k.apply(e,m)}catch(n){if(n.name!=="DataCloneError"&&typeof m[0]!=="object")throw n;m[0]=d.Ra(d.stringify(m[0]));return k.apply(e,m)}finally{b(l)}};e.pushState=h(a,2);e.replaceState=h(g,8);d.addEventListener(window,
"popstate",function(){b(4)},!1)}}function Uk(a){if(a=a.R.ob)return a.abn}function Dj(a){let b=a.fa.get("sst",!1);b||(b=a.g.Z.W(),a.fa.set("sst",b));b=parseInt(b,10);const c=a.g.Z.W();return{ni:Math.ceil((c-b)/6E4),oi:a.D.config.maxSessionDuration*60*1E3-(c-b)}}
function Sk(a,b,c=!1){if(b!==0){var d=a.fa.get("sampleReplayEnabled",null);if(d!==null)a.Vb&&(a.Vb=!1,Tl(a,d));else{if(c=!c)c=!a.D.config.temp.enableKVS||a.Hf||Yk()?!1:a.ra.get(a.D.config.sessionCookieName)!==null;c?a.Vb=!0:(d=a.g.Z.W()%100<b,a.fa.set("sampleReplayEnabled",d),a.Vb&&(a.Vb=!1,Tl(a,d)))}}}function Tk(a){if(a.Dc!==null&&!a.kg){var b=a.D.config.hookFetch,c=a.Dc.getEntries(),d=async e=>{(e.type!=="fetch"||b)&&await el(a,...e.args)};a.Dc.onAPI(d);a.kg=!0;return Promise.all(c.map(d))}}
function Yk(){const a=document.referrer;if(!a)return!1;try{return(new URL(a)).host===window.location.host}catch(b){return!1}}
function Ul(a){a.g.G.addEventListener(window,"load",function(){setTimeout(function(){rl(a)},5)});if(J(window.location.href,a.D.aa.nd))setTimeout(function(){a.start()},0);else if(a.g.G.readyState(document)==="complete")setTimeout(function(){a.start()},a.D.config.startOffset||0);else{var b=!1,c=function(d){try{b||d.type==="readystatechange"&&a.g.G.readyState(document)!=="complete"||(b=!0,setTimeout(function(){a.start()},a.D.config.startOffset||0))}catch(e){}};a.g.G.addEventListener(document,"DOMContentLoaded",
c,!1);a.g.G.addEventListener(document,"readystatechange",c,!1)}}function Vl(a){return J(a.Ea,a.D.aa.zh)?!1:J(a.Ea,a.D.aa.Cg)}function Fj(a){if(JSON&&JSON.stringify&&!a.Ef){a.Ef=!0;Ul(a);try{window.navigator.vendor&&window.navigator.vendor.indexOf("Apple")==0&&typeof document.hasStorageAccess=="function"&&document.requestStorageAccess().then(function(){},function(){a.gf=!1})}catch(b){}}}function Ij(a){a.pa?(a.zd=!0,rj(a)):a.pa=new je(a.zb,function(){a.zd=!0;rj(a)},a)}
function Wl(a,b){a.oa&&(b?(a.fa.set("visible",!0),L(a.ba,"visibleInstalled",!0),a.oa.freeze=()=>Il(a)):(a.fa.jb("visible"),delete a.oa.freeze))}function Xl(a){Yl(a);Jj(a,ib(a.M),!1);const b=document.createElement(a.xe);b.src=a.D.config.visibleURL;b.crossOrigin="anonymous";document.head.appendChild(b);Wl(a,!0)}
function Zl(a){window.addEventListener("message",function(b){var c=b.data;if(c&&typeof c=="object"&&c.namespace=="quantum"&&c.scope===a.sub)try{const d=b.data;if(d.type)switch(d.type){case "qm-visible":const e=d.action;if(e)switch(e){case "close":Wl(a,!1);break;case "install":Xl(a);break;case "start":Wl(a,!0)}else console.warn("Invalid visible action:",d);break;case "qm-recorder":Bd(a.g.se,d);break;default:L(a.ba,"unknown qframe message",{type:d.type},"error")}}catch(d){}},!1)}
function $l(a){var b=[];document.visibilityState==="visible"?setTimeout(a,0,...b):a(...b)}function am(a,b){const c=()=>{try{const d=b.shift();d&&(d(),$l(c))}catch(d){Cj(a,d)}};$l(c)}
async function Jj(a,b,c=!0,d=null){try{if(a.D.sc(),a.g.nc.B.sc(),a.fa.set("configReplayEnabled",a.D.config.replayEnabled),a.Ea=a.M.eb.qb,a.M.be(),Vl(a))jb(a.M,b),a.stop(y.Je);else if(Ii(a)){switch(a.ya){case y.NONE:break;case y.Je:case y.Se:a.stop(y.NONE);break;default:return}if(!a.Yb&&a.ub){await Nc(a.g.Z);nl(a);lj(a);qk(a,"input, select, option, textarea");a.R=new xg(a,a.Cf);a.R.load(a.Ea,{events:a.g.Ee.B});a.R.Ia=d;Sc(a.g.tb,document);ii(a.g.Da,document);Ni(a.g.Xa);vl(a);a.Ub=Ia();if(a.Na){const f=
Kl(a);Fl(a,document);bm(a);ui(a,document.documentElement);a.g.cc.observe(document);Ql(a);Nl(a);Gl(a);const g=a.g.Z.W();a.Ed=await f.catch(h=>{a.xa("SYNC_ERR",h.message);return""});a.Ha.La("html-snapshot",null);a.g.mh.sample(.01,()=>{const h=a.g.Z.W();L(a.ba,"snapshotDuration",h-g)});a.rc=(new TextEncoder).encode(a.Ed).length;Ll(a);if(a.M.Ua!==b){a.M.Xb(b)&&(db(a.M).Xb=!0);jb(a.M,b);return}}a.R.bg();[a.B.va].includes(a.K)||window.opener!==null&&window!==window.opener||a.Re||(a.frameId=a.g.Z.W());wl(a,
b);a.frameId&&nj(a,{method:"POST",url:"/v1/set-child-frame-id",body:{id:a.frameId}});c&&cm(a);zj(a,document.documentElement,"class",document.documentElement.className);a.D.config.disableErrorHooking||Ml(a);Fk(a);Pk(a);a.ih||(a.ih=setInterval(a.Nh.bind(a),1E3));a.Nc=setTimeout(()=>{if(a.ya===y.NONE){var f=a.g.G.innerText(document.body);typeof f=="string"&&f.length<100&&f.replace(/\s/g,"").length==0&&(f={flags:0,id:-46,ka:a.g.Z.W()},P(a.R,f,a.Ea));a.Nc=null}},6E3);a.oa.bg();try{window.dispatchEvent(new Event("QM-PAGE-READY"))}catch(f){}dm(a);
qj(a);a.pa.ea=!0;ej(a,a.O,a.ea);var e=rk();e&&(a.Uc=e,V(a,"sd",e));Qj(a);Ki(a)}}else a.stop(y.Te)}catch(f){Cj(a,f)}}function em(){const a=window[String.fromCharCode(81,77,95,83,85,82,86,69,89,95,84,65,71,95,85,82,76)];if(typeof a!=="string"||a.length===0)return null;try{return(new URL(a,window.location.href)).href}catch(b){return null}}
function fm(a){const b={ack:!0},c=a.g.$f;var d=a.ba,e=a.sub,f=new jh;do c.counter++;while(window[`__qm_voc_${c.counter}`]!==void 0);const g=new Mh({ba:d,sub:e,channel:f,oc:`__qm_voc_${c.counter}`,Ma:{GET:{v1:{connect:()=>{clearTimeout(h);g.connected=!0;Kh(g);a.Zd.then(()=>{g.Ga({method:"POST",url:"/v1/set-context",body:a.getContext()}).catch(k=>{L(a.ba,"voc: set-context push failed",{message:k.message},"warn")})});return b}}},POST:{v1:{voc:{show:k=>{[a.B.va].includes(a.K)||nj(a,{method:"POST",url:"/v1/voc/show",
body:k});return b},dismiss:async k=>{[a.B.va].includes(a.K)||await nj(a,{method:"POST",url:"/v1/voc/dismiss",body:k});return b},destroy:async k=>{if(![a.B.va].includes(a.K)){try{a.Yb&&vk(a)}catch(l){}await nj(a,{method:"POST",url:"/v1/voc/destroy",body:k})}Lh(g);c.B.delete(g);return b},event:async k=>{const l=k?k.id:void 0;if(typeof l!=="number"||!Number.isInteger(l)||l>=0)throw Error("VocHandler:400");if(!a.R)throw Error("VocHandler:event-engine-unavailable");var m=k.value;m=m===void 0||m===null?
"":String(m);var n=null;k=k.mde;k!==void 0&&k!==null&&(n=a.g.G.stringify(k,cc),n.length>a.D.config.maxMDELength&&(k={error:"Too much data"},n=a.g.G.stringify(k,cc)),n={hash:await Ub(n),value:k});P(a.R,{id:l,flags:0,ka:a.g.Z.W()},m,n);return b},encrypt:async k=>{if(!a.pa||!a.pa.supports||!a.zb)throw Error("VocHandler:encryption-unavailable");k=k&&k.v!==null?k.v:"";const l=await he(a.pa,k);if(!l&&k)throw Error("VocHandler:encryption-unavailable");return{encrypted:l,ekey:ie(a.pa),kid:a.pa.le||"",...b}}}}}},
timeout:a.D.config.sdkCommTimeout}),h=setTimeout(()=>{Lh(g);c.B.delete(g)},6E4);c.add(g);return g}function Yl(a){a=a.D.config;const b=["#overlay_container","[data-qm-freeze-exclude]"];for(let c=0;c<b.length;c++){const d=b[c];a.excludeDOMList.includes(d)||a.excludeDOMList.push(d);a.ignoreChangesList.includes(d)||a.ignoreChangesList.push(d)}}function dm(a){for(var b=0;b<10;b++)a.Eb[b]=0;a.Eb.totalTime=0;a.Uc=0;a.xc=a.g.Z.W();a.Xf=a.xc}
function bm(a){if(!a.hg){var b=window.Element.prototype.attachShadow;window.Element.prototype.attachShadow=function(c){const d=b.call(this,c);if(c.mode==="closed")return d;try{const e=a.$.B(this);if(a.g.G.isConnected(this)&&!e.qh){const f=e.da;if(!f)return d;const g=a.g.G.shadowRoot(this),h=a.$.B(g);h.da=a.da();K(a,{t:"SA",p:f,q:h.da,sa:c.slotAssignment});ej(a,a.O,a.ea);xj(a,this)}}catch(e){console.error(e)}return d};window.Element.prototype.attachShadow.toString=()=>"[native code]";if(window.customElements&&
window.customElements.define){const c=Object.getPrototypeOf(window.customElements),d=c.define;c.define=function(e,f,g,...h){f=d.call(this,e,f,g,...h);a.customElements.add(e);K(a,{t:"CE",n:e});return f}}a.hg=!0}}
function cm(a){a.Ha.addEventListener("start-event",async()=>{await oj(a,{method:"GET",url:"/v1/frame-id",body:{}},async(b,c)=>{({id:b}=b);b!==void 0&&(K(a,{t:"rnh",v:b}),await Hl(a,c.contentWindow,{method:"POST",url:"/v1/set-parent-id",body:{replayId:a.Ub,parentHitId:a.Ba}}))})},{once:!0})}function gm(a){const b=window.navigator.userAgent;return a.D.aa.ci.some(c=>c.test(b))}
function hm(a){if(E(window,["webkit","messageHandlers","QMSDKv5"],!1)!==!1||gm(a))return!0;a=window.navigator.standalone;var b=window.navigator.userAgent.toLowerCase(),c=/safari/.test(b);if(/iphone|ipod|ipad/.test(b)){if(!a&&c||a&&!c)return!1;if(!a&&!c)return!0}else return!1}function im(a){if(gm(a))return!0;a=window.navigator.userAgent;return a.indexOf("Android")>-1&&(a.indexOf("; wv)")>-1||RegExp("Version/[0-9]+.[0-9]+").test(a))?!0:!1}function jm(a){return hm(a)||im(a)}
async function km(a,b){a.fa.set("apiReplayEnabled",b);K(a,{t:"re",v:b});oj(a,{method:"POST",url:"/v1/enable-replay",body:{enabled:b}});b&&Rl(a,64)}
async function lm(a,b){if([a.B.va].includes(a.K))try{b?(a.ra.set({[a.D.config.enabledCookie]:!b,expires:"Fri, 31 Dec 2099 23:59:59 GMT"}),a.stop(y.Te)):a.Of||(a.Of=!0,a.ra.jb({[a.D.config.enabledCookie]:!b}),await a.stop(y.NONE),fj(a,gb(a.M)).then(()=>oj(a,{method:"POST",url:"/v1/reset",body:{}})).catch(ua).finally(()=>{a.Of=!1}))}catch(c){}else nj(a,{method:"POST",url:`/v1/${b?"opt-out":"opt-in"}`,body:{}})}
function Tl(a,b){if(b){if(a.Jc.length||a.Ic.length)a.O.push(...a.Jc),a.ea.push(...a.Ic),a.Jc.length=0,a.Ic.length=0,ej(a,a.O,a.ea);Rk(a)}else a.Jc.length=0,a.Ic.length=0,a.Hc.length=0}function mm(a){a.Re=!0;a.wd=!0;a.ra.jb({[a.D.config.enabledCookie]:!0})}function nm(a,b){const c=async()=>{await Hl(a,b,{method:"POST",url:"/v1/set-context",body:a.getContext()});await Hl(a,b,{method:"POST",url:"/v1/new-page",body:{}})};a.ha&&a.Ba?c():a.Ha.addEventListener("start-event",c,{once:!0})}
function om(a){for(a=a.getRootNode();a.nodeType===Node.DOCUMENT_FRAGMENT_NODE;)a=a.host.getRootNode();return a===document}
function pm(a){const b={ack:!0},c={GET:{v1:{connect:(e,f)=>{if(f.scope===a.sub)return b},"frame-id":()=>({id:a.frameId,...b})}},POST:{v1:{engaged:()=>{Ki(a);return b},"opt-out":()=>{lm(a,!0);return b},"opt-in":()=>{lm(a,!1);return b},"set-context":e=>{const {session:f,user:g,state:h,parentHitId:k,replayEnabled:l,contextId:m,userLogin:n,userFirstName:x,userLastName:r,userEmail:q,userIdentifier:w,userContextHashed:D}=e;if(f.length<=100&&g.length<=100){a.ha&&a.Ba&&(Ej(a,!0),Gj(a),gj(a),a.Ba=void 0);
a.ha=f;a.za=g;a.Fd=k;h&&(a.fa.import(h),a.Hf=!0);typeof l==="boolean"&&(a.pf=l);a.Yc=m;Lk(a);Sl(a);if(n!==void 0||x!==void 0||r!==void 0||q!==void 0||w!==void 0)D?(a.Rd={userLogin:n||"",userFirstName:x||"",userLastName:r||"",userEmail:q||"",userIdentifier:w||""},a.Zd=Promise.resolve()):a.Zd=Promise.all([n?Ub(String(n)):Promise.resolve(""),x?Ub(String(x)):Promise.resolve(""),r?Ub(String(r)):Promise.resolve(""),q?Ub(String(q)):Promise.resolve(""),w?Ub(String(w)):Promise.resolve("")]).then(([C,t,p,u,
z])=>{a.Rd={userLogin:C,userFirstName:t,userLastName:p,userEmail:u,userIdentifier:z}});a.Zd.catch(()=>{}).then(()=>{oj(a,{method:"POST",url:"/v1/set-context",body:a.getContext()})})}else L(a.ba,"sdkcomm: invalid context issued",{s:f,u:g},"error");return b},"child-ready":async(e,f)=>{({"from-frame":e}=e);e&&(e=await f.frame(),a.Pd.add(e));nm(a,f.sender);return b},"set-child-frame-id":async(e,f)=>{f=await f.frame();if(!f)return b;({id:e}=e);a.$.B(f).Cc=e;a.Yb||await new Promise(h=>a.Ha.addEventListener("start-event",
h,{once:!0}));let g=5;do{const h=a.g.G.isConnected(f),k=om(f),l=a.$.da(f);if(h&&k&&l)return K(a,{t:"T",I:l,n:"qframe",v:e}),b;await new Promise(m=>setTimeout(m,50))}while(g--);L(a.ba,"qframe: unable to resolve nodeIdentifier",{attempts:5},"warn");return b},"set-parent-id":e=>{const {replayId:f,parentHitId:g}=e;a.Fd=g;K(a,{t:"chr",p:f});return b},"sub-frame-size":async(e,f)=>{const {w:g,h}=e;a.Na&&(e=await f.frame(),e=a.$.da(e),K(a,{t:"i+",w:g,Li:h,I:e}));return b},"new-session":()=>{[a.B.lc].includes(a.K)?
nj(a,{method:"POST",url:"/v1/new-session",body:{}}):[a.B.va].includes(a.K)&&jj(a);return b},"enable-session":e=>{[a.B.lc].includes(a.K)?nj(a,{method:"POST",url:"/v1/enable-session",body:e}):[a.B.va].includes(a.K)&&Li(a,e.enabled);return b},"enable-replay":e=>{e=e.enabled;km(a,e);oj(a,{method:"POST",url:"v1/enable-replay",body:{enabled:e}});return b},"new-page":()=>{a.ya=y.NONE;fj(a,gb(a.M),!0,!1);return b},reset:()=>{a.Ha.addEventListener("start-event",()=>{oj(a,{method:"POST",url:"/v1/set-context",
body:a.getContext()}).then(()=>oj(a,{method:"POST",url:"/v1/reset",body:{}}))},{once:!0});fj(a,gb(a.M),!0,!1);return b},stop:e=>{e=e.reason;a.stop(e);oj(a,{method:"POST",url:"/v1/stop",body:{reason:e}});return b},"page-freeze":async e=>{const {hoveredElement:f,...g}=await Il(a);return{dom:g,id:e.id,qf:a.frameId?a.frameId.toString():a.frameId,hoveredElement:f,...b}},voc:{hide:e=>{Nh(a.g.$f,{method:"POST",url:"/v1/voc/hide",body:e});return b},show:e=>{[a.B.va].includes(a.K)||nj(a,{method:"POST",url:"/v1/voc/show",
body:e});return b},dismiss:e=>{[a.B.va].includes(a.K)||nj(a,{method:"POST",url:"/v1/voc/dismiss",body:e});return b},destroy:e=>{[a.B.va].includes(a.K)||nj(a,{method:"POST",url:"/v1/voc/destroy",body:e});return b},start:()=>{const e=em();e&&a.g.Ee.load(e);return b}}}}};var d=(new Hi(a)).sc();a.g.zc=new Dh({ba:a.ba,sub:a.sub,G:a.g.G,Ma:c,dc:a.dc,Kb:a.D.config.sdkCommRetryDelay,Hb:a.D.config.sdkCommRetryCount});a.g.bd=new Ei({ba:a.ba,sub:a.sub,Ma:d,Kb:a.D.config.sdkCommRetryDelay,Hb:a.D.config.sdkCommRetryCount});
d=hm(a);im(a)&&window.QMSDKv5&&(a.g.Nd=new Gh({Pa:window.QMSDKv5,ba:a.ba,sub:a.sub,G:a.g.G,timeout:a.D.config.sdkCommTimeout,Ma:c}));E(window,["webkit","messageHandlers","QMSDKv5"],!1)&&d&&(a.g.ie=new Hh({Pa:window.webkit.messageHandlers.QMSDKv5,ba:a.ba,sub:a.sub,timeout:a.D.config.sdkCommTimeout}));a.g.$f=new Oh}
function qm(a,b={}){let {eventDefinitions:c,sub:d,publicKeyString:e,ipEncryption:f,eventNameMap:g,errorIds:h,adobe:k,surveys:l,flutter:m,...n}=b;"capture"in n&&(n=n.capture);a.Xa=m;a.zb=e;a.df=g||{};a.Jg=h||[];if(!window[`QuantumMetricAPI_${d}`])if(window.location.protocol=="data:")console.warn("QM blocked in data: protocol environments");else{a.oa=new rm(a);window.QuantumMetricAPI=a.oa;[`QuantumMetricAPI_${d}`].forEach(t=>{Object.defineProperty(window,t,{configurable:!1,enumerable:!0,get:()=>a.oa,
set:()=>{a.xa("api_tamper",encodeURIComponent(Error().stack.toString()))}})});var x=!1,r=a.g.G.W()%100<10;b=new URLSearchParams(window.location.search);if(b.has("web-vitals-buffer")){x=!0;var q=b.get("web-vitals-buffer");zd.webVitalsSnapshotBuffer=parseInt(q,10)}q=typeof n.reportURL==="string"?n.reportURL:"";Lc(a.g.Z);a.D=new Fc(n,yd,zd,{Vd:"",Pb:"",Ud:"",ld:!1,Ze:"",$e:[ra],Vf:[],Cg:[],zh:[],uh:[],ae:"",fe:"",md:!1,Ii:[],nd:[],ag:[],th:[],Qd:[],Df:[],Ig:[],ad:"",Kg:[ta],ef:null,Gh:[],Eh:[],Bh:[],
Ah:[],Hh:[],Fh:[],Dh:[],Ch:[],af:[],Sf:[],fc:[],Be:".loading,.loader,.spinner",ff:[],Qg:null,oh:null,Ab:[],sf:"",Mi:!0,Tf:[],Na:!0,rf:"",ac:new window.Set},Ai,zi,d,a.g.G);a.D.sc();a.ba=new Ig({G:a.g.G,D:a.D,sub:d,kf:()=>a.Yc});a.la=new uh(a.g.G,a.D,d,a.ba);var w=wb(a.D.config,d);try{var D=Ta(w);if(D.href!==w&&D.href!==w+"/"&&D.pathname!==w)throw Error("URL is malformed");}catch(t){console.error("QM: reportURL is malformed");return}a.fa=new Fg(a,a.D.config.sessionStoreNamespace,"sessionPersistenceMediums",
a.g.G);a.D.fa=a.fa;a.kc=new Fg(a,a.D.config.userStoreNamespace,"userPersistenceMediums",a.g.G);D=()=>{let t={},p=null,u=0;const z=A=>{if(a.ha&&Object.keys(t).length){var W={s:a.ha,Q:5},F={...t};t={};p=null;switch(A){case 0:th(a.la,W,a.g.G.stringify(F)).then(()=>{u=0}).catch(()=>{t={...F,...t};!p&&u<5&&(u++,p=setTimeout(z,a.D.config.publishInterval,0))});break;case 1:rh(a.la,W,a.g.G.stringify(F))}}};a.g.G.addEventListener(document,"visibilitychange",()=>{document.visibilityState=="hidden"&&(clearTimeout(p),
z(1))});return A=>{A&&typeof A==="object"&&A.t==="set"&&Ka(A.path)&&(t[A.path]=A.value,p||(p=setTimeout(z,a.D.config.publishInterval,0)))}};a.D.config.temp.enableKVS&&yg(a.fa.M,D());a.sub=d;Mc(a.g.Z,a.D,a.ba,a.sub);Ad(a.g.se);a.ra=new mh(a.g.G,a.D);a.g.nc=new ai(a,k);Vh(a.g.nc);a.g.cc=new yi(a,a.g.G,a.Ha,a.ba,a.D,a.$);a.g.Ee=new Bi(l||{},a.Ha,()=>fm(a).oc);a.M=new nb(a);pm(a);Zl(a);a.g.Xa=new Qi(a.D,a.g.ia,a.g.G,a.Ha,a.g.bd,a);q&&L(a.ba,"dep-cfg",q);r&&x&&L(a.ba,"wo","web-vitals-buffer");a.ah=new RegExp(la(a.Oh),
"i");tl(a);Sk(a,a.D.config.sampleReplay);a.Cf=c||a.Cf;try{a.g.G.O(document,document.documentElement,window.NodeFilter.SHOW_ALL,null)}catch(t){}a.lg=new RegExp(window.location.host);try{++a.Pc;a.ta=window.performance;Hk(a);Sb(a.g.Aa);md(a.g.oa,a.D.config.apiDefinitions);try{const F=window.location.href;var C=a.fa.get("lru",null);a.D.aa.Qd.length&&(C?C!==window.location.href&&a.fa.jb("lru"):a.fa.set("lru",window.location.href));if(cb(a,"type")=="reload"||window.location.href==document.referrer||window.location.href==
C)for(C=0;C<a.D.aa.Qd.length;++C){const {re:R,count:ba}=a.D.aa.Qd[C],G=["bfr",R.source].join(":");if(R.test(F)){const ca=a.fa.get(G,0);if(ca>=ba)return;a.fa.set(G,ca+1)}else a.fa.jb(G)}else a.fa.jb(["bfr"])}catch(F){console.warn("QM: issue handling `blockFrequentReloads` config.")}a.g.G.addEventListener(document,"visibilitychange",()=>{Z(a,()=>{document.visibilityState==="visible"&&oc(a.g.G);Hk(a)})},!0);function t(){Fj(a);--a.Pc}const p=b.get(a.D.config.bookmarkToolbarQueryParamName);try{if(typeof p==
"string"){const F=p.replace(/-/g,"");F.length<=100?(a.ha=F,Lk(a)):console.warn("QM: bookmark recording ID is incorrect format")}}catch(F){console.error("QM: unable to initialize recorder:",F)}const u=window.QM_SDK_USER_ID||window.QM_USER_ID;u&&u.length<=100&&(a.za=u.toString());const z=window.QM_SDK_SESSION_ID||window.QM_SESSION_ID;z&&z.length<=100&&(a.ha=z.toString(),Lk(a));try{for(const F of a.D.config.nestedStitchingQueryParams){let R=F;const ba=Ta(window.location.href);let G=!1;R.reduce((ca,S,
X)=>{try{if(ca){var N=null,ab=(new URLSearchParams(ca.search)).get(S);ab&&(N=Ta(ab));if(N&&X==R.length-1){const bb=new URLSearchParams(N.search),Oa=bb.get(a.D.config.queryParamForSessionId),v=bb.get(a.D.config.queryParamForUserId);if(Oa&&v&&Oa.length<=100&&v.length<=100)return a.ha=Oa,a.za=v,Lk(a),G=!0,null}return N}}catch(bb){}},ba);if(G)break}}catch(F){}if(a.D.config.queryParamForSessionId||a.D.config.queryParamForUserId){const F=new URLSearchParams(window.location.search),R=F.get(a.D.config.queryParamForSessionId),
ba=F.get(a.D.config.queryParamForUserId);R&&ba&&R.length<=100&&ba.length<=100&&(a.ha=R,a.za=ba,Lk(a))}const A=p||a.fa.get("isRecording"),W=em()!==null;if(A||W)a.D.aa.nd=[/(?:)/],a.D.config.startOffset=0,Yl(a);if(!A)if(a.g.G.M(window)!==window||window.opener!==null&&window!==window.opener){const F=window.location.href;let R;a.D.aa.ag.length?(L(a.ba,"@deprecated: waitForSessionIdPathPatterns",!0,"warn"),R=J(F,a.D.aa.ag)?!0:!1):R=J(F,a.D.aa.th)?!1:!0;if(R&&!a.ha){const ba=window.opener?window.opener:
a.g.G.M(window);a.g.zc.Ga(ba,{method:"GET",url:"/v1/connect",body:{}}).then(()=>{a.K=a.B.lc;a.ya=y.ud}).catch(G=>{L(a.ba,"sdkcomm: connect to parent timed out",{message:G.message},"warn")}).finally(()=>{t()});return}}else if(jm(a)){const F=hm(a),R=im(a),ba={iosWebview:F,androidWebview:R,waitForNativeCapture:a.D.config.waitForNativeCapture,autoDetectSDK:a.D.config.autoDetectSDK,useFallbackSDKSync:a.D.config.useFallbackSDKSync};if(window.QMSDKv5&&R){a.g.Nd.Ga({method:"GET",url:"/v1/connect",body:{sub:a.sub}}).then(()=>
{a.K=a.B.td;a.wd=!0;a.ya=y.ud;a.D.aa.nd=[/(?:)/]}).catch(G=>{console.error(`Unable to connect with Android SDK: ${G}`)}).finally(()=>{t()});return}if(E(window,["webkit","messageHandlers","QMSDKv5"],!1)&&F){a.g.ie.Ga({method:"GET",url:"/v1/connect",body:{}}).then(()=>{a.K=a.B.vd;a.wd=!0;a.ya=y.ud;a.D.aa.nd=[/(?:)/]}).catch(G=>{console.error(`Unable to connect with iOS SDK: ${G}`)}).finally(()=>{t()});return}if(!a.D.config.autoDetectSDK){setTimeout(t,0);return}"QMFrameId"in window&&(a.frameId=window.QMFrameId);
Object.defineProperty(window,"QMFrameId",{set:function(G){return a.frameId=G},get:function(){return a.frameId}});if(a.D.config.useFallbackSDKSync){L(a.ba,"QMSDK:usesFallbackSDKSync",ba,"warn");"QMFrameId"in window&&(a.frameId=window.QMFrameId);const G=ml(a);if(G&&a.frameId){a.ha=G;mm(a);Lk(a);setTimeout(t,0);return}let ca=0;const S=Math.floor(a.D.config.maxWaitForSessionIdRetries/250),X=setInterval(function(){ca++;ca>S&&(console.warn("QM:: Timed out trying to get session & frameId from SDK. Continuing on with new session"),
X&&clearInterval(X),t());const N=ml(a);N&&a.frameId&&(mm(a),a.ha=N,Lk(a),setTimeout(t,0),X&&clearInterval(X))},250);return}(async function(){var G=window.QMSDK;let ca=window.QMSDKv4;if(!ca)try{ca=window.webkit.messageHandlers.QMSDKv4}catch(X){L(a.ba,"QMSDK:v4-not-present-ahead-of-time",{message:X.message,...ba},"error")}if(G||ca||a.D.config.waitForNativeCapture){if(G)if(G.sync){L(a.ba,"QMSDK:v2-sync",ba,"warn");var S=G.sync();typeof S==="string"&&(S=a.g.G.Ra(S))}else G.config&&G.config.reportURL||
(S=G);S||(S=await Promise.race([new Promise(X=>{window.addEventListener("qm_sdk_start",({detail:N})=>{X({sessionId:N.sessionId,userId:N.userId,frameId:N.frameId,config:{reportURL:N.config&&N.config.reportURL?N.config.reportURL:N.reportURL}})},{once:!0});window.dispatchEvent(new CustomEvent("qm_sdk_ready"))}),new Promise(async X=>{ca||(ca=await new Promise(N=>{Object.defineProperty(window,"QMSDKv4",{set:ab=>{N(ab)}})}));ca.start=N=>{X(N)};ca.postMessage(a.g.G.stringify({}))}),new Promise((X,N)=>{X=
a.D.config.maxSDKWaitTime;setTimeout(N,X,Error(`SDK not loaded within ${X}ms.`))})]));if(S){G=S.sessionId;const X=S.userId,N=S.frameId;G&&X&&N?(mm(a),a.ha=G,a.za=X,a.frameId=window.QMFrameId=N,Lk(a),(S=S.config)&&S.reportURL&&J(S.reportURL,a.D.aa.uh)&&(zd.reportURL=a.D.config.reportURL=S.reportURL)):L(a.ba,"QMSDK:v4-bad-payload",{payload:a.g.G.stringify(S),...ba},"error")}else L(a.ba,"QMSDK:v4-possible-bad-payload",{"payload-type":typeof S,payload:a.g.G.stringify(S),...ba},"error")}})().catch(G=>
{L(a.ba,"QMSDK:v4-sync-catch",{message:G.message,...ba},"error")}).then(t);return}t()}catch(t){Cj(a,t)}}}
class sm{constructor(){this.fb=null;this.Nf=0;this.oa=this.zb=null;this.Td={};this.$b=null;this.je=this.tg=this.dg=this.Qc=this.Uf=this.Qf=0;this.Eb=[];this.Jh=this.Sg=this.Lg=this.xc=this.Xf=this.Uc=0;this.R=null;this.Cf={events:[]};this.Xa=null;this.Xc=new Zi;this.ea=[];this.O=[];this.Vb=!1;this.Jc=[];this.Ic=[];this.ta=null;this.Mh={0:"navigate",1:"reload",2:"back_forward"};this.Oe=this.yc=!1;this.Cb=null;this.If=!1;this.ig="QM: fetch aborted.";this.og=this.wh=this.nh=this.jg=this.sg=!1;this.lg=
null;this.cg={connectStart:"cs",connectEnd:"ce",decodedBodySize:"dbs",domainLookupStart:"dls",domainLookupEnd:"dle",encodedBodySize:"ebs",fetchStart:"fs",initiatorType:"it",nextHopProtocol:"nhp",redirectStart:"rds",redirectEnd:"rde",requestStart:"rqs",responseStart:"rps",responseEnd:"rpe",secureConnectionStart:"scs",transferSize:"tz",workerStart:"ws"};this.Lh="connectStart connectEnd domainLookupStart domainLookupEnd fetchStart redirectStart redirectEnd requestStart responseStart responseEnd secureConnectionStart workerStart".split(" ");
this.qa={connectStart:"a",connectEnd:"b",domComplete:"c",domContentLoadedEventStart:"d",domContentLoadedEventEnd:"e",domInteractive:"f",domainLookupStart:"g",domainLookupEnd:"h",fetchStart:"i",loadEventStart:"j",loadEventEnd:"k",redirectStart:"l",redirectEnd:"m",requestStart:"n",responseStart:"o",responseEnd:"p",secureConnectionStart:"q",transferSize:"r",encodedBodySize:"s",decodedBodySize:"t","first-paint":"u","first-contentful-paint":"v","largest-contentful-paint":"w","first-input-delay":"x","cumulative-layout-shift":"y"};
this.Yg="redirectStart redirectEnd fetchStart domainLookupStart domainLookupEnd connectStart connectEnd requestStart responseStart responseEnd domInteractive domContentLoadedEventStart domContentLoadedEventEnd domComplete loadEventStart loadEventEnd".split(" ");this.Ef=!1;this.gf=!0;this.Qe=!1;this.ya=y.NONE;this.jf=this.Wg=0;this.jh=!1;this.Lc=this.Tb=this.Vg=this.bh=null;this.Zf=0;this.vg=this.Pe=!1;this.Mc=[];this.Bc=[];this.qg=!1;this.pg=Infinity;this.Pc=0;this.ug=!1;this.Eg=[];this.ua=[];this.Ad=
[];this.ca={};this.Sb=!1;this.Ea="";this.M=null;this.ha=void 0;this.Ie=this.ke=this.Of=this.Yb=!1;this.Ba=this.za=void 0;this.wd=this.Re=!1;this.B={va:0,lc:1,vd:2,td:3};this.pf=!0;this.dc=new Set;this.K=this.B.va;this.Jb=0;this.Kc=this.Id=this.Wc=this.$a=void 0;this.we=!1;this.Gd=void 0;this.Fc=this.Rc=this.Fg=0;this.eg=this.Ke=this.Oa=null;this.Gc=!1;this.xh=this.ec=0;this.Pd=new window.Set;this.Fd=null;this.Mb=this.jc=this.Zb=this.Lb=this.Vc=0;this.Sc=this.Hg=null;this.Ph={Bf:null,wf:null,gd:0,
qd:0,Zc:0,Fe:0,Yd:0,ne:null};this.kb={Bf:null,wf:null,gd:0,qd:0,Zc:0,Fe:0,Yd:0,ne:null,Fb:null};this.Cd=[0,0];this.Rb=null;this.Tc=this.mg=0;this.yg=!1;this.vf=void 0;this.wg=this.Dd=this.Oc=null;this.yh=!1;this.Ed="";this.Ub=null;this.Hc=[];this.rc=0;this.zd=!1;this.Nc=this.pa=null;this.customElements=new window.Set;this.Ih=/\n|\r|\f|[\u0000-\u001F]+/g;this.Oh=[100,105,99,107,115,104,105,116,124,102,117,99,107,124,106,97,99,107,97,115,115,124,99,117,110,116,124,112,117,115,115,121,124,100,111,117,
99,104,101,124,115,108,117,116,124,98,97,115,116,97,114,100,124,119,104,111,114,101,124,98,105,116,99,104,124,97,115,115,104,111,108,101,124,115,116,117,112,105,100,124,100,117,109,98,97,115,115];this.Gi=[101,118,97,108];this.Qh=[115,99,114,105,112,116];this.xe=this.rg="";this.ah=null;this.ng=!1;this.Rh=0;this.kc=this.fa=this.wc=this.ih=null;this.hg=!1;this.vc=this.Hd=null;this.xg=this.fg=this.zg=!1;this.sub="";this.frameId=void 0;this.Yc=Ia();this.Di=Ia();this.Rd={};this.Zd=Promise.resolve();this.Ha=
new jh;this.D=null;this.g={G:null,Z:null,animation:null,Aa:null,tb:null,Rg:null,oa:null,rd:null,se:null,supports:null,ia:null,zc:null,Nd:null,ie:null,bd:null,$f:null,Da:null,nc:null,mh:null,cc:null,Ee:null,Xa:null,console:null};this.g.G=new pc(this.Ha);this.$=new Si(this.g.G);this.g.Z=new Oc(this.g.G);this.g.animation=new vb(this,this.g.G,this.$);this.g.Aa=new ac(this);this.g.tb=new Zc(this);this.g.Rg=new ed(this);this.g.oa=new pd;this.g.rd=new Og(this);this.g.se=new Dd(this);this.g.supports=new ih;
this.g.ia=new lh(this.g.G);this.g.zc=null;this.g.Nd=null;this.g.ie=null;this.g.Da=new ni(this);this.g.console=new Yd({G:this.g.G,xa:this.xa.bind(this),Xd:(b,c)=>pj(this,b,c)});this.xd={};this.uf=0;this.ra=null;this.g.mh=new Ph;console=this.g.G.wa.contentWindow.console;this.g.Oi=new vd(this);const a=String.fromCharCode(76,105,103,104,116,110,105,110,103,32,87,101,98,32,83,101,99,117,114,105,116,121);this.tf=!1;try{URL.revokeObjectURL(URL.createObjectURL(new Blob([],{type:"text/javascript"})))}catch(b){this.tf=
b.message.includes(a)}this.la=null;this.yd=this.yd.bind(this);this.Dc=null;this.Bg=this.kg=!1;this.ba=null;this.Hf=!1;this.Sh=new Tg(this);this.df={};this.Jg=[];this.uc=null;this.Ha.addEventListener("mutations-observed",()=>{this.uc=null});this.da=Ea()}cb(a){if(a){if(a===document)return"^";if(a==document.documentElement)return"";if(a.nodeType==11)return(a=this.cb(a.host))?`${a} S#`:void 0;if(a.nodeType==1){var b=this.g.G.tagName(a).toLowerCase();if((b=="body"&&a===document.body||b=="head"||b=="html")&&
(!a.getRootNode||this.g.G.getRootNode(a)===document))return"<"+b.toUpperCase();this.$.B(a)}if(this.g.G.parentNode(a)){var c=this.g.G.parentNode(a);b=this.cb(c);if(b!==void 0&&(a=this.g.G.Array.prototype.indexOf.call(c.childNodes,a),a!==void 0))return b+" "+a}}}removedNodes(a){const b=this.$.Pf.get(a)||this.$.da(a);if(b===void 0)return null;this.g.G.isConnected(a)&&this.$.Pf.get(a)!==this.$.da(a)||Ri(this.$,a,!0);return{t:"r",I:b}}addedNodes(a){const b={t:"a"};for(var c=a.nextSibling;c&&!this.$.da(c);)c=
c.nextSibling;c?b[">"]=this.$.da(c):(c=this.g.G.parentNode(a))&&(b["p+"]=this.$.da(c));const {sb:d,Og:e}=uj(this,a);b.j=[d];this.ea.push(e);return b}get ub(){return this.Gc?!1:this.ya===y.Se?!0:this.ya===y.NONE}fh(a){if(a.type!="hidden"){const b=this.$.B(a);b.xb==void 0||b.xb==null?b.xb=gk(a):Sj(this,a)}}Nh(){var a=this;Z(a,function(){a.D.config.maskInputs||qk(a);if(a.D.config.checkBlankPages)try{typeof window.sessionStorage==="object"&&a.g.G.Storage.setItem.call(window.sessionStorage,"qm_last_period",
a.g.Z.W().toString())}catch(b){}})}Ya(a){var b=this.$.B(a);return b.Ya?b.Ya:b.Ya={Mg:0,zf:this.g.Z.W(),name:tk(this,a)}}mf(a){var b={T:"B",u:this.Ea,t:this.Jb,v:this.g.Z.W()};this.frameId&&(b.QF=this.frameId);this.Ba&&(b.H=this.Ba);this.ha&&(b.s=this.ha);a===0&&this.za&&(b.U=this.za);this.Wc&&(b.f=this.Wc);b.P=this.Nf;this.la.B>0&&(b.E=this.la.B);b.N=a;a===0&&this.Fd&&(b.pid=this.Fd);return b}Fi(a){a=this.mf(a);a.Q=2;delete a.P;delete a.E;return a}Ei(a,b){a=this.mf(a);a.Q=1;a.Y=1;if(b==null?0:b.de)a.X=
b.de;delete a.P;delete a.E;delete a.N;delete a.pid;return a}Nb(a){a=Y(this,a);return a==="input"||a==="textarea"?!0:null}Wb(a){const b=this.$.B(a);b.Wb===void 0&&(b.Wb=ok(this,a));return b.Wb}Za(a){var b=this.$.B(a);b.Za===void 0&&(a=a.nodeType!==1?null:ij(this,a)==="scrub"?!0:this.Ob(a),b.Za=a);return b.Za}Ob(a){var b=Y(this,a);b=b==="input"||b==="select"||b==="textarea";if(!b)return null;if(this.D.aa.ld||this.D.config.maskInputs&&b||this.Qa(a))return!0;if(b=a.getAttribute("autocomplete"))if(b=b.toLowerCase(),
b==="cc-number"||b==="cc-csc")return!0;if(b=a.getAttribute("x-autocompletetype"))if(b=b.toLowerCase(),b==="cc-number"||b==="cc-csc")return!0;b=a.getAttribute("title");if(!(a.id||a.name||b||a.className))return null;for(let c=0;c<this.D.aa.$e.length;++c){const d=this.D.aa.$e[c];if(a.id&&d.test(a.id)||a.name&&d.test(a.name)||b&&d.test(b)||a.className&&d.test(a.className))return!0}return null}Qa(a){var b=this.$.B(a);if(b.Qa===void 0)try{if(b.Qa=a.type&&a.type.toLowerCase()=="password",!b.Qa&&Y(this,a)==
"input"){var c=a.className||"";a.attributes.name&&a.attributes.name.value&&(c+=a.attributes.name.value);a.id&&(c+=a.id);c.toLowerCase().indexOf("password")>=0&&(b.Qa=!0)}}catch(d){b.Qa=!1}return b.Qa}yd(){var a=this;if(!a.wc){var b=0;a.wc=setInterval(()=>{b++;b>40?clearInterval(a.wc):nj(this,{method:"POST",url:"/v1/sub-frame-size",body:{w:Yj(),h:rk()}}).finally(()=>{a.wc&&(clearInterval(a.wc),a.wc=null)})},500)}}start(){this.Qe||(this.Qe=!0,am(this,[()=>{this.rg=la(this.Gi);this.xe=la(this.Qh)},()=>
{const a=window.QuantumMetricNetworkInterceptor;a&&(this.Dc=a)},()=>Ij(this),()=>{!this.yh&&this.D.config.hookFetch&&(Ik(this,typeof XMLHttpRequest!=="undefined","XMLHttpRequest must exist."),ll(this),this.yh=!0)},()=>jl(this),()=>hl(this),()=>{const a=window.navigator.userAgent,b=!!a.match(/WebKit/i);(a.match(/iPad/i)||a.match(/iPhone/i))&&b&&!a.match(/CriOS/i)&&this.g.G.M(window)!==window&&(this.yd(),this.g.G.addEventListener(window,"resize",this.yd,!0))},()=>{var a=window.navigator.userAgent||
window.navigator.vendor||window.opera;this.je=/uiwebview|(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substring(0,
4))?!0:!1},()=>Hj(this),()=>ul(this),()=>{this.oa.Ec()},()=>pk(this),()=>{if(window.Element.prototype.animate&&document.getAnimations){var a=this.g.animation;const h=document.getAnimations();try{for(let k=0;k<h.length;k++){const l=h[k];if(l instanceof window.CSSTransition||l.constructor.name==="CSSTransition"){var b=a;const m=l.effect&&l.effect.target;if(m){var c=l.transitionProperty,d=ob(),e=b.$.da(m);b.ma.set(l,d);b.log({t:"wa",v:">",I:e,p:c,i:d});tb(b,l,d)}break}if(l instanceof window.CSSAnimation||
l.constructor.name==="CSSAnimation"){c=a;const m=l.effect&&l.effect.target;if(m){b=l.animationName;var f=ob(),g=c.$.da(m);c.ma.set(l,f);c.log({t:"wa",v:">",I:g,a:b,i:f});tb(c,l,f)}break}sb(a,l)}}catch(k){}ub(this.g.animation)}},()=>{const a=(new URLSearchParams(window.location.search)).get(this.D.config.visibleQueryParamName);if(a!==null&&a=="true"||this.fa.get("visible"))return Xl(this)},()=>{if((new URLSearchParams(window.location.search)).get(this.D.config.surveyPreview.queryParamName)===this.D.config.surveyPreview.queryParamValue){var a=
fm(this).oc;const b=new URL(this.D.config.surveyPreview.url,window.location.href);b.searchParams.set("interface-handle",a);a=this.g.G.createElement(this.xe);a.src=b.href;a.crossOrigin="anonymous";document.head.appendChild(a)}},()=>{this.Bg=!0;this.yg=document.compatMode=="CSS1Compat";!kj(this)&&[this.B.va].includes(this.K)&&Jj(this,ib(this.M),!1);for(let b=0;b<this.D.config.sessionPersistenceMediums.length;b++){const c=this.D.config.sessionPersistenceMediums[b];if(c!=="cookie")for(var a in window[c])if(a.indexOf("QM:s:")==
0){const d=this.g.G.Ra(this.g.G.Storage.getItem.call(window[c],a));Cg(this.fa,d)&&window[c].removeItem(a)}}},()=>{if([this.B.va].includes(this.K)){Sl(this);const a=em();a&&this.g.Ee.load(a)}else nj(this,{method:"POST",url:"/v1/child-ready",body:{"from-frame":this.g.G.M(window)!==window}})}]))}xa(a,b){this.ba&&L(this.ba,a,{value:b,s:this.ha,h:this.Ba,u:this.Ea},"warning")}get Na(){const a=this.fa.get("apiReplayEnabled",null);return a!==null?a:this.pf===!1||this.fa.get("sampleReplayEnabled",null)===
!1||this.fa.get("configReplayEnabled",null)===!1?!1:!0}get ui(){const a=this.fa.get("apiReplayEnabled",null);return a!==null?a===!1?xa.gg:null:this.pf===!1?xa.gg:this.fa.get("sampleReplayEnabled",null)===!1?xa.Th:this.fa.get("configReplayEnabled",null)===!1?xa.Kh:null}stop(a){this.ya=a;if([y.NONE,y.Ne,y.Te,y.Je].includes(a)){const b=oj(this,{method:"POST",url:"/v1/stop",body:{reason:a}});a=this.g.bd?this.g.bd.Ga({method:"POST",url:`/v1/${a===y.NONE?"start":"stop"}`,body:{reason:a}}).catch(ua):Promise.resolve();
return Promise.all([b,a])}}ed(a){const b=this.$.B(a);if(b.ed===void 0)try{b.ed=a instanceof window.HTMLElement&&window.customElements.get(a.localName)}catch(c){b.ed=!1}return b.ed}getContext(){const a={session:this.ha,user:this.za,state:this.fa.get([],{}),parentHitId:this.Ba,contextId:this.Yc,replayEnabled:this.Na,...this.Rd,nativeSDK:this.wd};Object.keys(this.Rd).length&&(a.userContextHashed=!0);return a}}
typeof window!=="undefined"&&(window.QuantumMetricInstrumentationStart=function(a){qm(new sm,a)});const tm=new window.Set([-82,-83,-84,-85,-86,-87,-88]),um={rage:-2,frustration:-5};function wd(a,b,c,d){if(a.J.ub){var e=a.K[b];if(e){typeof b==="number"?c={id:c.i,value:c.v,ts:c.t,i:c.i,v:c.v,ev:c.ev,name:a.J.df[c.i]||"UNKNOWN"}:b==="api"&&(c={url:c.u,method:c.m,status:c.st,responseTime:c.r,xhr:d});for(var f=0;f<e.length;f++)try{e[f](c,b)}catch(g){vm||(vm=!0,console.warn("QM: API Listener caught exception: "+g))}}typeof b==="number"&&wd(a,"event",c,d)}}
function wm(a,b,c){a.J.ub&&P(b,{id:0,ja:1,flags:6,ka:a.J.g.Z.W()},c)}async function xm(a,b,c="",d=null){if(a.J.ub){var e=a.J.R;if(e){var f=e.O[b.id];if(f)f.ka=b.ka,b=f;else if(b.id>0){a.J.xa("unsupported_event",b.id);return}d!==null&&(f=a.J.g.G.stringify(d,cc),f.length>a.J.D.config.maxMDELength&&(d={error:"Too much data"},f=a.J.g.G.stringify(d,cc)),d={hash:await Ub(f),value:d});ng(e,b,c,d)&&qg(e,"timeline",a.J.g.Z.W())}else a.M.push({event:b,value:c,bc:d})}}
class rm{constructor(a){function b(c,d="",e=50,f=200){let g=0,h=null,k=!1;return function(...l){h||(h=setTimeout(()=>{g=0;h=null;k=!1},f));g++;if(g>e)k||(k=!0,this.J.xa("RATE_LIM",`API calls to ${d} exceeded configured rate limits.`));else return c.apply(this,l)}}this.J=a;this.B=null;this.M=[];this.K=[];["sendEvent"].forEach(c=>{this[c]=b(this[c],c)})}Ec(){const a=window.QuantumMetricOnload;if(a)if(a instanceof Array)for(let b=0;b<a.length;b++){if(typeof a[b]==="function")try{a[b](this)}catch(c){}}else if(typeof a===
"function")try{a(this)}catch(b){}}lastUrl(){const a=this.J.fa.get("lastUrl",!1);return a?new URL(a):!1}get(a,b,c){return E(a,b,c)}getSessionVar(a,b){return a?this.J.fa.get(`ext.${a}`,b):b}setSessionVar(a,b){if(a)return this.J.fa.set(`ext.${a}`,b)}addEventListener(a,b){if(a instanceof Array)for(var c=0;c<a.length;c++)this.addEventListener(a[c],b);else a=um[a]||a,(c=this.K[a])||(c=this.K[a]=[]),c.push(b);a==="start"&&this.J.Ba&&b({sessionID:this.J.ha,userID:this.J.za,hitID:this.J.Ba,url:this.J.M.eb.qb},
a)}removeEventListener(a,b){try{var c=this.K[a];c&&(this.K[a]=c.filter(function(d){return d!=b}))}catch(d){}}identifyUser(a){var b=this.J.R;b?(wm(this,b,a),this.B=null):this.B=a}sendEvent(a,b=0,c="",d=null){a<0&&!tm.has(a)?this.J.xa("unsupported_event",a):xm(this,{id:a,flags:b,ka:this.J.g.Z.W()},c,d)}setUserFirst(a){xm(this,{id:0,ja:1,flags:8,ka:this.J.g.Z.W()},a)}setUserLast(a){xm(this,{id:0,ja:1,flags:16,ka:this.J.g.Z.W()},a)}setUserIdentifier(a){xm(this,{id:0,ja:1,flags:131072,ka:this.J.g.Z.W()},
a)}getPrevEventData(a){var b=this.J.R;return b?pg(b,a):null}getCartValue(){return this.J.fa.get("cv",null)}setCart(a){String(a).indexOf(".")!==-1?xm(this,{id:-18,flags:0,ka:this.J.g.Z.W()},"Invalid cart value format: "+a):xm(this,{id:0,ja:2,flags:64,ka:this.J.g.Z.W()},a)}getSessionID(){return this.J.ha}getSession(){return this.getSessionID()}getUserID(){return this.J.za}getConfig(){return this.J.D.config}getRawConfig(){return this.J.D.K}_localOverride(a,b){switch(a){case "transformAttributesForNodesList":this.J.D.aa.Ab=
b;break;default:console.warn("invalid local override")}}getReplay(){const a=this.getSub(),b=this.getSessionID();if(!b)return"";var c=B(this.J.g.Z.W()/1E3);return`https://${a}.quantummetric.com/#/replay/cookie:${b}?ts=${c-43200}-${c+43200}`}getSub(){return this.J.sub}setMVTCampaignAndValue(a,b){xm(this,{id:-20,flags:0,ka:this.J.g.Z.W()},a);xm(this,{id:-21,flags:0,ka:this.J.g.Z.W()},b)}setApplicationVersion(a){xm(this,{id:-9999,ja:1,flags:2048,ka:this.J.g.Z.W()},a)}setABNSegment(a){xm(this,{id:-100,
flags:128,ka:this.J.g.Z.W()},a)}getABNSegment(){return Uk(this.J)}get conversionRates(){return this.J.Td}set conversionRates(a){this.J.Td=a}currencyConvertFromToValue(a,b,c){this.J.g.Z.W()%100<10&&L(this.J.ba,"currencyConvertFromToValue",!0);b=ya(a,b,c,this.conversionRates);typeof b==="string"?this.J.xa("currency_conversion",b):a=b;return B(a)}getCurrencyValue(a){this.J.g.Z.W()%100<10&&L(this.J.ba,"getCurrencyValue",!0);return za(a)}get targetCurrency(){return this.J.D.config.targetCurrency}get lastXHR(){return this.J.R?
this.J.R.Ia:null}newSession(){jj(this.J)}newUser(){try{const a=this.J.D&&this.J.D.config&&this.J.D.config.userCookieName;a&&this.J.ra.jb({[a]:""});this.J.kc&&this.J.kc.clear();this.J.za=void 0;this.B=null}catch(a){}this.newSession()}switchSession(a){var b=this.J;[b.B.va].includes(b.K)?a.length<=100&&(b.fa.archive(`QM:s:${b.ha}`),b.Gd=a,jj(b)):L(b.ba,"switchSession",!0)}newPage(){Rl(this.J,64)}stopPage(){this.J.stop(y.Ne)}stopSession(){Li(this.J,!1)}startSession(){Li(this.J,!0)}optInUser(){lm(this.J,
!1)}optOutUser(){lm(this.J,!0)}isOn(){var a=this.J;return a.Ef&&a.ya===y.NONE}isUserEnabled(){return Ii(this.J)}uploadRL(){this.J.D.aa.md=!0;this.J.g.Aa.ma=new this.J.g.G.WeakMap;Kl(this.J)}querySelectorCrossingShadowDOM(a,b){return this.J.g.ia.querySelector(a,b)}querySelectorAllCrossingShadowDOM(a,b){return this.J.g.ia.querySelectorAll(a,b)}installQMVisible(){return Xl(this.J)}async bg(){this.B&&wm(this,this.J.R,this.B);this.B=null;if(this.M.length>0){for(var a=0;a<this.M.length;a++){const d=this.M[a];
var b=d.event,c=this.J.R.O[b.id];if(c)b=c;else if(b.id>0){this.J.xa("unsupported_event",b.id);return}d.bc&&(d.bc={hash:await Ub(this.J.g.G.stringify(d.bc,cc)),value:d.bc});ng(this.J.R,b,d.value,d.bc)}this.M=[]}}enableReplay(a){typeof a!=="boolean"&&(console.warn("QM: enableReplay called with non-boolean value",a),L(this.J.ba,"enableReplay called with non-boolean value",!0));a=!!a;[this.J.B.va].includes(this.J.K)&&a!==this.J.Na&&km(this.J,a)}}var vm=!1;})();

window.QuantumMetricInstrumentationStart({"dataEncryptWhiteList":[{"pred":{"operator":"default"},"rules":[{"pred":{"operator":"default"},"value":["[data-qm-allow]","#header-search-input",".top-facet .ant-select-selection-item"]}]}],"dataScrubBlackList":[{"pred":{"operator":"default"},"rules":[{"pred":{"facet":"url","operator":"contains","value":"musicarts.com"},"value":["#global-header div:has(button > svg) > div > svg~span"]},{"pred":{"facet":"url","operator":"regex","value":"guitarcenter\\.com\\/myaccount\\/order\\/detail"},"value":["div.order-summary span > div > a","div.order-summary div > div~div > div~div > div > span","div.shipping-info > div"]},{"pred":{"facet":"url","operator":"regex","value":"guitarcenter\\.com\\/checkout"},"value":["form ul li"]},{"pred":{"facet":"url","operator":"contains","value":"musicarts.com/orderConfirmation/confirmation"},"value":["#main-content > div.max-w-\\[1312px\\].mx-auto.l\\:mt-\\[26px\\].l\\:flex.gap-x-\\[32px\\] > div.l\\:w-\\[865px\\] > div > div:nth-child(4) > ul > li.max-lg\\:mt-4 > div > span","#main-content > div.max-w-\\[1312px\\].mx-auto.l\\:mt-\\[26px\\].l\\:flex.gap-x-\\[32px\\] > div.l\\:w-\\[865px\\] > div.bg-n-200.p-4.l\\:p-m > div:nth-child(5) > ul > li.max-lg\\:mt-4 > div > span"]},{"pred":{"facet":"url","operator":"contains","value":"musicarts.com/cart/checkout"},"value":["#main-content > div.l\\:flex.l\\:flex-row-reverse.justify-between > div.l\\:w-\\[608px\\] > div:nth-child(2) > div.mt-8 > div.mb-6 > div:nth-child(2) > div > div > div.mt-4 > div:nth-child(1) > div:nth-child(2) > label > div > div.flex.items-center.mb-2.l\\:mb-0 > div:nth-child(2) > div.paragraph-small.text-n-500","#main-content > div.l\\:flex.l\\:flex-row-reverse.justify-between > div.l\\:w-\\[608px\\] > div:nth-child(2) > div.mt-8 > div.mb-6 > div:nth-child(2) > div > div > div.mt-4 > div:nth-child(1) > div:nth-child(2) > label > div > div.flex.items-center.mb-2.l\\:mb-0 > div:nth-child(2) > div.text-\\[14px\\].leading-\\[150\\%\\].flex","#main-content > div.l\\:flex.l\\:flex-row-reverse.justify-between > div.l\\:w-\\[608px\\] > div:nth-child(2) > div.paragraph-small.text-n-600.mt-\\[27px\\] > div:nth-child(1) > div:nth-child(2)","#main-content > div.l\\:flex.l\\:flex-row-reverse.justify-between > div.l\\:w-\\[608px\\] > div:nth-child(2) > div.paragraph-small.text-n-600.mt-\\[27px\\] > div:nth-child(2)","#main-content > div.l\\:flex.l\\:flex-row-reverse.justify-between > div.l\\:w-\\[608px\\] > div:nth-child(2) > div.mt-8 > div.mb-6 > div:nth-child(2) > div > div > div.mt-4 > div:nth-child(1) > div:nth-child(2) > label.flex.cursor-pointer.items-center.px-s.py-\\[10px\\].align-middle.inline-block.bg-n-100.border.rounded-\\[2px\\].sm\\:border-\\[\\#293340\\].py-\\[8\\.5px\\].mb-s.sm\\:p-2 > div > div.flex.items-center.mb-2.l\\:mb-0 > div:nth-child(2) > div.text-\\[14px\\].leading-\\[150\\%\\].flex > div:nth-child(1)","#main-content > div.l\\:flex.l\\:flex-row-reverse.justify-between > div.l\\:w-\\[608px\\] > div:nth-child(2) > div.mt-8 > div.mb-6 > div:nth-child(2) > div > div > div.mt-4 > div:nth-child(1) > div:nth-child(2) > label.flex.cursor-pointer.items-center.px-s.py-\\[10px\\].align-middle.inline-block.bg-n-100.py-\\[8\\.5px\\].mb-s.sm\\:p-2 > div > div.flex.items-center.mb-2.l\\:mb-0 > div:nth-child(2)","#main-content > div.l\\:flex.l\\:flex-row-reverse.justify-between.quantummetric_hover_class > div.l\\:w-\\[608px\\].quantummetric_hover_class > div.border.border-n-300.p-l.max-md\\:p-m.mb-6.quantummetric_hover_class > div.mt-8.quantummetric_hover_class > div.text-n-600.mb-6.quantummetric_hover_class > div.bg-\\[rgba\\(0\\,130\\,58\\,0\\.08\\)\\].flex.gap-2.p-4.mb-6 > div > div.flex.items-center.justify-between > div.flex.items-center.gap-2 > div","div[class*=\"paragraph-\"]:has(div~div) > div","div > ul > li > button"]},{"pred":{"facet":"url","operator":"contains","value":"musicarts.com/account/payments"},"value":["#main-content > div.flex-1.overflow-hidden > div > ul > li > div.flex-1 > div.paragraph-large.text-n-600.font-bold","#main-content > div.flex-1.overflow-hidden > div > ul > li > div.flex-1 > div.paragraph-medium"]},{"pred":{"facet":"url","operator":"regex","value":"musicarts\\.com\\/account\\/rentals\\/.+"},"value":["#main-content > div.w-full > div > div.p-4.mt-8.l\\:p-8.border.border-n-300.l\\:w-full > div.l\\:pt-6.l\\:flex.l\\:items-start.l\\:justify-between > div.l\\:w-\\[415px\\].mt-4.l\\:mt-2 > div.justify-between.flex.mb-4.l\\:justify-start > div:nth-child(2) > div > div > div:nth-child(1)","#main-content > div.w-full > div > div.p-4.mt-8.l\\:p-8.border.border-n-300.l\\:w-full > div.l\\:pt-6.l\\:flex.l\\:items-start.l\\:justify-between > div.l\\:w-\\[415px\\].mt-4.l\\:mt-2 > div.justify-between.flex.mb-4.l\\:justify-start > div:nth-child(2) > div > div > div:nth-child(2) > span:nth-child(2)","#main-content > div.w-full > div > div.md\\:flex.gap-x-8.mt-8 > div.bg-n-200.p-4.l\\:p-6.md\\:w-\\[475px\\].l\\:w-\\[528px\\] > div.mt-4.l\\:mt-6 > div.flex.mt-1.items-center > span"]},{"pred":{"facet":"url","operator":"regex","value":"musicarts\\.com\\/account\\/orders\\/.+"},"value":["#main-content > div.flex-1 > div.gap-x-8.mb-16 > div.bg-n-200.p-4 > div.mt-4 > div.flex.mt-1.items-center > span"]},{"pred":{"operator":"default"},"value":[".sensitive","input[autocomplete=\"cc-number\"]","input[autocomplete=\"cc-csc\"]","input[x-autocompletetype=\"cc-number\"]","input[x-autocompletetype=\"cc-csc\"]","[data-qm-block]","div.accountSubSection > div.subSegment > div > ul > li > ul > li","#creditCardNumber","#expiration","#cvvToolTip","section[s-object-region=\"confirmation-summary\"] div > p:has(span.payment-type-text)","p.billing-fullname-text","p.billing-address-text","#cardNumber","#expMonth","#expYear","#billingAddress","div.paymentLine","#card0 p.nameLabel","label[class*=\"base_checkout-input\"]","div.payment-billing-address > div > div","div.card-summary > div > div > span","div.card-summary > div > div > p","div.card-summary > div > div > div","section.essential > form > div > p","div#platinumAndChoice form div > span","div#platinumAndChoice form > div > div > div > p","input[id=\"expiration\"]","#payment_billingAddress","#payment_billingAddress > option","div.card-info > div",".lessonsPaymentLine","div.orderDetail div.paymentDetail > dl > dt","div.payment > .paymentInfo","p.license > span","div.card-item > div > div > div > span","div.card-item > div > div > span","div.summary-content > div > div > div > span:not(span[title=\"remove\"])","input#postalCode","input#city","#payment_billingAddress",".delivery-section button",".firstName","#myAccount_payment_removePrimaryCreditCardForm select","#myAccount_payment_removePrimaryCreditCardForm option","div.address-info p","div.card-info span","div.card-summary p","div.ant-select-item-option","div.ant-select-item-option > div",".private"]}]}],"dataScrubRE":[{"pred":{"operator":"default"},"rules":[{"pred":{"operator":"default"},"value":[{"f":"i","p":"cvv|cvc|month|year|birth|cid|csc|cvn|sensitive|security|ccnumber|card.*identification|verification|^aba$|^tin$|routing|ssn|itin|account.*number|acct.*num|card.*num|card.*#|card.*no|cc.*num|nummer|n.m.ro|credito|信用卡|카드|カード番|Номер.*карты"},{"f":"i","p":"giftCertificateNumber"},{"f":"i","p":"giftCertificatePin"},{"f":"i","p":"creditCardNumber"},{"f":"i","p":"cvvToolTip"},{"f":"i","p":"giftCardNumber"},{"f":"i","p":"pin"}]}]}],"dataScrubXHRRegExes":[{"pred":{"operator":"default"},"rules":[{"pred":{"operator":"default"},"value":[{"f":"i","p":"\"firstName\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"lastName\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"cvv_code\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"cvvCode\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"expiration_date\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"expirationDate\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"account_no\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"routingNumber\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"date_of_birth\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"dateOfBirth\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"countryOfBirth\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"new_password\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"gender\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"accountNo\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"accountNumber\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"confirm_password\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"confirmPassword\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"addr_Line1\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"addr_Line2\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"addrLine1\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"addrLine2\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"password\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"dob\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"newPassword\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"loginToken\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"card_number\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"address\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"name\"\\s*:\\s*\"([^,\"}]+)\"(?!\\s*,\\s*\"value\")\\s*,?"},{"f":"i","p":"\"nationality\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"routing_number\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"account_number\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"givenName\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"familyName\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"Password\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"Credit Card Details\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"DOB (Date of Birth)\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"DOB (Date of Birth)\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"returningCustomer_Password\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"newCustomer_Password\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"password\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"creditCardNumber\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"expirationMonth\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"expirationYear\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"paymentType\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"billingAddressName\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"creditCardNumberTemp\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"paymentGroupName\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"selectedPaymentType\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"creditCardFormState\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"cvv\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"_dynSessConf\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"giftCardNumber\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"pin\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"aroundLatLng\":\"?([^,\"}]+)\"?,?"},{"f":"i","p":"\"zipcode\":\"?([^,\"}]+)\"?,?"}]}]}],"elementVeinAttributes":[{"pred":{"operator":"default"},"rules":[{"pred":{"operator":"default"},"value":["id","aria-label","alt","name","s-object-region","data-product-sku-id","data-ae-carousel-index","class"]}]}],"encryptScrubList":[{"pred":{"operator":"default"},"rules":[{"pred":{"facet":"url","operator":"contains","value":"musicarts.com/account/payments"},"value":["#main-content > div.flex-1.overflow-hidden > div > div > h5","#main-content > div.flex-1.overflow-hidden > h4"]},{"pred":{"facet":"url","operator":"contains","value":"musicarts.com/cart"},"value":["input[name=\"coupon-code\"]","#main-content > section > form > div > div.l\\:w-\\[416px\\] > div.bg-n-200.p-6.mb-6 > div.pt-\\[14\\.5px\\].pb-2.border-t.border-b.border-n-300 > div.flex.mt-2.border-n-300.items-center > div.text-m-s.paragraph-medium.flex-shrink-0","#main-content > div.l\\:flex.l\\:flex-row-reverse.justify-between > div.border.border-n-300.py-3.px-4.mb-6.l\\:w-\\[416px\\].l\\:border-0.print\\:border-0.print\\:p-0.l\\:p-0 > div.l\\:block.sm\\:hidden > div.mb-6 > div > div.pt-\\[14\\.5px\\].pb-2.border-t.border-b.border-n-300 > div.flex.mt-2.border-n-300.items-center > div.text-m-s.paragraph-medium.flex-shrink-0"]},{"pred":{"facet":"url","operator":"contains","value":"musicarts.com/account/commercial-accounts"},"value":["#main-content > div.pb-\\[49px\\].l\\:pb-\\[19px\\].l\\:w-\\[976px\\] > div.l\\:flex.justify-between.mt-8.items-center > div:nth-child(1) > div > div:nth-child(3) > div","#main-content > div.pb-\\[49px\\].l\\:pb-\\[19px\\].l\\:w-\\[976px\\] > div.l\\:flex.justify-between.mt-8.items-center > div:nth-child(1) > div > div:nth-child(1) > div.paragraph-medium","#main-content > div.pb-\\[49px\\].l\\:pb-\\[19px\\].l\\:w-\\[976px\\] > div.l\\:flex.justify-between.mt-8.items-center > div:nth-child(1) > div > div:nth-child(2) > div","#main-content > div.pb-\\[49px\\].l\\:pb-\\[19px\\].l\\:w-\\[976px\\] > div:nth-child(5) > ul > li","#main-content > div.pb-\\[49px\\].l\\:pb-\\[19px\\].l\\:w-\\[976px\\] > h4"]},{"pred":{"facet":"url","operator":"contains","value":"musicarts.com/request-quote"},"value":["#ae-main-content > div.mt-8.max-w-full.w-\\[1088px\\].mb-12.md\\:flex.mx-auto.print\\:\\!m-0.print\\:\\!p-0.print\\:\\!w-full > div.space-y-6.md\\:mr-4.lg\\:mr-16.md\\:w-7\\/12.flex-shrink-0.print\\:hidden > div:nth-child(1) > div.empty\\:hidden > div > div","body > div.ReactModalPortal > div > div > div > div.overflow-auto.flex-auto.basis-full.space-y-4 > div","#ae-main-content > div.mt-8.max-w-full.w-\\[1088px\\].mb-12.md\\:flex.mx-auto.print\\:\\!m-0.print\\:\\!p-0.print\\:\\!w-full > div.space-y-6.md\\:mr-4.lg\\:mr-16.md\\:w-7\\/12.flex-shrink-0 > div:nth-child(1) > div > div > div > p.paragraph-medium","#ae-main-content > div.mt-8.max-w-full.w-\\[1088px\\].mb-12.md\\:flex.mx-auto.print\\:\\!m-0.print\\:\\!p-0.print\\:\\!w-full > div.space-y-6.md\\:mr-4.lg\\:mr-16.md\\:w-7\\/12.flex-shrink-0.print\\:hidden > div:nth-child(2) > div.empty\\:hidden > div","#ae-main-content > div.mt-8.max-w-full.w-\\[1088px\\].mb-12.md\\:flex.mx-auto.print\\:\\!m-0.print\\:\\!p-0.print\\:\\!w-full > div.space-y-6.md\\:mr-4.lg\\:mr-16.md\\:w-7\\/12.flex-shrink-0.print\\:hidden > div:nth-child(1) > div.empty\\:hidden > div","#ae-main-content > div.mt-8.max-w-full.w-\\[1088px\\].mb-12.md\\:flex.mx-auto.print\\:\\!m-0.print\\:\\!p-0.print\\:\\!w-full > div.space-y-6.md\\:mr-4.lg\\:mr-16.md\\:w-7\\/12.flex-shrink-0.print\\:hidden > div:nth-child(1) > div:nth-child(2)"]},{"pred":{"facet":"url","operator":"contains","value":"musicarts.com/orderConfirmation/confirmation"},"value":["#main-content > div.max-w-\\[1312px\\].mx-auto.l\\:mt-\\[26px\\].l\\:flex.gap-x-\\[32px\\] > div.l\\:w-\\[865px\\] > div > p > span.font-bold","#main-content > div.max-w-\\[1312px\\].mx-auto.l\\:mt-\\[26px\\].l\\:flex.gap-x-\\[32px\\] > div.l\\:w-\\[865px\\] > div > div:nth-child(3) > ul > li.l\\:w-\\[465px\\]","#main-content > div.max-w-\\[1312px\\].mx-auto.l\\:mt-\\[26px\\].l\\:flex.gap-x-\\[32px\\] > div.l\\:w-\\[865px\\] > div > div:nth-child(4) > ul > li.l\\:w-\\[465px\\]","#main-content > div > div > div.bg-n-200 > div:nth-child(4) > ul > li","#main-content > div.max-w-\\[1312px\\].mx-auto.l\\:mt-\\[26px\\].l\\:flex.gap-x-\\[32px\\] > div.l\\:w-\\[865px\\] > div.bg-n-200.p-4.l\\:p-m > div:nth-child(5) > ul > li.l\\:w-\\[465px\\] > div.mt-1"]},{"pred":{"facet":"url","operator":"contains","value":"musicarts.com/cart/checkout"},"value":["#main-content > div.l\\:flex.l\\:flex-row-reverse.justify-between > div.l\\:w-\\[608px\\] > div:nth-child(1) > div:nth-child(2) > div:nth-child(4) > div:nth-child(2) > label > div > div > div.paragraph-small","#main-content > div.l\\:flex.l\\:flex-row-reverse.justify-between > div.l\\:w-\\[608px\\] > div:nth-child(2) > div.mt-8 > div.mb-8 > div:nth-child(3) > div:nth-child(1) > label > div > div","#main-content > div.l\\:flex.l\\:flex-row-reverse.justify-between > div.l\\:w-\\[608px\\] > div:nth-child(1) > div.paragraph-small.text-n-600.mt-\\[27px\\] > div:not(.mt-2)","#main-content > div.paragraph-large.text-n-600.mb-6.flex.items-center.justify-between > div > div > span.font-bold","#main-content > div.l\\:flex.l\\:flex-row-reverse.justify-between > div.l\\:w-\\[608px\\] > div:nth-child(2) > div.mt-8 > div.mb-8 > div:nth-child(2) > div:nth-child(1) > label > div > div","#main-content > div.l\\:flex.l\\:flex-row-reverse.justify-between > div.l\\:w-\\[608px\\] > div:nth-child(1) > div:nth-child(2) > div:nth-child(4) > div:nth-child(2) > label.flex.cursor-pointer.items-center.px-s.py-\\[10px\\].align-middle.inline-block.bg-n-100.py-\\[8\\.5px\\].mb-s.sm\\:p-s > div > div > div:nth-child(1)","body > div.ReactModalPortal > div > div > div > div.overflow-auto > label.flex.cursor-pointer.items-center.px-s.py-\\[10px\\].align-middle.inline-block.bg-n-100.py-\\[8\\.5px\\].mb-s.sm\\:p-s > div > div","#main-content > div.l\\:flex.l\\:flex-row-reverse.justify-between > div.l\\:w-\\[608px\\] > div:nth-child(1) > div:nth-child(2) > div:nth-child(6) > section > div.relative > div.absolute.top-\\[52px\\].left-0.w-full.z-10"]},{"pred":{"facet":"url","operator":"contains","value":"musicarts.com/account/addresses"},"value":["#main-content > div.flex-1.overflow-hidden > div > ul > li > div.text-n-600.font-bold","#main-content > div.flex-1.overflow-hidden > div > ul > li > div.paragraph-medium"]},{"pred":{"facet":"url","operator":"regex","value":"musicarts\\.com\\/account\\/rentals\\/.+"},"value":["#main-content > div.w-full > div > div.md\\:flex.gap-x-8.mt-8 > div.bg-n-200.p-4.l\\:p-6.md\\:w-\\[475px\\].l\\:w-\\[528px\\] > div:nth-child(1) > div.paragraph-small:not(:last-child)","#main-content > div.w-full > div > div.md\\:flex.gap-x-8.mt-8 > div.bg-n-200.p-4.l\\:p-6.md\\:w-\\[475px\\].l\\:w-\\[528px\\] > div.mt-4.l\\:mt-6 > div.paragraph-small","#main-content > div.w-full > div > div.l\\:flex.justify-between.mt-6.l\\:mt-8 > h4","#main-content > div.w-full > div > div.p-4.mt-8.l\\:p-8.border.border-n-300.l\\:w-full > div.text-n-600.l\\:flex > div.flex.justify-between > div.flex.flex-col.l\\:mr-16 > strong"]},{"pred":{"facet":"url","operator":"contains","value":"musicarts.com"},"value":["#global-header > section > div.bg-gray-600 > div > div.flex.h-full.max-ssm\\:gap-x-\\[10px\\] > div.relative.flex.sm\\:px-0.l\\:px-4.text-\\[\\#fff\\].flex-shrink-0 > button > span","#global-header > section > div.bg-gray-200.h-10 > div > ul.flex.h-full.items-center.shrink-0.max-w-full > li:nth-child(3) > button > span > span.underline.underline-offset-2","#global-header > section > div.bg-red-secondary > div > div.flex.h-full.max-ssm\\:gap-x-\\[10px\\] > div.relative.flex.sm\\:px-0.l\\:px-4.text-\\[\\#fff\\].flex-shrink-0 > button > span","body > div.ReactModalPortal > div > div > div > form > div > div:nth-child(4) > div.text-base.leading-\\[150\\%\\]","div.absolute.left-0.w-full.z-10.top-\\[50px\\] > ul > li","#global-header > section > div.bg-n-100 > div > div.flex.h-full.max-ssm\\:gap-x-\\[10px\\] > div.relative.flex.sm\\:px-0.l\\:px-4.text-\\[\\#fff\\].flex-shrink-0.sm\\:bg-white.sm\\:text-n-600 > button > span","body > div.ReactModalPortal > div > div > div > div.flex-1 > div:nth-child(2) > label > div","#global-header > section > div.bg-gray-200.h-10 > div > ul.flex.h-full.items-center.shrink-0.max-w-full > li.flex-1 > button > span"]},{"pred":{"facet":"url","operator":"regex","value":"musicarts\\.com\\/account\\/rentals"},"value":["#main-content > div.mb-8.mx-auto.grow-0.overflow-hidden > ul > li > div > p.mb-2.text-n-600.font-bold"]},{"pred":{"facet":"url","operator":"regex","value":"musicarts\\.com\\/account\\/orders\\/.+"},"value":["#main-content > div.flex-1 > div.gap-x-8.mb-16 > div.bg-n-200.p-4 > div:nth-child(1) > div.mt-1:not(:last-child)","#main-content > div.flex-1 > div.gap-x-8.mb-16 > div.bg-n-200.p-4 > div.mt-4 > div.paragraph-small","#main-content > div.max-w-\\[976px\\].flex-1 > div.md\\:flex.gap-x-8.mb-16 > div.bg-n-200.p-4.l\\:p-6.md\\:w-\\[475px\\].l\\:w-\\[528px\\] > div.mt-4.l\\:mt-6 > div.flex.mt-1.items-center > div > div:nth-child(2)"]},{"pred":{"facet":"url","operator":"regex","value":"\\/checkout\\/payment|\\/cart|\\/checkout\\/shipping"},"value":["div.ant-message-top span.message-content-wrap","div.discount","form.ant-form div.relative a","p.break-all","div.ant-message-custom-content","dl.coupon > dd","section[s-object-region=\"delivery\"] p.break-all"]},{"pred":{"operator":"default"},"value":["[data-qm-encrypt]","div.profile > h5","div.profile > p","div.accountSubSection div.subSegment > div~div > ul:has(li > h4.addrHeading) > li:not(li:has(h4))",".email",".name",".last-name","#address","#address apt","#phone","#email","#fullName","#address1","#address2","#phoneToolTip","section[s-object-region=\"delivery\"] p:has(br)","section.credit-card div.gc-checkbox~div > div","#city","#state","#postalCode","section[s-object-region=\"confirmation-summary\"] > div > p","section[s-object-region=\"confirmation-summary\"] div > h6~p:not(.delivery-method-text)","#firstName","#lastName","#email","#phoneNumber","#birthmonth","#birthday","div.shipDetails > ul > li > p","div.ship-details > ul > li > span.rightCell","#name3 > p.nameLabel","div.addressLine","button:has(img[alt=\"logged account icon\"]) > span","h3 > span > a[href=\"/myaccount/overview\"]",".ant-select-selection-item","div[id*=\"state_list\"]","div.ant-modal-body > div > p~p:has(br)","#address-suggestion","#address-suggestion > ul > li",".suggestion-list > li","#mySubscriptions > div.title > span:not(.pageTitle)","div.paymentContainer dt","div.shipping-address","div.shipping-address > p","div.orderDetail li > a","section[s-object-region=\"cart-right-rail-wrapper\"] ~ section > div:has(div ~ div[id=\"cart-top-title\"]) > div:not([id=\"cart-top-title\"]) > div","div.summary-content > div > div > div > span:not(span[title=\"remove\"])","div.cart-summary > div > div > div > div:has(span[title=\"remove\"]) > span:not([title=\"remove\"])","span.ShopLoginText",".orderDetail .orderIteration .orderPrefs",".payment-group span+span","form.ant-form>div>div.ant-form-item~div>a","button[id=\"enterLocation\"]","button[id=\"enterLocation\"] > span",".address",".billingAddress",".shipping-done",".address p",".shipping-done p",".billingAddress p",".payment-done p",".review-container a.text-textDarkColor",".userPoints li",".order-confirmation li p[class*=\"md:leading-snug\"]",".order-confirmation p.leading-snug","header li.text-sm",".cart-page__shipping__country-text span",".cart-page-summary-box ul li:has(+ .ant-divider) span:nth-child(1)",".gift-card-container .payment-summary label+span","[value=\"Address\"] option",".replay-faux-dropdown span",".nameLabel","[value*=\"address\"]",".addressContainer p","div.checkoutLogin-wrapper:has(form#checkoutLoginForm) > div","button[data-testid=\"new-header-account-button\"] div span:first-of-type:not(.gc-hidden)",".my-account-overview .profile p",".my-account-overview .address-book address",".address-1",".credit-card-info",".credit-card-type",".credit-card-number",".expiration-date",".order-number",".order-total",".recipients",".quotes-content div div.whitespace-nowrap:nth-of-type(2)",".quotes-content div:not(.font-semibold) > div.text-left",".quotes-content div:not(.font-semibold) > div.text-center",".quotes-content div.font-bold > span span:nth-of-type(2)",".my-account-card span > a",".my-account-card > div > div > div > div > div:nth-of-type(3) > span:nth-of-type(2)",".my-account-card code",".my-account-card span.uppercase span",".my-account-card section div > div > div > div > p",".my-account-card p > span:nth-of-type(2)",".my-account-card p.font-normal",".my-account-card p.text-std-gray-500",".my-account-card a > h3",".my-account-card div > p:first-of-type",".my-account-card div > div.text-std-gray-500",".my-account-card div > span.font-bold","[id^=\"subscription-\"] span.flex-1",".my-account-card div.text-std-gray-500","[data-test-id=\"shipping-done\"] div:has(p~p)>p","[data-test-id=\"payment-done\"] div:has(p~p)>p","[data-test-id=\"checkout-review\"] p>a"]}]}],"encryptXHR":[{"pred":{"operator":"default"},"value":true}],"excludeRageCSS":[{"pred":{"operator":"default"},"rules":[{"pred":{"operator":"default"},"value":["img[src*=\"-navigation\"]"]}]}],"hashResourceURL":[{"pred":{"operator":"default"},"value":"https://ingest.quantummetric.com/resource-loader/guitarcenter"}],"hashUploadPercent":[{"pred":{"facet":"url","operator":"contains","value":"inst-listing"},"value":100},{"pred":{"operator":"default"},"value":10}],"horizonEnabled":[{"pred":{"operator":"default"},"value":true}],"ignoreElementCSSSerialization":[{"pred":{"operator":"default"},"rules":[{"pred":{"operator":"default"},"value":["link[href*=\"gcinc.my.site.com\"]"]}]}],"ingestBaseURL":[{"pred":{"operator":"default"},"value":"https://ingest.quantummetric.com"}],"logResourcePercent":[{"pred":{"operator":"default"},"value":5}],"maskSensitiveQueryParams":[{"pred":{"operator":"default"},"rules":[{"pred":{"operator":"default"},"value":["accountid","accountnumber","address","address1","address2","alias","authcode","authtoken","bankclearingcode","bankcountry","clientid","confirmation","confirmation-number","confirmationno","confirmationnumber","customer_id","customerid","dateofbirth","email","email_address","emailaddress","emailid","first_name","firstname","fname","gname","id","invoicenumber","last_name","lastname","location","login_hint","loginemail","loginhint","loginid","name","order","orderemail","orderid","orderno","ordernumber","ordertoken","passcode","password","password","phone","phone_number","phonenumber","po","postcode","referrerid","routingnumber","sname","ssn","state","surname","title","token","transactionid","transid","txtpassword","txtuserid","user","user-id","userid","username","utm_email","vin","cust_email","optid","trackEmail","quoteCode","latitude","longitude"]}]}],"maxMDELength":[{"pred":{"operator":"default"},"value":200000}],"reportFailedImages":[{"pred":{"operator":"default"},"value":true}],"reportURL":[{"pred":{"operator":"default"},"value":"https://ingest.quantummetric.com/horizon/guitarcenter"}],"spinnerSelectorList":[{"pred":{"operator":"default"},"rules":[{"pred":{"operator":"default"},"value":[]}]}],"temp":[{"pred":{"operator":"default"},"value":{"cleanAPIUrls":false,"enableKVS":true}}],"transformAttributesForNodesList":[{"pred":{"operator":"default"},"rules":[{"pred":{"operator":"default"},"value":[{"attr":"href","re":{"f":"","p":"^.+$"},"rep":"","sel":"a"}]}]}],"urlTransforms":[{"pred":{"operator":"default"},"rules":[{"pred":{"operator":"default"},"value":[{"re":{"f":"ig","p":"zipCode=[^&]+"},"rep":"zipCode=*****"},{"re":{"f":"ig","p":"\\.gc\\?.*"},"rep":".gc"},{"re":{"f":"ig","p":"\\/$"},"rep":""},{"re":{"f":"ig","p":"\\/\\?.*"},"rep":""}]}]}],"xhrErrorBlacklist":[{"pred":{"operator":"default"},"rules":[{"pred":{"operator":"default"},"value":[{"f":"i","p":"appdynamics"},{"f":"i","p":"aws-origin"},{"f":"i","p":"bam"},{"f":"i","p":"bam-cell"},{"f":"i","p":"cdnbasket"},{"f":"i","p":"cdnwidget"},{"f":"i","p":"chtbl"},{"f":"i","p":"clarity"},{"f":"i","p":"clearbit"},{"f":"i","p":"demdex"},{"f":"i","p":"doubleclick"},{"f":"i","p":"facebook"},{"f":"i","p":"google"},{"f":"i","p":"google-analytics"},{"f":"i","p":"hotjar"},{"f":"i","p":"instagram"},{"f":"i","p":"iperceptions"},{"f":"i","p":"litix"},{"f":"i","p":"omtrdc"},{"f":"i","p":"pinterest"},{"f":"i","p":"snowplowanalytics"},{"f":"i","p":"tealium"},{"f":"i","p":"tvpixel"},{"f":"i","p":"yimg"},{"f":"i","p":"px-cloud"},{"f":"i","p":"linkedin"},{"f":"i","p":"taboola"},{"f":"i","p":"adroll"}]}]}],"xhrHookBlackList":[{"pred":{"operator":"default"},"rules":[{"pred":{"operator":"default"},"value":[{"f":"i","p":"adroll"},{"f":"i","p":"googleadservices"},{"f":"i","p":"taboola"},{"f":"i","p":"qualtrics"},{"f":"i","p":"google\\.com"}]}]}],"xhrHookBlackListDetails":[{"pred":{"operator":"default"},"rules":[{"pred":{"operator":"default"},"value":[{"f":"i","p":"adroll"},{"f":"i","p":"googleadservices"},{"f":"i","p":"taboola"}]}]}],"xhrHookWhiteListDetails":[{"pred":{"operator":"default"},"rules":[{"pred":{"operator":"default"},"value":[{"f":"i","p":"([a-zA-Z0-9.-]+)\\.guitarcenter\\.com"},{"f":"i","p":"([a-zA-Z0-9.-]+)\\.musiciansfriend\\.com"},{"f":"i","p":".*rst\\.musicarts\\.com"},{"f":"i","p":"([a-zA-Z0-9.-]+)\\.recaptcha\\.net\\/recaptcha\\/api2\\/"},{"f":"i","p":"algolia\\.net"},{"f":"i","p":"([a-zA-Z0-9.-]+)\\.smartystreets\\.com"}]}]}],"xhrPerformanceWhitelistDetails":[{"pred":{"operator":"default"},"rules":[{"pred":{"operator":"default"},"value":[{"f":"i","p":"([a-zA-Z0-9.-]+)\\.guitarcenter\\.com"},{"f":"i","p":"([a-zA-Z0-9.-]+)\\.musiciansfriend\\.com"},{"f":"i","p":".*rst\\.musicarts\\.com"},{"f":"i","p":"([a-zA-Z0-9.-]+)\\.recaptcha\\.net\\/recaptcha\\/api2\\/"},{"f":"i","p":"algolia\\.net"},{"f":"i","p":"([a-zA-Z0-9.-]+)\\.smartystreets\\.com"}]}]}],"zones":[{"pred":{"operator":"default"},"rules":[{"pred":{"operator":"default"},"value":[]}]}],"eventDefinitions":{"events":[{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":true,"i":1,"f":0,"m":1,"s":2,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":14,"f":0,"m":0,"s":1,"u":".*","x":"QJS,QCC","v":{"t":"MAE","v":[1,0,{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {try {
  return (
    window.GCI &&
    window.GCI.digitalData &&
    window.GCI.digitalData.omnitureData &&
    window.GCI.digitalData.omnitureData.pageType.trim().indexOf("ategory") >
      0 &&
    !!window.GCI.digitalData.omnitureData.pageName
  );
} catch (err) {}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  return (
    window.GCI &&
    window.GCI.digitalData &&
    window.GCI.digitalData.omnitureData &&
    window.GCI.digitalData.omnitureData.pageName.trim()
  );
} catch (err) {}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var qPLP = {};
  var digitalData = window.GCI && window.GCI.digitalData;
  var siteVars = digitalData && digitalData.siteVars;
  var omnitureData = digitalData && digitalData.omnitureData;

  qPLP.pagination = siteVars && siteVars.pagination;
  qPLP.reportData = siteVars && siteVars.reportData;
  qPLP.selectFacets = siteVars && siteVars.selectFacets || siteVars && siteVars.siteVars && siteVars.siteVars.selectFacets;
  qPLP.omnitureData = {};
  qPLP.omnitureData.category = omnitureData && omnitureData.category;
  qPLP.omnitureData.countryName = omnitureData && omnitureData.countryName;
  qPLP.omnitureData.displayPerPage =
    omnitureData && omnitureData.displayPerPage;
  qPLP.omnitureData.listFilters = omnitureData && omnitureData.listFilters;
  qPLP.omnitureData.pageName = omnitureData && omnitureData.pageName;
  qPLP.omnitureData.pageType = omnitureData && omnitureData.pageType;
  qPLP.omnitureData.siteSection = omnitureData && omnitureData.siteSection;
  qPLP.omnitureData.sortByType = omnitureData && omnitureData.sortByType;
  qPLP.omnitureData.subCategory1 = omnitureData && omnitureData.subCategory1;
  var qSortBy = siteVars && siteVars.sortBy;
  if (qSortBy) {
   for (var i = 0; i < qSortBy.length; i++) {
    if (qSortBy[i].selected === true) {
      qPLP.sort_by = qSortBy[i].name;
      break;
    }
   }
  }
  return qPLP;
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError("14", err);
  }
}}}]}]},{"t":"MDE","v":[{"t":"SelectorPresent","v":[".plp-container.testing-template"]},{"t":"JSValueEx","v":[{"fn":function () {try {
  return (
    window.GCI &&
    window.GCI.digitalData &&
    window.GCI.digitalData.omnitureData &&
    window.GCI.digitalData.omnitureData.pageName.trim()
  );
} catch (err) {}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var qPLP = {};
  var digitalData = window.GCI && window.GCI.digitalData;
  var siteVars = digitalData && digitalData.siteVars;
  var omnitureData = digitalData && digitalData.omnitureData;

  qPLP.pagination = siteVars && siteVars.pagination;
  qPLP.reportData = siteVars && siteVars.reportData;
  qPLP.selectFacets = siteVars && siteVars.selectFacets || siteVars && siteVars.siteVars && siteVars.siteVars.selectFacets;
  qPLP.omnitureData = {};
  qPLP.omnitureData.category = omnitureData && omnitureData.category;
  qPLP.omnitureData.countryName = omnitureData && omnitureData.countryName;
  qPLP.omnitureData.displayPerPage =
    omnitureData && omnitureData.displayPerPage;
  qPLP.omnitureData.listFilters = omnitureData && omnitureData.listFilters;
  qPLP.omnitureData.pageName = omnitureData && omnitureData.pageName;
  qPLP.omnitureData.pageType = omnitureData && omnitureData.pageType;
  qPLP.omnitureData.siteSection = omnitureData && omnitureData.siteSection;
  qPLP.omnitureData.sortByType = omnitureData && omnitureData.sortByType;
  qPLP.omnitureData.subCategory1 = omnitureData && omnitureData.subCategory1;
  var qSortBy = siteVars && siteVars.sortBy;
  if (qSortBy) {
   for (var i = 0; i < qSortBy.length; i++) {
    if (qSortBy[i].selected === true) {
      qPLP.sort_by = qSortBy[i].name;
      break;
    }
   }
  }
  return qPLP;
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError("14", err);
  }
}}}]}]}]}},{"f":0,"i":15,"evalAlways":false,"m":1,"s":1,"u":".*","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]}]},"x":"QJS","sessionInfoReq":false,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":16,"f":0,"m":0,"s":1,"u":".*","x":"QCE","v":{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".product-item a,.product-card a,.product-item a *,.product-card a *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var lastClicked = window.QuantumMetricAPI && window.QuantumMetricAPI.lastClicked;
  if (!lastClicked) {
    return;
  }

  // 1. Identify Target Card Container (GC: .product-item, MF: .product-card)
  var qCard = lastClicked.closest('.product-item, .product-card');
  if (!qCard) {
    return;
  }

  var isMF = qCard.classList.contains('product-card');

  // Exclude non-product MF cards (e.g., Deal of the Day tiles) that lack a real title
  if (isMF && !qCard.querySelector('.product-card-title')) {
    return;
  }

  // 2. Resolve Product Name
  var productName = "N/A";
  if (isMF) {
    var titleEl = qCard.querySelector('.product-card-title');
    productName = titleEl ? titleEl.innerText.trim() : "N/A";
  } else {
    var heading = qCard.querySelector('h2');
    productName = heading ? heading.innerText.trim() : "N/A";
  }

  // 3. Resolve Product ID / SKU
  var productId = "N/A";
  var clickedAnchor = lastClicked.closest('a');
  if (clickedAnchor) {
    var href = clickedAnchor.getAttribute('href') || "";
    // GC: -123456789.gc  |  MF: /guitars/slug/m11728000001000 (id after final "/m")
    var match = href.match(/-([0-9]{13,15})\.gc/) || href.match(/\/m(\d+)(?:[/?#]|$)/);
    if (match && match[1]) {
      productId = match[1];
    }
  }

  // Fallback to card-level data attribute (GC only - MF cards carry no dataset)
  if (productId === "N/A" && qCard.dataset) {
    productId = qCard.dataset.productSkuId || "N/A";
  }

  // 4. Resolve Category
  var category = (window.GCI && window.GCI.digitalData && window.GCI.digitalData.omnitureData)
    ? window.GCI.digitalData.omnitureData.category
    : "N/A";

  var productObj = {
    productName: productName,
    productId: productId,
    category: category
  };

  // 5. Position Calculation
  var productPosition = 0;

  if (isMF) {
    var allMFProductCards = Array.prototype.slice.call(
      document.querySelectorAll('.product-card')
    ).filter(function(card) {
      return card.querySelector('.product-card-title');
    });

    var cardIndex = allMFProductCards.indexOf(qCard);
    if (cardIndex !== -1) {
      productPosition = cardIndex + 1;
    }
  } else {
    var parentSection = qCard.closest('[s-object-region]');
    if (parentSection) {
      var regionValue = parentSection.getAttribute('s-object-region');
      if (regionValue && regionValue.indexOf('product-item-') === 0) {
        productPosition = parseInt(regionValue.replace('product-item-', ''), 10) + 1;
      }
    }
  }

  // 6. Page Number Calculation
  var pageNumber = 1;
  try {
    var urlParams = new URLSearchParams(window.location.search);
    var pageParam = urlParams.get('page');
    if (pageParam) {
      pageNumber = parseInt(pageParam, 10);
    }
  } catch (urlErr) {}

  // 7. Construct Payload
  var returnObj = {
    pageName: window.location.pathname,
    pageType: (window.GCI && window.GCI.digitalData && window.GCI.digitalData.pageType) || "PLP",
    pageNumber: pageNumber,
    index: productPosition,
    products: [productObj]
  };

  var dataToStore = {
    pageNumber: pageNumber,
    index: productPosition
  };
  localStorage.setItem('QMclickedProductIndex', JSON.stringify(dataToStore));

  if (window.QuantumMetricAPI && window.QuantumMetricAPI.sendEvent) {
    window.QuantumMetricAPI.sendEvent(16, 0, productName, returnObj);
  }

  return productName;
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError("16", err);
  }
}}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":17,"f":0,"m":1,"s":1,"u":"/checkout/payment*","x":"QCE","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["[id='payPal'],[id='payPal'] *"]}]},{"t":"SelectorText","v":["[id='payPal']"]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":18,"f":0,"m":1,"s":1,"u":"musicarts\\.com","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"f":0,"i":19,"evalAlways":false,"m":1,"s":1,"u":".*","v":{"t":"MDE","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["\\/checkoutActor\\/processPaymentAndSubmitOrder-spa|\\/checkoutActor\\/commitOrderForSPA"]},{"t":"XFJPar","v":[]}]},"/orderState",{"t":"Is","v":["confirmation"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  return JSON.parse(this.api.lastXHR.qresponse).order.orderSubtotal.toFixed(2);
}
catch (err) {}}}]},{"t":"VXF","v":[{"t":"XHR","v":["\\/checkoutActor\\/processPaymentAndSubmitOrder-spa|\\/checkoutActor\\/commitOrderForSPA"]},{"t":"XFPK","v":[["qurl","url"],["qstatus","statusCode"]]},{"t":"XFMG","v":[{"t":"JSValueEx","v":[{"fn":function () {try {
  var obj = {};
  var sourceCode = localStorage.getItem('sourceCodeNameQM') || localStorage.getItem('src_code');
    
  obj.sourceCodeName = sourceCode;
  return obj;
}catch(err){}}}]}]}]}]},"x":"QXJ","sessionInfoReq":false,"excludeBlank":true},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":20,"f":0,"m":0,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {try {
  var QM_PDP_DETAIL_LOG = '[QM PDP Detail / Event 20]';

  // Helper function to get query parameter

  var getQueryParam = function(param) {
    var urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
  };
  
  // Helper function to detect gear type from DOM
  var getGearTypeFromDOM = function() {
    try {
      var gearTypeToggle = document.querySelector('.gear-type-toggle');
      if (!gearTypeToggle) {
        return null; // No gear type toggle on this page
      }
      
      // Find the button text to determine which option is displayed
      var buttonText = gearTypeToggle.querySelector('button span.text-std-gray-600');
      if (!buttonText) {
        return null;
      }
      
      var text = buttonText.innerText.trim().toLowerCase();
      
      // Check for "Demo Gear"
      if (text.indexOf('demo gear') !== -1) {
        return 'demoGear';
      }
      
      // Check for "New in box"
      if (text.indexOf('new in box') !== -1) {
        return 'new';
      }
      
      return null;
    } catch (e) {
      return null;
    }
  };
  
  // Helper function to get PFM value using the same logic as Adobe Launch utility
  var getPFMValue = function() {
    // Check for ICGTID
    if (getQueryParam('ICGTID')) {
      try {
        var storeId = getQueryParam('ICGTID') || '101';
        var searchTerm = getQueryParam('ICGTTerm') || '';
        var channel = getQueryParam('ICGTChannel') || '';
        
        return 'chatGPT:storeId:' + storeId + ':searchTerm:' + searchTerm + ':channel:' + channel;
      } catch (error) {
        console.error('Error processing ICGTID parameters:', error);
        return 'chatGPT:storeId:101:searchTerm::channel:';
      }
    }
    
    // Check for source param
    if (getQueryParam('source')) {
      return getQueryParam('source');
    }
    
    // Check for icid param
    if (getQueryParam('icid')) {
      return getQueryParam('icid');
    }
    
    // Check for pfm param
    if (getQueryParam('pfm')) {
      return getQueryParam('pfm');
    }
    
    // Check for searchFlag in localStorage
    if (sessionStorage.getItem('qm_wst_last_fired')) {
       var searchTerm = '';
      try {
        //searchTerm = _satellite.getVar('search:search term') || '';
       // var searchTermls = JSON.parse(window.localStorage.recentSearchValues);
		//searchTerm = searchTermls[0] || '';
        searchTerm = sessionStorage.getItem('qm_wst_last_fired');
      } catch (e) {
        searchTerm = '';
      }
      return 'internal search > ' + searchTerm;
    }
    
    // Check for external organic search
    if (document.referrer.match(/bing|google|duckduckgo|baidu|yandex|yahoo/i)) {
      return 'external organic search';
    }
    
    // Fallback to passPFM from localStorage
    if (window.localStorage.passPFM) {
      return window.localStorage.passPFM;
    }
    
    return null;
  };
  
  // Helper function to enhance product data with additional GC fields
  var enhanceGCProductData = function(productData, siteVars) {
    if (!productData || !siteVars) return productData;
    
    // Only add GC fields if this is GC data
    if (productData.siteId !== "5" && productData.siteId) return productData;
    
    // Detect initial gear type from DOM (Demo Gear vs New in box)
    var initialGearType = getGearTypeFromDOM();
    if (initialGearType) {
      productData.initialGearType = initialGearType;
    } else {

    }
    
    // PDPRightPrice fields
    if (siteVars.PDPRightPrice) {
      if (siteVars.PDPRightPrice.salePrice) {
        productData.salePrice = parseFloat(siteVars.PDPRightPrice.salePrice);
      }
      if (siteVars.PDPRightPrice.wasPrice) {
        productData.wasPrice = parseFloat(siteVars.PDPRightPrice.wasPrice);
      }
    }
    
    // PDPStyleSelector fields
    if (siteVars.PDPStyleSelector && siteVars.PDPStyleSelector.selectedStyle) {
      productData.selectedStyle = siteVars.PDPStyleSelector.selectedStyle;
    }
    
    // Financing fields
    if (siteVars.Financing && siteVars.Financing.financingTextContent) {
      productData.financingTextContent = siteVars.Financing.financingTextContent;
    }
    
    // OmnitureTagging fields
    if (siteVars.OmnitureTagging && siteVars.OmnitureTagging.products) {
      productData.products = siteVars.OmnitureTagging.products;
    }
    
    // PDPCTA fields (handle object and array shapes safely)
    if (siteVars.PDPCTA && siteVars.PDPCTA.CTAButtons) {
      var ctaButtons = siteVars.PDPCTA.CTAButtons;
      var ctaText = null;

      if (Array.isArray(ctaButtons) && ctaButtons.length && ctaButtons[0] && ctaButtons[0].text) {
        ctaText = ctaButtons[0].text;
      } else if (ctaButtons.Text) {
        ctaText = ctaButtons.Text;
      } else if (ctaButtons.text) {
        ctaText = ctaButtons.text;
      }

      if (ctaText) {
        productData.ctaButtonText = ctaText;
        productData.CTAButtonText = ctaText;
      }

      if (Array.isArray(ctaButtons)) {
        productData.PDPCTA = ctaButtons;
      }
    }
    
    // StoreAndDelivery fields
    if (siteVars.StoreAndDelivery && siteVars.StoreAndDelivery.shipToStore) {
      productData.shipToStore = siteVars.StoreAndDelivery.shipToStore;
    }

    // Product-level fallback fields (used heavily on MF)
    if (siteVars.product) {
      if (!productData.sticker && siteVars.product.sticker) {
        productData.sticker = siteVars.product.sticker;
      }
      if (!productData.styleSelected && siteVars.product.styleSelected) {
        productData.styleSelected = siteVars.product.styleSelected;
      }
      if (!productData.CTAButtonText && siteVars.product.CTAButtonText) {
        productData.CTAButtonText = siteVars.product.CTAButtonText;
      }
      if (!productData.ctaButtonText && siteVars.product.CTAButtonText) {
        productData.ctaButtonText = siteVars.product.CTAButtonText;
      }
    }
    // Display id fallback from PDPDetail when available
    if (siteVars.PDPDetail && siteVars.PDPDetail.id) {
      productData.displayId = siteVars.PDPDetail.id;
    }
      
  // StoreAndDelivery fields
    if (siteVars.PDPDetail && siteVars.PDPDetail.alertType) {
      productData.stockStatus = siteVars.PDPDetail.alertType;
    } else if (siteVars.product && siteVars.product.stock) {
      productData.stockStatus = siteVars.product.stock;
    }
    
    return productData;
  };
  
  // Helper function to send QM event
  var sendQMEvent = function(productData, source) {
    if (window._pdpDetailEvent20Sent) {
      return true;
    }

    if (!productData) {
      return false;
    }

    if (!productData.displayId && !productData.id) {
      return false;
    }

    if (!productData.displayId && productData.id) {
      productData.displayId = productData.id;
    }

    var pfm = getPFMValue();
    if (pfm) {
      productData.pfm = pfm;
    }

    // Getting QMclickedProductIndex from Web - PLP - Item Click event
    try {
      if (window.localStorage && window.localStorage.QMclickedProductIndex) {
        var raw = window.localStorage.QMclickedProductIndex;
        var parsed = JSON.parse(raw);

        if (parsed && typeof parsed === 'object') {
          productData.plpPosition = parsed;
        }
      }
    } catch (e) {
    }

    var productDataCopy = JSON.parse(JSON.stringify(productData));

    if (productDataCopy.catalogRefId && typeof productDataCopy.catalogRefId === 'string') {
      productDataCopy.catalogRefId = productDataCopy.catalogRefId.replace(/^site5/, '').replace(/^site1sku/, '');
    }

    var sourceCode = null;
    try {
      sourceCode = localStorage.getItem('sourceCodeNameQM') || localStorage.getItem('src_code');
    } catch (storageErr) {
    }

    productDataCopy.sourceCodeName = sourceCode;
    productDataCopy.sendEventLocation = 'Quantum';
    if (typeof(productDataCopy.sticker) === 'string') {
  	productDataCopy.sticker = [{ stickerName: productDataCopy.sticker, 			stickerLink: "N/A" }];
	}

    if (!window.QuantumMetricAPI || !window.QuantumMetricAPI.sendEvent) {
      return false;
    }

    try {
      window.QuantumMetricAPI.sendEvent(20, 0, productDataCopy.displayId, productDataCopy);
      window._pdpDetailEvent20Sent = true;
      return true;
    } catch (sendErr) {
      console.error(QM_PDP_DETAIL_LOG, 'sendEvent(20) error', {
        source: source,
        displayId: productDataCopy.displayId
      }, sendErr);
      if (window.handleQMError) {
        window.handleQMError('20-send', sendErr);
      }
      return false;
    }
  };

  var parseHiddenSiteVars = function() {
    if (window._pdpDetailHiddenSiteVars) {
      return window._pdpDetailHiddenSiteVars;
    }

    try {
      if (typeof document === 'undefined' || !document.querySelectorAll) {
        return null;
      }

      var hiddenSiteVarsNodes = document.querySelectorAll('div.siteVars, .siteVars');
      for (var i = 0; i < hiddenSiteVarsNodes.length; i++) {
        var node = hiddenSiteVarsNodes[i];
        var raw = node.textContent || node.innerHTML || '';
        raw = String(raw)
          .replace(/<!--[\s\S]*?-->/g, '')
          .trim();

        var jsonStart = raw.indexOf('{');
        var jsonEnd = raw.lastIndexOf('}');
        if (jsonStart === -1 || jsonEnd === -1 || jsonEnd <= jsonStart) {
          continue;
        }

        var jsonText = raw.substring(jsonStart, jsonEnd + 1);
        var parsed = JSON.parse(jsonText);
        if (parsed && typeof parsed === 'object' && (parsed.product || parsed.PDPDetail)) {
          try {
            Object.defineProperty(parsed, '_qmSiteVarsSource', {
              value: 'div.siteVars.hidden',
              enumerable: false
            });
          } catch (sourceErr) {
            parsed._qmSiteVarsSource = 'div.siteVars.hidden';
          }

          window._pdpDetailHiddenSiteVars = parsed;
          return parsed;
        }
      }
    } catch (hiddenErr) {
      console.error(QM_PDP_DETAIL_LOG, 'hidden siteVars parse failed', hiddenErr);
    }

    return null;
  };

  var getSiteVarsSource = function(siteVars) {
    if (!siteVars) {
      return 'none';
    }
    return siteVars._qmSiteVarsSource || 'window/dataLayer siteVars';
  };

  var getSiteVars = function() {
    var digitalData = window.GCI && window.GCI.digitalData;
    var ppcSiteVars = digitalData && digitalData.ppcSiteVars;
    var gcSiteVars = digitalData && digitalData.siteVars;
    var dataLayerSiteVars =
      window.dataLayer && window.dataLayer._state && window.dataLayer._state.siteVars;
    var hiddenSiteVars = parseHiddenSiteVars();

    if (ppcSiteVars && ppcSiteVars.PDPDetail) {
      return ppcSiteVars;
    }
    if (gcSiteVars && (gcSiteVars.PDPDetail || gcSiteVars.product)) {
      return gcSiteVars;
    }
    if (dataLayerSiteVars && (dataLayerSiteVars.PDPDetail || dataLayerSiteVars.product)) {
      return dataLayerSiteVars;
    }
    if (hiddenSiteVars && (hiddenSiteVars.PDPDetail || hiddenSiteVars.product)) {
      return hiddenSiteVars;
    }

    return ppcSiteVars || gcSiteVars || dataLayerSiteVars || hiddenSiteVars || null;
  };

  var getPdpDetailData = function() {
    var digitalData = window.GCI && window.GCI.digitalData;
    var ppcSiteVars = digitalData && digitalData.ppcSiteVars;
    var gcSiteVars = digitalData && digitalData.siteVars;
    var dataLayerSiteVars =
      window.dataLayer && window.dataLayer._state && window.dataLayer._state.siteVars;

    if (ppcSiteVars && ppcSiteVars.PDPDetail) {
      return {
        source: 'GCI.digitalData.ppcSiteVars.PDPDetail',
        data: ppcSiteVars.PDPDetail
      };
    }
    if (dataLayerSiteVars && dataLayerSiteVars.PDPDetail) {
      return {
        source: 'dataLayer._state.siteVars.PDPDetail',
        data: dataLayerSiteVars.PDPDetail
      };
    }
    if (gcSiteVars && gcSiteVars.PDPDetail) {
      return {
        source: 'GCI.digitalData.siteVars.PDPDetail',
        data: gcSiteVars.PDPDetail
      };
    }

    return {
      source: 'none',
      data: null
    };
  };

  var isPdpSiteVarsLoaded = function(eventData) {
    var eventName = eventData && (eventData.eventName || eventData.event);

    if (!eventData || eventName !== 'siteVarsLoaded') {
      return false;
    }
    if (eventData.pageLocation === 'pdp') {
      return true;
    }
    return !eventData.pageLocation &&
      !!(eventData.siteVars && (eventData.siteVars.PDPDetail || eventData.siteVars.product));
  };

  var isMfPdpReadySignal = function(eventData) {
    return !!(
      eventData &&
      eventData.event === 'mainCarouselFirstImage' &&
      eventData.siteVars &&
      eventData.siteVars.productImages
    );
  };

  var buildMfProductData = function(siteVars) {
    if (!siteVars || !siteVars.product) {
      return null;
    }

    var mfProduct = siteVars.product;
    var productDataMF = window.GCI &&
      window.GCI.digitalData &&
      window.GCI.digitalData.productData;

    var parsePrice = function(raw) {
      if (raw === null || typeof raw === 'undefined' || raw === '') return undefined;
      var parsed = parseFloat(String(raw).replace(/[^0-9.-]/g, ''));
      return isNaN(parsed) ? undefined : parsed;
    };

    var salePriceValue = parsePrice(mfProduct.price);
    var wasPriceValue = parsePrice(mfProduct.wasPrice);
    if (typeof wasPriceValue === 'undefined' && productDataMF && productDataMF.priceMax) {
      wasPriceValue = parsePrice(productDataMF.priceMax);
    }
    var priceDifference = (typeof wasPriceValue !== 'undefined' && typeof salePriceValue !== 'undefined')
      ? parseFloat((wasPriceValue - salePriceValue).toFixed(2))
      : undefined;

    var span = document.querySelector('#MSG_KEY_INV_MSG_BUY_TO_DEMAND');
    var stockStatusCopy = span ? span.textContent : '';

    return {
      displayId: mfProduct.sku_id,
      catalogRefId: mfProduct.sku_rep_id,
      productName: mfProduct.title || mfProduct.name,
      title: mfProduct.title || mfProduct.name,
      brandName: mfProduct.brand,
      salePrice: salePriceValue,
      wasPrice: wasPriceValue,
      priceDifference: priceDifference,
      sticker: mfProduct.sticker,
      CTAButtonText: mfProduct.CTAButtonText,
      ctaButtonText: mfProduct.CTAButtonText,
      styleSelected: mfProduct.styleSelected,
      reviewCount: mfProduct.reviewCount,
      Rating: mfProduct.Rating || mfProduct.rating,
      rating: mfProduct.rating || mfProduct.Rating,
      commerceType: mfProduct.commerceType,
      upcCode: mfProduct.upcCode,
      download: mfProduct.download,
      stockStatus: mfProduct.stock,
      stockStatusCopy: stockStatusCopy,
      checksum: mfProduct.checksum,
      siteId: '1'
    };
  };

  var sendFromSiteVars = function(siteVars, source) {
    if (!siteVars) {
      return false;
    }

    if (siteVars.PDPDetail) {
      try {
        var pdpData = siteVars.PDPDetail;
        var productDataCopy = JSON.parse(JSON.stringify(pdpData));

        productDataCopy = enhanceGCProductData(productDataCopy, siteVars);
        return sendQMEvent(productDataCopy, source + ':PDPDetail');
      } catch (pdpErr) {
        console.error(QM_PDP_DETAIL_LOG, source + ' PDPDetail error', pdpErr);
        return false;
      }
    }

    if (siteVars.product) {
      try {
        var mfProductData = buildMfProductData(siteVars);
        if (mfProductData && mfProductData.displayId) {
          mfProductData = enhanceGCProductData(mfProductData, siteVars);
          return sendQMEvent(mfProductData, source + ':siteVars.product');
        }
        return false;
      } catch (mfErr) {
        console.error(QM_PDP_DETAIL_LOG, source + ' MF product error', mfErr);
        return false;
      }
    }
    return false;
  };

  var handleReadySignal = function(eventData, source) {
    var eventSiteVars = eventData && eventData.siteVars;
    var pageSiteVars = getSiteVars();
    var usableSiteVars =
      (eventSiteVars && (eventSiteVars.PDPDetail || eventSiteVars.product) && eventSiteVars) ||
      (pageSiteVars && (pageSiteVars.PDPDetail || pageSiteVars.product) && pageSiteVars);

    return sendFromSiteVars(usableSiteVars, source);
  };

  var replayExistingDataLayerReadySignals = function() {
    if (!window.dataLayer || typeof window.dataLayer.forEach !== 'function') {
      return;
    }

    window.dataLayer.forEach(function(entry) {
      if (window._pdpDetailEvent20Sent) {
        return;
      }
      if (isPdpSiteVarsLoaded(entry) || isMfPdpReadySignal(entry)) {
        handleReadySignal(entry, 'dataLayer replay');
      }
    });
  };
  
  var pdpDetailLookup = getPdpDetailData();
  var productDataSource = pdpDetailLookup.source;
  var productData = pdpDetailLookup.data;

  // MF: Use product data directly with minimal transformation
  if (!productData) {
    var initialSiteVars = getSiteVars();
    productData = buildMfProductData(initialSiteVars);
    if (productData) {
      productDataSource = getSiteVarsSource(initialSiteVars) + '.product (immediate)';
    }
  }

  // If we have data immediately, fire the event
  var immediateSent = false;
  if (productData && (productData.displayId || productData.id)) {
    var siteVars = getSiteVars();

    productData = enhanceGCProductData(productData, siteVars);
    immediateSent = sendQMEvent(productData, 'immediate:' + productDataSource);
  }
  
  // If no data yet, set up listener to fire when dlUpdateEvent arrives
  if (!immediateSent && !window._pdpDetailListenerSet) {
    window._pdpDetailListenerSet = true;
    
    window.addEventListener('dlUpdateEvent', function(event) {
      var eventData = event.detail;

      if (isMfPdpReadySignal(eventData)) {
        handleReadySignal(eventData, 'dlUpdateEvent:mainCarouselFirstImage');
        return;
      }

      if (!isPdpSiteVarsLoaded(eventData)) {
        return;
      }

      handleReadySignal(eventData, 'dlUpdateEvent:siteVarsLoaded');
    });

    replayExistingDataLayerReadySignals();
  }
  
  return undefined;
  
} catch (err) {
  console.error('[QM PDP Detail / Event 20]', 'attributes script error', err);
  if (window.handleQMError) {
    window.handleQMError('20', err);
  }
  return undefined;
}}}]},{"t":"JSValue","v":[{"fn":function () {try {
    var productData =
      (window.GCI &&
        window.GCI.digitalData &&
        window.GCI.digitalData.ppcSiteVars &&
        window.GCI.digitalData.ppcSiteVars.PDPDetail) ||
      (window.dataLayer &&
        window.dataLayer._state &&
        window.dataLayer._state.siteVars &&
        window.dataLayer._state.siteVars.PDPDetail) ||
      (window.GCI &&
        window.GCI.digitalData &&
        window.GCI.digitalData.siteVars &&
        window.GCI.digitalData.siteVars.PDPDetail) ||
      (window.GCI &&
        window.GCI.digitalData &&
        window.GCI.digitalData.siteVars &&
        window.GCI.digitalData.siteVars.product);
    //mf display sku
	if (productData && productData.sku_id) {
		console.log('QM sku_idssssssssss', productData.sku_id);
       return true; 
    }
    if (productData && productData.id) {
        return productData.id;
    } 
}
catch (err) {
    if (window.handleQMError) {
      window.handleQMError('20', err);
    }
    return undefined;
  }
return undefined;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":21,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":22,"f":64,"m":1,"s":1,"u":".*","x":"QXJ","v":{"t":"E","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["cartRedesignNew"]},{"t":"XFJPar","v":[]}]},"/order/orderSubtotal"]},{"t":"CV","v":[{"t":"JSValueEx","v":[{"fn":function () {try {
  return JSON.parse(this.api.lastXHR.qresponse).order.orderSubtotal.toFixed(2);
}
catch (err){}}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":25,"f":64,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {try {
  var MINI_CART_DEBOUNCE_MS = 300;
  var miniCartDebounceTimer = null;

  var buildPayload = function(miniCartData) {
    if (!miniCartData) {
      return null;
    }
    var cartItems = miniCartData.cartItems;
    if (!cartItems || !Array.isArray(cartItems) || cartItems.length === 0) {
      return null;
    }
    var itemCount = miniCartData.itemCount;
    if (itemCount === null || typeof itemCount === 'undefined') {
      itemCount = miniCartData.lineCount;
    }
    
    return {
      itemCount: itemCount,
      subtotal: miniCartData.subtotal,
      cartItems: cartItems,
      sendEventLocation: 'QM'
    };
  };

  var fireQMEvent = function(miniCartData) {
    if (!window.QuantumMetricAPI || !window.QuantumMetricAPI.sendEvent) {
      return false;
    }
    var payload = buildPayload(miniCartData);
    if (!payload) {
      return false;
    }
    var subtotalCents = '0';
    var subtotal = parseFloat(payload.subtotal);
    if (!isNaN(subtotal) && subtotal > 0) {
      subtotalCents = Math.round(subtotal * 100).toString();
    }
    try {
      window.QuantumMetricAPI.sendEvent(25, 0, subtotalCents, payload);
      return true;
    } catch (err) {
      if (window.handleQMError) {
        window.handleQMError('25', err);
      }
      return false;
    }
  };

  var scheduleMiniCartQMEvent = function(miniCartData) {
    if (miniCartDebounceTimer) {
      clearTimeout(miniCartDebounceTimer);
    }
    miniCartDebounceTimer = setTimeout(function() {
      miniCartDebounceTimer = null;
      fireQMEvent(miniCartData);
    }, MINI_CART_DEBOUNCE_MS);
  };

  var getMiniCartDataFromEvent = function(eventData) {
    if (!eventData) {
      return null;
    }
    if (eventData.miniCartData) {
      return eventData.miniCartData;
    }
    if (
      window.dataLayer &&
      window.dataLayer._state &&
      window.dataLayer._state.miniCartDisplayed &&
      window.dataLayer._state.miniCartDisplayed.miniCartData
    ) {
      return window.dataLayer._state.miniCartDisplayed.miniCartData;
    }
    return null;
  };

  if (!window._miniCartQMListenerSet) {
    window._miniCartQMListenerSet = true;
    window.addEventListener('dlUpdateEvent', function(event) {
      var eventData = event.detail || event;
      var eventName = eventData && (eventData.eventName || eventData.event);
      if (eventName !== 'miniCartDisplayed') {
        return;
      }
      var miniCartData = getMiniCartDataFromEvent(eventData);
      if (miniCartData) {
        scheduleMiniCartQMEvent(miniCartData);
      }
    });
  }

  return false;
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError('25', err);
  }
  return false;
}}}]},{"t":"CV","v":[{"t":"V","v":[""]}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":26,"f":6,"m":0,"s":0,"u":".*","x":"QXJ","v":{"t":"E","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["login"]},{"t":"XFJPar","v":[]}]},"/statusMessage",{"t":"Is","v":["success"]}]},{"t":"ObjPathValue","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["login"]},{"t":"XFJPar","v":[]}]},"/profile/email"]}]}},{"f":6,"i":27,"evalAlways":false,"m":0,"s":0,"u":".*","v":{"t":"MDE","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["headerUserInfo"]},{"t":"XFJPar","v":[]}]},"/user/email"]},{"t":"ObjPathValue","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["headerUserInfo"]},{"t":"XFJPar","v":[]}]},"/user/email"]},{"t":"VXF","v":[{"t":"XHR","v":["headerUserInfo"]},{"t":"XFPK","v":[["qurl","url"],["qstatus","statusCode"]]},{"t":"XFMG","v":[{"t":"JSValueEx","v":[{"fn":function () {return {};}}]}]}]}]},"x":"QXJ","sessionInfoReq":false,"excludeBlank":true},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":28,"f":0,"m":0,"s":1,"u":".*","x":"QXJ,QOP,QOP","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["guitarcenter"]},{"t":"XFJPar","v":[]}]},"/user/loginStatus"]},{"t":"ObjPathValue","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["guitarcenter"]},{"t":"XFJPar","v":[]}]},"/user/loginStatus"]}]},{"t":"E","v":[{"t":"ObjPath","v":[{"t":"WV","v":[]},"/dataLayer/_state/userLoginStatus/isLoggedIn"]},{"t":"JSValueEx","v":[{"fn":function () {try {
  return window.dataLayer._state.userLoginStatus.isLoggedIn.toString();
}
catch (err){}}}]}]},{"t":"E","v":[{"t":"ObjPath","v":[{"t":"WV","v":[]},"/GCI/digitalData/pageData/cookieLoggedIn"]},{"t":"JSValueEx","v":[{"fn":function () {try {
  return window.GCI.digitalData.pageData.cookieLoggedIn.toString();
}
catch (err){}}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":29,"f":64,"m":1,"s":1,"u":".*","x":"QXJ","v":{"t":"MDE","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["moveToPurchaseInfo"]},{"t":"XFJPar","v":[]}]},"/statusMessage",{"t":"Is","v":["success"]}]},{"t":"CV","v":[{"t":"JSValueEx","v":[{"fn":function () {try {
  return JSON.parse(this.api.lastXHR.qresponse).order.orderTotalFinal.toFixed(2);
}
catch (err) {}}}]}]},{"t":"VXF","v":[{"t":"XHR","v":["moveToPurchaseInfo"]},{"t":"XFPK","v":[["qurl","url"],["qstatus","statusCode"]]},{"t":"XFMG","v":[{"t":"JSValueEx","v":[{"fn":function () {return {};}}]}]}]}]}},{"f":0,"i":30,"evalAlways":false,"m":1,"s":1,"u":".*","v":{"t":"E","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["\\/checkoutActor\\/processPaymentAndSubmitOrder-spa|\\/checkoutActor\\/commitOrderForSPA"]},{"t":"XFJPar","v":[]}]},"/statusMessage",{"t":"Is","v":["failure"]}]},{"t":"ObjPathValue","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["\\/checkoutActor\\/processPaymentAndSubmitOrder-spa|\\/checkoutActor\\/commitOrderForSPA"]},{"t":"XFJPar","v":[]}]},"/formExceptions/0/localizedMessage"]}]},"x":"QXJ","sessionInfoReq":false,"excludeBlank":false},{"f":0,"i":31,"evalAlways":false,"m":1,"s":2,"u":".*","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRRequest","v":["\\/checkoutActor\\/commitOrderForSPA"]},{"t":"XFJPar","v":[]}]},"/orderId"]},{"t":"ObjPathValue","v":[{"t":"VXF","v":[{"t":"XHRRequest","v":["\\/checkoutActor\\/commitOrderForSPA"]},{"t":"XFJPar","v":[]}]},"/orderId"]}]},{"t":"E","v":[{"t":"ObjSearch","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["\\/checkoutActor\\/processPaymentAndSubmitOrder-spa"]},{"t":"XFJPar","v":[]}]},"/ListId"]},{"t":"ObjPathValue","v":[{"t":"VXF","v":[{"t":"XHRRequest","v":["\\/checkoutActor\\/processPaymentAndSubmitOrder-spa"]},{"t":"XFJPar","v":[]}]},"/ListId"]}]},{"t":"E","v":[{"t":"ObjSearch","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["\\/checkoutActor\\/processPaymentAndSubmitOrder-spa"]},{"t":"XFJPar","v":[]}]},"/order/id"]},{"t":"ObjPathValue","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["\\/checkoutActor\\/processPaymentAndSubmitOrder-spa"]},{"t":"XFJPar","v":[]}]},"/order/id"]}]}]},"x":"QXJ,QXJ,QXJ","sessionInfoReq":true,"excludeBlank":true},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":32,"f":0,"m":1,"s":1,"u":".*","x":"QXJ","v":{"t":"MDE","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["guitarcenter\\.com"]},{"t":"XFJPar","v":[]}]},"/alertMessage"]},{"t":"ObjPathValue","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["guitarcenter\\.com"]},{"t":"XFJPar","v":[]}]},"/alertMessage"]},{"t":"VXF","v":[{"t":"XHR","v":["guitarcenter\\.com"]},{"t":"XFPK","v":[["qurl","url"],["qstatus","statusCode"]]},{"t":"XFMG","v":[{"t":"JSValueEx","v":[{"fn":function () {return {};}}]}]}]}]}},{"f":0,"i":33,"evalAlways":false,"m":1,"s":1,"u":".*","v":{"t":"MDE","v":[{"t":"ObjSearch","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["guitarcenter\\.com"]},{"t":"XFJPar","v":[]}]},"/pageName"]},{"t":"ObjSearchValue","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["guitarcenter\\.com"]},{"t":"XFJPar","v":[]}]},"/pageName"]},{"t":"VXF","v":[{"t":"XHR","v":["guitarcenter\\.com"]},{"t":"XFPK","v":[["qurl","url"],["qstatus","statusCode"]]},{"t":"XFMG","v":[{"t":"JSValueEx","v":[{"fn":function () {return {};}}]}]}]}]},"x":"QXJ","sessionInfoReq":false,"excludeBlank":false},{"f":0,"i":34,"evalAlways":false,"m":0,"s":1,"u":".*","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {try {
  // Helper function to normalize page types
  var normalizePageType = function (pageType) {
    if (!pageType) {
      return undefined;
    }

    var plpPageTypes = [
      "product collection",
      "store inventory",
      "brand",
      "vintage",
      "outlet",
      "platinum",
      "used",
      "sub category1",
      "sub category2",
      "sub category3",
      "sub category4",
      "sub category5",
    ];

    var pageTypeLower = pageType.toLowerCase();

    if (plpPageTypes.indexOf(pageTypeLower) !== -1) {
      return "product listing page";
    }

    return pageType;
  };

  // Helper function to build event data and send event
  var buildAndSendPageTypeEvent = function (omnitureData) {
    if (!omnitureData || !omnitureData.pageType) {
      return false;
    }

    var pageType = omnitureData.pageType;

    // Sanitize pageType by trimming whitespace
    if (pageType && typeof pageType === "string") {
      pageType = pageType.trim();
    }

    var normalizedPageType = normalizePageType(pageType);
    if (!normalizedPageType) {
      return false;
    }

    // Build event data with lowercase values
    var eventData = {
      pageType: normalizedPageType.toLowerCase(),
      sendEventLocation: "Quantum",
    };

    // Add category data for PLP and PDP pages
    if (
      normalizedPageType === "product listing page" ||
      normalizedPageType === "product detail page" ||
      normalizedPageType === "product details listing page"
    ) {
      if (omnitureData.category) {
        eventData.category = omnitureData.category.toLowerCase();
      }

      if (
        normalizedPageType === "product listing page" ||
        normalizedPageType === "product details listing page" ||
        normalizedPageType === "product detail page"
      ) {
        var lastSubCategoryIndex = 0;

        // Check for direct subCategory fields (MF structure)
        // If no direct subCategories found, check for category1-5 fields (GC structure)
        for (var i = 1; i <= 5; i++) {
          var categoryKey = "category" + i;
          var subCategoryKey = "subCategory" + i;
          if (omnitureData[subCategoryKey]) {
            eventData[subCategoryKey] =
              omnitureData[subCategoryKey].toLowerCase();
            lastSubCategoryIndex = i;
          } else if (omnitureData[categoryKey]) {
            eventData[subCategoryKey] = omnitureData[categoryKey].toLowerCase();
            lastSubCategoryIndex = i;
          }
        }

        if (omnitureData.categoryType) {
          eventData.categoryType = omnitureData.categoryType.toLowerCase();
        } else if (lastSubCategoryIndex > 0) {
          eventData.categoryType = "sub category" + lastSubCategoryIndex;
        }
      }
    }

    // Brand, product collection, daily pick: categoryType mirrors omniture pageType
    var pageTypeForCategory = pageType && String(pageType).trim().toLowerCase();
    if (
      pageTypeForCategory === "brand" ||
      pageTypeForCategory === "product collection" ||
      pageTypeForCategory === "daily pick"
    ) {
      eventData.categoryType = pageTypeForCategory;
    }

    // Send the event
    window.QuantumMetricAPI.sendEvent(34, 0, normalizedPageType, eventData);
    if (window._pageTypeListenerSet) {
      window.removeEventListener("dlUpdateEvent", function (event) {
        var eventData = event.detail;
        if (
          eventData &&
          eventData.eventName === "omnitureLoaded" &&
          eventData.omnitureData
        ) {
          buildAndSendPageTypeEvent(eventData.omnitureData);
        }
      });
    }
  };

  // Try to get omniture data from normal locations
  var omnitureData =
    (window.GCI &&
      window.GCI.digitalData &&
      window.GCI.digitalData.omnitureData) ||
    (window.dataLayer &&
      window.dataLayer._state &&
      window.dataLayer._state.omnitureLoaded &&
      window.dataLayer._state.omnitureLoaded.omnitureData);

  // If we have data immediately, send the event
  if (omnitureData && omnitureData.pageType) {
    buildAndSendPageTypeEvent(omnitureData);
    return undefined;
  }

  // If no data yet, set up listener for omnitureLoaded event
  if (!window._pageTypeListenerSet) {
    window._pageTypeListenerSet = true;

    window.addEventListener("dlUpdateEvent", function (event) {
      var eventData = event.detail;

      // Check if this is the omnitureLoaded event
      if (
        eventData &&
        eventData.eventName === "omnitureLoaded" &&
        eventData.omnitureData
      ) {
        buildAndSendPageTypeEvent(eventData.omnitureData);
      }
    });
  }

  return undefined;
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError("34", err);
  }
  return undefined;
}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  // Helper function to normalize page types
  var normalizePageType = function (pageType) {
    if (!pageType) {
      return undefined;
    }

    var plpPageTypes = [
      "product collection",
      "store inventory",
      "brand",
      "vintage",
      "outlet",
      "platinum",
      "used",
      "sub category1",
      "sub category2",
      "sub category3",
      "sub category4",
      "sub category5",
    ];

    var pageTypeLower = pageType.toLowerCase();

    if (plpPageTypes.indexOf(pageTypeLower) !== -1) {
      return "product listing page";
    }

    return pageType;
  };

  // Helper function to build event data and send event
  var buildAndSendPageTypeEvent = function (omnitureData) {
    if (!omnitureData || !omnitureData.pageType) {
      return false;
    }

    var pageType = omnitureData.pageType;

    // Sanitize pageType by trimming whitespace
    if (pageType && typeof pageType === "string") {
      pageType = pageType.trim();
    }

    var normalizedPageType = normalizePageType(pageType);
    if (!normalizedPageType) {
      return false;
    }

    // Build event data with lowercase values
    var eventData = {
      pageType: normalizedPageType.toLowerCase(),
      sendEventLocation: "Quantum",
    };

    // Add category data for PLP and PDP pages
    // console.log(
    //   "[QM Page Type Debug] Normalized page type:",
    //   normalizedPageType
    // );
    // console.log(
    //   "[QM Page Type Debug] OmnitureData:",
    //   JSON.stringify(omnitureData, null, 2)
    // );

    if (
      normalizedPageType === "product listing page" ||
      normalizedPageType === "product detail page" ||
      normalizedPageType === "product details listing page"
    ) {
      // console.log(
      //   "[QM Page Type Debug] Entering category data section for:",
      //   normalizedPageType
      // );

      if (omnitureData.category) {
        eventData.category = omnitureData.category.toLowerCase();
        // console.log(
        //   "[QM Page Type Debug] Added main category:",
        //   eventData.category
        // );
      } else {
        // console.log(
        //   "[QM Page Type Debug] No main category found in omnitureData"
        // );
      }

      if (
        normalizedPageType === "product listing page" ||
        normalizedPageType === "product details listing page" ||
        normalizedPageType === "product detail page"
      ) {
        // console.log(
        //   "[QM Page Type Debug] Processing subcategories for:",
        //   normalizedPageType
        // );
        var lastSubCategoryIndex = 0;

        // Check for direct subCategory fields (MF structure)
        // If no direct subCategories found, check for category1-4 fields (GC structure)
        for (var i = 1; i <= 5; i++) {
          var categoryKey = "category" + i;
          var subCategoryKey = "subCategory" + i;
          if (omnitureData[subCategoryKey]) {
            eventData[subCategoryKey] =
              omnitureData[subCategoryKey].toLowerCase();
            // console.log(
            //   "[QM Page Type Debug] Added",
            //   subCategoryKey + ":",
            //   eventData[subCategoryKey]
            // );
          } else if (omnitureData[categoryKey]) {
            eventData[subCategoryKey] = omnitureData[categoryKey].toLowerCase();
            // console.log(
            //   "[QM Page Type Debug] Added",
            //   subCategoryKey,
            //   "from",
            //   categoryKey + ":",
            //   eventData[subCategoryKey]
            // );
          }
          lastSubCategoryIndex = i;
        }

        if (omnitureData.categoryType) {
          eventData.categoryType = omnitureData.categoryType.toLowerCase();
          // console.log(
          //   "[QM Page Type Debug] Added categoryType from omnitureData:",
          //   eventData.categoryType
          // );
        } else if (lastSubCategoryIndex > 0) {
          eventData.categoryType = "sub category" + lastSubCategoryIndex;
          // console.log(
          //   "[QM Page Type Debug] Added derived categoryType:",
          //   eventData.categoryType
          // );
        }
      } else {
        // console.log(
        //   "[QM Page Type Debug] SKIPPING subcategories - page type is:",
        //   normalizedPageType
        // );
        // console.log(
        //   '[QM Page Type Debug] Subcategories only processed for "product listing page", "product details listing page", or "product detail page"'
        // );
      }
    }

    // Send the event
    // console.log(
    //   "[QM Page Type Debug] Final eventData being sent:",
    //   JSON.stringify(eventData, null, 2)
    // );
    window.QuantumMetricAPI.sendEvent(34, 0, normalizedPageType, eventData);
    if (window._pageTypeListenerSet) {
      window.removeEventListener("dlUpdateEvent", function (event) {
        var eventData = event.detail;
        if (
          eventData &&
          eventData.eventName === "omnitureLoaded" &&
          eventData.omnitureData
        ) {
          buildAndSendPageTypeEvent(eventData.omnitureData);
        }
      });
    }
  };

  // Try to get omniture data from normal locations
  var omnitureData =
    (window.GCI &&
      window.GCI.digitalData &&
      window.GCI.digitalData.omnitureData) ||
    (window.dataLayer &&
      window.dataLayer._state &&
      window.dataLayer._state.omnitureLoaded &&
      window.dataLayer._state.omnitureLoaded.omnitureData);

  // If we have data immediately, send the event
  if (omnitureData && omnitureData.pageType) {
    buildAndSendPageTypeEvent(omnitureData);
    return undefined;
  }

  // If no data yet, set up listener for omnitureLoaded event
  if (!window._pageTypeListenerSet) {
    window._pageTypeListenerSet = true;

    window.addEventListener("dlUpdateEvent", function (event) {
      var eventData = event.detail;

      // Check if this is the omnitureLoaded event
      if (
        eventData &&
        eventData.eventName === "omnitureLoaded" &&
        eventData.omnitureData
      ) {
        buildAndSendPageTypeEvent(eventData.omnitureData);
      }
    });
  }

  return undefined;
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError("34", err);
  }
  return undefined;
}}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]},"x":"QJS","sessionInfoReq":false,"excludeBlank":true},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":36,"f":0,"m":0,"s":1,"u":".*","x":"QJS,QJS,QJS","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
  var raw = window.dataLayer._state.loadedFromSearch.searchValue;
  if (!raw){
    return false;
  } 

  var searchValue = String(raw).trim().toLowerCase();
  var lastFired = sessionStorage.getItem('qm_wst_last_fired');

  if (lastFired === searchValue) {
    return false; // same search, refinement/pagination; don't refire
  }

  window.QuantumMetricAPI.sendEvent(36, 0, raw); // send original casing if you want it in reports
  sessionStorage.setItem('qm_wst_last_fired', searchValue);
  return raw;
} catch (err) {
  return false;
}}}]},{"t":"V","v":[""]}]},{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
  return window.localStorage.qmSearchFlag === 'true';
} catch (err) {
  return false;
}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var searchValue = window.GCI.digitalData.omnitureData.searchTerm;
  window.localStorage.removeItem('qmSearchFlag');
  return searchValue;
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError('34', err);
  }
}}}]}]},{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
  var navigation = window.performance.getEntriesByType('navigation')[0];
  var isBackNavigation = navigation && navigation.type === 'back_forward';
  if (!isBackNavigation) {
    var searchTerm = window.GCI.digitalData.omnitureData.searchTerm.toLowerCase();
    sessionStorage.setItem('qm_wst_last_fired', searchTerm);
    return window.GCI.digitalData.omnitureData.searchTerm.toLowerCase();
  }
} catch (err) {

}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var navigation = window.performance.getEntriesByType('navigation')[0];
  var isBackNavigation = navigation && navigation.type === 'back_forward';
  
  if (!isBackNavigation) {
    return window.GCI.digitalData.omnitureData.searchTerm.toLowerCase();
  }
} catch (err) {

}}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":37,"f":0,"m":0,"s":1,"u":".*","x":"QCC,QCC,QOP,QJS","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"SelectorPresent","v":["div.no-result-message"]},{"t":"SelectorText","v":["div.no-result-message > h4"]}]},{"t":"E","v":[{"t":"SelectorPresent","v":[".plp-no-result-content.plp-title h2"]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var recentSearches = JSON.parse(localStorage.getItem('recentSearchValues'));

  if (Array.isArray(recentSearches) && recentSearches.length > 0) {
    return recentSearches[0];
  }

  return '';
} catch (e) {
  return '';
}}}]}]},{"t":"E","v":[{"t":"ObjPath","v":[{"t":"WV","v":[]},"/dataLayer/_state/pageType",{"t":"Is","v":["searchNoResultsPlp"]}]},{"t":"V","v":[""]}]},{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
  if (
    window.dataLayer &&
    window.dataLayer._state &&
    window.dataLayer._state.loadedFromSearch &&
    window.dataLayer._state.loadedFromSearch.searchValue
  ) {
    var searchValue = String(window.dataLayer._state.loadedFromSearch.searchValue).trim().toLowerCase();
    if (!searchValue) {
		return false;
    }
    var seenTerm = sessionStorage.getItem('qm_null_term_seen');
    if (seenTerm === searchValue) {
      return false;
    }

    sessionStorage.setItem('qm_null_term_seen', searchValue);

    var hasNoResultContainer = document.querySelector('.no-result-message .no-result');
    var hasAlgoliaGallery = document.querySelector('.algolia-plp-product-gallery');
    if (hasNoResultContainer && !hasAlgoliaGallery) {
      return true;
    }
  }
  return false;
} catch (e) {
  console.error('[QM Null Search] Error:', e);
  if (window && typeof window.handleQMError === 'function') {
    window.handleQMError('Null Search', e);
  }
  return false;
}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var obj = {};
  var searchTerm = window.dataLayer._state.loadedFromSearch.searchValue.toLowerCase();
  obj.searchTerm = searchTerm;
  obj.searchType = "Internal";
  
  window.QuantumMetricAPI.sendEvent(154, 0, searchTerm);
	return searchTerm;
 
} catch (err) {
  return err;
}}}]}]}]}},{"f":0,"i":40,"evalAlways":false,"m":0,"s":1,"u":".*","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {false;}}]},{"t":"V","v":[""]}]},"x":"QJS","sessionInfoReq":false,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":41,"f":0,"m":0,"s":1,"u":"/checkout","x":"QOP","v":{"t":"E","v":[{"t":"ObjPath","v":[{"t":"WV","v":[]},"/dataLayer/_state/eventName",{"t":"Is","v":["userSignUp"]}]},{"t":"V","v":[""]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":true,"i":45,"f":0,"m":0,"s":2,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
   var camStack =
      (window.localStorage && window.localStorage.getItem('src_stacked_campaigns')) || 'N/A';
    return camStack;
  } catch (err) {
    if (window.handleQMError) {
      window.handleQMError('45', err);
    }
  }}}]},{"t":"JSValue","v":[{"fn":function () {try {
   var camStack =
      (window.localStorage && window.localStorage.getItem('src_stacked_campaigns')) || 'N/A';
    return camStack;
  } catch (err) {
    if (window.handleQMError) {
      window.handleQMError('45', err);
    }
  }}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":47,"f":1,"m":0,"s":1,"u":"\\/checkout\\/(confirmation|order-confirmation)|musicarts\\.com\\/orderConfirmation\\/confirmation","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {try {
  var isOrderConfirmationPage = function() {
    var href = window.location.href;
    var isGC = href.indexOf('guitarcenter') > -1;
    // GC: /checkout/order-confirmation
    if (isGC) {
      return href.indexOf('/checkout/order-confirmation') !== -1 ||
        window.location.pathname.indexOf('/order-confirmation') !== -1;
    }
    // MF: /checkout/confirmation (Music Arts, etc.)
    return href.indexOf('/checkout/confirmation') !== -1;
  };

  var parseSubtotal = function(rawSubtotal) {
    if (rawSubtotal === null || typeof rawSubtotal === 'undefined') {
      return null;
    }
    if (rawSubtotal && typeof rawSubtotal === 'object' && rawSubtotal.c && Array.isArray(rawSubtotal.c)) {
      return parseFloat(parseFloat(rawSubtotal.c[0] + '.' + rawSubtotal.c[1]).toFixed(2));
    }
    return parseFloat(parseFloat(rawSubtotal).toFixed(2));
  };

  var getData = function() {
    if (!isOrderConfirmationPage()) {
      return null;
    }

    var order = null;
    // MF + GC: order on confirmation is in GCI.digitalData.siteVars after cookieLoaded
    if (window.GCI && window.GCI.digitalData && window.GCI.digitalData.siteVars && window.GCI.digitalData.siteVars.id) {
      order = window.GCI.digitalData.siteVars;
    // GC only: fallback if siteVars not set yet
    } else if (window.dataLayer && window.dataLayer._state && window.dataLayer._state.checkoutStepChanged && window.dataLayer._state.checkoutStepChanged.order) {
      order = window.dataLayer._state.checkoutStepChanged.order;
    }

    if (!order || !order.id) {
      return null;
    }

    try {
      // MF: subtotal on siteVars (may be BigDecimal { c: [...] } — handled in parseSubtotal)
      if (window.GCI && window.GCI.digitalData && window.GCI.digitalData.siteVars &&
          typeof window.GCI.digitalData.siteVars.subtotal !== 'undefined') {
        order.subtotal = parseSubtotal(window.GCI.digitalData.siteVars.subtotal);
      } else if (typeof order.subtotal !== 'undefined') {
        order.subtotal = parseSubtotal(order.subtotal);
      }
    } catch (subtotalErr) {
      if (window.handleQMError) {
        window.handleQMError('47-quantum-subtotal', subtotalErr);
      }
    }

    var subtotal = 0;
    var orderValueInCents = '0';
    try {
      if (typeof order.subtotal !== 'undefined' && order.subtotal !== null) {
        subtotal = parseSubtotal(order.subtotal);
      }
      if (!isNaN(subtotal) && subtotal > 0) {
        orderValueInCents = Math.round(subtotal * 100).toString();
      }
    } catch (subtotalError) {
      if (window.handleQMError) {
        window.handleQMError('47-quantum-primary', subtotalError);
      }
    }

    return {
      order: order,
      orderValueInCents: orderValueInCents
    };
  };

  var buildOrderAttributes = function(order) {
    var orderAttributes = JSON.parse(JSON.stringify(order));
    var isGC = window.location.hostname.indexOf('guitarcenter') > -1;
    var directSourceCode = isGC ? 'GCDIRECTSOURCECODE1' : 'DIRECTSOURCECODE2';
    var resolvedSourceCode = null;

    try {
      var srcCode = localStorage.getItem('src_code');
      var existingQM = localStorage.getItem('sourceCodeNameQM');
      var directCodes = ['GCDIRECTSOURCECODE1', 'DIRECTSOURCECODE2'];
      var srcIsValid = srcCode && directCodes.indexOf(srcCode) === -1;
      var qmIsDirect = existingQM && directCodes.indexOf(existingQM) !== -1;

      if (!existingQM || existingQM === '') {
        if (srcCode && srcCode !== '') {
          localStorage.setItem('sourceCodeNameQM', srcCode);
          resolvedSourceCode = srcCode;
        } else {
          resolvedSourceCode = directSourceCode;
        }
      } else if (srcIsValid && qmIsDirect) {
        localStorage.setItem('sourceCodeNameQM', srcCode);
        resolvedSourceCode = srcCode;
      } else {
        resolvedSourceCode = existingQM;
      }

      if (!resolvedSourceCode || resolvedSourceCode === '') {
        resolvedSourceCode = localStorage.getItem('sourceCodeNameQM') || localStorage.getItem('src_code') || directSourceCode;
      }
      localStorage.removeItem('src_code');
      localStorage.removeItem('src_code_timestamp');
    } catch (e) {
      resolvedSourceCode = directSourceCode;
    }

    // GC: parsed when QM Helper is loaded; MF: raw source code (no QM Helper)
    if (window._qmParseSourceCode) {
      orderAttributes.sourceCodeName = window._qmParseSourceCode(resolvedSourceCode);
    } else {
      orderAttributes.sourceCodeName = resolvedSourceCode;
    }
    orderAttributes.sendEventLocation = 'QM';

    try {
      orderAttributes.shippingMethod = (window.GCI && window.GCI.digitalData && window.GCI.digitalData.omnitureData && window.GCI.digitalData.omnitureData.shippingMethod) || '';
    } catch (e) {
      orderAttributes.shippingMethod = '';
    }

    var totalUnits = 0;
    if (orderAttributes.commerceItems && Array.isArray(orderAttributes.commerceItems)) {
      orderAttributes.commerceItems.forEach(function(item) {
        totalUnits += item.quantity;
      });
    }
    orderAttributes.totalUnits = totalUnits;
    if (orderAttributes.payment) {
      orderAttributes.payment = '';
    }
    if (orderAttributes.shipping) {
      orderAttributes.shipping = '';
    }
    if (orderAttributes.emailAddress) {
      orderAttributes.emailAddress = '';
    }

    return orderAttributes;
  };

  var fireQMEvent = function(data) {
    if (!window.QuantumMetricAPI || !window.QuantumMetricAPI.sendEvent) {
      return false;
    }

    var hasLocalStorage = false;
    try {
      var testLS = '__storage_test__';
      localStorage.setItem(testLS, testLS);
      localStorage.removeItem(testLS);
      hasLocalStorage = true;
    } catch (err) {}

    if (hasLocalStorage && localStorage.getItem('qmOrderId') === data.order.id) {
      return true;
    }

    try {
      var orderAttributes = buildOrderAttributes(data.order);
      window.QuantumMetricAPI.sendEvent(47, 0, data.orderValueInCents, orderAttributes);
      if (hasLocalStorage) {
        localStorage.setItem('qmOrderId', data.order.id);
      }
      return true;
    } catch (err) {
      if (window.handleQMError) {
        window.handleQMError('47-quantum-send', err);
      }
      return false;
    }
  };

  var tryFire = function() {
    var data = getData();
    if (data) {
      fireQMEvent(data);
    }
  };

  var data = getData();
  if (data) {
    fireQMEvent(data);
    return false;
  }

  if (!window._orderConfirmationQMListenerSet) {
    window._orderConfirmationQMListenerSet = true;
    window.addEventListener('dlUpdateEvent', function(event) {
      var eventData = event.detail || event;
      // MF: cookieLoaded after siteVars has order; GC: checkoutStepChanged or cookieLoaded
      if (eventData &&
          (eventData.eventName === 'checkoutStepChanged' ||
           eventData.eventName === 'cookieLoaded')) {
        setTimeout(tryFire, 100);
      }
    });
  }

  return false;
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError('47-quantum-order-view', err);
  }
  return false;
}}}]},{"t":"CV","v":[{"t":"V","v":[""]}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"f":0,"i":48,"evalAlways":false,"m":0,"s":1,"u":"/cart","v":{"t":"HE","v":[]},"x":"QHE","sessionInfoReq":false,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":49,"f":0,"m":1,"s":1,"u":".*","x":"QXJ,QJS","v":{"t":"MAE","v":[1,0,{"t":"MDE","v":[{"t":"ObjSearch","v":[{"t":"VXF","v":[{"t":"XHRRequest","v":["\\/removeItemFromOrder"]},{"t":"XFJPar","v":[]}]},"/fromPage"]},{"t":"ObjPathValue","v":[{"t":"VXF","v":[{"t":"XHRRequest","v":["\\/removeItemFromOrder"]},{"t":"XFJPar","v":[]}]},"/fromPage"]},{"t":"VXF","v":[{"t":"XHR","v":["\\/removeItemFromOrder"]},{"t":"XFPK","v":[["qurl","url"],["qstatus","statusCode"]]},{"t":"XFMG","v":[{"t":"JSValueEx","v":[{"fn":function () {try {
    var state = window.dataLayer && window.dataLayer._state;
    if (!state || !state.removeItemDetail) 
    {
		return null;
    }
    var detail = state.removeItemDetail;

    return {
      item_id: detail.item_id || '',
      item_name: detail.item_name || '',
      price: (typeof detail.price === 'number') ? detail.price : null,
      quantity: (typeof detail.quantity === 'number') ? detail.quantity : null,
      discount: (typeof detail.discount === 'number') ? detail.discount : 0
    };
  } catch (e) {
    return null;
  }}}]}]}]}]},{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {//MF Cart Removal (ETO-2678)
try {
  var QM_EVENT_ID_MF_REMOVE_FROM_CART = 49; 

  if (window.qmMfRemoveFromCartListenerInitialized) {
    return false;
  }
  window.qmMfRemoveFromCartListenerInitialized = true;

  var sendToQM = function (primaryValue, attributes) {
    try {
      if (window.QuantumMetricAPI && typeof window.QuantumMetricAPI.sendEvent === 'function') {
        window.QuantumMetricAPI.sendEvent(QM_EVENT_ID_MF_REMOVE_FROM_CART, 0, String(primaryValue), attributes);
      }
    } catch (err) {
      if (window.handleQMError) {
        window.handleQMError('mf-remove-from-cart-qm', err);
      }
    }
  };

  var processDetail = function (detail) {
    if (!detail || !detail.removeFromCart) {
      return;
    }

    var item = detail.removeFromCart;

    var attributes = {
      price: item.price,
      item_name: item.productName,
      quantity: item.quantity,
      item_id: item.sku
    };

    sendToQM(item.sku || item.productName, attributes);
  };

  window.dataLayer = window.dataLayer || [];
  var originalPush = window.dataLayer.push;

  window.dataLayer.push = function () {
    var result = originalPush.apply(window.dataLayer, arguments);

    for (var i = 0; i < arguments.length; i++) {
      try {
        var pushedObj = arguments[i];
        if (pushedObj && (pushedObj.event === 'removeFromCart' || pushedObj.eventName === 'removeFromCart')) {
          processDetail(pushedObj);
        }
      } catch (pushErr) {
        if (window.handleQMError) {
          window.handleQMError('mf-remove-from-cart-qm-push', pushErr);
        }
      }
    }

    return result;
  };

  // NEW: MF does a full page reload on remove — the push already happened on the
  // previous page and is gone. Check dataLayer._state once on this fresh load,
  // since _state persists the last removeFromCart value across the reload.
  if (window.dataLayer && window.dataLayer._state && window.dataLayer._state.removeFromCart) {
    processDetail(window.dataLayer._state);
  }

  return false;
} catch (e) {
  if (window.handleQMError) {
    window.handleQMError('mf-remove-from-cart-qm-init', e);
  }
  return false;
}}}]},{"t":"V","v":[""]},{"t":"JSValue","v":[{"fn":function () {}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":50,"f":0,"m":0,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]}]}},{"f":0,"i":53,"evalAlways":false,"m":1,"s":1,"u":".*","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".PDPCTA-wrapper button[type=\"submit\"],.PDPCTA-wrapper button[type=\"submit\"] *"]}]},{"t":"SelectorText","v":["h1"]}]},"x":"QCE","sessionInfoReq":false,"excludeBlank":false},{"f":0,"i":54,"evalAlways":false,"m":0,"s":1,"u":"\\/cart","v":{"t":"HE","v":[]},"x":"QHE","sessionInfoReq":false,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":55,"f":0,"m":1,"s":1,"u":".*","x":"QCE","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".cart-summary button[type=\"submit\"]:not(#applyCoupon):not(#updateLocation),.cart-summary button[type=\"submit\"]:not(#applyCoupon):not(#updateLocation) *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try { return (this.api || QuantumMetricAPI).lastClicked ? (this.api || QuantumMetricAPI).lastClicked.innerText : ""; } catch (e) {}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":56,"f":0,"m":0,"s":1,"u":"\\/checkout\\/shipping","x":"QHE","v":{"t":"HE","v":[]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":57,"f":0,"m":0,"s":1,"u":"\\/checkout\\/payment","x":"QHE","v":{"t":"HE","v":[]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":58,"f":0,"m":1,"s":1,"u":".*","x":"QCE","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["#completeMyOrder,#completeMyOrder *"]}]},{"t":"V","v":[""]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":59,"f":0,"m":0,"s":1,"u":"\\/checkout\\/order-confirmation|\\/orderConfirmation\\/confirmation","x":"QHE","v":{"t":"HE","v":[]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":60,"f":0,"m":0,"s":0,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"V","v":[""]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":61,"f":0,"m":0,"s":0,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
  return !!navigator.language;
}
catch (err) {}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  return navigator.language.toLowerCase();
}
catch (err) {}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":62,"f":0,"m":0,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]}]}},{"f":0,"i":63,"evalAlways":false,"m":0,"s":1,"u":".*","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"SelectorText","v":[".sitemap-hero"]},{"t":"Contains","v":["page doesn't exist"]}]},{"t":"SelectorText","v":[".sitemap-hero h1"]}]},"x":"QPC","sessionInfoReq":false,"excludeBlank":false},{"f":0,"i":65,"evalAlways":false,"m":1,"s":2,"u":".*","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]},"x":"QJS","sessionInfoReq":true,"excludeBlank":false},{"f":0,"i":66,"evalAlways":false,"m":0,"s":1,"u":".*","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"URLPropValue","v":[{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/location/href"]},"origin"]},{"t":"Is","v":[true]}]},{"t":"URLPropValue","v":[{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/location/href"]},"origin"]}]},"x":"QUR","sessionInfoReq":false,"excludeBlank":false},{"f":0,"i":70,"evalAlways":false,"m":0,"s":1,"u":".*","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"ObjPath","v":[{"t":"WV","v":[]},"/dataLayer/_state/eventName",{"t":"Is","v":["userSignUp"]}]},{"t":"V","v":[""]}]},{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["form#newCustomer #newCustomerSubmit,form#newCustomer #newCustomerSubmit *"]}]},{"t":"V","v":[""]}]},{"t":"E","v":[{"t":"ObjPath","v":[{"t":"WV","v":[]},"/GCI/digitalData/omnitureData/events",{"t":"StrCmp","v":[1,"accountCreate"]}]},{"t":"V","v":[""]}]},{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
  if (!window.accountCreateListenerSet) {
      window.accountCreateListenerSet = true;

      window.addEventListener('dlUpdateEvent', function(event) {
        var eventData = event.detail;

        // Check if this is the ppcMonetateCampaign event
        if (eventData && eventData.eventName === 'userSignUp') {
          // Store the variant value globally for future data element calls
          var accountCreate = eventData.userSignUp || 
                       (window.dataLayer && 
                        window.dataLayer._state && 
                        window.dataLayer._state.userSignUp);
                        console.log('[QM Account Create] accountCreate:', accountCreate);
          QuantumMetricAPI.sendEvent(70);
          if (accountCreate) {
            window.accountCreate = accountCreate;
          }
        }
      });
    }
}
catch(err) {
  if (window.handleQMError) {
        window.handleQMError('20', err);
      }
}}}]},{"t":"V","v":[""]}]},{"t":"E","v":[{"t":"JSValue","v":["window.addEventListener('dlUpdateEvent', function (event) {\n  var detail = event && event.detail;\n  if (!detail) { return false; }\n\n  // Handle userSignUp event\n  if (detail.eventName === \"userSignUp\" &&\n      detail.userSignUp &&\n      detail.userSignUp.signUpPayload) {\n\n    return true;  // or run your code here\n  }\n\n  return false;\n});\n"]},{"t":"V","v":[""]}]}]},"x":"QOP,QCE,QOP,QJS,QJS","sessionInfoReq":false,"excludeBlank":false},{"f":0,"i":74,"evalAlways":false,"m":0,"s":1,"u":".*","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]},"x":"QJS","sessionInfoReq":false,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":76,"f":0,"m":0,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {//This event configuration is in "Web - Custom Page View - Helper" event 
return undefined;}}]},{"t":"V","v":[""]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":77,"f":0,"m":0,"s":1,"u":".*","x":"QCE,QCE","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["#start-live-chat,#couponMsgChatClick,.pdp-help a~button,a[class*=\"chat-btn\"],li.chat-icon,li.chat-icon div,li.chat-icon a,li.chat-icon span,#start-live-chat *,#couponMsgChatClick *,.pdp-help a~button *,a[class*=\"chat-btn\"] *,li.chat-icon *,li.chat-icon div *,li.chat-icon a *,li.chat-icon span *"]}]},{"t":"V","v":[""]}]},{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"KeyValue","v":["value","Chat Now"]}]},{"t":"V","v":[""]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":78,"f":0,"m":0,"s":1,"u":".*","x":"QUR","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"URLParamsValue","v":[{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/location/href"]},"source"]},{"t":"Exists","v":[]}]},{"t":"URLParamsValue","v":[{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/location/href"]},"source"]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":79,"f":0,"m":1,"s":1,"u":".*","x":"QXJ,QXJ,QJS","v":{"t":"MAE","v":[1,0,{"t":"MDE","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRRequest","v":["\\/addItemToOrder"]},{"t":"XFJPar","v":[]}]},"/addItemCount"]},{"t":"ObjPathValue","v":[{"t":"VXF","v":[{"t":"XHRRequest","v":["\\/addItemToOrder"]},{"t":"XFJPar","v":[]}]},"/addItemCount"]},{"t":"VXF","v":[{"t":"XHR","v":["\\/addItemToOrder"]},{"t":"XFPK","v":[["qurl","url"],["qstatus","statusCode"]]},{"t":"XFMG","v":[{"t":"JSValueEx","v":[{"fn":function () {// QM Event 79 attributes — runs on QM-captured addItemToOrder XHR (this.api.lastXHR).
// Monetate rec ATC fires Event 79 from Web - Monetate Cart Additions Helper.js.

var QM_CART_ADDITIONS_LOG = '[QM Cart Additions / Event 79]';

try {
  var hasQmApiContext =
    this &&
    this.api &&
    this.api.lastXHR &&
    this.api.lastXHR.qrequest;

  if (!hasQmApiContext) {
    return null;
  }

  /** Object returned to Quantum Metric (schema fields + cart lines). */
  var quantumEventPayload = {
    items: []
  };
  var passFromMarketing = '';
  var addToCartLocation = '';
  /** Parsed JSON body of the add-to-cart XHR (addItemToOrder). */
  var addToCartRequest;

  try {
    addToCartRequest = JSON.parse(this.api.lastXHR.qrequest);
    if (addToCartRequest && addToCartRequest.pfm) {
      passFromMarketing = addToCartRequest.pfm;
    }
    if (addToCartRequest && addToCartRequest.ATCLocation) {
      addToCartLocation = addToCartRequest.ATCLocation;
    }
  } catch (parseRequestErr) {
    console.error(
      QM_CART_ADDITIONS_LOG,
      'failed to parse qrequest JSON',
      parseRequestErr
    );
  }

  if (!passFromMarketing) {
    passFromMarketing = localStorage.getItem('passPFM');
  }

  var xhrLineItems;
  try {
    xhrLineItems = JSON.parse(this.api.lastXHR.qrequest).items;
  } catch (parseItemsErr) {
    console.error(
      QM_CART_ADDITIONS_LOG,
      'failed to read items from qrequest',
      parseItemsErr
    );
    return null;
  }

  if (!xhrLineItems || !xhrLineItems.length) {
    return null;
  }

  function stripCommerceIdPrefix(id) {
    if (id == null) {
      return '';
    }
    return String(id).replace(/^site5/i, '');
  }

  xhrLineItems.forEach(function (lineItem) {
    var workingItem = Object.assign({}, lineItem);

    if (workingItem.catalogRefId) {
      workingItem.catalogRefId = stripCommerceIdPrefix(workingItem.catalogRefId);
    }
    if (workingItem.productId) {
      workingItem.productId = stripCommerceIdPrefix(workingItem.productId);
    }

    quantumEventPayload.items.push(workingItem);
  });

  quantumEventPayload.pfm = passFromMarketing;
  quantumEventPayload.ATCLocation = addToCartLocation;

  // --- PDP enrichment: XHR lines often omit unit price, product name, or quantity ---

  function readGcSiteVarsFromPage() {
    var digitalData = window.GCI && window.GCI.digitalData;
    var ppcSiteVars = digitalData && digitalData.ppcSiteVars;
    var gcSiteVars = digitalData && digitalData.siteVars;
    var dataLayerSiteVars =
      window.dataLayer && window.dataLayer._state && window.dataLayer._state.siteVars;
    return ppcSiteVars || gcSiteVars || dataLayerSiteVars || null;
  }

  function parseSalePriceFromPdp(siteVars) {
    if (!siteVars || !siteVars.PDPRightPrice) {
      return null;
    }
    var rawSalePrice = siteVars.PDPRightPrice.salePrice;
    if (rawSalePrice === undefined || rawSalePrice === null) {
      return null;
    }
    var numeric = parseFloat(String(rawSalePrice).replace(/,/g, ''));
    return isNaN(numeric) ? null : numeric;
  }

  function cartLineMatchesPdpProduct(cartLineItem, pdpDetail) {
    if (!pdpDetail) {
      return true;
    }
    var lineCatalogRef = stripCommerceIdPrefix(cartLineItem.catalogRefId);
    var lineProductId = stripCommerceIdPrefix(cartLineItem.productId);
    var pdpCatalogRef = stripCommerceIdPrefix(pdpDetail.catalogRefId);
    var pdpProductId = stripCommerceIdPrefix(pdpDetail.productId);
    var pdpDisplayId = String(pdpDetail.id || '');
    if (pdpCatalogRef && (lineCatalogRef === pdpCatalogRef || lineProductId === pdpCatalogRef)) {
      return true;
    }
    if (pdpProductId && (lineCatalogRef === pdpProductId || lineProductId === pdpProductId)) {
      return true;
    }
    if (pdpDisplayId && (lineCatalogRef === pdpDisplayId || lineProductId === pdpDisplayId)) {
      return true;
    }
    return false;
  }

  function cartLineHasDisplayName(cartLineItem) {
    var fromProductName = cartLineItem.productName && String(cartLineItem.productName).trim();
    var fromItemName = cartLineItem.itemName && String(cartLineItem.itemName).trim();
    return !!(fromProductName || fromItemName);
  }

  function productTitleFromPdpDetail(pdpDetail) {
    if (!pdpDetail) {
      return '';
    }
    var raw = pdpDetail.productName || pdpDetail.title || '';
    return String(raw).trim();
  }

  function mergePdpFieldsOntoCartLines(cartLineItems, addToCartRequestBody) {
    var siteVars = readGcSiteVarsFromPage();
    if (!siteVars || !cartLineItems || !cartLineItems.length) {
      return cartLineItems;
    }

    var pdpDetail = siteVars.PDPDetail;
    var salePriceFromPdp = parseSalePriceFromPdp(siteVars);
    var productTitleFromPdp = productTitleFromPdpDetail(pdpDetail);

    var quantityFallback = 1;
    if (
      addToCartRequestBody &&
      addToCartRequestBody.addItemCount != null &&
      addToCartRequestBody.addItemCount !== ''
    ) {
      var parsedAddItemCount = Number(addToCartRequestBody.addItemCount);
      if (!isNaN(parsedAddItemCount) && parsedAddItemCount > 0) {
        quantityFallback = parsedAddItemCount;
      }
    }

    cartLineItems.forEach(function (cartLineItem) {
      if (pdpDetail && !cartLineMatchesPdpProduct(cartLineItem, pdpDetail)) {
        return;
      }

      var quantityFromLine = Number(cartLineItem.quantity);
      if (isNaN(quantityFromLine) || quantityFromLine <= 0) {
        cartLineItem.quantity = quantityFallback;
      }

      var unitPriceFromLine = Number(cartLineItem.price);
      if (salePriceFromPdp != null && (isNaN(unitPriceFromLine) || unitPriceFromLine <= 0)) {
        cartLineItem.price = salePriceFromPdp;
      }

      if (productTitleFromPdp && !cartLineHasDisplayName(cartLineItem)) {
        cartLineItem.itemName = productTitleFromPdp;
      }
    });

    return cartLineItems;
  }

  function resolveApiResponseStatus(lastXhr) {
    if (!lastXhr) {
      return 'Success';
    }

    var statusCode = lastXhr.qstatus != null ? lastXhr.qstatus : lastXhr.status;
    if (statusCode != null && statusCode !== '') {
      var numericStatus = Number(statusCode);
      if (!isNaN(numericStatus)) {
        return numericStatus >= 200 && numericStatus < 300 ? 'Success' : 'Failure';
      }
    }

    return 'Success';
  }

  function buildQmSchemaLineItem(cartLineItem) {
    var displayId =
      cartLineItem.catalogRefId || cartLineItem.sku || '';

    var itemName = String(cartLineItem.itemName || '').trim();

    var quantity = Number(cartLineItem.quantity);
    if (isNaN(quantity) || quantity <= 0) {
      quantity = 1;
    }

    var price = Number(cartLineItem.price);
    if (isNaN(price)) {
      price = 0;
    }

    var schemaItem = {
      itemName: itemName,
      price: price,
      quantity: quantity,
      displayId: String(displayId)
    };

    if (cartLineItem.recSetId != null && cartLineItem.recSetId !== '') {
      schemaItem.recSetId = String(cartLineItem.recSetId);
    }
    if (cartLineItem.slotIndex != null && cartLineItem.slotIndex !== '') {
      schemaItem.slotIndex = String(cartLineItem.slotIndex);
    }

    return schemaItem;
  }

  mergePdpFieldsOntoCartLines(quantumEventPayload.items, addToCartRequest);

  var qmEventPayload = {
    ATCLocation: addToCartLocation || '',
    pfm: passFromMarketing || null,
    apiResponseStatus: resolveApiResponseStatus(this.api.lastXHR),
    items: quantumEventPayload.items.map(buildQmSchemaLineItem)
  };

  if (
    window.dataLayer &&
    window.dataLayer._state &&
    window.dataLayer._state.userChangeDemoGearType &&
    window.dataLayer._state.userChangeDemoGearType.gearType
  ) {
    qmEventPayload.gearType =
      window.dataLayer._state.userChangeDemoGearType.gearType;
  }

  try {
    if (window.dataLayer && qmEventPayload.items && qmEventPayload.items.length) {
      window.dataLayer.push({
        event: 'cartAdditions',
        cartAdditions: Object.assign(
          {
            pfm: qmEventPayload.pfm,
            ATCLocation: qmEventPayload.ATCLocation,
            apiResponseStatus: qmEventPayload.apiResponseStatus,
            source: 'quantumMetric',
            items: qmEventPayload.items
          },
          qmEventPayload.gearType ? { gearType: qmEventPayload.gearType } : {}
        )
      });
    }
  } catch (dataLayerPushErr) {
    console.error(
      QM_CART_ADDITIONS_LOG,
      'dataLayer push failed',
      dataLayerPushErr
    );
  }

  return qmEventPayload;
} catch (err) {
  console.error(QM_CART_ADDITIONS_LOG, 'attributes script error', err);
  if (window.handleQMError) {
    window.handleQMError('79', err);
  }
  return null;
}}}]}]}]}]},{"t":"MDE","v":[{"t":"ObjSearch","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["\\/responsive\\/ajax\\/addToCart\\.jsp"]},{"t":"XFJPar","v":[]}]},"/success",{"t":"Is","v":["true"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var quantityEl = document.querySelector('select[data-js="product-action-quantity"]');
  var quantityFromDom = quantityEl ? Number(quantityEl.value) : null;

  if (!isNaN(quantityFromDom) && quantityFromDom > 0) {
    return quantityFromDom;
  }

  var digitalData = window.GCI && window.GCI.digitalData;
  var siteVars = digitalData && digitalData.siteVars;
  var product =
    (siteVars && siteVars.product) ||
    (digitalData && digitalData.product) ||
    (digitalData && digitalData.pageData && digitalData.pageData.product) ||
    {};

  var quantityFromProduct = Number(product.quantity);
  if (!isNaN(quantityFromProduct) && quantityFromProduct > 0) {
    return quantityFromProduct;
  }

  return 1;
} catch (err) {
  console.error('[QM MF Cart Additions / Event 79]', 'primary value error', err);
  return 1;
}}}]},{"t":"VXF","v":[{"t":"XHR","v":["\\/responsive\\/ajax\\/addToCart\\.jsp"]},{"t":"XFPK","v":[["qurl","url"],["qstatus","statusCode"]]},{"t":"XFMG","v":[{"t":"JSValueEx","v":[{"fn":function () {try {
  var QM_MF_CART_ADDITIONS_LOG = '[QM MF Cart Additions / Event 79]';

  var lastXhr = this && this.api && this.api.lastXHR;
  var qurl = lastXhr && (lastXhr.qurl || lastXhr.url);

  function resolveApiResponseStatus(xhr) {
    if (!xhr) {
      return 'Success';
    }

    var statusCode = xhr.qstatus != null ? xhr.qstatus : xhr.status;
    if (statusCode != null && statusCode !== '') {
      var numericStatus = Number(statusCode);
      if (!isNaN(numericStatus)) {
        return numericStatus >= 200 && numericStatus < 300 ? 'Success' : 'Failure';
      }
    }

    return 'Success';
  }

  function stripCommerceIdPrefix(id) {
    if (id == null) {
      return '';
    }
    return String(id).replace(/^site\d+(sku|prod)?/i, '');
  }

  function parsePositiveNumber(value, fallback) {
    var parsed = Number(value);
    return !isNaN(parsed) && parsed > 0 ? parsed : fallback;
  }

  function firstValue() {
    for (var i = 0; i < arguments.length; i++) {
      if (arguments[i] !== null && typeof arguments[i] !== 'undefined' && arguments[i] !== '') {
        return arguments[i];
      }
    }
    return '';
  }

  function hasProductData(productData) {
    return !!(
      productData &&
      typeof productData === 'object' &&
      (
        productData.price ||
        productData.wasPrice ||
        productData.sku_id ||
        productData.sku_rep_id ||
        productData.title ||
        productData.name ||
        productData.id
      )
    );
  }

  function resolveProductData() {
    var candidates = [
      digitalData && digitalData.product,
      siteVars && siteVars.product,
      digitalData && digitalData.pageData && digitalData.pageData.product
    ];

    for (var i = 0; i < candidates.length; i++) {
      if (hasProductData(candidates[i])) {
        return candidates[i];
      }
    }

    return {};
  }

  var digitalData = window.GCI && window.GCI.digitalData;
  var siteVars =
    digitalData &&
    digitalData.siteVars;
  var omnitureData =
    digitalData &&
    digitalData.omnitureData;
  var product = resolveProductData();

  var quantityEl = document.querySelector('select[data-js="product-action-quantity"]');
  var quantityFromDom = quantityEl ? parseInt(quantityEl.value, 10) : null;

  var productDisplayId = firstValue(
    product.sku_id,
    product.sku,
    product.selectedSku,
    product.selectedSerialSku,
    product.sku_rep_id,
    product.catalogRefId,
    product.productId,
    product.rep_id,
    product.urlProductId,
    product.displayId,
    product.id
  );

  var displayId = stripCommerceIdPrefix(productDisplayId);

  var itemName = firstValue(
    (omnitureData && omnitureData.pageName) ||
      '',
    product.name,
    product.productName,
    product.displayName,
    product.title
  );

  var price = parsePositiveNumber(
    firstValue(
      product.price,
      product.wasPrice,
      product.salePrice,
      product.sale,
      product.listPrice,
      product.regularPrice
    ),
    0
  );

  var quantity = parsePositiveNumber(
    firstValue(
      quantityFromDom,
      product.quantity
    ),
    1
  );

  var passFromMarketing = '';
  try {
    passFromMarketing = localStorage.getItem('passPFM') || '';
  } catch (pfmErr) {
    passFromMarketing = '';
  }

  var qmEventPayload = {
    ATCLocation: '',
    pfm: passFromMarketing || null,
    apiResponseStatus: resolveApiResponseStatus(lastXhr),
    items: [
      {
        price: price,
        quantity: quantity,
        displayId: String(displayId || ''),
        itemName: String(itemName || '')
      }
    ]
  };

  console.log(QM_MF_CART_ADDITIONS_LOG, 'script executed', {
    hasApiContext: !!(this && this.api),
    hasLastXHR: !!lastXhr,
    qurl: qurl,
    qstatus: lastXhr && (lastXhr.qstatus || lastXhr.status),
    qrequest: lastXhr && lastXhr.qrequest,
    qresponse: lastXhr && lastXhr.qresponse
  });

  console.log(QM_MF_CART_ADDITIONS_LOG, 'resolved request data', {
    hasGCI: !!window.GCI,
    hasDigitalData: !!digitalData,
    hasSiteVars: !!siteVars,
    hasOmnitureData: !!omnitureData,
    omniturePageName: omnitureData && omnitureData.pageName,
    hasProduct: !!product,
    product: product || null
  });

  console.log(QM_MF_CART_ADDITIONS_LOG, 'returning payload', qmEventPayload);

  return qmEventPayload;
} catch (e) {
  console.error('[QM MF Cart Additions / Event 79]', 'error building payload', e);
  return {
    ATCLocation: '',
    pfm: null,
    apiResponseStatus: 'Failure',
    items: [
      {
        price: 0,
        quantity: 1,
        displayId: '',
        itemName: ''
      }
    ]
  };
}}}]}]}]}]},{"t":"MDE","v":[{"t":"JSValue","v":["try {\n  (function () {\n    if (window.__qmMfCartAdditionsInstalled) {\n      return;\n    }\n\n    window.__qmMfCartAdditionsInstalled = true;\n\n    function getParam(url, key) {\n      var match = url.match(new RegExp('[?&]' + key + '=([^&]*)'));\n      return match ? decodeURIComponent(match[1]) : '';\n    }\n\n    function cleanSku(value) {\n      return value ? String(value).replace('site1sku', '') : '';\n    }\n\n    function parsePrice(value) {\n      var parsed = parseFloat(String(value || '').replace(/[^0-9.]/g, ''));\n      return isNaN(parsed) ? null : parsed;\n    }\n\n    function getGciProductBySku(skuId) {\n      var products =\n        window.GCI &&\n        window.GCI.digitalData &&\n        window.GCI.digitalData.siteVars &&\n        window.GCI.digitalData.siteVars.product;\n\n      if (!products) {\n        return null;\n      }\n\n      for (var key in products) {\n        if (products.hasOwnProperty(key)) {\n          var product = products[key];\n\n          if (\n            product &&\n            (\n              product.sku_id === skuId ||\n              product.sku_rep_id === 'site1sku' + skuId\n            )\n          ) {\n            return product;\n          }\n        }\n      }\n\n      return null;\n    }\n\n    var originalOpen = XMLHttpRequest.prototype.open;\n    var originalSend = XMLHttpRequest.prototype.send;\n\n    XMLHttpRequest.prototype.open = function (method, url) {\n      this.__qmMfAtcUrl = url;\n      return originalOpen.apply(this, arguments);\n    };\n\n    XMLHttpRequest.prototype.send = function () {\n      this.addEventListener('load', function () {\n        try {\n          var url = this.__qmMfAtcUrl || '';\n\n          if (\n            this.status === 200 &&\n            url.indexOf('/responsive/ajax/addToCart.jsp') > -1 &&\n            url.indexOf('dcs_action=additemtocart') > -1\n          ) {\n            var rawSku = getParam(url, 'url_catalog_ref_id');\n            var skuId = cleanSku(rawSku);\n            var quantity = Number(getParam(url, 'url_quantity')) || 1;\n            var product = getGciProductBySku(skuId) || {};\n\n            var qmPayload = {\n              ATCLocation: 'MF addToCart.jsp',\n              pfm: 'SDOTD add to cart ad',\n              apiResponseStatus: 'Success',\n              items: [\n                {\n                  itemName: product.name || product.title || '',\n                  price: parsePrice(product.price),\n                  quantity: quantity,\n                  recSetId: '',\n                  slotIndex: '',\n                  displayId: product.sku_id || skuId\n                }\n              ]\n            };\n\n            if (\n              window.QuantumMetricAPI &&\n              typeof window.QuantumMetricAPI.sendEvent === 'function'\n            ) {\n              window.QuantumMetricAPI.sendEvent(\n                79,\n                0,\n                'Web - Cart Additions',\n                qmPayload\n              );\n            }\n          }\n        } catch (e) {\n          console.error('QM MF Cart Additions error:', e);\n          if (window.handleQMError) {\n            window.handleQMError(e);\n          }\n        }\n      });\n\n      return originalSend.apply(this, arguments);\n    };\n  })();\n} catch (e) {\n  console.error('QM MF Cart Additions setup error:', e);\n  if (window.handleQMError) {\n    window.handleQMError(e);\n  }\n}\n\n\n"]},{"t":"V","v":[""]},{"t":"JSValue","v":[{"fn":function () {}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":81,"f":0,"m":0,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {// QM Data Element: Payment Type (Evaluation)
// Debugs source selection for payment type.
try {
  var LOG_PREFIX = '[QM Payment Eval]';
  var log = function() {
    if (!window.console || typeof window.console.log !== 'function') {
      return;
    }
    var args = Array.prototype.slice.call(arguments);
    args.unshift(LOG_PREFIX);
    window.console.log.apply(window.console, args);
  };
  var normalize = function(value) {
    if (typeof value !== 'string') {
      return '';
    }
    return value.trim().toLowerCase();
  };
  var extractPaymentValue = function(value) {
    if (!value) {
      return '';
    }
    if (typeof value === 'string') {
      return normalize(value);
    }
    if (typeof value !== 'object') {
      return '';
    }
    var direct = normalize(value.paymentType) ||
      normalize(value.paymentMethod) ||
      normalize(value.type);
    if (direct) {
      return direct;
    }
    var fromCard = normalize(
      value.creditCardDetails &&
      value.creditCardDetails.creditCardType
    );
    if (fromCard) {
      return fromCard;
    }
    var fromGroup = normalize(
      value.paymentGroup &&
      value.paymentGroup[0] &&
      value.paymentGroup[0].creditCardDetails &&
      value.paymentGroup[0].creditCardDetails.creditCardType
    );
    if (fromGroup) {
      return fromGroup;
    }
    // --- ADDED: surface gear (Synchrony) + Fortiva cards. Rename in QM. ---
    var fromGearCard = normalize(
      value.paymentGroup &&
      value.paymentGroup[0] &&
      value.paymentGroup[0].gearCardDetails &&
      value.paymentGroup[0].gearCardDetails.creditCardType
    );
    if (fromGearCard) {
      return fromGearCard; // 'hsbccard' -> Platinum Card in QM
    }
    var fromFortivaCard = normalize(
      value.paymentGroup &&
      value.paymentGroup[0] &&
      value.paymentGroup[0].fortivaCardDetails &&
      value.paymentGroup[0].fortivaCardDetails.creditCardType
    );
    if (fromFortivaCard) {
      return fromFortivaCard; // 'fortivacard' -> Fortiva in QM
    }
    // --- END ADDED ---
    return '';
  };
  var applyPaymentTypes = '';
  try {
    applyPaymentTypes = localStorage.getItem('applyPaymentTypes') || '';
  } catch (e) {
    log('localStorage getItem failed', e);
  }
  var fromLocalStorage = normalize(applyPaymentTypes);
  if (fromLocalStorage) {
    log('using localStorage.applyPaymentTypes', fromLocalStorage);
    return fromLocalStorage;
  }
  log('localStorage.applyPaymentTypes empty');
  var siteVars = window.GCI &&
    window.GCI.digitalData &&
    window.GCI.digitalData.siteVars;
  var fromSiteVarsPayment = extractPaymentValue(
    siteVars && siteVars.payment
  );
  if (fromSiteVarsPayment) {
    log('using siteVars.payment.paymentGroup[0].creditCardDetails.creditCardType', fromSiteVarsPayment);
    return fromSiteVarsPayment;
  }
  log('siteVars payment creditCardType empty');
  var fromSiteVarsOrderPayment = extractPaymentValue(
    siteVars &&
    siteVars.order &&
    siteVars.order.payment
  );
  if (fromSiteVarsOrderPayment) {
    log('using siteVars.order.payment (MF)', fromSiteVarsOrderPayment);
    return fromSiteVarsOrderPayment;
  }
  log('siteVars.order.payment empty');
  var fromCheckoutPayment = extractPaymentValue(
    window.dataLayer &&
    window.dataLayer._state &&
    window.dataLayer._state.checkoutStepChanged &&
    window.dataLayer._state.checkoutStepChanged.order &&
    window.dataLayer._state.checkoutStepChanged.order.payment
  );
  if (fromCheckoutPayment) {
    log('using checkoutStepChanged.order.payment', fromCheckoutPayment);
    return fromCheckoutPayment;
  }
  log('checkoutStepChanged.order.payment empty');
  var fromOmniture = window.GCI &&
    window.GCI.digitalData &&
    window.GCI.digitalData.omnitureData &&
    window.GCI.digitalData.omnitureData.paymentType;
  fromOmniture = normalize(fromOmniture);
  if (fromOmniture) {
    log('using omnitureData.paymentType', fromOmniture);
    return fromOmniture;
  }
  log('no payment type found');
  return '';
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError('81', err);
  }
  return '';
}}}]},{"t":"JSValue","v":[{"fn":function () {// QM Data Element: Payment Type (Primary Value)
// Used on order confirmation page only.
// Priority: Apple Pay -> localStorage applyPaymentTypes -> siteVars payment creditCardType -> omnitureData.paymentType

try {
  var LOG_PREFIX = '[QM Payment Primary]';
  var log = function() {
    if (!window.console || typeof window.console.log !== 'function') {
      return;
    }
    var args = Array.prototype.slice.call(arguments);
    args.unshift(LOG_PREFIX);
    window.console.log.apply(window.console, args);
  };

  var normalize = function(value) {
    if (typeof value !== 'string') {
      return '';
    }
    return value.trim().toLowerCase();
  };

  var extractPaymentValue = function(value) {
    if (!value) {
      return '';
    }
    if (typeof value === 'string') {
      return normalize(value);
    }
    if (typeof value !== 'object') {
      return '';
    }

    var direct = normalize(value.paymentType) ||
      normalize(value.paymentMethod) ||
      normalize(value.type);
    if (direct) {
      return direct;
    }

    var fromCard = normalize(
      value.creditCardDetails &&
      value.creditCardDetails.creditCardType
    );
    if (fromCard) {
      return fromCard;
    }

    var fromGroup = normalize(
      value.paymentGroup &&
      value.paymentGroup[0] &&
      value.paymentGroup[0].creditCardDetails &&
      value.paymentGroup[0].creditCardDetails.creditCardType
    );
    if (fromGroup) {
      return fromGroup;
    }

    // --- ADDED: surface gear (Synchrony) + Fortiva cards. Rename in QM. ---
    var fromGearCard = normalize(
      value.paymentGroup &&
      value.paymentGroup[0] &&
      value.paymentGroup[0].gearCardDetails &&
      value.paymentGroup[0].gearCardDetails.creditCardType
    );
    if (fromGearCard) {
      return fromGearCard; // 'hsbccard' -> Platinum Card in QM
    }

    var fromFortivaCard = normalize(
      value.paymentGroup &&
      value.paymentGroup[0] &&
      value.paymentGroup[0].fortivaCardDetails &&
      value.paymentGroup[0].fortivaCardDetails.creditCardType
    );
    if (fromFortivaCard) {
      return fromFortivaCard; // 'fortivacard' -> Fortiva in QM
    }
    // --- END ADDED ---

    return '';
  };

  var paymentGroup = window.dataLayer &&
    window.dataLayer._state &&
    window.dataLayer._state.checkoutStepChanged &&
    window.dataLayer._state.checkoutStepChanged.order &&
    window.dataLayer._state.checkoutStepChanged.order.payment &&
    window.dataLayer._state.checkoutStepChanged.order.payment.paymentGroup;
  if (paymentGroup && Array.isArray(paymentGroup)) {
    for (var i = 0; i < paymentGroup.length; i++) {
      if (paymentGroup[i] && paymentGroup[i].applePayDetails) {
        log('using applepay from checkoutStepChanged paymentGroup');
        return 'applepay';
      }
    }
  }
  log('applepay not found in checkoutStepChanged paymentGroup');

  var applyPaymentTypes = '';
  try {
    applyPaymentTypes = localStorage.getItem('applyPaymentTypes') || '';
    if (applyPaymentTypes) {
      localStorage.removeItem('applyPaymentTypes');
    }
  } catch (e) {
    log('localStorage read/remove failed', e);
  }
  var fromLocalStorage = normalize(applyPaymentTypes);
  if (fromLocalStorage) {
    log('using localStorage.applyPaymentTypes', fromLocalStorage);
    return fromLocalStorage;
  }
  log('localStorage.applyPaymentTypes empty');

  var siteVars = window.GCI &&
    window.GCI.digitalData &&
    window.GCI.digitalData.siteVars;

  var fromSiteVarsPayment = extractPaymentValue(
    siteVars && siteVars.payment
  );
  if (fromSiteVarsPayment) {
    log('using siteVars.payment.paymentGroup[0].creditCardDetails.creditCardType', fromSiteVarsPayment);
    return fromSiteVarsPayment;
  }
  log('siteVars payment creditCardType empty');

  var fromSiteVarsOrderPayment = extractPaymentValue(
    siteVars &&
    siteVars.order &&
    siteVars.order.payment
  );
  if (fromSiteVarsOrderPayment) {
    log('using siteVars.order.payment (MF)', fromSiteVarsOrderPayment);
    return fromSiteVarsOrderPayment;
  }
  log('siteVars.order.payment empty');

  var fromCheckoutPayment = extractPaymentValue(
    window.dataLayer &&
    window.dataLayer._state &&
    window.dataLayer._state.checkoutStepChanged &&
    window.dataLayer._state.checkoutStepChanged.order &&
    window.dataLayer._state.checkoutStepChanged.order.payment
  );
  if (fromCheckoutPayment) {
    log('using checkoutStepChanged.order.payment', fromCheckoutPayment);
    return fromCheckoutPayment;
  }
  log('checkoutStepChanged.order.payment empty');

  var fromOmniture = window.GCI &&
    window.GCI.digitalData &&
    window.GCI.digitalData.omnitureData &&
    window.GCI.digitalData.omnitureData.paymentType;
  fromOmniture = normalize(fromOmniture);
  if (fromOmniture) {
    log('using omnitureData.paymentType', fromOmniture);
    return fromOmniture;
  }

  log('no payment type found');
  return '';
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError('81', err);
  }
  return '';
}}}]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":false,"i":82,"f":0,"m":0,"s":2,"u":".*","x":"QCK,QCK","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"CookiePresent","v":["guitarcenter_clarip_consent"]},{"t":"CookieValue","v":["guitarcenter_clarip_consent"]}]},{"t":"E","v":[{"t":"CookiePresent","v":["musiciansfriend_clarip_consent"]},{"t":"V","v":[""]}]}]}},{"f":0,"i":83,"evalAlways":false,"m":0,"s":1,"u":".*","v":{"t":"E","v":[{"t":"SelectorPresent","v":["#checkBalanceTrigger"]},{"t":"SelectorText","v":["#checkBalanceTrigger"]}]},"x":"QCC","sessionInfoReq":false,"excludeBlank":true},{"f":0,"i":84,"evalAlways":false,"m":0,"s":0,"u":".*","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {(function () {
  try {
    var rVersion = (window._satellite && window._satellite.buildInfo) || {};
    window.QuantumMetricAPI.sendEvent(
      84,
      0,
      rVersion.turbineVersion || 'N/A',
      rVersion
    );
  } catch (err) {
    if (window.handleQMError) {
      window.handleQMError('84', err);
    }
  }
  return undefined;
})();}}]},{"t":"V","v":[""]},{"t":"JSValue","v":[{"fn":function () {}}]}]},"x":"QJS","sessionInfoReq":false,"excludeBlank":false},{"f":0,"i":85,"evalAlways":true,"m":1,"s":2,"u":"\\/cart","v":{"t":"E","v":[{"t":"SelectorPresent","v":["[data-js=\"cartCouponSuccess\"]"]},{"t":"SelectorText","v":["[data-js=\"cartCouponSuccess\"]"]}]},"x":"QCC","sessionInfoReq":true,"excludeBlank":true},{"f":0,"i":86,"evalAlways":true,"m":1,"s":2,"u":"\\/cart","v":{"t":"E","v":[{"t":"SelectorPresent","v":["[data-js=\"cartCouponError\"]"]},{"t":"SelectorText","v":["[data-js=\"cartCouponError\"]"]}]},"x":"QCC","sessionInfoReq":true,"excludeBlank":true},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":false,"i":87,"f":0,"m":1,"s":2,"u":".*","x":"QOP","v":{"t":"E","v":[{"t":"ObjPath","v":[{"t":"WV","v":[]},"/dataLayer/_state/changeShippingType"]},{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/dataLayer/_state/changeShippingType"]}]}},{"f":0,"i":88,"evalAlways":false,"m":0,"s":1,"u":".*","v":{"t":"E","v":[{"t":"ObjPath","v":[{"t":"WV","v":[]},"/dataLayer/_state/omnitureLoaded/omnitureData/soimTitle"]},{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/dataLayer/_state/omnitureLoaded/omnitureData/soimTitle"]}]},"x":"QOP","sessionInfoReq":false,"excludeBlank":false},{"f":0,"i":89,"evalAlways":false,"m":0,"s":2,"u":".*","v":{"t":"E","v":[{"t":"ObjPath","v":[{"t":"WV","v":[]},"/GCI/digitalData/omnitureData/hashedEmail"]},{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/GCI/digitalData/omnitureData/hashedEmail"]}]},"x":"QOP","sessionInfoReq":true,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":90,"f":0,"m":1,"s":1,"u":".*","x":"QCE","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["#custom-help-btn,[class*=\"custom-help-btn\"],#custom-help-btn *,[class*=\"custom-help-btn\"] *"]}]},{"t":"V","v":[""]}]}},{"f":0,"i":91,"evalAlways":false,"m":0,"s":2,"u":".*","v":{"t":"E","v":[{"t":"ObjPath","v":[{"t":"WV","v":[]},"/s/version"]},{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/s/version"]}]},"x":"QOP","sessionInfoReq":true,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":92,"f":0,"m":1,"s":1,"u":".*","x":"QCE,QCE,QJS","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["[data-testid=\"responsive-menu\"] [data-category-name],[data-testid=\"responsive-menu\"] [data-category-name] *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try { return (this.api || QuantumMetricAPI).lastClicked ? (this.api || QuantumMetricAPI).lastClicked.innerText : ""; } catch (e) {}}}]}]},{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".responsive-header_browse_categories a[data-js-categories-link]:not([href=\"#\"]),a#more_id_link,.responsive-header_utility_logo,.responsive-header_browse_deals_flyout_promos li:first-child a,.responsive-header_utility_signin_icon,.responsive-header_utility_account-dropdown,.responsive-header_browse_categories a[data-js-categories-link]:not([href=\"#\"]) *,a#more_id_link *,.responsive-header_utility_logo *,.responsive-header_browse_deals_flyout_promos li:first-child a *,.responsive-header_utility_signin_icon *,.responsive-header_utility_account-dropdown *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try { return (this.api || QuantumMetricAPI).lastClicked ? (this.api || QuantumMetricAPI).lastClicked.innerText : ""; } catch (e) {}}}]}]},{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {// Click Event: Browse Deals - Fires QM Event 92
// Stupid Deal of the Day

try {
  // Prevent setting up multiple listeners
  if (window.qm92ListenerSet) {
    return;
  }
  
  document.addEventListener('click', function(event) {
    var target = event.target;
    
    if (target && target instanceof Element) {
      var element = target.closest('.responsive-header_browse_deals_stupid');
      
      if (element) {
        
        // Fire QM event 92 directly (if-else ensures only one fires)
          QuantumMetricAPI.sendEvent(92, 0, 'Stupid Deal of the Day');
  
      }
    }
  });
  
  window.qm92ListenerSet = true;
  
} catch (error) {
  console.error('[QM 92] Error:', error);
  if (window.handleQMError) {
    window.handleQMError('92', error);
  }
  return false;
}}}]},{"t":"V","v":[""]}]}]}},{"f":0,"i":93,"evalAlways":false,"m":0,"s":1,"u":".*","v":{"t":"E","v":[{"t":"ObjPath","v":[{"t":"WV","v":[]},"/dataLayer/_state/product/availability"]},{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/dataLayer/_state/product/availability"]}]},"x":"QOP","sessionInfoReq":false,"excludeBlank":false},{"f":0,"i":94,"evalAlways":false,"m":0,"s":1,"u":".*","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".serialized-compare-modal button[type=\"submit\"],.serialized-compare-modal button[type=\"submit\"] *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  return window.QuantumMetricAPI.lastClicked.parentElement.querySelector("a").href;
}
catch (err) {}}}]}]},"x":"QCE","sessionInfoReq":false,"excludeBlank":true},{"f":0,"i":95,"evalAlways":false,"m":0,"s":1,"u":".*","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
    var srlCmp =
      (localStorage && localStorage.getItem('serializedItemsClicked'));
  if (srlCmp) {
    window.QuantumMetricAPI.sendEvent(95, 0, srlCmp);
  }
 } catch (err) {
    if (window.handleQMError) {
      window.handleQMError('95', err);
    }
  }
  return undefined;}}]},{"t":"V","v":[""]}]},"x":"QJS","sessionInfoReq":false,"excludeBlank":true},{"f":0,"i":96,"evalAlways":false,"m":0,"s":1,"u":".*","v":{"t":"E","v":[{"t":"SelectorPresent","v":["#PDPGalleryWrapper .serialized-item-selection,#PDPRightRailWrapper .serialized-item-selection"]},{"t":"V","v":[""]}]},"x":"QCC","sessionInfoReq":false,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":98,"f":0,"m":0,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]}]}},{"f":0,"i":99,"evalAlways":false,"m":0,"s":1,"u":".*","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
    return (
      window.siteVars &&
      window.siteVars.order &&
      window.siteVars.order.commerceItems &&
      window.siteVars.order.commerceItems[0].itemPromo &&
      window.siteVars.order.commerceItems[0].itemPromo[0].promoName
    );
  } catch (err) {
    if (window.handleQMError) {
      window.handleQMError('99', err);
    }
  }}}]},{"t":"JSValue","v":[{"fn":function () {try {
    return (
      window.siteVars &&
      window.siteVars.order &&
      window.siteVars.order.commerceItems &&
      window.siteVars.order.commerceItems[0].itemPromo &&
      window.siteVars.order.commerceItems[0].itemPromo[0].promoName
    );
  } catch (err) {
    if (window.handleQMError) {
      window.handleQMError('99', err);
    }
  }}}]}]},"x":"QJS","sessionInfoReq":false,"excludeBlank":true},{"f":0,"i":100,"evalAlways":false,"m":0,"s":1,"u":".*","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["[class*=\"bx-element\"] button[type=\"submit\"],[class*=\"bx-element\"] button[type=\"submit\"] *"]}]},{"t":"V","v":[""]}]},"x":"QCE","sessionInfoReq":false,"excludeBlank":false},{"f":0,"i":101,"evalAlways":false,"m":1,"s":1,"u":".*","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {//MF only
try {
  if (!document.querySelector('.typeahead-wrapper')) {
    return false;
  }

  // Set up listener only once
  if (!window._typeAheadClickFlag) {
    window._typeAheadClickFlag = true;

    document.addEventListener(
      'mousedown',
      function (event) {
        try {
          var link = event.target && event.target.closest(
            '#typeAheadDimensions a, #searchTypeAhead-list a'
          );

          if (!link) {
            return;
          }

          var typeAheadType = '';
          var typeAheadValue = '';

          // Determine type from selector
          if (link.closest('#typeAheadDimensions')) {
            typeAheadType = 'brands';
          } else if (link.closest('#searchTypeAhead-list')) {
            typeAheadType = 'term';
          }

          // Get value from DOM
          typeAheadValue =
            link.getAttribute('data-name') ||
            (link.textContent || '').trim() ||
            '';

          if (!typeAheadType || !typeAheadValue) {
            return;
          }

          // Build payload
          var payload = {
            typeAheadType: typeAheadType,
            typeAheadValue: typeAheadValue
          };

          // Send QM Event (PRIMARY VALUE = TYPE)
          if (
            window.QuantumMetricAPI &&
            window.QuantumMetricAPI.sendEvent
          ) {
            window.QuantumMetricAPI.sendEvent(
              101,
              0,
              payload.typeAheadType, // <-- key change
              payload
            );
          }
        } catch (e) {
          console.error('[QM Type Ahead Click] Error processing event:', e);
          if (window.handleQMError) {
            window.handleQMError('TypeAheadClick', e);
          }
        }
      },
      true
    );
  }
} catch (err) {
  console.error('[QM Type Ahead Click] Error:', err);
  if (window.handleQMError) {
    window.handleQMError('TypeAheadClick', err);
  }
}}}]},{"t":"JSValue","v":[{"fn":function () {var d =
  window.GCI &&
  window.GCI.digitalData &&
  window.GCI.digitalData.omnitureData;

return (d && d.typeAheadType) ? d.typeAheadType : undefined;}}]}]},{"t":"E","v":[{"t":"ObjPath","v":[{"t":"WV","v":[]},"/GCI/digitalData/omnitureData/typeAheadValue",{"t":"Is","v":[true]}]},{"t":"V","v":[""]}]},{"t":"E","v":[{"t":"JSValue","v":["// GC only — QM Event 101: Type Ahead Click\n// dlUpdateEvent (Top Searches) + direct DOM listener (Recent Searches) → localStorage. Next evaluation run → send + clear.\n(function() {\n  var STORAGE_KEY = 'qmPendingTypeAheadClick';\n\n  try {\n    var hostname = window.location.hostname || '';\n    if (hostname.indexOf('guitarcenter.com') === -1) {\n      return false;\n    }\n\n    // --- SEND PENDING EVENT ---\n    var raw = localStorage.getItem(STORAGE_KEY);\n    if (raw) {\n      try {\n        var pending = JSON.parse(raw);\n        if (\n          pending &&\n          pending.typeAheadType &&\n          pending.typeAheadValue &&\n          window.QuantumMetricAPI &&\n          window.QuantumMetricAPI.sendEvent\n        ) {\n          window.QuantumMetricAPI.sendEvent(\n            101,\n            0,\n            pending.typeAheadType,\n            {\n              typeAheadType: pending.typeAheadType,\n              typeAheadValue: pending.typeAheadValue\n            }\n          );\n        }\n      } catch (sendErr) {\n        if (window.handleQMError) {\n          window.handleQMError('101', sendErr);\n        }\n      }\n      localStorage.removeItem(STORAGE_KEY);\n    }\n\n    // --- LISTENER 1: Top Searches (existing dlUpdateEvent path) ---\n    if (!window._typeAheadClickListenerSet) {\n      window._typeAheadClickListenerSet = true;\n      window.addEventListener('dlUpdateEvent', function(event) {\n        try {\n          var detail = event.detail;\n          if (!detail) {\n            return;\n          }\n          var eventName = detail.eventName || detail.event;\n          if (eventName !== 'typeAheadLinkClicked') {\n            return;\n          }\n          var typeAheadType = detail.typeAheadSectionTitle || '';\n          var typeAheadValue = detail.typeAheadLinkTitle || '';\n          if (!typeAheadType || !typeAheadValue) {\n            return;\n          }\n          localStorage.setItem(STORAGE_KEY, JSON.stringify({\n            typeAheadType: typeAheadType,\n            typeAheadValue: typeAheadValue\n          }));\n        } catch (e) {\n          if (window.handleQMError) {\n            window.handleQMError('101', e);\n          }\n        }\n      });\n    }\n\n    // --- LISTENER 2: Recent Searches (no dataLayer hook, direct DOM click) ---\n    if (!window._recentSearchClickListenerSet) {\n      window._recentSearchClickListenerSet = true;\n      document.addEventListener('click', function(e) {\n        try {\n          var container = e.target.closest('.recent-search');\n          if (!container) {\n            return;\n          }\n          var li = e.target.closest('li');\n          if (!li) {\n            return;\n          }\n          // skip the \"Clear all recent searches\" action\n          if (li.classList.contains('text-std-red-200')) {\n            return;\n          }\n          var value = (li.textContent || '').trim();\n          if (!value) {\n            return;\n          }\n          localStorage.setItem(STORAGE_KEY, JSON.stringify({\n            typeAheadType: 'Recent Search',\n            typeAheadValue: value\n          }));\n        } catch (e) {\n          if (window.handleQMError) {\n            window.handleQMError('101', e);\n          }\n        }\n      });\n    }\n\n    return false;\n  } catch (err) {\n    if (window.handleQMError) {\n      window.handleQMError('101', err);\n    }\n    return false;\n  }\n})();"]},{"t":"V","v":[""]}]}]},"x":"QJS,QOP,QJS","sessionInfoReq":false,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":102,"f":0,"m":0,"s":1,"u":".*","x":"QCC","v":{"t":"E","v":[{"t":"SelectorPresent","v":["[id^=\"bx-creative\"]"]},{"t":"V","v":[""]}]}},{"f":0,"i":103,"evalAlways":false,"m":1,"s":2,"u":"\\/cart","v":{"t":"E","v":[{"t":"SelectorPresent","v":[".cart-page__cart-error__text"]},{"t":"SelectorText","v":[".cart-page__cart-error__text"]}]},"x":"QCC","sessionInfoReq":true,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":104,"f":0,"m":1,"s":1,"u":".*","x":"QXJ","v":{"t":"MDE","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRRequest","v":["\\/claimCoupon|addCouponCode"]},{"t":"XFJPar","v":[]}]},"/couponClaimCode"]},{"t":"JSValueEx","v":[{"fn":function () {try {
    var respJSON = JSON.parse(window.QuantumMetricAPI.lastXHR.qresponse);
    var returnObj = {
      'analyticsData': {
        'siteSection': respJSON.analyticsData.siteSection,
        'reportSuiteIds': respJSON.analyticsData.reportSuiteIds,
        'pageType': respJSON.analyticsData.pageType,
        'ATGID': respJSON.analyticsData.ATGID,
        'sessionId': respJSON.analyticsData.sessionId,
        'couponCode': respJSON.analyticsData.couponCode,
        'pageName': respJSON.analyticsData.pageName
      },
      'formError': respJSON.formError,
      'formException': {
        'localizedMessage': respJSON.formExceptions[0].localizedMessage,
        'errorCode': respJSON.formExceptions[0].errorCode
      },
      'statusMessage': respJSON.statusMessage,
      'statusCode': respJSON.statusCode
    };
    window.QuantumMetricAPI.sendEvent(
      104,
      0,
      returnObj.analyticsData.couponCode,
      returnObj
    );
  if (respJSON.statusCode) {
    window.QuantumMetricAPI.sendEvent(113, 0,
      "Coupon Code Failed");
    window.QuantumMetricAPI.sendEvent(242, 0,
      returnObj.formException.localizedMessage, returnObj);
  }
  } catch (err) {
    if (window.handleQMError) {
      window.handleQMError('104', err);
    }
  }
  return undefined;}}]},{"t":"VXF","v":[{"t":"XHR","v":["\\/claimCoupon|addCouponCode"]},{"t":"XFPK","v":[["qurl","url"],["qstatus","statusCode"]]},{"t":"XFMG","v":[{"t":"JSValueEx","v":[{"fn":function () {}}]}]}]}]}},{"f":0,"i":105,"evalAlways":false,"m":1,"s":1,"u":".*","v":{"t":"MDE","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["\\/checkoutActor\\/processPaymentAndSubmitOrder-spa|\\/checkoutActor\\/commitOrderForSPA"]},{"t":"XFJPar","v":[]}]},"/orderState",{"t":"Is","v":["confirmation"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var response = JSON.parse(
      window.QuantumMetricAPI.lastXHR.qresponse
    );
    var order = response.order;
  	var orderObj = {};
  orderObj.shippingMethod = response.analyticsData.shippingMethod;
  orderObj.paymentType = response.analyticsData.paymentType;
  orderObj.sourceCodeName = localStorage.getItem('sourceCodeNameQM');
  orderObj.saleItemDiscounts = order.saleItemDiscounts;
  orderObj.taxTotal = order.taxTotal;
  orderObj.doNotSell = order.doNotSell;
  orderObj.isSubscription = order.isSubscription;
  orderObj.discounts = order.discounts;
  orderObj.stateFeeLabel = order.stateFeeLabel;
  orderObj.id = order.id;
  orderObj.international = order.international;
  orderObj.commerceItems = order.commerceItems;
  orderObj.orderTotalFinal = order.orderTotalFinal;
  orderObj.stateFee = order.stateFee;
  orderObj.currencySymbol = order.currencySymbol;
  orderObj.totalSavings = order.totalSavings;
  orderObj.shippingTotal = order.shippingTotal;
  orderObj.orderSubtotal = order.orderSubtotal;
  orderObj.additionalDiscounts = order.additionalDiscounts;
  orderObj.subtotal = order.subtotal;
  orderObj.stateFeeTax = order.stateFeeTax;
  orderObj.cartOrderSubtotal = order.cartOrderSubtotal;
  orderObj.savedTotal = order.savedTotal;
  orderObj.stateCode = order.stateCode;
    window.QuantumMetricAPI.sendEvent(
      105,
      0,
      orderObj.id || 'N/A',
      orderObj
    );
  } catch (err) {}}}]},{"t":"VXF","v":[{"t":"XHR","v":["\\/checkoutActor\\/processPaymentAndSubmitOrder-spa|\\/checkoutActor\\/commitOrderForSPA"]},{"t":"XFPK","v":[["qurl","url"],["qstatus","statusCode"]]},{"t":"XFMG","v":[{"t":"JSValueEx","v":[{"fn":function () {}}]}]}]}]},"x":"QXJ","sessionInfoReq":false,"excludeBlank":true},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":106,"f":0,"m":0,"s":0,"u":".*","x":"QCE","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".serialized-item-selection button,.serialized-item-selection button *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try { return (this.api || QuantumMetricAPI).lastClicked ? (this.api || QuantumMetricAPI).lastClicked.innerText : ""; } catch (e) {}}}]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":true,"i":109,"f":0,"m":1,"s":1,"u":".*","x":"QOP,QOP","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"ObjPath","v":[{"t":"WV","v":[]},"/dataLayer/_state/userChangeFacet/type",{"t":"Is","v":["selected"]}]},{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/dataLayer/_state/userChangeFacet/value"]}]},{"t":"E","v":[{"t":"ObjPath","v":[{"t":"WV","v":[]},"/GCI/digitalData/analyticsData/faceting/activatedFacet/refinementValue"]},{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/GCI/digitalData/analyticsData/faceting/activatedFacet/refinementValue"]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":110,"f":0,"m":1,"s":1,"u":".*","x":"QJS,QJS","v":{"t":"MAE","v":[1,0,{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {//GC only
try {
  if (!document.querySelector('.plp-container')) {
    return false;
  }
  
  // Set up listener only once
  if (!window._refinementTypeFlag) {
    window._refinementTypeFlag = true;

    window.addEventListener('dlUpdateEvent', function (event) {
      var eventData = event.detail;

      // Check if this is the userChangeDemoGearType event
      if (
        eventData &&
        eventData.eventName === 'userChangeFacet' &&
        eventData.userChangeFacet
      ) {
        try {
          var facetData = eventData.userChangeFacet;

          // Extract data from the event
          var dimensionName = facetData.dimensionName || '';
          var dimensionType = facetData.type || '';
          var dimensionValue = facetData.value || '';

          // Build the payload
          var payload = {
            dimensionName: dimensionName,
            dimensionType: dimensionType,
            dimensionValue: dimensionValue
          };

          // Send QM Event
          if (
            window.QuantumMetricAPI &&
            window.QuantumMetricAPI.sendEvent
          ) {
            window.QuantumMetricAPI.sendEvent(
              110,
              0,
              payload.dimensionName,
              payload
            );
          }
        } catch (e) {
          console.error('[QM Refinement Change] Error processing event:', e);
          if (window.handleQMError) {
            window.handleQMError('RefinementType', e);
          }
        }
      }
    });
  }
} catch (err) {
  console.error('[QM Refinement Change] Error:', err);
  if (window.handleQMError) {
    window.handleQMError('RefinementType', err);
  }
}}}]},{"t":"JSValue","v":[{"fn":function () {var p = window.__qmFacetPayload;
return (p && p.dimensionName) ? p.dimensionName : undefined;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]},{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {// QM Event: Web - Refinement Types (MF only)
// Reuse GC logic, adapted for Endeca payload and MF facets container.
// 1) userChangeFacet (dlUpdateEvent)
// 2) SEO facet links (full navigation, no userChangeFacet) — .-seo-facet menus

try {
  // Gate to MF PLP facets UI
  var facetsContainer = document.querySelector('.plp-title');
  if (!facetsContainer) {
    return false;
  }

  // Install once for MF
  if (!window._qmMFRefinementListenerSet) {
    window._qmMFRefinementListenerSet = true;

    // Strip tags + decode entities (&nbsp;, &amp;, …) + normalize spaces for QM/analytics
    var normalizeFacetLabel = function (s) {
      if (s === null || s === undefined) { return ''; }
      var str = String(s).replace(/<[^>]*>/g, '');
      try {
        var t = document.createElement('textarea');
        t.innerHTML = str;
        str = t.value;
      } catch (e) { /* keep str */ }
      return str
        .replace(/\u00A0/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
    };

    var sendMfRefinementPayload = function (payload) {
      var sig = JSON.stringify(payload);
      if (window.__qmMFlastRefinementSig === sig) { return; }
      window.__qmMFlastRefinementSig = sig;

      console.log('[QM WRT MF] sending', payload);
      window.__qmFacetPayload = payload;

      if (window.QuantumMetricAPI && typeof window.QuantumMetricAPI.sendEvent === 'function') {
        window.QuantumMetricAPI.sendEvent(110, 0, payload.dimensionName, payload);
      } else {
        console.log('[QM WRT MF] QM API not available; would send:', payload);
      }
    };

    window.addEventListener('dlUpdateEvent', function (event) {
      var detail = event && event.detail;
      if (!detail) { return; }

      // Only handle refinement changes
      if (detail.eventName === 'userChangeFacet' && detail.userChangeFacet) {
        try {
          // ----- MF (Endeca) shape -----
          // detail.userChangeFacet.changedFacet.detail.{dimensionName,value}
          // type on changedFacet.type (or sometimes userChangeFacet.type)
          var uc = detail.userChangeFacet;
          var changed = uc.changedFacet || {};
          var det = changed.detail || {};

          var name = det.dimensionName || '';
          var rawValue = det.value;
          var rawType = (changed.type || uc.type || '');

          if (!name) { return; }

          // Normalize value (unwrap {label}, coerce to string)
          var value;
          if (rawValue && typeof rawValue === 'object' && rawValue.label !== null) {
            value = normalizeFacetLabel(rawValue.label);
          } else if (rawValue !== null) {
            value = normalizeFacetLabel(rawValue);
          } else {
            value = '';
          }

          // Normalize type
          var type = String(rawType || '').toLowerCase();
          if (type !== 'selected' && type !== 'unselected') {
            type = 'selected';
          }

          sendMfRefinementPayload({
            dimensionName: name,
            dimensionValue: value,
            dimensionType: type
          });
        } catch (e) {
          console.error('[QM WRT MF] handler error:', e);
          if (window.handleQMError) { window.handleQMError('WRT_MF', e); }
        }
      }
    });

    // SEO facet menus: navigation links only (no userChangeFacet). Delegate to option anchors.
    document.addEventListener('click', function (event) {
      var target = event.target;
      if (!target || !target.closest) { return; }

      var link = target.closest('a.plp-utils-facets_filters-wrap-menu_options-btn');
      if (!link || !link.href) { return; }

      var wrap = link.closest('.plp-utils-facets_filters-wrap-menu.-seo-facet');
      if (!wrap) { return; }

      try {
        var headerBtn = wrap.querySelector('.js-filter-menu-header');
        var name = headerBtn
          ? normalizeFacetLabel(headerBtn.textContent)
          : (wrap.getAttribute('data-facet-id') || '');

        var value = normalizeFacetLabel(link.textContent);

        if (!name || !value) { return; }

        sendMfRefinementPayload({
          dimensionName: name,
          dimensionValue: value,
          dimensionType: 'selected'
        });
      } catch (e) {
        console.error('[QM WRT MF] SEO facet click error:', e);
        if (window.handleQMError) { window.handleQMError('WRT_MF_SEO', e); }
      }
    }, true);

    console.log('[QM WRT MF] listener installed (dlUpdateEvent + SEO facet links)');
  }

  return false; // listener pattern
} catch (err) {
  console.error('[QM WRT MF] setup error:', err);
  if (window.handleQMError) { window.handleQMError('WRT_MF', err); }
  return false;
}}}]},{"t":"V","v":[""]},{"t":"JSValue","v":[{"fn":function () {}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":111,"f":0,"m":1,"s":1,"u":".*","x":"QOP,QCE,QJS","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"ObjPath","v":[{"t":"WV","v":[]},"/dataLayer/_state/ominitureLoaded/omnitureData/sortByType"]},{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/dataLayer/_state/omnitureLoaded/omnitureData/sortByType"]}]},{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["#sortBy .ant-select-item-option,#sortBy .ant-select-item-option *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try { return (this.api || QuantumMetricAPI).lastClicked ? (this.api || QuantumMetricAPI).lastClicked.innerText : ""; } catch (e) {}}}]}]},{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {//got to setup a click handler for MF, there's no datalayer event (update later to listen for datalayer event when possible)
try {
  /** @type {any} */
  var doc = document;
  
  if (!doc.qmSortListenerAttached) {
    
    doc.addEventListener('change', function(e) {
      /** @type {any} */
      var target = e.target;
      
      if (target && typeof target.matches === 'function' && target.matches('select[data-plp-utils-facets-sort]')) {
        
        var opts = target.options;
        var idx = target.selectedIndex;
        
        if (opts && opts[idx]) {
          var val = opts[idx].text.trim();
          
          if (val && window.QuantumMetricAPI) {
            window.QuantumMetricAPI.sendEvent(111, 0, val);
          }
        }
      }
    }, true); // Use 'true' (capture phase) to ensure we catch the event before other scripts stop it
    
    doc.qmSortListenerAttached = true;
  }
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError('111', err);
  }
}

return "";}}]},{"t":"V","v":[""]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":112,"f":0,"m":0,"s":1,"u":".*","x":"QOP","v":{"t":"E","v":[{"t":"ObjPath","v":[{"t":"WV","v":[]},"/dataLayer/_state/eventName",{"t":"Is","v":["paymentFailed"]}]},{"t":"V","v":[""]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":true,"i":113,"f":0,"m":1,"s":2,"u":"\\/checkout|\\/cart","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":114,"f":0,"m":0,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {var urlParams = new URLSearchParams(window.location.search);
var keysToCapture = ['template', 'srsltid', 'gStoreCode', 'gQT'];
var result = [];

for (var i = 0; i < keysToCapture.length; i++) {
  var key = keysToCapture[i];
  var value = urlParams.get(key);
  if (value !== null) {
    result.push(key + '=' + value);
  }
}

var output = result.length ? '?' + result.join('&') : null;
console.log('Quantum Metric param capture:', output);
return output;}}]},{"t":"JSValue","v":[{"fn":function () {var urlParams = new URLSearchParams(window.location.search);
var keysToCapture = ['template', 'srsltid', 'gStoreCode', 'gQT'];
var result = [];

for (var i = 0; i < keysToCapture.length; i++) {
  var key = keysToCapture[i];
  var value = urlParams.get(key);
  if (value !== null) {
    result.push(key + '=' + value);
  }
}

var output = result.length ? '?' + result.join('&') : null;
console.log('Quantum Metric param capture:', output);
return output;}}]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":false,"i":115,"f":0,"m":0,"s":2,"u":".*","x":"QCK","v":{"t":"MDE","v":[{"t":"CookiePresent","v":["JSESSIONID"]},{"t":"CookieValue","v":["JSESSIONID"]},{"t":"JSValue","v":[{"fn":function () {try {
  var obj = {
    tt: window.sessionStorage.getItem('tt_sessionId'),
    qm: window.QuantumMetricAPI.getSessionID(),
    PIM: window.sessionStorage.getItem('PIM-SESSION-ID')
  };
 
  return obj;

} catch(err){}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":116,"f":0,"m":0,"s":1,"u":"\\/cart|\\/checkout","x":"QJS,QJS","v":{"t":"MAE","v":[1,0,{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {try {
  var LOG = '[QM Cart ID]';
  var isMF = window.location.hostname.indexOf('musiciansfriend') > -1;

  var normalizeCouponsForQM = function(couponData) {
    if (!couponData) {
      return null;
    }

    var list = Array.isArray(couponData) ? couponData : [couponData];

    if (!list.length) {
      return null;
    }

    return list.map(function(coupon) {
      var couponName = coupon.couponName;

      if (Array.isArray(couponName)) {
        couponName = couponName.length ? String(couponName[0]) : '';
      } else {
        couponName = String(couponName || '');
      }

      return {
        couponId: String(coupon.couponId || ''),
        couponName: couponName,
        discountAmount: Number(coupon.discountAmount) || 0
      };
    });
  };

  var resolveRawCoupons = function(order, siteVars, omnitureData) {
    var source = null;

    if (order) {
      source = order.coupon || order.coupons;
    }

    if (!source && siteVars) {
      source = siteVars.coupon || siteVars.coupons;
    }

    if (!source && omnitureData && omnitureData.couponCode) {
      source = {
        couponId: omnitureData.couponCode,
        couponName: omnitureData.couponName || ''
      };
    }

    console.log(LOG, 'resolveRawCoupons', {
      brand: isMF ? 'MF' : 'GC',
      source: source
    });

    return source;
  };

  var buildCouponLookup = function(couponData) {
    var lookup = {};
    var list = couponData
      ? (Array.isArray(couponData) ? couponData : [couponData])
      : [];

    list.forEach(function(coupon) {
      var couponId = String(coupon.couponId || '');

      if (!couponId) {
        return;
      }

      if (coupon.couponName) {
        lookup[String(coupon.couponName)] = couponId;
      }

      var promotionNames = coupon.promotionNames;

      if (typeof promotionNames === 'string' && promotionNames) {
        promotionNames
          .replace(/[\[\]]/g, '')
          .split('|')
          .forEach(function(name) {
            var trimmedName = name.trim();
            if (trimmedName) {
              lookup[trimmedName] = couponId;
            }
          });
      } else if (Array.isArray(promotionNames)) {
        promotionNames.forEach(function(name) {
          var promoName =
            typeof name === 'string' ? name : String(name.promotionName || '');

          if (promoName) {
            lookup[promoName] = couponId;
          }
        });
      }
    });

    return lookup;
  };

  var getData = function() {
    if (window.GCI && window.GCI.digitalData && window.GCI.digitalData.siteVars) {
      var siteVars = window.GCI.digitalData.siteVars;
      var omnitureData = window.GCI.digitalData.omnitureData;
      var items = null;
      var orderId = '';
      var subtotal = 0;
      var rawCoupons = null;
      var order = siteVars.order;

      if (order) {
        var orderItems = order.commerceItems || order.items;

        if (orderItems && orderItems.length > 0) {
          items = orderItems;
          orderId = order.id || '';
          subtotal =
            parseFloat(
              order.subtotal !== undefined ? order.subtotal : order.subTotal
            ) || 0;
          rawCoupons = resolveRawCoupons(order, siteVars, omnitureData);
        }
      }

      if (!items && siteVars.commerceItems && siteVars.commerceItems.length > 0) {
        items = siteVars.commerceItems;
        orderId = siteVars.id || '';
        subtotal = parseFloat(siteVars.subtotal) || 0;
        rawCoupons = resolveRawCoupons(null, siteVars, omnitureData);
      }

      if (items) {
        var result = {
          items: items,
          orderId: String(orderId || 'unknown'),
          subtotal: subtotal,
          isMF: isMF
        };

        if (rawCoupons) {
          result.rawCoupons = rawCoupons;
          result.coupons = normalizeCouponsForQM(rawCoupons);
        }

        console.log(LOG, 'getData result', {
          brand: isMF ? 'MF' : 'GC',
          orderId: result.orderId,
          itemCount: items.length,
          coupons: result.coupons
        });

        return result;
      }
    }

    return null;
  };

  var fireQMEvent = function(data) {
    if (!window.QuantumMetricAPI || !window.QuantumMetricAPI.sendEvent) {
      return false;
    }

    var couponLookup = data.rawCoupons ? buildCouponLookup(data.rawCoupons) : {};
    var rawCouponList = data.rawCoupons
      ? (Array.isArray(data.rawCoupons) ? data.rawCoupons : [data.rawCoupons])
      : [];

    var resolveCouponCode = function(promoName, explicitCode) {
      if (explicitCode) {
        return String(explicitCode);
      }

      if (promoName && couponLookup[promoName]) {
        return couponLookup[promoName];
      }

      if (rawCouponList.length === 1) {
        return String(rawCouponList[0].couponId || '');
      }

      return '';
    };

    var simpleItems = [];

    if (data.items && Array.isArray(data.items)) {
      for (var i = 0; i < data.items.length; i++) {
        var item = data.items[i];
        var simplified = {
          displayId: String(item.displayId || item.id || ''),
          displayName: String(item.displayName || item.name || ''),
          salePrice: Number(item.salePrice || item.price) || 0,
          quantity: Number(item.quantity) || 0,
          total: Number(item.total || item.itemTotal) || 0,
          productId: String(item.productId || ''),
          catalogRefId: String(item.catalogRefId || ''),
          brandName: String(item.brandName || ''),
          image: String(item.image || ''),
          skuSeoUrl: String(item.skuSeoUrl || item.url || ''),
          demoGearMessageTitle: String(item.demoGearMessageTitle || '')
        };

        if (item.discountedPrice !== undefined) {
          simplified.discountedPrice = Number(item.discountedPrice);
        }
        if (item.listPrice !== undefined) {
          simplified.listPrice = Number(item.listPrice);
        }
        if (item.commerceType) {
          simplified.commerceType = String(item.commerceType);
        }

        var promos = [];

        if (item.itemPromo && Array.isArray(item.itemPromo)) {
          for (var j = 0; j < item.itemPromo.length; j++) {
            var promo = item.itemPromo[j];
            var promoName = '';

            if (typeof promo === 'string') {
              promoName = promo;
            } else if (promo && typeof promo === 'object') {
              promoName = String(promo.promoName || '');
            }

            var type = 'item';

            if (!data.isMF && promoName.toLowerCase().indexOf('stupid deal') !== -1) {
              promoName = 'Daily Pick';
              type = 'dailyDeal';
            }

            promos.push({
              promoName: promoName,
              type: type,
              adjustedPrice:
                promo && typeof promo === 'object'
                  ? Number(promo.adjustedPrice) || 0
                  : 0,
              discount: 0,
              couponCode: data.isMF
                ? resolveCouponCode(
                    promoName,
                    promo && typeof promo === 'object' ? promo.couponCode : ''
                  )
                : ''
            });
          }
        }

        if (item.orderPromo && Array.isArray(item.orderPromo)) {
          for (var k = 0; k < item.orderPromo.length; k++) {
            var orderPromo = item.orderPromo[k];
            var orderPromoName = String(orderPromo.promoName || '');

            promos.push({
              promoName: orderPromoName,
              type: 'order',
              adjustedPrice: 0,
              discount: Number(orderPromo.discount) || 0,
              couponCode: data.isMF
                ? resolveCouponCode(orderPromoName, orderPromo.couponCode)
                : String(orderPromo.couponCode || '')
            });
          }
        }

        if (promos.length > 0) {
          simplified.promos = promos;
        }

        simpleItems.push(simplified);
      }
    }

    var payload = {
      orderId: data.orderId,
      subtotal: data.subtotal,
      cartItems: simpleItems
    };

    if (data.coupons) {
      payload.coupons = data.coupons;
    }

    try {
      console.log(LOG, 'sendEvent 116', {
        brand: data.isMF ? 'MF' : 'GC',
        payload: payload
      });
      window.QuantumMetricAPI.sendEvent(116, 0, data.orderId, payload);
      return true;
    } catch (err) {
      if (window.handleQMError) {
        window.handleQMError('116', err);
      }
      return false;
    }
  };

  var data = getData();

  if (data) {
    fireQMEvent(data);
    return false;
  }

  if (!window._checkoutQMListenerSet) {
    window._checkoutQMListenerSet = true;

    window.addEventListener('dlUpdateEvent', function(event) {
      var eventData = event.detail || event;

      if (
        eventData &&
        (eventData.eventName === 'checkoutStepChanged' ||
          eventData.eventName === 'siteVarsOrderInfoChange')
      ) {
        setTimeout(function() {
          var retryData = getData();
          if (retryData) {
            fireQMEvent(retryData);
          }
        }, 100);
      }
    });
  }

  return false;
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError('116', err);
  }
  return false;
}}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]}]},{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {try {
  return window.GCI.digitalData.siteVars.order.items;
}catch(err) {

}}}]},{"t":"JSValue","v":[{"fn":function () {try{
  var orderId = window.GCI.digitalData.siteVars.order.id;
  return orderId;
}catch(err){
}}}]},{"t":"JSValue","v":[{"fn":function () {//MF
try {
  var siteVars = window.GCI.digitalData.siteVars;
  var order = siteVars.order;
  var omnitureData = window.GCI.digitalData.omnitureData;
  var orderId = order.id;
  var items = order.items || order.commerceItems;
  var subtotalVal =
    order.subtotal !== undefined ? order.subtotal : order.subTotal;
  var subtotal = parseFloat(subtotalVal) || 0;

  var hasCouponAppliedEvent = function() {
    if (!omnitureData || !omnitureData.events) {
      return false;
    }

    var events = String(omnitureData.events).split(',');

    for (var i = 0; i < events.length; i++) {
      if (events[i].trim() === 'event15') {
        return true;
      }
    }

    return false;
  };

  var normalizeRawCoupons = function(couponData) {
    if (!couponData) {
      return [];
    }

    return Array.isArray(couponData) ? couponData : [couponData];
  };

  var couponApplied = hasCouponAppliedEvent();
  var rawCoupons = [];

  if (couponApplied) {
    rawCoupons = normalizeRawCoupons(
      order.coupon ||
      order.coupons ||
      siteVars.coupon ||
      siteVars.coupons
    );

    if (
      !rawCoupons.length &&
      omnitureData &&
      omnitureData.couponCode
    ) {
      rawCoupons = [
        {
          couponId: omnitureData.couponCode,
          couponName: omnitureData.couponName || ''
        }
      ];
    }
  }

  if (!items || !Array.isArray(items)) {
    return undefined;
  }

  var buildCoupons = function(orderCoupons) {
    var list = normalizeRawCoupons(orderCoupons);

    if (!list.length) {
      return null;
    }

    return list.map(function(coupon) {
      var couponName = coupon.couponName;

      if (Array.isArray(couponName)) {
        couponName = couponName.length ? String(couponName[0]) : '';
      } else {
        couponName = String(couponName || '');
      }

      return {
        couponId: String(coupon.couponId || ''),
        couponName: couponName,
        discountAmount: Number(coupon.discountAmount) || 0
      };
    });
  };

  var buildCouponLookup = function(orderCoupons) {
    var lookup = {};
    var list = normalizeRawCoupons(orderCoupons);

    if (!list.length) {
      return lookup;
    }

    list.forEach(function(coupon) {
      var couponId = String(coupon.couponId || '');

      if (!couponId) {
        return;
      }

      if (coupon.couponName) {
        lookup[String(coupon.couponName)] = couponId;
      }

      var promotionNames = coupon.promotionNames;

      if (typeof promotionNames === 'string' && promotionNames) {
        promotionNames
          .replace(/[\[\]]/g, '')
          .split(',')
          .forEach(function(name) {
            var trimmedName = name.trim();
            if (trimmedName) {
              lookup[trimmedName] = couponId;
            }
          });
      } else if (Array.isArray(promotionNames)) {
        promotionNames.forEach(function(name) {
          var promoName =
            typeof name === 'string' ? name : String(name.promotionName || '');

          if (promoName) {
            lookup[promoName] = couponId;
          }
        });
      }
    });

    return lookup;
  };

  var couponLookup = buildCouponLookup(rawCoupons);

  var resolveCouponCode = function(promoName, explicitCode) {
    if (explicitCode) {
      return String(explicitCode);
    }

    if (promoName && couponLookup[promoName]) {
      return couponLookup[promoName];
    }

    if (rawCoupons.length === 1) {
      return String(rawCoupons[0].couponId || '');
    }

    return '';
  };

  var buildPromos = function(item) {
    var promos = [];

    if (item.itemPromo && Array.isArray(item.itemPromo)) {
      for (var j = 0; j < item.itemPromo.length; j++) {
        var promo = item.itemPromo[j];
        var promoName = '';

        if (typeof promo === 'string') {
          promoName = promo;
        } else if (promo && typeof promo === 'object') {
          promoName = String(promo.promoName || '');
        }

        promos.push({
          promoName: promoName,
          type: 'item',
          adjustedPrice:
            promo && typeof promo === 'object'
              ? Number(promo.adjustedPrice) || 0
              : 0,
          discount: 0,
          couponCode: resolveCouponCode(
            promoName,
            promo && typeof promo === 'object' ? promo.couponCode : ''
          )
        });
      }
    }

    if (item.orderPromo && Array.isArray(item.orderPromo)) {
      for (var k = 0; k < item.orderPromo.length; k++) {
        var orderPromo = item.orderPromo[k];
        var orderPromoName = String(orderPromo.promoName || '');

        promos.push({
          promoName: orderPromoName,
          type: 'order',
          adjustedPrice: 0,
          discount: Number(orderPromo.discount) || 0,
          couponCode: resolveCouponCode(orderPromoName, orderPromo.couponCode)
        });
      }
    }

    return promos;
  };

  var normalizedItems = items.map(function(item) {
    var normalized;

    if (item.displayId) {
      normalized = Object.assign({}, item);
    } else {
      normalized = {
        displayId: item.id,
        productId: item.productId,
        salePrice: parseFloat(item.price),
        displayName: item.name,
        quantity: item.quantity,
        skuSeoUrl: item.url,
        total: parseFloat(item.itemTotal),
        discount: parseFloat(item.discount)
      };
    }

    var promos = buildPromos(item);

    if (promos.length > 0) {
      normalized.promos = promos;
    }

    return normalized;
  });

  var result = {
    orderId: orderId,
    cartItems: normalizedItems,
    subtotal: subtotal
  };

  var coupons = couponApplied ? buildCoupons(rawCoupons) : null;

  if (coupons) {
    result.coupons = coupons;
  }

  return result;
} catch (err) {
  console.error('[QM Cart ID MF] Error:', err);
  return undefined;
}}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":117,"f":0,"m":0,"s":1,"u":"\\/checkout","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {try {
  return window.dataLayer._state.checkoutStepChanged.order.commerceItems;
}catch(err) {
  
}}}]},{"t":"JSValue","v":[{"fn":function () {try{
  var productList = [];
  var items = window.dataLayer._state.checkoutStepChanged.order.commerceItems;
    items.forEach(function(item) {
    productList.push(item.displayId + ": " + item.quantity);
  });
  var productString = productList.join(' | ');
    var itemObj = {
    cartItems: items
  };
  window.QuantumMetricAPI.sendEvent(116, 0, productString, itemObj);
  return productString;
}catch(err){
}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var items = window.dataLayer._state.checkoutStepChanged.order.commerceItems;
  var returnObj = {
    checkoutItems: items
  };
  return returnObj;
  } catch (err) {}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":118,"f":0,"m":0,"s":1,"u":".*","x":"QCC","v":{"t":"E","v":[{"t":"SelectorPresent","v":[".mini-pdp ~ section .plp-container"]},{"t":"V","v":[""]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":121,"f":0,"m":0,"s":1,"u":".*","x":"QCC","v":{"t":"MDE","v":[{"t":"SelectorPresent","v":["#pdp-layout section .product-sticker"]},{"t":"JSValueEx","v":[{"fn":function () {(function () {
  try {
    var returnObj = {
      'stickers': Array.from(
        document.querySelectorAll('#pdp-layout section .product-sticker')
      ).map(function (el) {
        return { 'name': el.innerText.trim().toLowerCase() };
      })
    };
    window.QuantumMetricAPI.sendEvent(
      121,
      0,
      returnObj.stickers.length,
      returnObj
    );
  } catch (err) {}
})();}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"f":0,"i":123,"evalAlways":false,"m":0,"s":1,"u":"\\/cart","v":{"t":"E","v":[{"t":"SelectorPresent","v":["#demoGear"]},{"t":"V","v":[""]}]},"x":"QCC","sessionInfoReq":false,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":125,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":["// Monetate recommendation \"Add to Cart\" (button.qm-atc).\n// XHR addItemToOrder → QM Web - Cart Additions.js fires Event 79 on the request.\n// Helper only refreshes mini-cart + pushes cartAdditions dataLayer for GTM.\n\nvar QM_MONETATE_RECS_CART_ADDITIONS_LOG =\n  '[QM Monetate Recs Cart Additions / Event 79]';\n\ntry {\n  var buildMonetateRecsCartAdditionsPayload = function(\n    addItemToOrderRequest,\n    atcLocation,\n    pfmValue\n  ) {\n    var resolvedPfm = pfmValue || localStorage.getItem('passPFM') || '';\n    var cartLineItems = (addItemToOrderRequest && addItemToOrderRequest.items) || [];\n    var cartAdditionsPayload = {\n      items: [],\n      pfm: resolvedPfm,\n      ATCLocation: atcLocation || ''\n    };\n\n    cartLineItems.forEach(function(lineItem) {\n      var cartLine = Object.assign({}, lineItem);\n      if (cartLine.catalogRefId && String(cartLine.catalogRefId).indexOf('site5') !== -1) {\n        cartLine.catalogRefId = cartLine.catalogRefId.split('site5')[1];\n      }\n      if (cartLine.productId) {\n        delete cartLine.productId;\n      }\n      if (cartLine.itemName && !cartLine.productName) {\n        cartLine.productName = cartLine.itemName;\n      }\n      cartAdditionsPayload.items.push(cartLine);\n    });\n\n    return cartAdditionsPayload;\n  };\n\n  var pushMonetateRecsCartAdditionsDataLayer = function(cartAdditionsPayload) {\n    if (!window.dataLayer || !cartAdditionsPayload.items.length) {\n      return;\n    }\n\n    window.dataLayer.push({\n      event: 'cartAdditions',\n      cartAdditions: {\n        pfm: cartAdditionsPayload.pfm,\n        ATCLocation: cartAdditionsPayload.ATCLocation,\n        source: 'monetateRecs',\n        items: cartAdditionsPayload.items\n      }\n    });\n  };\n\n  var completeMonetateRecsCartAdditions = function(\n    payloadApi,\n    addLocation,\n    pfmTopLevel\n  ) {\n    if (\n      typeof window.GCI !== 'undefined' &&\n      window.GCI.reactUtils &&\n      typeof window.GCI.reactUtils.refreshMiniCart === 'function'\n    ) {\n      window.GCI.reactUtils.refreshMiniCart();\n    }\n\n    var cartAdditionsPayload = buildMonetateRecsCartAdditionsPayload(\n      payloadApi,\n      addLocation,\n      pfmTopLevel\n    );\n    pushMonetateRecsCartAdditionsDataLayer(cartAdditionsPayload);\n  };\n\n  if (!window._recsAddToCartQMLIstenerSet) {\n    window._recsAddToCartQMLIstenerSet = true;\n\n    var addItemToOrderApiUrl =\n      '/rest/model/atg/checkout/checkoutActor/addItemToOrder?storeId=123&SPA=true';\n\n    document.addEventListener('click', function(event) {\n      var target = event.target;\n      var button = target && target.closest('button.qm-atc');\n\n      if (button) {\n        try {\n        if (window._monetateRecsAtcInFlight) {\n          return;\n        }\n\n        event.preventDefault();\n        event.stopPropagation();\n\n        var merchItemContainer = button.closest('.mt-merch-item');\n        var productData = {};\n        var dataProductEl = merchItemContainer\n          ? merchItemContainer.querySelector('[data-product]')\n          : null;\n        if (dataProductEl) {\n          try {\n            var jsonStr = dataProductEl.getAttribute('data-product');\n            if (jsonStr) {\n              productData = JSON.parse(jsonStr);\n            }\n          } catch (e) { /* fallback to DOM */ }\n        }\n\n        var dataPid = productData.id || button.getAttribute('data-pid');\n        var quantity = parseInt(button.getAttribute('data-quantity') || '1', 10);\n        var catalogRefId = 'site5' + dataPid;\n        var recsData = {};\n        var addLocation = 'Unknown Rec Location';\n        var pfmTopLevel = '';\n\n        if (merchItemContainer) {\n          recsData.sku = merchItemContainer.getAttribute('data-sku');\n          recsData.rec_set_id = merchItemContainer.getAttribute('data-rec-set-id');\n          recsData.slot_index = merchItemContainer.getAttribute('data-slot-index');\n\n          var mtLink = merchItemContainer.querySelector('.mt-link');\n          if (mtLink && mtLink.href) {\n            var href = mtLink.href;\n            var pfmMatch = href.match(/pfm=([^&]*)/);\n            if (pfmMatch && pfmMatch[1]) {\n              recsData.pfm = pfmMatch[1];\n              pfmTopLevel = pfmMatch[1];\n            }\n          }\n\n          var parentSlider = merchItemContainer.closest('[id^=\"mt-slider-\"]');\n          if (parentSlider && parentSlider.id) {\n            var idMatch = parentSlider.id.match(/mt-slider-(\\d+)-/);\n            if (idMatch && idMatch[1]) {\n              addLocation = 'Monetate Rec: ' + idMatch[1];\n            } else {\n              addLocation = 'Monetate Rec: ' + parentSlider.id;\n            }\n          } else {\n            addLocation = 'Monetate Rec';\n          }\n        }\n\n        var item_name = productData.title || button.getAttribute('data-product-name');\n        if (!item_name && merchItemContainer) {\n          var mtTitle = merchItemContainer.querySelector('.mt-title');\n          if (mtTitle) {\n            item_name = mtTitle.textContent.trim();\n          }\n        }\n        item_name = item_name || 'Unknown Product';\n\n        if (productData.recSetId) {\n          recsData.rec_set_id = productData.recSetId;\n        }\n\n        var price = 0;\n        var sp = productData.salePrice;\n        var p = productData.price;\n        if (sp != null && sp !== '' && !isNaN(parseFloat(sp))) {\n          price = parseFloat(sp);\n        } else if (p != null && p !== '' && !isNaN(parseFloat(p))) {\n          price = parseFloat(p);\n        }\n        if (isNaN(price)) {\n          price = parseFloat(button.getAttribute('data-price'));\n          if (isNaN(price) && merchItemContainer) {\n            price = parseFloat(merchItemContainer.getAttribute('data-price'));\n          }\n        }\n        price = isNaN(price) ? 0 : price;\n\n        var payloadApi = {\n          addItemCount: quantity,\n          pfm: pfmTopLevel,\n          ATCLocation: addLocation,\n          excludeOmnitureData: false,\n          items: [\n            {\n              catalogRefId: catalogRefId,\n              commerceType: 'New',\n              quantity: quantity,\n              itemName: item_name,\n              price: price,\n              sku: recsData.sku,\n              recSetId: recsData.rec_set_id,\n              slotIndex: recsData.slot_index\n            }\n          ]\n        };\n\n        try {\n          var dynSessConf = localStorage.getItem('dynSessConf');\n          if (dynSessConf) {\n            payloadApi._dynSessConf = dynSessConf;\n          }\n        } catch (sessionErr) {\n          console.error(\n            QM_MONETATE_RECS_CART_ADDITIONS_LOG,\n            'could not read dynSessConf from localStorage',\n            sessionErr\n          );\n        }\n\n        window._monetateRecsAtcInFlight = true;\n\n        var addItemToOrderXhr = new XMLHttpRequest();\n        addItemToOrderXhr.open('POST', addItemToOrderApiUrl, true);\n        addItemToOrderXhr.withCredentials = true;\n        addItemToOrderXhr.timeout = 20000;\n        addItemToOrderXhr.setRequestHeader('Content-Type', 'application/json');\n\n        addItemToOrderXhr.onload = function() {\n          window._monetateRecsAtcInFlight = false;\n\n          if (\n            addItemToOrderXhr.status < 200 ||\n            addItemToOrderXhr.status >= 300\n          ) {\n            console.error(\n              QM_MONETATE_RECS_CART_ADDITIONS_LOG,\n              'addItemToOrder XHR failed',\n              addItemToOrderXhr.status,\n              addItemToOrderXhr.statusText\n            );\n            if (window.dataLayer) {\n              window.dataLayer.push({\n                event: 'cartAdditionsError',\n                error: addItemToOrderXhr.statusText,\n                ATCLocation: addLocation,\n                catalogRefId: catalogRefId\n              });\n            }\n            return;\n          }\n\n          completeMonetateRecsCartAdditions(\n            payloadApi,\n            addLocation,\n            pfmTopLevel\n          );\n        };\n\n        addItemToOrderXhr.onerror = function() {\n          window._monetateRecsAtcInFlight = false;\n          console.error(\n            QM_MONETATE_RECS_CART_ADDITIONS_LOG,\n            'addItemToOrder XHR network error'\n          );\n          if (window.dataLayer) {\n            window.dataLayer.push({\n              event: 'cartAdditionsError',\n              error: 'Network request failed',\n              ATCLocation: addLocation,\n              catalogRefId: catalogRefId\n            });\n          }\n        };\n\n        addItemToOrderXhr.ontimeout = function() {\n          window._monetateRecsAtcInFlight = false;\n          console.error(\n            QM_MONETATE_RECS_CART_ADDITIONS_LOG,\n            'addItemToOrder XHR timed out after 20s'\n          );\n        };\n\n        addItemToOrderXhr.send(JSON.stringify(payloadApi));\n        } catch (clickHandlerErr) {\n          console.error(\n            QM_MONETATE_RECS_CART_ADDITIONS_LOG,\n            'click handler error before/during fetch',\n            clickHandlerErr\n          );\n          if (window.handleQMError) {\n            window.handleQMError('125', clickHandlerErr);\n          }\n        }\n      }\n    });\n  }\n} catch (err) {\n  console.error(QM_MONETATE_RECS_CART_ADDITIONS_LOG, 'helper setup error', err);\n  if (window.handleQMError) {\n    window.handleQMError('125', err);\n  }\n}\n"]},{"t":"V","v":[""]}]}},{"f":0,"i":126,"evalAlways":false,"m":0,"s":1,"u":".*","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"URLParamsValue","v":[{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/location/href"]},"icid"]},{"t":"Exists","v":[]}]},{"t":"URLParamsValue","v":[{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/location/href"]},"icid"]}]},"x":"QUR","sessionInfoReq":false,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":127,"f":0,"m":0,"s":1,"u":".*","x":"QCC","v":{"t":"E","v":[{"t":"SelectorPresent","v":[".custom-ship-box+.open-email,div.PDPCTA-wrapper .open-email"]},{"t":"URLPropValue","v":[{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/location/href"]},"pathname"]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":true,"i":128,"f":0,"m":1,"s":2,"u":".*","x":"QCC","v":{"t":"E","v":[{"t":"SelectorPresent","v":["button[id^=\"deliveryMethod\"][class*=\"bg-\"]"]},{"t":"JSValueEx","v":[{"fn":function () {try {
  if (!localStorage.getItem(location.href+"|delivery")) {
    localStorage.setItem(location.href+"|delivery", "true");
    return document.querySelector('button[id^="deliveryMethod"][class*="bg-"]').innerText;
  }
}
catch (err) {}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":132,"f":0,"m":0,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
  return window.monetateCampaigns && window.monetateCampaigns.length > 0;
}
catch (err) {
}}}]},{"t":"JSValue","v":[{"fn":function () {try{

var mcs = window.monetateCampaigns;
 if (!!mcs) {
  for (var i = 0; i < mcs.length && i < 20; i++) {
   var c = mcs[i],
     key = !!c ? c.key : "",
     vId = !!c ? c.variant_id : "",
     exp = !!c ? c.split : "";
     QuantumMetricAPI.sendEvent(139, 0, vId + "|" + key + "|" + exp, c);
  }
 }
 return window.location.href;
}catch(e){ this.api.sendEvent(159,0, 'Campaign Detected Error Msg:' + e);}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":133,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"V","v":[""]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":134,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"V","v":[""]}]}},{"f":0,"i":136,"evalAlways":false,"m":1,"s":2,"u":".*","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]}]},"x":"QJS","sessionInfoReq":true,"excludeBlank":false},{"f":0,"i":137,"evalAlways":false,"m":0,"s":1,"u":".*","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return true;}}]},{"t":"JSValue","v":[{"fn":function () {// Get source code and determine if it's NEW (from URL/referrer) or existing (from localStorage)
// Priority: URL ?source= param → srsltid → localStorage (with 30-day expiry) → referrer
var sourceCodeResult = (function() {
  var isGC = window.location.hostname.includes('guitarcenter');
  var directSourceCode = isGC ? 'GCDIRECTSOURCECODE1' : 'DIRECTSOURCECODE2';
  
  try {
    var urlParams = new URLSearchParams(window.location.search);
    
    // 1. Check URL for ?source= parameter (highest priority - new campaign)
    var sourceParam = urlParams.get('source');
    if (sourceParam) {
      return { code: sourceParam.toUpperCase(), isNew: true };
    }
    
    // 2. Check for srsltid (Google Shopping - new campaign)
    var srsltidParam = urlParams.get('srsltid');
    if (srsltidParam) {
      return { code: (isGC ? '4SOSWXXA' : '3SOSWXXA'), isNew: true };
    }
    
    // 3. Check localStorage (preserve existing campaigns unless expired)
    // BUT: only preserve real campaigns, not direct source codes
    if (window.localStorage && window.localStorage.getItem('src_code')) {
      var storedCode = window.localStorage.getItem('src_code');
      
      // Skip if it's a direct source code - let referrer override it
      if (storedCode !== 'GCDIRECTSOURCECODE1' && storedCode !== 'DIRECTSOURCECODE2') {
        var timestamp = parseInt(window.localStorage.getItem('src_code_timestamp'), 10);
        
        // Check if expired (30 days)
        if (timestamp) {
          var now = Date.now();
          var thirtyDaysInMs = 30 * 24 * 60 * 60 * 1000;
          
          if (now - timestamp <= thirtyDaysInMs) {
            // Not expired - use stored campaign
            return { code: storedCode, isNew: false };
          }
          // If expired, continue to check referrer/direct
        } else {
          // No timestamp, but has source code - use it
          return { code: storedCode, isNew: false };
        }
      }
      // If it IS a direct source code, fall through to check referrer
    }
    
    // 4. Check referrer (lowest priority - only if no stored campaign)
    var referrer = document.referrer;
    if (referrer) {
      var customSourceCodes = isGC ? [
        { name: "google.com/", sourceCode: "4SOSWXXA" },
        { name: "bing.com/", sourceCode: "4SOSWXXM" },
        { name: "yahoo.com/", sourceCode: "4SOSWXXB" },
        { name: "lycos.com/", sourceCode: "4SOSWXXC" }
      ] : [
        { name: "google.com/", sourceCode: "3SOSWXXA" },
        { name: "bing.com/", sourceCode: "3SOSWXXM" },
        { name: "yahoo.com/", sourceCode: "3SOSWXXB" }
      ];
      
      for (var i = 0; i < customSourceCodes.length; i++) {
        if (referrer.indexOf(customSourceCodes[i].name) > -1) {
          return { code: customSourceCodes[i].sourceCode, isNew: true };
        }
      }
      
      // External referrer (not from own site)
      var ownDomain = isGC ? 'guitarcenter.com' : 'musiciansfriend.com';
      if (referrer.indexOf(ownDomain) === -1 && referrer !== '') {
        return { code: (isGC ? '4SOSWXXP' : '3SOSWXXA'), isNew: true };
      }
    }
  } catch (e) {}
  
  // Final fallback - direct traffic
  return { code: directSourceCode, isNew: false };
})();

var srcCode = sourceCodeResult.code;

// Build campaign stacking value
var campaignStacking = 'N/A';
try {
  var hasLocalStorage = false;
  try {
    var testLS = '__storage_test__';
    window.localStorage.setItem(testLS, testLS);
    window.localStorage.removeItem(testLS);
    hasLocalStorage = true;
  } catch (e) {}
  
  if (hasLocalStorage) {
    var isGC = window.location.hostname.includes('guitarcenter');
    var directSourceCode = isGC ? 'GCDIRECTSOURCECODE1' : 'DIRECTSOURCECODE2';
    var existingStack = window.localStorage.getItem('src_stacked_campaigns');
    
    if (sourceCodeResult.isNew && existingStack) {
      // New source code detected - build updated stack
      var stackArray = existingStack.split(' > ');
      
      // Only add if it's different from the last item
      if (stackArray[stackArray.length - 1] !== srcCode) {
        // Remove first item if we already have 5
        if (stackArray.length >= 5) {
          stackArray.shift();
        }
        stackArray.push(srcCode);
      }
      
      campaignStacking = stackArray.join(' > ');
    } else if (existingStack) {
      // Use existing stack from localStorage
      campaignStacking = existingStack;
    } else {
      // No existing stack
      campaignStacking = srcCode;
    }
  }
} catch (e) {
  campaignStacking = srcCode || 'N/A';
}

// Clean and parse source code list
var srcCodeList = srcCode.replace(/^"|"$/g, "").split(",");
var parsedSrcCodeList = [];
srcCodeList.forEach(function (part) {
  part = part.trim().toUpperCase();
  part = part.replace(/^\?SOURCE=/, ""); // clean (?)SOURCE= prefixes
  part = part.replace(/\??SOURCE=.*$/, ""); // clean (?)SOURCE= suffixes
  part = part.replace(/HTTPS?:\/\/.*$/, ""); // clean url suffixes
  part = part.replace(/[^A-Z0-9_-\s].+$/, ""); // extract the first alphanumeric_- whitespace substring

  if (!parsedSrcCodeList.includes(part)) {
    parsedSrcCodeList.push(part);
  }
});

// Send event 21 (Source Code) for each parsed source code
parsedSrcCodeList.forEach(function (part) {
  try {
    window.QuantumMetricAPI.sendEvent(21, 0, part, { sourceCodeName: part, v: '9.6a' });
  } catch (err) {
    if (window.handleQMError) {
      window.handleQMError("21", err);
    }
  }
});

// Send event 45 (Campaign Stacking)
try {
  window.QuantumMetricAPI.sendEvent(45, 0, campaignStacking, { campaignStacking: campaignStacking, v: '9.6a' });
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError("45", err);
  }
}

return undefined;}}]}]},"x":"QJS","sessionInfoReq":false,"excludeBlank":false},{"f":0,"i":138,"evalAlways":false,"m":0,"s":1,"u":"^(.*\\/checkout)(?!.*\\/(?:order-confirmation)).*","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
  var sessionId = JSON.parse(window.localStorage.getItem("QM_S")).s;
  window.localStorage.setItem("QM_Checkout", sessionId);
  return sessionId;
} catch(err) {
  
}}}]},{"t":"V","v":[""]}]},"x":"QJS","sessionInfoReq":false,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":139,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":140,"f":0,"m":0,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
    var value = window.dataLayer.filter(function (obj) {
      return (
        obj.eventName === "monetateVariants" &&
        obj.monetateVariants
      );
    });
      return value[0].monetateVariants;
  } catch (error) {}}}]},{"t":"JSValue","v":[{"fn":function () {try {
    var value = window.dataLayer.filter(function (obj) {
      return (
        obj.eventName === "monetateVariants" &&
        obj.monetateVariants
      );
    });
  var variantId = value[0].monetateVariants.split('|')[0];
  var key = value[0].monetateVariants.split('|')[1];
  var monObj = {variant_id: variantId,
               key: key};
  window.QuantumMetricAPI.sendEvent(139,0,value[0].monetateVariants,monObj);
      return value[(value.length-1)].monetateVariants;
  } catch (error) {}}}]}]}},{"sessionInfoReq":false,"evalAlways":true,"excludeBlank":false,"i":141,"f":0,"m":0,"s":1,"u":".*","x":"QCC","v":{"t":"E","v":[{"t":"SelectorPresent","v":["[id=\"exitIntentEmailPopupCapture\"]"]},{"t":"SelectorAttribute","v":[{"t":"SelectorElement","v":["#exitIntentEmailPopupCapture"]},"data-evg-campaign-name"]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":142,"f":0,"m":0,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"V","v":[""]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":143,"f":0,"m":1,"s":1,"u":".*","x":"QCE","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["[id=\"exitIntentEmailPopupCapture\"] .exit-popup-shop-best-seller,[id=\"exitIntentEmailPopupCapture\"] .exit-popup-shop-best-seller *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try { return (this.api || QuantumMetricAPI).lastClicked ? (this.api || QuantumMetricAPI).lastClicked.innerText : ""; } catch (e) {}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":144,"f":0,"m":1,"s":1,"u":".*","x":"QCE","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["[id=\"exitIntentEmailPopupCapture\"] button.exit-popup-continue,[id=\"exitIntentEmailPopupCapture\"] button.exit-popup-continue *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try { return (this.api || QuantumMetricAPI).lastClicked ? (this.api || QuantumMetricAPI).lastClicked.innerText : ""; } catch (e) {}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":145,"f":0,"m":1,"s":1,"u":".*","x":"QCE","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["[id=\"exitIntentEmailPopupCapture\"] button.exit-popup-exit,[id=\"exitIntentEmailPopupCapture\"] button.exit-popup-exit *"]}]},{"t":"V","v":[""]}]}},{"f":0,"i":146,"evalAlways":false,"m":1,"s":1,"u":".*","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["[id=\"exitIntentEmailPopupCapture\"] button[class=\"exit-popup-opt-out\"],[id=\"exitIntentEmailPopupCapture\"] button[class=\"exit-popup-opt-out\"] *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try { return (this.api || QuantumMetricAPI).lastClicked ? (this.api || QuantumMetricAPI).lastClicked.innerText : ""; } catch (e) {}}}]}]},"x":"QCE","sessionInfoReq":false,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":147,"f":0,"m":1,"s":1,"u":".*","x":"QCE","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["[id=\"exitIntentEmailPopupCapture\"] .exit-popup-overlay,[id=\"exitIntentEmailPopupCapture\"] .exit-popup-overlay *"]}]},{"t":"V","v":[""]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":149,"f":0,"m":0,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
   return true;
} catch(err){}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  // gclid/fbclid capture for MCP tracking (port from Adobe source_code_handler)
  var checkAndUpdateExpiredItem = function(key, days) {
    var now = Date.now();
    var timestamp = parseInt(localStorage.getItem(key + '_timestamp'), 10);
    var daysInMs = days * 24 * 60 * 60 * 1000;
    if (now - timestamp > daysInMs) {
      localStorage.removeItem(key);
      localStorage.removeItem(key + '_timestamp');
    }
  };
  var checkConfirmationPage = window.location.href.indexOf('/checkout/order-confirmation') !== -1;
  var isCheckoutPage = window.location.href.indexOf('/checkout/') !== -1;
  if (!checkConfirmationPage) {
    try {
      var urlParams = new URLSearchParams(window.location.search);
      var gclidParam = urlParams.get('gclid');
      if (gclidParam) {
        localStorage.setItem('gclid', gclidParam);
        localStorage.setItem('gclid_timestamp', Date.now());
      }
      var fbclidParam = urlParams.get('fbclid');
      if (fbclidParam) {
        localStorage.setItem('fbclid', fbclidParam);
        localStorage.setItem('fbclid_timestamp', Date.now());
      }
      if (localStorage.getItem('gclid_timestamp')) {
        checkAndUpdateExpiredItem('gclid', 90);
      }
      if (localStorage.getItem('fbclid_timestamp')) {
        checkAndUpdateExpiredItem('fbclid', 28);
      }
    } catch (e) {}
  }

  // Helper function to normalize page types
  var normalizePageType = function(pageType) {
    if (!pageType) {
      return undefined;
    }
    
    var plpPageTypes = [
      'product collection',
      'store inventory',
      'brand',
      'vintage',
      'outlet',
      'platinum',
      'sub category1',
      'sub category2',
      'sub category3',
      'sub category4',
      'sub category5',
      'used'
    ];
    
    if (plpPageTypes.indexOf(pageType.toLowerCase()) !== -1) {
      return 'product listing page';
    }
    
    return pageType;
  };

  // Build the custom page view payload for QM send only
  var buildCustomPageViewPayload = function(omnitureData) {
    if (!omnitureData) {
      return undefined;
    }
    
    // LocalStorage-derived values
    var hasLocalStorage = false;
    try {
      var testLS = '__storage_test__';
      localStorage.setItem('testLS', testLS);
      localStorage.removeItem('testLS');
      hasLocalStorage = true;
    } catch (err) {
      if (window.handleQMError) {
        window.handleQMError('149', err);
      }
    }
    
    // Get current source code and determine if it's NEW (from URL/referrer) or existing (from localStorage)
    // Priority: URL ?source= param → srsltid → localStorage (with 30-day expiry) → referrer
    var sourceCodeResult = (function() {
      var isGC = window.location.hostname.includes('guitarcenter');
      var directSourceCode = isGC ? 'GCDIRECTSOURCECODE1' : 'DIRECTSOURCECODE2';
      
      try {
        var urlParams = new URLSearchParams(window.location.search);
        
        // 1. Check URL for ?source= parameter (highest priority - new campaign)
        var sourceParam = urlParams.get('source');
        if (sourceParam) {
          return { code: sourceParam.toUpperCase(), isNew: true };
        }
        
        // 2. Check for srsltid (Google Shopping - new campaign)
        var srsltidParam = urlParams.get('srsltid');
        if (srsltidParam) {
          return { code: (isGC ? '4SOSWXXA' : '3SOSWXXA'), isNew: true };
        }
        
           // 3. Check localStorage (preserve existing campaigns unless expired)


if (hasLocalStorage && localStorage.getItem('src_code')) {
  var storedCode = localStorage.getItem('src_code');

  
  // Skip if it's a direct source code - let referrer override it
  if (storedCode !== 'GCDIRECTSOURCECODE1' && storedCode !== 'DIRECTSOURCECODE2') {
    var timestamp = parseInt(localStorage.getItem('src_code_timestamp'), 10);

            
            // Check if expired (30 days)
            if (timestamp) {
              var now = Date.now();
              var thirtyDaysInMs = 30 * 24 * 60 * 60 * 1000;
              
              if (now - timestamp <= thirtyDaysInMs) {
                // Not expired - use stored campaign
                return { code: storedCode, isNew: false };
              }
              // If expired, continue to check referrer/direct
            } else {
              // No timestamp, but has source code - use it
              return { code: storedCode, isNew: false };
            }
          }
          // If it IS a direct source code, fall through to check referrer
        }
        
        // 4. Check referrer (lowest priority - only if no stored campaign)
        var referrer = document.referrer;
        if (referrer) {
          var customSourceCodes = isGC ? [
            { name: "google.com/", sourceCode: "4SOSWXXA" },
            { name: "bing.com/", sourceCode: "4SOSWXXM" },
            { name: "yahoo.com/", sourceCode: "4SOSWXXB" },
            { name: "lycos.com/", sourceCode: "4SOSWXXC" }
          ] : [
            { name: "google.com/", sourceCode: "3SOSWXXA" },
            { name: "bing.com/", sourceCode: "3SOSWXXM" },
            { name: "yahoo.com/", sourceCode: "3SOSWXXB" }
          ];
          
          for (var i = 0; i < customSourceCodes.length; i++) {
            if (referrer.indexOf(customSourceCodes[i].name) > -1) {
              return { code: customSourceCodes[i].sourceCode, isNew: true };
            }
          }
          
          // External referrer (not from own site)
          var ownDomain = isGC ? 'guitarcenter.com' : 'musiciansfriend.com';
          if (referrer.indexOf(ownDomain) === -1 && referrer !== '') {
            return { code: (isGC ? '4SOSWXXP' : '3SOSWXXA'), isNew: true };
          }
        }
      } catch (e) {}
      
      // Final fallback - direct traffic
      return { code: directSourceCode, isNew: false };
    })();
    
    var sourceCode = sourceCodeResult.code;
    
    // Save source code to localStorage with timestamp when new or missing.
    // This ensures direct traffic is explicitly persisted as src_code.
    if (hasLocalStorage) {
      try {
        var existingSrcCode = localStorage.getItem('src_code');
        if (sourceCodeResult.isNew || !existingSrcCode || existingSrcCode === '') {
          localStorage.setItem('src_code', sourceCode);
          localStorage.setItem('src_code_timestamp', Date.now().toString());
        }
      } catch (e) {
        if (window.handleQMError) {
          window.handleQMError('149', e);
        }
      }
    }
    
    // On checkout: preserve sourceCodeNameQM from src_code so order confirmation has it (backup before any clearing)
    if (hasLocalStorage && isCheckoutPage) {
      try {
        var validSrc = sourceCode !== 'GCDIRECTSOURCECODE1' && sourceCode !== 'DIRECTSOURCECODE2';
        if (validSrc) {
          localStorage.setItem('sourceCodeNameQM', sourceCode);
        }
      } catch (e) {}
    }
    
    // Parse source code using QM enrichment logic
    var parseSourceCode = function(srcCode) {
      if (!srcCode) return '';
      
      var srcCodeList = srcCode.replace(/^"|"$/g, "").split(",");
      var parsedSrcCodeList = [];
      
      srcCodeList.forEach(function (part) {
        part = part.trim().toUpperCase();
        part = part.replace(/^\?SOURCE=/, ""); // clean (?)SOURCE= prefixes
        part = part.replace(/\??SOURCE=.*$/, ""); // clean (?)SOURCE= suffixes
        part = part.replace(/HTTPS?:\/\/.*$/, ""); // clean url suffixes
        part = part.replace(/[^A-Z0-9_-\s].+$/, ""); // extract the first alphanumeric_- whitespace substring
        
        if (part && !parsedSrcCodeList.includes(part)) {
          parsedSrcCodeList.push(part);
        }
      });
      
      return parsedSrcCodeList[0] || srcCode; // Return first parsed code or original
    };
    
    var parsedSourceCode = parseSourceCode(sourceCode);
    var isGC = window.location.hostname.includes('guitarcenter');
    var directSourceCode = isGC ? 'GCDIRECTSOURCECODE1' : 'DIRECTSOURCECODE2';
    var campaignStacking = directSourceCode;
    
    // Build campaign stacking (use parsed source code)
    if (hasLocalStorage) {
      try {
        var existingStack = localStorage.getItem('src_stacked_campaigns');
        
        if (sourceCodeResult.isNew && existingStack) {
          // New source code detected - build updated stack
          var stackArray = existingStack.split(' > ');
          
          // Only add if it's different from the last item
          if (stackArray[stackArray.length - 1] !== parsedSourceCode) {
            // Remove first item if we already have 5
            if (stackArray.length >= 5) {
              stackArray.shift();
            }
            stackArray.push(parsedSourceCode);
          }
          
          campaignStacking = stackArray.join(' > ');
          
          // Save updated stack to localStorage
          localStorage.setItem('src_stacked_campaigns', campaignStacking);
        } else if (existingStack) {
          // Use existing stack from localStorage
          campaignStacking = existingStack;
        } else {
          // No existing stack - initialize with current source code
          campaignStacking = parsedSourceCode;
          
          // Save initial stack to localStorage
          localStorage.setItem('src_stacked_campaigns', campaignStacking);
        }
      } catch (e) {
        campaignStacking = parsedSourceCode;
        if (window.handleQMError) {
          window.handleQMError('149', e);
        }
      }
    }
    
      // Login status from dataLayer only; omit if unavailable
      var loginStatus;
      try {
      var ls = window.dataLayer && window.dataLayer._state && window.dataLayer._state.userLoginStatus;
      // If string, try to parse into an object
      if (typeof ls === 'string') {
          try {
          ls = JSON.parse(ls);
          } catch (eParse) {}
      }
      // Accept only objects with expected flags
      if (ls && typeof ls === 'object' &&
          (typeof ls.isLoggedIn !== 'undefined' || typeof ls.cookieLoggedIn !== 'undefined')) {
          loginStatus = ls; // keep as object
      }
      } catch (e3) {}
    
    // Extract page data with fallbacks
    var pageTitle = document.title || omnitureData.pageTitle || '';
    var pageType = omnitureData.pageType || '';
    if (pageType && typeof pageType === 'string') {
      pageType = pageType.trim();
    }
    
    
    var normalizedPageType = normalizePageType(pageType);
    var pageName = omnitureData.pageName || normalizedPageType || pageType;
    var isMF = window.location.hostname.indexOf('musiciansfriend') > -1;
    var mfJsessionId = isMF &&
      window.GCI &&
      window.GCI.digitalData &&
      window.GCI.digitalData.JSESSIONID
      ? window.GCI.digitalData.JSESSIONID
      : '';
    var jsessionId = omnitureData.sessionId || mfJsessionId || '';
    
    
    var previousPageType;
    try {
      var cartFlag = localStorage.getItem('quantumCartPreviousPageType');
      if (cartFlag) {
        previousPageType = cartFlag;
        localStorage.removeItem('quantumCartPreviousPageType');
      } else {
        previousPageType = window.QuantumMetricAPI && window.QuantumMetricAPI.getSessionVar ? 
          window.QuantumMetricAPI.getSessionVar('qm_previous_page_type', '') : undefined;
        if (previousPageType === '') previousPageType = undefined;
      }
    } catch (e) {}
    
    if (!normalizedPageType && !pageType && !pageName) {
      return undefined;
    }
    
    var payload = {
      'pageTitle': pageTitle,
      'baseUrl': window.location.origin + window.location.pathname,
      'fullUrl': window.location.href,
      'referrer': document.referrer,
      'userAgent': navigator.userAgent,
      'pageType': normalizedPageType || pageType,
      'pageName': pageName,
      'timestamp': Date.now(),
      'sourceCodeName': parsedSourceCode,
      'campaignStacking': campaignStacking,
      'sendEventLocation': 'Quantum',
      'jsessionId': jsessionId,
      'atgId': omnitureData.ATGID || omnitureData.atgId || ''
    };
    
    if (normalizedPageType) {
      payload.pageType = normalizedPageType;
    }
    
    if (previousPageType) {
      payload.previousPageType = previousPageType;
    }
    
    if (typeof loginStatus !== 'undefined') {
      payload.isLoggedIn = loginStatus.isLoggedIn;
      payload.cookieLoggedIn = loginStatus.cookieLoggedIn;
    }

    var country =
      (window.GCI &&
        window.GCI.digitalData &&
        window.GCI.digitalData.omnitureData &&
        window.GCI.digitalData.omnitureData.countryName) ||
      omnitureData.countryName;
    if (country) {
      payload.country = country;
    }
    
    return payload;
  };
  
  // Try to get omniture data from multiple known shapes
  var getOmnitureData = function() {
    var direct = null;
    if (window.GCI && window.GCI.digitalData && window.GCI.digitalData.omnitureData) {
      direct = window.GCI.digitalData.omnitureData;
    }
    if (direct) {
      return direct;
    }
    
    var dlState = null;
    if (window.dataLayer && window.dataLayer._state && window.dataLayer._state.omnitureLoaded) {
      dlState = window.dataLayer._state.omnitureLoaded;
    }
    if (!dlState) {
      return null;
    }
    
    if (dlState.omnitureData) {
      return dlState.omnitureData;
    }
    // Fallback: use the dlState object itself
    return dlState;
  };

  var fireCustomPageView = function(omnitureData) {
    if (!omnitureData || !window.QuantumMetricAPI || !window.QuantumMetricAPI.sendEvent) {
      return false;
    }

    var rawPageType = omnitureData.pageType || '';
    if (rawPageType && typeof rawPageType === 'string') {
      rawPageType = rawPageType.trim();
    }
    
    var shouldUpdateSessionVar = rawPageType ? true : false;
    
    var payload = buildCustomPageViewPayload(omnitureData);
    if (!payload) {
      return false;
    }

    try {
      window.QuantumMetricAPI.sendEvent(76, 0, payload.pageType, payload);
      window._qmCustomPageViewBackupResolved = true;
      
      var canSendEntry = true;
      try {
        var lastEntryUrl = window.QuantumMetricAPI.getSessionVar ? window.QuantumMetricAPI.getSessionVar('entryPageType', '') : '';
        if (lastEntryUrl === location.href) {
          canSendEntry = false;
        }
      } catch (e1) {}
      
      if (canSendEntry) {
        window.QuantumMetricAPI.sendEvent(60, 0, payload.pageType, payload);
        try {
          if (window.QuantumMetricAPI.setSessionVar) {
            window.QuantumMetricAPI.setSessionVar('entryPageType', location.href);
          }
        } catch (e2) {}
      }
      
      if (shouldUpdateSessionVar && window.QuantumMetricAPI && window.QuantumMetricAPI.setSessionVar) {
        window.QuantumMetricAPI.setSessionVar('qm_previous_page_type', rawPageType);
      }
      
      // Set localStorage flag AFTER sending events so it doesn't get consumed on the same page
      if (rawPageType === 'shopping cart') {
        try {
          localStorage.setItem('quantumCartPreviousPageType', 'shopping cart');
        } catch (e) {}
      }

      return true;
    } catch (e) {
      if (window.handleQMError) {
        window.handleQMError('149', e);
      }
      return false;
    }
  };

  var initialFireComplete = fireCustomPageView(getOmnitureData());

  if (!initialFireComplete && !window._qmCustomPageViewOmnitureLoadedListenerSet) {
    window._qmCustomPageViewOmnitureLoadedListenerSet = true;
    window.addEventListener('dlUpdateEvent', function(event) {
      var eventData = event && (event.detail || event);
      if (!eventData || eventData.eventName !== 'omnitureLoaded' || window._qmCustomPageViewBackupResolved) {
        return;
      }

      var backupOmnitureData = getOmnitureData() || eventData.omnitureData || eventData;
      fireCustomPageView(backupOmnitureData);
    });
  }
  
  return undefined;
  
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError('149', err);
  }
  return undefined;
}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":150,"f":64,"m":0,"s":1,"u":"\\/checkout","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try{
  // GC path
  if (window.dataLayer && window.dataLayer._state && window.dataLayer._state.checkoutStepChanged && window.dataLayer._state.checkoutStepChanged.order) {
    return window.dataLayer._state.checkoutStepChanged.order.subtotal;
  }
  // MF path
  if (window.GCI && window.GCI.digitalData && window.GCI.digitalData.siteVars && window.GCI.digitalData.siteVars.subtotal) {
    return window.GCI.digitalData.siteVars.subtotal;
  }
}catch(err){
  
}}}]},{"t":"CV","v":[{"t":"JSValue","v":[{"fn":function () {try{
  // GC path
  if (window.dataLayer && window.dataLayer._state && window.dataLayer._state.checkoutStepChanged && window.dataLayer._state.checkoutStepChanged.order) {
    return window.dataLayer._state.checkoutStepChanged.order.subtotal;
  }
  // MF path
  if (window.GCI && window.GCI.digitalData && window.GCI.digitalData.siteVars && window.GCI.digitalData.siteVars.orderSubtotal) {
    return window.GCI.digitalData.siteVars.orderSubtotal;
  }
}catch(err){
  
}}}]}]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":true,"i":151,"f":0,"m":1,"s":2,"u":"\\/checkout|\\/cart","x":"QCC","v":{"t":"E","v":[{"t":"SelectorPresent","v":[".alert-messages-list"]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var aMessages = document.querySelectorAll(".alert-messages-list .alert-item-with-img-container");
  var msgArr = [];
  var alerts = !!window.dataLayer && !!window.dataLayer._state && !!window.dataLayer._state.siteVarsOrderInfoChange && !!window.dataLayer._state.siteVarsOrderInfoChange.orderInfo && !!window.dataLayer._state.siteVarsOrderInfoChange.orderInfo.alertMessages && window.dataLayer._state.siteVarsOrderInfoChange.orderInfo.alertMessages || null;
  aMessages.forEach(function(message, i) {
    var aMessage = message.innerText;
    if (!aMessage.includes('success')) {
      var details = alerts ? alerts[i] : {message: aMessage};
    if (!details.message || details.message === undefined) {
      details.message = aMessage;
    }
    msgArr.push(aMessage);
    window.QuantumMetricAPI.sendEvent(113,0,aMessage,details);
    }
  });
  
  return msgArr;
}
catch (err) {
  if (window.handleQMError) {
    window.handleQMError('151', err);
  }
}}}]}]}},{"f":0,"i":152,"evalAlways":false,"m":1,"s":2,"u":"\\/checkout|\\/cart","v":{"t":"E","v":[{"t":"SelectorPresent","v":[".checkout-error-message"]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var eMessage = document.querySelector('.checkout-error-message').innerText;
  window.QuantumMetricAPI.sendEvent(113,0,eMessage);
  return eMessage;
}
catch (err) {}}}]}]},"x":"QCC","sessionInfoReq":true,"excludeBlank":true},{"f":0,"i":153,"evalAlways":false,"m":1,"s":2,"u":"\\/checkout|\\/cart","v":{"t":"E","v":[{"t":"SelectorPresent","v":[".ant-message-error"]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var mMessage = document.querySelector(".ant-message-error").innerText;
  window.QuantumMetricAPI.sendEvent(113,0,mMessage);
  return mMessage;
}
catch (err) {}}}]}]},"x":"QCC","sessionInfoReq":true,"excludeBlank":true},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":true,"i":154,"f":0,"m":0,"s":2,"u":"\\/search","x":"QUR","v":{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"URLParamsValue","v":[{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/location/href"]},"Ntt"]},{"t":"Exists","v":[]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var searchTerm = ('#header-search-input')[0].value;
  return searchTerm;
}catch(err){}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var obj = {};
  var searchTerm = ('#header-search-input')[0].value;
  obj.searchTerm = searchTerm;
  obj.searchType = "Default";
  return obj;
}
catch (err) {}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":155,"f":0,"m":1,"s":1,"u":".*","x":"QCE,QCE","v":{"t":"MAE","v":[1,0,{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["div:has(>[data-testid=\"left-menu\"]) a,div:has(>[data-testid=\"left-menu\"]) a *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try { return (this.api || QuantumMetricAPI).lastClicked ? (this.api || QuantumMetricAPI).lastClicked.innerText : ""; } catch (e) {}}}]},{"t":"JSValue","v":[{"fn":function () {try{
  var obj = {};
  obj.clicked = window.QuantumMetricAPI.lastClicked.innerText;
  if (window.document.querySelector('div[data-name]:not(.gc-hidden)') && window.document.querySelector('div[data-name]:not(.gc-hidden)').dataset) {
    obj.mainCategory = window.document.querySelector('div[data-name]:not(.gc-hidden)').dataset.name;
  }
  return obj;
}catch(err){}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".responsive-header_browse_categories_flyout a[href]:not([href=\"#\"]),.shop-menu-layout button,.shop-menu-layout li,.responsive-header_browse_categories_flyout a[href]:not([href=\"#\"]) *,.shop-menu-layout button *,.shop-menu-layout li *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try { return (this.api || QuantumMetricAPI).lastClicked ? (this.api || QuantumMetricAPI).lastClicked.innerText : ""; } catch (e) {}}}]},{"t":"JSValue","v":[{"fn":function () {try{
  var obj = {};
  obj.clicked = window.QuantumMetricAPI.lastClicked.innerText;
  if (window.document.querySelector('[data-selected]')) {
    obj.mainCategory = window.document.querySelector('[data-selected]').innerText;
  }
  return obj;
}catch(err){}}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":156,"f":0,"m":1,"s":1,"u":".*","x":"QXJ","v":{"t":"MDE","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["\\/ProfileActor\\/login"]},{"t":"XFJPar","v":[]}]},"/statusMessage",{"t":"Is","v":["failure"]}]},{"t":"ObjPathValue","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["\\/ProfileActor\\/login"]},{"t":"XFJPar","v":[]}]},"/formExceptions/0/localizedMessage"]},{"t":"VXF","v":[{"t":"XHR","v":["\\/ProfileActor\\/login"]},{"t":"XFPK","v":[["qurl","url"],["qstatus","statusCode"]]},{"t":"XFMG","v":[{"t":"JSValueEx","v":[{"fn":function () {return {};}}]}]}]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":false,"i":157,"f":0,"m":1,"s":2,"u":".*","x":"QCC","v":{"t":"E","v":[{"t":"SelectorPresent","v":[".ant-form-item-explain-error"]},{"t":"SelectorText","v":[".ant-form-item-explain-error"]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":158,"f":0,"m":0,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
  return !!location.search;
}
catch (err) {}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  return location.search.toLowerCase();
}
catch (err) {}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":159,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":167,"f":0,"m":0,"s":1,"u":".*","x":"QOP","v":{"t":"E","v":[{"t":"ObjPath","v":[{"t":"WV","v":[]},"/GCI/digitalData/omnitureData/events",{"t":"Is","v":["internalSearch,searchRedirect"]}]},{"t":"V","v":[""]}]}},{"sessionInfoReq":true,"evalAlways":true,"excludeBlank":true,"i":168,"f":0,"m":0,"s":2,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValueEx","v":[{"fn":function () {try {
  var utmKeys = [
    'utm_campaign', 
    'utm_creative', 
    'utm_content',
    'utm_id', 
    'utm_medium',
    'utm_source', 
    'utm_marketing_tactic', 
    'utm_term',
    'utm_click_id',
    'gclid',
    'fbclid',
    'msclkid',
    'srsltid'  
  ];
  var hasUtmParams = false;
  var qmAPI = window.QuantumMetricAPI;
  var qs = !!(qmAPI.getPrevEventData(158) && qmAPI.getPrevEventData(158).value) ? qmAPI.getPrevEventData(158).value : '';
  utmKeys.forEach(function(utmKey) {
    if (qs.includes(utmKey) || window.location.href.includes(utmKey)) {
      hasUtmParams = true;
      if (utmKey === 'gclid' || utmKey === 'fbclid' || utmKey === 'msclkid' || utmKey === 'srsltid') {  
        var search = window.location.search || '';
        var match = search.match(new RegExp(utmKey + '=([^&]*)'));
        if (match && match[1]) {
          try { localStorage.setItem('utm_click_id', match[1]); } catch (e) {}
        }
      }
    } else if (window.localStorage.getItem(utmKey)) {
      hasUtmParams = true;
    }
  });
  return hasUtmParams;
} catch(err) {}}}]},{"t":"JSValueEx","v":[{"fn":function () {// GLOBAL VARS
var qmAPI = window.QuantumMetricAPI;
var qs = !!(qmAPI.getPrevEventData(158) && qmAPI.getPrevEventData(158).value) ? qmAPI.getPrevEventData(158).value : '';

var getParamsReference = function() {
  var search = window.location.search || '';
  var hasClickId = search.includes('gclid=') || search.includes('fbclid=') || search.includes('msclkid=') || search.includes('srsltid=');
  var qsHasClickId = qs && (qs.indexOf('gclid=') !== -1 || qs.indexOf('fbclid=') !== -1 || qs.indexOf('msclkid=') !== -1 || qs.indexOf('srsltid=') !== -1);
  // Always prefer live URL for click IDs: getPrevEventData(158) qs can be truncated by QM field limits,
  // which made qsHasClickId true with a short gclid and skipped using the full window.location.search.
  if (hasClickId) {
    return search;
  }
  if (!!qs && (qs.includes('utm_') || qsHasClickId)) {
    return qs;
  }
  if (search.includes('utm_') || hasClickId) {
    return search;
  }
  return '';
};
var paramsStr = getParamsReference();

var getUtmParamVal = function(utmKey) {
  var queryParamsArr = !!paramsStr ? paramsStr.replace(/^\?/, '').split('&') : [];
  if (!queryParamsArr.length) {
    return '';
  }
  var utmParamVal = '';
  queryParamsArr.forEach(function(param) {
    var eq = param.indexOf('=');
    if (eq === -1) {
      return;
    }
    var key = decodeURIComponent(param.slice(0, eq));
    var val = param.slice(eq + 1);
    if (key === utmKey || key.toLowerCase() === utmKey.toLowerCase()) {
      try {
        utmParamVal = decodeURIComponent(val.replace(/\+/g, ' '));
      } catch (e) {
        utmParamVal = val.replace(/\+/g, ' ');
      }
    }
  });
  return utmParamVal;
};

try {
  var utmKeys = [
    'utm_campaign', 
    'utm_creative', 
    'utm_content',
    'utm_id', 
    'utm_medium',
    'utm_source', 
    'utm_marketing_tactic', 
    'utm_term',
    'utm_click_id'
  ];
  var result = '';
 
  utmKeys.forEach(function(utmKey) {
    var utmParamVal = getUtmParamVal(utmKey);
    if (utmKey === 'utm_click_id' && !utmParamVal) {
      utmParamVal = getUtmParamVal('gclid') || getUtmParamVal('fbclid') || getUtmParamVal('msclkid') || getUtmParamVal('srsltid');  
    }
    var utmValue = window.localStorage.getItem(utmKey);
    if (!!utmParamVal && utmParamVal !== 'null') {
      result += utmKey + '|' + utmParamVal + ', ';
    } else if (!!utmValue && utmValue !== 'null') {
      result += utmKey + '|' + utmValue + ', ';
    }
  });
  var filteredResult = result.split(',').filter(function(item) {
    return !item.includes('null');
  }).join(',');
  return decodeURI(filteredResult);
} catch(err) {}}}]},{"t":"JSValue","v":[{"fn":function () {// GLOBAL VARS
var qmAPI = window.QuantumMetricAPI;
var qs = !!(qmAPI.getPrevEventData(158) && qmAPI.getPrevEventData(158).value) ? qmAPI.getPrevEventData(158).value : '';

var getParamsReference = function() {
  var search = window.location.search || '';
  var hasClickId = search.includes('gclid=') || search.includes('fbclid=') || search.includes('msclkid=') || search.includes('srsltid=');
  var qsHasClickId = qs && (qs.indexOf('gclid=') !== -1 || qs.indexOf('fbclid=') !== -1 || qs.indexOf('msclkid=') !== -1 || qs.indexOf('srsltid=') !== -1);
  // Prefer live URL when it has click IDs — event 158 qs can be truncated (QM length limits), yielding short gclid.
  if (hasClickId) {
    return search;
  }
  if (!!qs && (qs.includes('utm_') || qsHasClickId)) {
    return qs;
  }
  if (search.includes('utm_') || hasClickId) {
    return search;
  }
  return '';
};
var paramsStr = getParamsReference();
  
var getUtmParamVal = function(utmKey) {
  var queryParamsArr = !!paramsStr ? paramsStr.replace(/^\?/, '').split('&') : [];
  if (!queryParamsArr.length) {
    return '';
  }
  var utmParamVal = 'Unspecified';
  queryParamsArr.forEach(function(param) {
    var eq = param.indexOf('=');
    if (eq === -1) {
      return;
    }
    var key = decodeURIComponent(param.slice(0, eq));
    var val = param.slice(eq + 1);
    if (key === utmKey || key.toLowerCase() === utmKey.toLowerCase()) {
      try {
        utmParamVal = decodeURIComponent(val.replace(/\+/g, ' '));
      } catch (e) {
        utmParamVal = val.replace(/\+/g, ' ');
      }
    }
  });
  return utmParamVal;
};
  
try {
  var utmKeys = [
    'utm_campaign', 
    'utm_creative', 
    'utm_content',
    'utm_id', 
    'utm_medium',
    'utm_source', 
    'utm_marketing_tactic', 
    'utm_term',
    'utm_click_id'
  ];
  var result = {};
  
  utmKeys.forEach(function(utmKey) {
    var utmValue = window.localStorage.getItem(utmKey);
    var utmParamVal = getUtmParamVal(utmKey);
    if (utmKey === 'utm_click_id' && (!utmParamVal || utmParamVal === 'Unspecified')) {
      utmParamVal = getUtmParamVal('gclid') || getUtmParamVal('fbclid') || getUtmParamVal('msclkid') || getUtmParamVal('srsltid');  
      if (utmParamVal === 'Unspecified') utmParamVal = '';
    }
  
    if (!!utmParamVal && utmParamVal !== 'null') {
      result[utmKey] = decodeURI(utmParamVal);
    } else if (!!utmValue && utmValue !== 'null') {
      result[utmKey] = decodeURI(utmValue);
    }
  });
  for (var key in result) { 
    if (result[key] === 'null' || result[key] === null) {
      delete result[key];
    }
  }
  return result;
  
} catch(err) {}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":171,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {if (window.saveForLaterQMHelperInitialized) {
    return;
  }
  window.saveForLaterQMHelperInitialized = true;

  var QM_SAVE_FOR_LATER_LOG = '[QM Save For Later]';

  var sendToQM = function (primaryValue, attributes) {
    if (!primaryValue) {
      return;
    }
    try {
      if (window.QuantumMetricAPI && typeof window.QuantumMetricAPI.sendEvent === 'function') {
        window.QuantumMetricAPI.sendEvent(171, 0, String(primaryValue), attributes);
      }
    } catch (err) {
      console.error(QM_SAVE_FOR_LATER_LOG, 'sendEvent error', err);
      if (window.handleQMError) {
        window.handleQMError('save-for-later-qm', err);
      }
    }
  };

  var isSaveForLaterEvent = function (detail) {
    return !!(detail && detail.event === 'saveForLaterItemDetail');
  };

  var processDetail = function (detail) {
    if (!detail || !isSaveForLaterEvent(detail)) {
      return;
    }

    var attributes = {
      item_id: detail.item_id,
      item_name: detail.item_name,
      price: detail.price,
      quantity: detail.quantity,
      discount: detail.discount
    };

    sendToQM(detail.item_id, attributes);
  };

  try {
    window.dataLayer = window.dataLayer || [];
    var originalPush = window.dataLayer.push;

    window.dataLayer.push = function () {
      var result = originalPush.apply(window.dataLayer, arguments);

      for (var i = 0; i < arguments.length; i++) {
        try {
          processDetail(arguments[i]);
        } catch (pushErr) {
          console.error(QM_SAVE_FOR_LATER_LOG, 'processDetail error', pushErr);
          if (window.handleQMError) {
            window.handleQMError('save-for-later-qm-push', pushErr);
          }
        }
      }

      return result;
    };
  } catch (e) {
    console.error(QM_SAVE_FOR_LATER_LOG, 'init error', e);
    if (window.handleQMError) {
      window.handleQMError('save-for-later-qm-init', e);
    }
  }}}]},{"t":"V","v":[""]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":172,"f":0,"m":1,"s":1,"u":".*","x":"QXJ","v":{"t":"MDE","v":[{"t":"ObjSearch","v":[{"t":"VXF","v":[{"t":"XHRRequest","v":["\\/addItemToAllTargetLists"]},{"t":"XFJPar","v":[]}]},"/catalogRefIds"]},{"t":"VXF","v":[{"t":"ObjSearchValue","v":[{"t":"VXF","v":[{"t":"XHRRequest","v":["\\/addItemToAllTargetLists"]},{"t":"XFJPar","v":[]}]},"/catalogRefIds"]},{"t":"XFRR","v":[{"p":"site(\\d+)","f":""},"$1"]}]},{"t":"VXF","v":[{"t":"XHR","v":["\\/addItemToAllTargetLists"]},{"t":"XFPK","v":[["qurl","url"],["qstatus","statusCode"]]},{"t":"XFMG","v":[{"t":"JSValueEx","v":[{"fn":function () {try {
  var request = JSON.parse(window.QuantumMetricAPI.lastXHR.qrequest);
  var productId = request.productId.split("site")[1];
  
  var returnObj = {
    productId: productId
  };
  
  return returnObj;
} catch (err) {}}}]}]}]}]}},{"f":0,"i":173,"evalAlways":false,"m":1,"s":1,"u":".*","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {// QM Event 173: Web - Remove From Wishlist
// Listens for wishlistItemRemoved dataLayer event

try {
  if (window.location.pathname.indexOf('/wishlists') !== 0) {
    return false;
  }

  if (!window._wrfwListenerSet) {
    window._wrfwListenerSet = true;

    window.addEventListener('dlUpdateEvent', function(event) {
      var eventData = event.detail;

      if (eventData &&
          eventData.eventName === 'wishlistItemRemoved' &&
          eventData.wishlistItemRemoved) {

        try {
          var data = eventData.wishlistItemRemoved;

          var payload = {
            itemId: data.itemId || '',
            listId: data.listId || '',
            productId: (data.productId || '').replace(/^site\d*/, '')
          };

          if (window.QuantumMetricAPI && window.QuantumMetricAPI.sendEvent) {
            window.QuantumMetricAPI.sendEvent(173, 0, payload.productId, payload);
          }

        } catch (e) {
          if (window.handleQMError) {
            window.handleQMError('remove-from-wishlist', e);
          }
        }
      }
    });
  }

} catch (err) {
  if (window.handleQMError) {
    window.handleQMError('remove-from-wishlist-init', err);
  }
}

return false;}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var w = window.__qmWRFWlast || {};
  return w.productId || w.itemId;
} catch (err) {}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var w = window.__qmWRFWlast || {};
  return {
    itemId: w.itemId,
    listId: w.listId,
    productId: w.productId
  };
} catch (err) {}}}]}]},"x":"QJS","sessionInfoReq":false,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":175,"f":0,"m":1,"s":1,"u":".*","x":"QCE,QCE","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".ant-checkbox-wrapper-checked,.ant-checkbox-wrapper-checked *"]}]},{"t":"V","v":[""]}]},{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".refine-your-search-list li > span,.refine-your-search-list li > span *"]}]},{"t":"V","v":[""]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":176,"f":0,"m":1,"s":1,"u":".*","x":"QCE","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".gc-checkbox label:not(.ant-checkbox-wrapper-checked),.gc-checkbox label:not(.ant-checkbox-wrapper-checked) *"]}]},{"t":"V","v":[""]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":177,"f":0,"m":1,"s":1,"u":".*","x":"QCE","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["[aria-label=\"Category\"] a,[aria-label=\"Category\"] a *"]}]},{"t":"V","v":[""]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":178,"f":0,"m":1,"s":1,"u":".*","x":"QCE","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["[aria-label=\"Brands\"] .gc-checkbox label:not(.ant-checkbox-wrapper-checked),[aria-label=\"Brands\"] .gc-checkbox label:not(.ant-checkbox-wrapper-checked) *"]}]},{"t":"V","v":[""]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":180,"f":0,"m":1,"s":1,"u":".*","x":"QXJ","v":{"t":"MDE","v":[{"t":"XHRRequestHeader","v":[".*?","Signature-Agent"]},{"t":"VXF","v":[{"t":"XHRRequestHeaderValue","v":[".*?","Signature-Agent"]},{"t":"XFCC","v":["l"]}]},{"t":"VXF","v":[{"t":"XHR","v":[".*?"]},{"t":"XFPK","v":[["qurl","url"],["qstatus","statusCode"]]},{"t":"XFMG","v":[{"t":"JSValueEx","v":[{"fn":function () {return {};}}]}]}]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":false,"i":181,"f":0,"m":1,"s":2,"u":"(guitarcenter\\.com|musiciansfriend\\.com).*\\/lessons-sign-up","x":"QCE,QCE,QCE,QCE,QCE,QCE,QCE,QFL,QFL,QCC,QCC,QCC","v":{"t":"MAE","v":[1,0,{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["form#multiStepForm div:first-child .radio-group label,form#multiStepForm div:first-child .radio-group label *"]}]},{"t":"V","v":["Step 1"]},{"t":"JSValue","v":[{"fn":function () {try {
  var btn = this.api.lastClicked;
  if (btn.tagName === 'LABEL'){
    return {
      "Form Step": "1",
      "Form Answer": [btn.innerText]
    };
  } else {
    return {
      "Form Step": "1",
      "Form Answer": [btn.closest('label').innerText]
    };
  }
} catch (err) {}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["#multiStepForm:has(div:nth-child(2).active) #nextBtn.valid,#multiStepForm:has(div:nth-child(2).active) #nextBtn.valid *"]}]},{"t":"V","v":["Step 2"]},{"t":"JSValue","v":[{"fn":function () {try {
  var elementsList = document.querySelectorAll('.checkbox-subgroup label:has(input:checked) span');
  var list = [];
  
  elementsList.forEach(function (element) {
    list.push(element.innerText);
  });
  
  var instrumentsObj = {
    "Form Step": "2",
    "Form Answer": list
  };
  
  return instrumentsObj;
  
} catch (err) {}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["#multiStepForm:has(div:nth-child(3).active) #nextBtn.valid,#multiStepForm:has(div:nth-child(3).active) #nextBtn.valid *"]}]},{"t":"V","v":["Step 3"]},{"t":"JSValue","v":[{"fn":function () {try {
  return {
    "Form Step": "3",
	"Form Answer": ["Name Populated"]
  };
} catch (err){}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["form#multiStepForm div:nth-child(4) .radio-group input,form#multiStepForm div:nth-child(4) .radio-group input *"]}]},{"t":"V","v":["Step 4"]},{"t":"JSValue","v":[{"fn":function () {try {
  var btnValue = this.api.lastClicked.getAttribute('value');
  return {
    "Form Step": "4",
    "Form Answer": [btnValue]
  };
} catch (err) {}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["#multiStepForm:has(div:nth-child(5).active) #nextBtn.valid,#multiStepForm:has(div:nth-child(5).active) #nextBtn.valid *"]}]},{"t":"V","v":["Step 5"]},{"t":"JSValue","v":[{"fn":function () {try {
  var activeLevel = document.querySelector('.slider-labels span[style="color: rgb(103, 103, 103);"]');
  
  return {
    "Form Step": "5",
    "Form Answer": [activeLevel.innerText]
  };
  
} catch (err) {}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["#multiStepForm:has(div:nth-child(6).active) #nextBtn.valid,#multiStepForm:has(div:nth-child(6).active) #nextBtn.valid *"]}]},{"t":"V","v":["Step 6"]},{"t":"JSValue","v":[{"fn":function () {try {
  var checkbox = document.querySelector('#multiStepForm div:nth-child(6).active input[type="checkbox"]:checked');
  var store = checkbox.closest('label').querySelector('.store-name').innerText;
  
  return {
    "Form Step": "6",
    "Form Answer": [store]
  };
} catch (err) {
}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["#multiStepForm:has(div:nth-child(7).active) #nextBtn.valid,#multiStepForm:has(div:nth-child(7).active) #nextBtn.valid *"]}]},{"t":"V","v":["Step 7"]},{"t":"JSValue","v":[{"fn":function () {try {
  return {
    "Form Step": "7",
    "Form Answer": ["Email Populated"]
  };
} catch (err) {
}}}]}]},{"t":"MDE","v":[{"t":"FieldFilledNode","v":["#multiStepForm div:nth-child(8).active [name=\"phone\"]"]},{"t":"V","v":["Step 8"]},{"t":"JSValue","v":[{"fn":function () {try {
  return {
    "Form Step": "8",
	"Form Answer": ["Phone Populated"]
  };
} catch (err){}}}]}]},{"t":"MDE","v":[{"t":"FieldFilledNode","v":["#multiStepForm:has(div:nth-child(7).active) input[name=\"email\"]"]},{"t":"V","v":["Step 7"]},{"t":"JSValue","v":[{"fn":function () {try {
  return {
    "Form Step": "7",
    "Form Answer": ["Email Populated"]
  };
} catch (err) {
}}}]}]},{"t":"MDE","v":[{"t":"SelectorPresent","v":["#multiStepForm .step:nth-child(4).active"]},{"t":"V","v":["Step 3"]},{"t":"JSValue","v":[{"fn":function () {try {
  return {
    "Form Step": "3",
	"Form Answer": ["Name Populated"]
  };
} catch (err){}}}]}]},{"t":"MDE","v":[{"t":"SelectorPresent","v":["#multiStepForm .step:nth-child(8).active"]},{"t":"V","v":["Step 7"]},{"t":"JSValue","v":[{"fn":function () {try {
  return {
    "Form Step": "7",
    "Form Answer": ["Email Populated"]
  };
} catch (err) {
}}}]}]},{"t":"MDE","v":[{"t":"SelectorPresent","v":["#multiStepForm .step:nth-child(9).active"]},{"t":"V","v":["Step 8"]},{"t":"JSValue","v":[{"fn":function () {try {
  return {
    "Form Step": "8",
	"Form Answer": ["Phone Populated"]
  };
} catch (err){}}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":182,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {// QM Event for Gear Type Selection Change
// Listens for userChangeDemoGearType dataLayer event

try {
  if (!document.querySelector('.gear-type-toggle')) {
    return false;
  }
  // Set up listener only once
  if (!window._gearTypeListenerSet) {
    window._gearTypeListenerSet = true;
    
    window.addEventListener('dlUpdateEvent', function(event) {
      var eventData = event.detail;
      
      // Check if this is the userChangeDemoGearType event
      if (eventData && 
          eventData.eventName === 'userChangeDemoGearType' &&
          eventData.userChangeDemoGearType) {
        
        try {
          var gearData = eventData.userChangeDemoGearType;
          
          // Extract data from the event
          var skuId = gearData.skuId || '';
          var gearType = gearData.gearType || '';
          var salePrice = gearData.salePrice || '';
          
          // Remove "site5" prefix from skuId if it exists
          var cleanSkuId = skuId.replace(/^site5/, '');
          
          
          // Build the payload
          var payload = {
            gearType: gearType,
            skuId: cleanSkuId,
            salePrice: parseFloat(salePrice) || 0
          };
          
          // Send QM Event (TODO: Assign event number)
          // Using skuId as the primary key
          if (window.QuantumMetricAPI && window.QuantumMetricAPI.sendEvent) {
            window.QuantumMetricAPI.sendEvent(182, 0, cleanSkuId, payload);
          }
          
        } catch (e) {
          console.error('[QM Gear Type Change] Error processing event:', e);
          if (window.handleQMError) {
            window.handleQMError('gear-type-change', e);
          }
        }
      }
    });
    
  }
  
} catch (err) {
  console.error('[QM Gear Type Change] Error:', err);
  if (window.handleQMError) {
    window.handleQMError('gear-type-change-init', err);
  }
}}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":183,"f":0,"m":1,"s":1,"u":"\\/(cart|checkout)","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {// QM Event for Cart Item Removal
// Listens for removeItemFromCart dataLayer event

try {
  // Set up listener only once
  if (!window._cartRemovalListenerSet) {
    window._cartRemovalListenerSet = true;
    
    window.addEventListener('dlUpdateEvent', function(event) {
      var eventData = event.detail;
      
      // Check if this is the removeItemFromCart event
      if (eventData && 
          (eventData.eventName === 'removeItemFromCart' || eventData.eventName ===               'removeItemFromCheckout') &&
          (eventData.removeItemFromCart || eventData.removeItemFromCheckout))  {
        
        try {
          if (eventData.removeItemFromCart){
             var removalData = eventData.removeItemFromCart;
          }
         else if (eventData.removeItemFromCheckout ){
           var removalData = eventData.removeItemFromCheckout;
         }
  
          
          // Extract data from the event
          var commerceId = removalData.commerceId || '';
          var orderId = removalData.orderId || '';
          var displaySku = removalData.displaySku || '';
          var catalogRefId = removalData.catalogRefId || '';
          var gearType = removalData.gearType || '';
          
          // Remove "site5" prefix from catalogRefId if it exists
          var cleanCatalogRefId = catalogRefId.replace(/^site5/, '');
          
          // Build the payload
          var payload = {
            commerceId: commerceId,
            orderId: orderId,
            displaySku: displaySku,
            catalogRefId: cleanCatalogRefId,
            gearType: gearType
          };
          
          // Send QM Event (TODO: Assign event number)
          // Using displaySku as the primary key
          if (window.QuantumMetricAPI && window.QuantumMetricAPI.sendEvent) {
            window.QuantumMetricAPI.sendEvent(183, 0, displaySku, payload);
          }
          
        } catch (e) {
          console.error('[QM Cart Removal] Error processing event:', e);
          if (window.handleQMError) {
            window.handleQMError('cart-removal', e);
          }
        }
      }
    });
    
  }
  
} catch (err) {
  console.error('[QM Cart Removal] Error:', err);
  if (window.handleQMError) {
    window.handleQMError('cart-removal-init', err);
  }
}}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":true,"i":184,"f":0,"m":1,"s":2,"u":"(guitarcenter\\.com|musiciansfriend\\.com|musicarts\\.com).*\\/(lessons-purchase|inst-listing)","x":"QCE,QCE,QCE,QCE,QCE,QCE,QCE,QFL,QCC","v":{"t":"MAE","v":[1,0,{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["form:has(input.rbt-input-main):has(button[aria-label=\"Clear\"]) button[type=\"submit\"],form .basic-instrument-ta + [type=\"submit\"].btn-danger,form:has(input.rbt-input-main):has(button[aria-label=\"Clear\"]) button[type=\"submit\"] *,form .basic-instrument-ta + [type=\"submit\"].btn-danger *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var element = document.querySelector('form input.rbt-input-main');
  var value = element.getAttribute('value');
  if (value) {
    return "Step 1";
  }
} catch (err) {}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var element = document.querySelector('form input.rbt-input-main');
  var value = element && (element.value || element.getAttribute('value'));
  var instrument = window.localStorage.getItem('instrument');
  
  if (!!element){
    return {
      "Web - Lessons Purchase Form Step": "1",
      "Web - Lessons Purchase Form Answer": [ instrument || value]
    };
  }

} catch (err) {}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["form:has(input[name=\"daysOfWeek\"]) button.btn-danger,form:has(input[name=\"daysOfWeek\"]) button.btn-danger *"]}]},{"t":"V","v":["Step 2"]},{"t":"JSValue","v":[{"fn":function () {try {
  var lastClicked = this.api.lastClicked;
  
  if (lastClicked.getAttribute('name') === "Next") {
    
    var checkboxes = document.querySelectorAll('label:has(input[name="daysOfWeek"]:checked)');
    var list = [];
    
    for (var i = 0; i < checkboxes.length; i++) {
      list.push(checkboxes[i].innerText);
    }
    
    var daysOfWeek = {
      "Web - Lessons Purchase Form Step": "2",
      "Web - Lessons Purchase Form Answer": list
    };
      
    return daysOfWeek;
    
  } else if (lastClicked.getAttribute('name') === "Skip"){
    
    return {
      "Web - Lessons Purchase Form Step": "2",
      "Web - Lessons Purchase Form Answer": ["Skip"]
    };
    
  }
} catch (err) {}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["form:has(input[name=\"timeOfDay\"]) button.btn-danger,form:has(input[name=\"timeOfDay\"]) button.btn-danger *"]}]},{"t":"V","v":["Step 3"]},{"t":"JSValue","v":[{"fn":function () {try {
  var lastClicked = this.api.lastClicked;

  if (lastClicked.getAttribute('name') === "Next") {
    var tod = window.localStorage.getItem('timeOfDay');
 
    if (tod !== ""){
      
      var result = tod;
      window.localStorage.removeItem('timeOfDay');
      
      var timesOfDay = {
        "Web - Lessons Purchase Form Step": "3",
        "Web - Lessons Purchase Form Answer": result.split(", ")
      };
      
      return timesOfDay;
    }
  } else if (lastClicked.getAttribute('name') === "Skip"){ 
    return {
      "Web - Lessons Purchase Form Step": "3",
      "Web - Lessons Purchase Form Answer": ["Skip"]
    };
    
  }
} catch (err) {}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["form button#zipcode-submit:not([disabled]),form button#zipcode-submit:not([disabled]) *"]}]},{"t":"V","v":["Step 4"]},{"t":"JSValue","v":[{"fn":function () {try {
  return {
    "Web - Lessons Purchase Form Step": "4",
	"Web - Lessons Purchase Form Answer": ["Zipcode Populated"]
  };
} catch (err) {}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".card-footer a.btn-primary,.card-footer a.btn-primary *"]}]},{"t":"V","v":["Step 5"]},{"t":"JSValue","v":[{"fn":function () {try {
  return {
    "Web - Lessons Purchase Form Step": "5",
    "Web - Lessons Purchase Form Answer": ["Book Now Clicked"]
  };
  
} catch (err){}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["a[aria-label=\"Add to Cart\"],a[aria-label=\"Add to Cart\"] *"]}]},{"t":"V","v":["Step 6"]},{"t":"JSValue","v":[{"fn":function () {try {
  
  return {
  	"Web - Lessons Purchase Form Step": "6",
    "Web - Lessons Purchase Form Answer": ["Book Now Completed"]
  };
  
} catch (err) {}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".modal-terms a:not([disabled]).btn-danger,.modal-terms a:not([disabled]).btn-danger *"]}]},{"t":"V","v":["Step 7"]},{"t":"JSValue","v":[{"fn":function () {try {
  
  return {
    "Web - Lessons Purchase Form Step": "7",
    "Web - Lessons Purchase Form Answer": ["Terms and Conditions Completed"]
  };
  
} catch (err){}}}]}]},{"t":"MDE","v":[{"t":"FieldFilledNode","v":["#zipcode-modal-field"]},{"t":"V","v":["Step 4"]},{"t":"JSValue","v":[{"fn":function () {try {
  
  return {
    "Web - Lessons Purchase Form Step": "4",
    "Web - Lessons Purchase Form Answer": ["Zipcode Populated"]
  };
  
} catch (err) {}}}]}]},{"t":"MDE","v":[{"t":"SelectorPresent","v":["form:has(input[name=\"daysOfWeek\"])"]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var instrument = window.localStorage.getItem('instrument');
  window.localStorage.removeItem('instrument');
  
  if (!!instrument){
    return "Step 1";
  }

} catch (err) {}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var instrument = window.localStorage.getItem('instrument');
  window.localStorage.removeItem('instrument');
  
  if (!!instrument){
    return {
      "Web - Lessons Purchase Form Step": "1",
      "Web - Lessons Purchase Form Answer": [instrument]
    };
  }

} catch (err) {}}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":185,"f":0,"m":1,"s":1,"u":".*","x":"QCE","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".dow-lbl.form-check-label:has([name=\"student-taking\"]),.dow-lbl.form-check-label:has([name=\"student-taking\"]) *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  return this.api.lastClicked.innerText;
} catch (err) {}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":186,"f":0,"m":0,"s":1,"u":"/search","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {try {
    
    if(!!window.dataLayer._state.loadedFromSearch){
      return true;
    }
    
  } catch (error) {}}}]},{"t":"JSValue","v":[{"fn":function () {try {
    
    if(!!window.dataLayer._state.loadedFromSearch){
      return window.dataLayer._state.loadedFromSearch.searchValue;
    }
    
  } catch (error) {}}}]},{"t":"JSValue","v":[{"fn":function () {try {
    
    var searchValues = {};
    if(!!window.dataLayer._state.loadedFromSearch){
      var searchTerm = window.dataLayer._state.loadedFromSearch.searchValue;
      searchValues.searchTerm = searchTerm;
      searchValues.resultsNum = window.dataLayer._state.plpMatchCount;
      return searchValues;
    }
    
  } catch (error) {}}}]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":true,"i":187,"f":0,"m":1,"s":2,"u":"\\/lessons-purchase","x":"QCE,QFL","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".basic-instrument-ta + button.disabled,.basic-instrument-ta + button.disabled *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var inputValue = document.querySelector('input[aria-describedby="ae_search_instructions"]').value;
  if (inputValue) {
    return inputValue;
  }
} catch (err) {}}}]}]},{"t":"E","v":[{"t":"FieldFilledNode","v":["form:has(.basic-instrument-ta):has(button.disabled) input[aria-describedby=\"ae_search_instructions\"]"]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var inputValue = document.querySelector('input[aria-describedby="ae_search_instructions"]').value;
  if (inputValue) {
    return inputValue;
  }
} catch (err) {}}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":188,"f":0,"m":1,"s":1,"u":"\\/lessons-purchase","x":"QCE,QCE","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["form:has(input[name=\"timeOfDay\"]) label.dow-lbl,form:has(input[name=\"timeOfDay\"]) label.dow-lbl *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var labels = document.querySelectorAll('form:has(input[name="timeOfDay"]) label.dow-lbl');
  var listString = '';
  
  for (var i = 0; i < labels.length; i++){
    var checkedLabels = document.querySelectorAll('label.dow-lbl:has(input[name="timeOfDay"]:checked)');
    var list = [];
        
    for (var j = 0; j < checkedLabels.length; j++){
      list.push(checkedLabels[j].innerText);
    }

    listString = list.join(', ');
    window.localStorage.setItem('timeOfDay', listString);
    return listString;
}
  
  
} catch (err) {}}}]}]},{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["form .basic-instrument-ta .dropdown-item,form .basic-instrument-ta .dropdown-item *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var lastClicked = QuantumMetricAPI.lastClicked || this.api.lastClicked;
  
  if (lastClicked.innerText){
    window.localStorage.setItem('instrument', lastClicked.innerText);
    return lastClicked.innerText;
  }
  
} catch (err) {}}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":189,"f":0,"m":0,"s":1,"u":".*","x":"QUR","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"URLPropValue","v":[{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/location/href"]},"href"]},{"t":"StrCmp","v":[1,"musiciansfriend.com"]}]},{"t":"JSValueEx","v":[{"fn":function () {// Data Element: Returns PDP PPC Variant value
// Returns the string value of pdpPpcVariant from dataLayer state or event

try {
  // Try to get value from dataLayer state
  var variantValue = window.dataLayer && 
                     window.dataLayer._state && 
                     window.dataLayer._state.pdpPpcVariant;
  
  // If found, return it
  if (variantValue) {
    return variantValue;
  }
  
  // If not found and listener not set up yet, set up listener for ppcMonetateCampaign event
  if (!window._ppcVariantListenerSet) {
    window._ppcVariantListenerSet = true;
    
    window.addEventListener('dlUpdateEvent', function(event) {
      var eventData = event.detail;
      
      // Check if this is the ppcMonetateCampaign event
      if (eventData && eventData.eventName === 'ppcMonetateCampaign') {
        // Store the variant value globally for future data element calls
        var variant = eventData.pdpPpcVariant || 
                     (window.dataLayer && 
                      window.dataLayer._state && 
                      window.dataLayer._state.pdpPpcVariant);
        
        if (variant) {
          window._pdpPpcVariantValue = variant;
        }
      }
    });
  }
  
  // Return stored value from event if available
  return window._pdpPpcVariantValue || undefined;
  
} catch (err) {
  console.error('[QM PDP PPC Variant] Error:', err);
  return undefined;
}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":190,"f":0,"m":0,"s":0,"u":".*","x":"QCK","v":{"t":"E","v":[{"t":"CookiePresent","v":["_rtagid"]},{"t":"CookieValue","v":["_rtagid"]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":191,"f":0,"m":0,"s":0,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
    
    var qparam = window.location.search;
    
    if(qparam.indexOf('optid=')>-1){
      
      return true;
     
	}
  } catch (error) {}}}]},{"t":"JSValue","v":[{"fn":function () {try {
    
    var qparam = window.location.search;
    var param = 'optid';
    var regex = new RegExp('[?&]' + param + '=([^&#]*)');
    var results = regex.exec(qparam);
    
    if(results && results[1]){
      return decodeURIComponent(results[1].replace(/\+/g, ' '));
    }
  } catch (error) {}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":195,"f":0,"m":0,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return true;}}]},{"t":"JSValue","v":[{"fn":function () {// This script listens for the "dlUpdateEvent" CustomEvent dispatched on the window.
// It specifically processes "monetate campaign" events found within the event's detail
// and sends corresponding data to Quantum Metric (Event 196).
// Deduplication: each unique campaign (id|key|split) is sent to QM only once.

if (!window._monetateQMCampaignHelperInitialized) {
  window._monetateQMCampaignHelperInitialized = true;

  try {
    // Track which campaigns have been sent to avoid duplicates for QM event 196
    var _monetateCampaignsSentQM = window._monetateCampaignsSentQM = window._monetateCampaignsSentQM || {};

    // Function to send QM event 196 for a campaign string (only once per campaign)
    var sendCampaignToQM = function(campaignString) {
      if (!campaignString) {
        return;
      }
      if (_monetateCampaignsSentQM[campaignString]) {
        return; // Already sent, skip
      }
      try {
        if (window.QuantumMetricAPI && typeof window.QuantumMetricAPI.sendEvent === 'function') {
          window.QuantumMetricAPI.sendEvent(196, 0, campaignString);
          _monetateCampaignsSentQM[campaignString] = true;
        }
      } catch (err) {
        // console.error('[Monetate Campaign QM] Error sending event 196:', err);
      }
    };

    // Process a monetate campaign event object
    var processMonetateCampaign = function(eventData) {
      if (!eventData || !eventData.key || !eventData.id || !eventData.split) {
        return;
      }
      var campaignString = eventData.id + '|' + eventData.key + '|' + eventData.split;
      sendCampaignToQM(campaignString);
    };

    // Process any historical "monetate campaign" events already in dataLayer
    if (window.dataLayer && Array.isArray(window.dataLayer)) {
      for (var i = 0; i < window.dataLayer.length; i++) {
        var entry = window.dataLayer[i];
        if (entry && entry.event === 'monetate campaign') {
          processMonetateCampaign(entry);
        }
      }
    }

    // Listen for future dlUpdateEvent
    if (typeof window.addEventListener === 'function') {
      window.addEventListener('dlUpdateEvent', function(e) {
        try {
          if (e.detail && e.detail.event === 'monetate campaign') {
            processMonetateCampaign(e.detail);
          }
        } catch (listenerErr) {
          // console.error('[Monetate Campaign QM] Listener error:', listenerErr);
        }
      });
    }
  } catch (e) {
    // console.error('[Monetate Campaign QM] Critical error:', e);
  }
}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":196,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":197,"f":0,"m":0,"s":1,"u":"musicarts\\.com\\/cart\\/checkout","x":"QUR","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"URLPropValue","v":[{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/location/href"]},"hash"]},{"t":"Is","v":["review"]}]},{"t":"V","v":[""]}]}},{"sessionInfoReq":true,"evalAlways":true,"excludeBlank":false,"i":198,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValueEx","v":[{"fn":function () {try{
        var ret = false;
        var cleanGA = [];
        for (var y = 0; y < window.dataLayer.length; y++) {
            if (window.dataLayer[y].event === 'gtm.linkClick' || window.dataLayer[y].event === 'gtm.click') {
                continue;
            }
            else {
                cleanGA.push(window.dataLayer[y]);
            }
        }
        if (!!window.QuantumMetricAPI) {
            /* Construct a Hash of the DataLayer */
            var dataLayerHash = !!window.dataLayer && JSON.stringify(cleanGA);
            var hash = 0,
                chr;
            if (dataLayerHash.length === 0) {
                dataLayerHash = hash;
            }
            for (var i = 0; i < dataLayerHash.length; i++) {
                chr = dataLayerHash.charCodeAt(i);
                hash = ((hash << 5) - hash) + chr;
                hash |= 0;
            }
            dataLayerHash = hash;
            /* Construct a Hash of the DataLayer */
            /* No Event Data */
            if (!QuantumMetricAPI.getPrevEventData(198)) {
                ret = true;
            } /* Previous Value, Check Unique Hash */
            else if (!!QuantumMetricAPI.getPrevEventData(198) && !!QuantumMetricAPI.getPrevEventData(198).value && !!dataLayerHash && parseInt(QuantumMetricAPI.getPrevEventData(198).value) !== dataLayerHash) {
                ret = true;
            }
        }
        return ret;
    }catch(err){}}}]},{"t":"JSValueEx","v":[{"fn":function () {try{
            var cleanGA = [];
            for (var y = 0; y < window.dataLayer.length; y++) {
                if (window.dataLayer[y].event === 'gtm.linkClick' || window.dataLayer[y].event === 'gtm.click') {
                    continue;
                }
                else {
                    cleanGA.push(window.dataLayer[y]);
                }
            }
            /* Construct a Hash of the DataLayer */ 
        var dataLayerHash =
                !!window.dataLayer && JSON.stringify(cleanGA);
            var hash = 0,
                chr;
            if (dataLayerHash.length === 0) {
                dataLayerHash = hash;
            }
            for (var j = 0; j < dataLayerHash.length; j++) {
                chr = dataLayerHash.charCodeAt(j);
                hash = (hash << 5) - hash + chr;
                hash |= 0;
            }
            dataLayerHash = hash;
            /* Construct a Hash of the DataLayer */ return dataLayerHash;
        }catch(err){}}}]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":true,"i":199,"f":0,"m":1,"s":2,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":200,"f":0,"m":0,"s":1,"u":"musiciansfriend\\.com/stupid","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {// QM Event Handler - Stupid Deal Add to Cart
// Fires "Web - Cart Additions" (Event 79) for Stupid Deal section

try {
  // Prevent multiple handler attachments
  if (window._stupidDealHandlerAttached) {
    return;
  }
  window._stupidDealHandlerAttached = true;

  // Debounce variables
  var lastFireTime = 0;
  var debounceDelay = 1000; // 1 second

  // Function to scrape data and fire QM event
  var handleStupidDealAddToCart = function() {
    try {
      // Debounce: prevent duplicate fires within debounceDelay
      var currentTime = Date.now();
      if (currentTime - lastFireTime < debounceDelay) {
        return;
      }
      lastFireTime = currentTime;

      // Scrape SKU ID from hidden input
      var skuIdElement = document.getElementById('skuDailyId');

      if (!skuIdElement) {
        console.warn('[QM Stupid Deal] Missing SKU ID element');
        return;
      }

      var skuId = skuIdElement.value;

      if (!skuId) {
        console.warn('[QM Stupid Deal] Empty SKU ID value');
        return;
      }

      // Strip "site1sku" prefix if present
      if (skuId.indexOf('site1sku') === 0) {
        skuId = skuId.substring(8); // Remove "site1sku"
      }

      // Quantity is always 1
      var quantity = 1;

      // commerceType is always "new"
      var commerceType = "new";

      // Build QM schema
      var qmAddToCartSchema = {
        items: [
          {
            catalogRefId: skuId,
            productId: skuId,
            commerceType: commerceType,
            quantity: quantity
          }
        ]
      };

      // Try to get PFM from Adobe Launch data element
      try {
        if (window._satellite && typeof _satellite.getVar === 'function') {
          var pfm = _satellite.getVar('product: finding method pfm');
          if (pfm) {
            qmAddToCartSchema.pfm = pfm;
          }
        }
      } catch (pfmErr) {
        console.warn('[QM Stupid Deal] Could not get PFM:', pfmErr);
      }

      // Fire QM event 79 - Web - Cart Additions
      if (window.QuantumMetricAPI && typeof QuantumMetricAPI.sendEvent === 'function') {
        QuantumMetricAPI.sendEvent(79, 0, quantity, qmAddToCartSchema);
      } else {
        console.warn('[QM Stupid Deal] QuantumMetricAPI not available');
      }

    } catch (innerErr) {
      console.error('[QM Stupid Deal] Error in click handler:', innerErr);
      if (window.handleQMError) {
        window.handleQMError("79", innerErr);
      }
    }
  };

  // Set up click handler using native event delegation
  document.addEventListener('click', function(e) {
    var target = e.target;
    
    // Check if clicked element is the stupid deal add to cart button
    if (target.id === 'addToCartStupid' || 
        (target.classList && target.classList.contains('addToCartStupid'))) {
      handleStupidDealAddToCart();
      // Note: Allow event to propagate so form submission can occur
    }
  });

} catch (err) {
  console.error('[QM Stupid Deal] Critical error setting up handler:', err);
}}}]},{"t":"V","v":[""]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":201,"f":0,"m":1,"s":1,"u":"musicarts\\.com","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"f":0,"i":202,"evalAlways":false,"m":0,"s":1,"u":"musicarts\\.com","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"V","v":[""]}]},"x":"QJS","sessionInfoReq":false,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":204,"f":0,"m":0,"s":0,"u":"musicarts\\.com","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"f":0,"i":205,"evalAlways":false,"m":0,"s":2,"u":".*","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {if(window.s && window.s.marketingCloudVisitorID) {
  return window.s.marketingCloudVisitorID;
}
else if(window._satellite && window._satellite.getVisitorId && window._satellite.getVisitorId()) {
  return window._satellite.getVisitorId().getMarketingCloudVisitorID();
}
else if(window.sma && window.sma.marketingCloudVisitorID) {
  return window.sma.marketingCloudVisitorID;
}}}]},{"t":"JSValue","v":[{"fn":function () {if(window.s && window.s.marketingCloudVisitorID) {
  return window.s.marketingCloudVisitorID;
}
else if(window._satellite && window._satellite.getVisitorId) {
  return window._satellite.getVisitorId().getMarketingCloudVisitorID();
}
else if(window.sma && window.sma.marketingCloudVisitorID) {
  return window.sma.marketingCloudVisitorID;
}}}]}]},"x":"QJS","sessionInfoReq":true,"excludeBlank":true},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":206,"f":0,"m":0,"s":1,"u":"musicarts\\.com","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":true,"i":208,"f":0,"m":0,"s":2,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {// Helper Function - Extract and Store UTM Parameters
var captureUtmParams = function() {
  try {
    var url = window.location.href;
    var queryString = url.split('?')[1];
    
    if (!queryString) {
      return false;
    }
    
    var params = queryString.split('&');
    var foundUtm = false;
    
    for (var i = 0; i < params.length; i++) {
      var pair = params[i].split('=');
      var key = decodeURIComponent(pair[0]);
      var value = decodeURIComponent(pair[1] || '');
      
      // Check if parameter starts with 'utm_'
      if (key.indexOf('utm_') === 0) {
        localStorage.setItem(key, value);
        foundUtm = true;
      }
    }
    
    return foundUtm;
  } catch (e) {
    return false;
  }
};

// Helper Function - Check if UTM params exist
var getSecondaryTrigger = function() {
  var hasUtmParams = false;
  var qmAPI = window.QuantumMetricAPI;
  var qs = !!(qmAPI.getPrevEventData(158) && qmAPI.getPrevEventData(158).value) ? qmAPI.getPrevEventData(158).value : '';
  var UTM_KEY = 'utm_';

  // Check in previous event data or current URL
  if (qs.includes(UTM_KEY) || window.location.href.includes(UTM_KEY)) {
    hasUtmParams = true;
  }
  
  // Check localStorage for any keys starting with utm_
  if (!hasUtmParams) {
    var storageKeys = Object.keys(window.localStorage);
    for (var i = 0; i < storageKeys.length; i++) {
      if (storageKeys[i].indexOf(UTM_KEY) === 0) {
        hasUtmParams = true;
        break;
      }
    }
  }
  
  return hasUtmParams;
};

// Main Execution
try {
  // First, try to capture any UTM params from current URL
  captureUtmParams();
  
  // Check if we have valid trigger
  var hasValidTrigger = getSecondaryTrigger();

  if (!!hasValidTrigger) {
    return true;
  }
  
  var api = window.QuantumMetricAPI;

  // Previous event data - query string params
  var prevEventData = (api && api.getPrevEventData(158));
  var qs = !!(prevEventData && prevEventData.value) ? prevEventData.value : '';      
  // current window - search params
  var search = window.location.search || '';
  // local storage - keys string
  var storageKeys = Object.keys(window.localStorage).join(',') || '';
  var UTM_KEY = 'utm_';

  return (qs.includes(UTM_KEY) || search.includes(UTM_KEY) || storageKeys.includes(UTM_KEY));

} catch (err) {
  var msg = "error found in trigger block of V3 UTM capture " + err; 

  window.QuantumMetricAPI.sendEvent(214, 0, msg);
}}}]},{"t":"JSValue","v":[{"fn":function () {try {
    var api = (this.api || window.QuantumMetricAPI);
    var prevEventData = api && api.getPrevEventData(158);
    var qs = (prevEventData && prevEventData.value) ? prevEventData.value : '';
    var search = window.location.search || '';
    var UTM_PREFIX = 'utm_';
    var UNSPECIFIED = 'Unspecified';
    var utmObj = {};
    var allUtmKeys = {};
    
    // Helper function to extract params starting with utm_
    var extractUtmParams = function(queryString) {
        if (!queryString) return {};
        
        var params = {};
        var pairs = queryString.replace('?', '').split('&');
        
        for (var i = 0; i < pairs.length; i++) {
            var pair = pairs[i].split('=');
            var key = decodeURIComponent(pair[0]);
            var value = decodeURIComponent(pair[1] || '');
            
            if (key.indexOf(UTM_PREFIX) === 0) {
                params[key] = value || UNSPECIFIED;
            }
        }
        
        return params;
    };
    
    // Priority 1: Check previous event data (qs)
    if (qs.includes(UTM_PREFIX)) {
        var qsParams = extractUtmParams(qs);
        for (var key in qsParams) {
            if (qsParams.hasOwnProperty(key)) {
                allUtmKeys[key] = true;
                utmObj[key] = qsParams[key];
            }
        }
    }
    
    // Priority 2: Check current URL search params (only if not already set)
    if (search.includes(UTM_PREFIX)) {
        var searchParams = extractUtmParams(search);
        for (var sKey in searchParams) {
            if (searchParams.hasOwnProperty(sKey)) {
                allUtmKeys[sKey] = true;
                if (!utmObj[sKey]) {
                    utmObj[sKey] = searchParams[sKey];
                }
            }
        }
    }
    
    // Priority 3: Check localStorage for any utm_ keys (only if not already set)
    var storageKeys = Object.keys(window.localStorage);
    for (var i = 0; i < storageKeys.length; i++) {
        var lsKey = storageKeys[i];
        if (lsKey.indexOf(UTM_PREFIX) === 0) {
            allUtmKeys[lsKey] = true;
            if (!utmObj[lsKey]) {
                var lsValue = window.localStorage.getItem(lsKey);
                utmObj[lsKey] = lsValue || UNSPECIFIED;
            }
        }
    }
    
    // If no UTM params found, don't send anything
    if (Object.keys(utmObj).length === 0) {
        return;
    }
    
    return api.sendEvent(208, 0, JSON.stringify(utmObj), utmObj);
  
  } catch (err) {
    var msg = "error found in primary event of V3 UTM capture " + err; 

    (this.api || window.QuantumMetricAPI).sendEvent(214, 0, msg);
  }}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":209,"f":0,"m":1,"s":1,"u":"musicarts\\.com","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":210,"f":0,"m":1,"s":1,"u":"musicarts\\.com","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":211,"f":0,"m":1,"s":1,"u":"musicarts\\.com","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":212,"f":0,"m":0,"s":1,"u":".*","x":"QFF,QFF","v":{"t":"MAE","v":[1,0,{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"FormFieldSubmittedValue","v":["#gcNewsletterForm #btnJoinNow"]},{"t":"IsNotNull","v":[]}]},{"t":"V","v":["gcNewsletterForm"]},{"t":"JSValue","v":[{"fn":function () {try {
  var formData = {};
  formData.formUrl = window.location.pathname;
  formData.formButton = window.QuantumMetricAPI.lastClicked.innerText;
  formData.lastField = window.QuantumMetricAPI.lastField.id;
  return formData;
}catch(err){}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"FormFieldSubmittedValue","v":["#csEmailUsForm input[type=\"submit\"],#emailForm input[type=\"submit\"],#freeTrialForm input[type=\"submit\"],#sweepstakesForm input[type=\"submit\"],#lessonsForm input[type=\"submit\"],#rsvp input[type=\"submit\"]"]},{"t":"IsNotNull","v":[]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  return window.location.pathname;
}catch(err){}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var formData = {};
  formData.formUrl = window.location.pathname;
  formData.formButton = window.QuantumMetricAPI.lastClicked.innerText;
  formData.lastField = window.QuantumMetricAPI.lastField.id;
  formData.storeLocation = window.QuantumMetricAPI.lastClicked.closest("#emailForm").querySelector("#storeName").selectedOptions[0].text;
  formData.date = window.QuantumMetricAPI.lastClicked.closest("#emailForm").querySelector("#dateTime").selectedOptions[0].text.split(", ")[0];
   formData.time = window.QuantumMetricAPI.lastClicked.closest("#emailForm").querySelector("#dateTime").selectedOptions[0].text.split(", ")[1];
  return formData;
}catch(err){}}}]}]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":false,"i":215,"f":0,"m":0,"s":2,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {//This event configuration is in "Acixom Person ID Helper" event
return undefined;}}]},{"t":"V","v":[""]}]}},{"f":0,"i":216,"evalAlways":false,"m":0,"s":0,"u":".*","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
   return true;
} catch(err){}}}]},{"t":"JSValue","v":[{"fn":function () {// QM Event 215: Acxiom Person ID
// Set this event to "Fire Once Per Session" in QM portal
// This code returns false when PERSON_ID is available, triggering the event

try {
  
  // Try to get from cookie first
  var getCookie = function(name) {
    if (!document.cookie) return null;
    var nameEQ = name + '=';
    var cookies = document.cookie.split(';');
    for (var i = 0; i < cookies.length; i++) {
      var cookie = cookies[i];
      while (cookie.charAt(0) === ' ') {
        cookie = cookie.substring(1);
      }
      if (cookie.indexOf(nameEQ) === 0) {
        return cookie.substring(nameEQ.length);
      }
    }
    return null;
  };
  
  var riDataCookie = getCookie('ri_data');
  
  if (riDataCookie) {
    var riData = JSON.parse(decodeURIComponent(riDataCookie));
    if (riData.PERSON_ID) {
      
      if (typeof QuantumMetricAPI !== 'undefined' && QuantumMetricAPI.sendEvent) {
        QuantumMetricAPI.sendEvent(215, 0, riData.PERSON_ID);
      }
      
      return true; // Don't let QM auto-fire
    }
  }
  
  // No cookie, listen for postMessage
  
  if (!window.acxiomListener215Set) {
    window.addEventListener('message', function(event) {
      if (event.data && event.data.ri_response) {
        
        var riResponse = event.data.ri_response;
        
        // Parse if it's a string
        if (typeof riResponse === 'string') {
          riResponse = JSON.parse(riResponse);
        }
        
        if (riResponse && riResponse.PERSON_ID) {
          // Store globally
          window.acxiomPersonId = riResponse.PERSON_ID;
          
          // Manually trigger QM event since we're in an async callback
          if (typeof QuantumMetricAPI !== 'undefined' && QuantumMetricAPI.sendEvent) {
            var pageType = 'unknown';
            if (window.GCI && window.GCI.digitalData && window.GCI.digitalData.pageInfo) {
              pageType = window.GCI.digitalData.pageInfo.pageType || 'unknown';
            }
            
            QuantumMetricAPI.sendEvent(
              215,
              0,
              riResponse.PERSON_ID
            );
          }
        }
      }
    });
    
    window.acxiomListener215Set = true;
  }
  
  // Don't fire the event yet - waiting for postMessage
  return true; // Don't fire
  
} catch (error) {
  return true; // Don't fire on error
}}}]}]},"x":"QJS","sessionInfoReq":false,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":222,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":223,"f":0,"m":0,"s":1,"u":".*","x":"QCC","v":{"t":"E","v":[{"t":"SelectorPresent","v":["div.panel-three.active .exit-popup-shop-best-seller"]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var form = "";
  if (!!window.document.querySelector('div.panel-three.active .text-container')) {
    var form = window.document.querySelector('div.panel-three.active .text-container').innerText.split('\n').join('');
  }
  return form;
}catch(err){
    if (window.handleQMError) {
    window.handleQMError("223 - SP", err);
  }
}}}]}]}},{"f":0,"i":224,"evalAlways":false,"m":1,"s":1,"u":".*","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]}]},"x":"QJS","sessionInfoReq":false,"excludeBlank":true},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":225,"f":0,"m":0,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":false,"i":226,"f":0,"m":0,"s":0,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return true;}}]},{"t":"JSValue","v":[{"fn":function () {try {
    var pstString = new Date().toLocaleString("en-US", {
      timeZone: "America/Los_Angeles",
    });
    var date = new Date(pstString);
  
    // 1. Determine the NRF Start Date for the current calendar year
    var currentCalYear = date.getFullYear();
    var jan31 = new Date(currentCalYear, 0, 31);
    var dayOfWeek = jan31.getDay();
    
    var nrfStartDate;
    if (dayOfWeek <= 3) {
      nrfStartDate = new Date(currentCalYear, 0, 31 - dayOfWeek);
    } else {
      nrfStartDate = new Date(currentCalYear, 0, 31 + (7 - dayOfWeek));
    }
  
    // 2. Adjust if the current date falls before this year's NRF start
    if (date < nrfStartDate) {
      var prevJan31 = new Date(currentCalYear - 1, 0, 31);
      var prevDayOfWeek = prevJan31.getDay();
      if (prevDayOfWeek <= 3) {
        nrfStartDate = new Date(currentCalYear - 1, 0, 31 - prevDayOfWeek);
      } else {
        nrfStartDate = new Date(currentCalYear - 1, 0, 31 + (7 - prevDayOfWeek));
      }
    }
  
    // 3. Set variables based on the NRF calculation
    // The NRF Year is the year of the start date
    var year = nrfStartDate.getFullYear();
    
    var diffInMs = date - nrfStartDate;
    var diffInDays = Math.floor(diffInMs / (24 * 60 * 60 * 1000));
    var week = Math.floor(diffInDays / 7) + 1;
  return year + " | " + week;
} catch (err) {}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var obj = {};
  var pstString = new Date().toLocaleString("en-US", {
    timeZone: "America/Los_Angeles",
  });
  var date = new Date(pstString);

  // 1. Determine the NRF Start Date for the current calendar year
  var currentCalYear = date.getFullYear();
  var jan31 = new Date(currentCalYear, 0, 31);
  var dayOfWeek = jan31.getDay();

  var nrfStartDate;
  if (dayOfWeek <= 3) {
    nrfStartDate = new Date(currentCalYear, 0, 31 - dayOfWeek);
  } else {
    nrfStartDate = new Date(currentCalYear, 0, 31 + (7 - dayOfWeek));
  }

  // 2. Adjust if the current date falls before this year's NRF start
  if (date < nrfStartDate) {
    var prevJan31 = new Date(currentCalYear - 1, 0, 31);
    var prevDayOfWeek = prevJan31.getDay();
    if (prevDayOfWeek <= 3) {
      nrfStartDate = new Date(currentCalYear - 1, 0, 31 - prevDayOfWeek);
    } else {
      nrfStartDate = new Date(currentCalYear - 1, 0, 31 + (7 - prevDayOfWeek));
    }
  }

  // 3. Set variables based on the NRF calculation
  // The NRF Year is the year of the start date

  var diffInMs = date - nrfStartDate;
  var diffInDays = Math.floor(diffInMs / (24 * 60 * 60 * 1000));
  var nrfWeek = Math.floor(diffInDays / 7) + 1;

  // 4. Calculate NRF Month (4-5-4 Calendar Logic)
  var nrfMonth;
  var nrfMonthName
  if (nrfWeek <= 4) {
    nrfMonth = 1;
    nrfMonthName = "Feb";
  } else if (nrfWeek <= 9) {
    nrfMonth = 2;
    nrfMonthName = "Mar";
  } else if (nrfWeek <= 13) {
    nrfMonth = 3;
    nrfMonthName = "Apr";
  } else if (nrfWeek <= 17) {
    nrfMonth = 4;
    nrfMonthName = "May";
  } else if (nrfWeek <= 22) {
    nrfMonth = 5;
    nrfMonthName = "Jun";
  } else if (nrfWeek <= 26) {
    nrfMonth = 6;
    nrfMonthName = "Jul";
  } else if (nrfWeek <= 30) {
    nrfMonth = 7;
    nrfMonthName = "Aug";
  } else if (nrfWeek <= 35) {
    nrfMonth = 8;
    nrfMonthName = "Sep";
  } else if (nrfWeek <= 39) {
    nrfMonth = 9;
    nrfMonthName = "Oct";
  } else if (nrfWeek <= 43) {
    nrfMonth = 10;
    nrfMonthName = "Nov";
  } else if (nrfWeek <= 48) {
    nrfMonth = 11;
    nrfMonthName = "Dec";
  } else {
    nrfMonth = 12;
    nrfMonthName = "Jan";
  }

  obj.year = nrfStartDate.getFullYear();
  obj.month = date.getMonth() + 1;
  obj.day = date.getDate();
  obj.week = nrfWeek;
  obj.nrfMonth = nrfMonth;
  obj.nrfMonthName = nrfMonthName;
  obj.monthName = date.toLocaleString("en-US", { month: "long" });
  obj.dayName = date.toLocaleString("en-US", { weekday: "long" });
  QuantumMetricAPI.sendEvent(239, 0, obj.year + " | " + obj.week, obj);
  return obj;
} catch (err) {}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":227,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return {};}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":228,"f":0,"m":0,"s":1,"u":".*","x":"QCE","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["div a:has(#plpItem),button[aria-label*=\"Quick View\"],div a:has(#plpItem) *,button[aria-label*=\"Quick View\"] *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var clickedEl = QuantumMetricAPI.lastClicked;
  var productTitle = clickedEl.closest('a').querySelector('#plpItem + div').innerText;
  
  if (!!productTitle){
    return productTitle;
  }
 
} catch (err) {}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":229,"f":0,"m":1,"s":1,"u":".*","x":"QCE","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".productListContainer a:has(input[type=\"checkbox\"][checked]),.productListContainer a:has(input[type=\"checkbox\"][checked]) *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var clickedFilter = QuantumMetricAPI.lastClicked;
  var filterName = clickedFilter.innerText;
  
  if (!!filterName){
    return filterName;
  }
  
} catch (err){}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":230,"f":0,"m":0,"s":1,"u":"musicarts\\.com","x":"QCC,QCC","v":{"t":"MAE","v":[0,0,{"t":"E","v":[{"t":"SelectorPresent","v":[".productListContainer [aria-label=\"Results Per Page\"]"]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var itemsNo = document.querySelectorAll("#plpItem").length;
  
  if (!!itemsNo){
    return itemsNo;
  }
  
} catch (err) {}}}]}]},{"t":"E","v":[{"t":"SelectorPresent","v":["#plp"]},{"t":"V","v":[""]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":231,"f":0,"m":1,"s":1,"u":".*","x":"QXJ","v":{"t":"MDE","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["\\/refreshTokenForWeb"]},{"t":"XFJPar","v":[]}]},"/errorMessage"]},{"t":"ObjPathValue","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["\\/refreshTokenForWeb"]},{"t":"XFJPar","v":[]}]},"/errorMessage"]},{"t":"VXF","v":[{"t":"XHR","v":["\\/refreshTokenForWeb"]},{"t":"XFPK","v":[["qurl","url"],["qstatus","statusCode"]]},{"t":"XFMG","v":[{"t":"JSValueEx","v":[{"fn":function () {}}]}]}]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":true,"i":232,"f":0,"m":1,"s":1,"u":".*","x":"QCE,QCE","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".productListContainer a:has(input[type=\"checkbox\"]:not([checked])),.productListContainer a:has(input[type=\"checkbox\"]:not([checked])) *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var clickedFilter = QuantumMetricAPI.lastClicked;
  var filterName = clickedFilter.innerText;
  
  if (!!filterName){
    return filterName;
  }
  
} catch (err){}}}]}]},{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".productListContainer label input[type=\"checkbox\"]:not([checked]),.productListContainer label input[type=\"checkbox\"]:not([checked]) *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var clickedFilter = QuantumMetricAPI.lastClicked;
  var filterTitle = clickedFilter.closest('label').innerText;
  
  if (!clickedFilter.checked && !!filterTitle){
    return filterTitle;
  }
  
} catch (err) {}}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":233,"f":0,"m":0,"s":1,"u":".*","x":"QCC","v":{"t":"E","v":[{"t":"SelectorPresent","v":["#productList"]},{"t":"JSValueEx","v":[{"fn":function () {try {
  
  return window.location.pathname;
  
} catch (err){}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":234,"f":64,"m":1,"s":1,"u":"musicarts\\.com","x":"QXJ","v":{"t":"E","v":[{"t":"ObjSearch","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["api\\/graphql\\?op=updateCart|\\/api\\/graphql\\/mutation\\/updateCart"]},{"t":"XFJPar","v":[]}]},"/data"]},{"t":"CV","v":[{"t":"JSValueEx","v":[{"fn":function () {try {
  var response = JSON.parse(this.api.lastXHR.qresponse);
  var amount = response.data.updateCart.subtotalPrice.centAmount / 100;
  return amount.toFixed(2);
}
catch (err){}}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":235,"f":0,"m":0,"s":1,"u":"musicarts\\.com","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return {};}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":236,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":237,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":false,"i":238,"f":0,"m":0,"s":1,"u":".*","x":"QXJ","v":{"t":"E","v":[{"t":"ObjSearch","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["\\/thirdPartyLogin"]},{"t":"XFJPar","v":[]}]},"/statusMessage",{"t":"Is","v":["success"]}]},{"t":"V","v":[""]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":false,"i":239,"f":0,"m":0,"s":0,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]}]}},{"f":0,"i":240,"evalAlways":false,"m":0,"s":1,"u":"musiciansfriend\\.com","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
    
    /** @type {any} */
    var win = window;
    
    if (!win._qmMFSearchInitialized) {
      
      // A. Standard Search Form Submission
      document.addEventListener('submit', function(e) {
        /** @type {any} */
        var target = e.target;
        if (target && target.id === 'search-form') {
          localStorage.setItem('qmSearchFlag', 'true');
          localStorage.setItem('typeAheadFlag', 'false'); // Standard search, not typeahead
        }
      }, true);

      // B. Granular Click Listeners (Typeahead / History)
      document.addEventListener('click', function(e) {
        /** @type {any} */
        var t = e.target;
        if (!t || typeof t.closest !== 'function') {
          return;
        }

        // 1. Popular Search links
        if (t.closest('#searchTypeAhead-list > li > a')) {
          localStorage.setItem('qmSearchFlag', 'true');
          localStorage.setItem('typeAheadFlag', 'true');
          localStorage.setItem('typeAheadType', 'popular');
        }
        // 2. Brand/Category links
        else if (t.closest('#typeAheadDimensions > li > ul > li > a')) {
          localStorage.setItem('qmSearchFlag', 'true');
          localStorage.setItem('typeAheadFlag', 'true');
          localStorage.setItem('typeAheadType', 'brand/category');
        }
        // 3. Product items
        else if (t.closest('#typeAheadProducts > ul > li')) {
          localStorage.setItem('qmSearchFlag', 'true');
          localStorage.setItem('typeAheadFlag', 'true');
          localStorage.setItem('typeAheadType', 'product');
        }
        // 4. Recent Search History
        else if (t.closest('.recent-search-history-item') && !t.closest('.clear-history')) {
          localStorage.setItem('qmSearchFlag', 'true');
          localStorage.setItem('typeAheadFlag', 'true');
          localStorage.setItem('typeAheadType', 'history');
        }
      }, true);

      win._qmMFSearchInitialized = true;
    }
  
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError('240', err);
  }
}
return "";}}]},{"t":"V","v":[""]}]},"x":"QJS","sessionInfoReq":false,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":241,"f":0,"m":1,"s":1,"u":".*","x":"QJS,QJS,QJS","v":{"t":"MAE","v":[1,0,{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {(function() {
  // Prevent duplicate listeners
  if (window.gtmNavClickInitialized) {
    return;
  }

  document.addEventListener('click', function(event) {
    /** @type {any} */
    var target = event.target;
    if (!target || !target.closest) {
      return;
    }
    var el = target;

    // Detect Site
    var isMF = window.location.hostname.indexOf('musiciansfriend.com') > -1;

    // 1. Identify context/container
    var isDesktopMainNav, isDesktopRightNav, isSubNavFlyout, isMobilePanel, isTopPromo, isHamburger, isDrawerMenu;
    var navType = "Main Nav";

    if (isMF) {
      // MF Selectors
      isHamburger = el.closest('.responsive-header_utility_mobile_hamburger, [data-js-mobile-menu-btn]');
      isDesktopMainNav = el.closest('.responsive-header_browse_categories');
      isDesktopRightNav = el.closest('.responsive-header_utility_search, .responsive-header_utility_help, #yourAccount-dropdown, .responsive-header_utility_cart');
      isSubNavFlyout = el.closest('.responsive-header_browse_categories_flyout');
      isTopPromo = el.closest('.responsive-header_promo');
      isDrawerMenu = el.closest('#mf-shopping-menubar[data-js-mobile-menu]');
      
      // Determine Nav Type for MF
      if (isHamburger) {
        navType = "Hamburger";
      } else if (isSubNavFlyout) {
        navType = "Sub Nav";
      } else if (isDrawerMenu) {
        navType = "Mobile Menu";
      } else if (isTopPromo) {
        navType = "Top Promo Nav";
      } else if (isDesktopRightNav) {
        navType = "Utility Nav";
      }
    } else {
      // GC Selectors (Original)
      isDesktopMainNav = el.closest('[data-testid="new-header-bottom"]');
      isDesktopRightNav = el.closest('[data-testid="new-header-right-nav"]');
      isSubNavFlyout = el.closest('.sub-category-content, [class*="SubCategoryModalContent"]');
      isMobilePanel = el.closest('[data-testid="left-menu"], [class*="left-menu"]');
      isTopPromo = el.closest('.gc-top-headroll-container');
      isHamburger = el.closest('.shop-menu, [aria-label="shop menu"]');
      isDrawerMenu = el.closest('#drawer-root, [class*="Drawer_"], .drawer-wrapper, .shop-menu-layout');

      // Determine Nav Type for GC
      if (isHamburger) {
        navType = "Hamburger";
      } else if (isDrawerMenu) {
        navType = "Mobile Menu";
      } else if (isSubNavFlyout) {
        navType = "Sub Nav";
      } else if (isMobilePanel) {
        navType = "Mobile Panel";
      } else if (isTopPromo) {
        navType = "Top Promo Nav";
      } else if (isDesktopRightNav) {
        navType = "Utility Nav";
      }
    }

    // 2. Filter out non-nav clicks
    if (!isDesktopMainNav && !isDesktopRightNav && !isSubNavFlyout && !isMobilePanel && !isTopPromo && !isHamburger && !isDrawerMenu) {
      return;
    }

    // 3. Find the actionable element
    var selector = 'a, button, li[class*="border-b"], [class*="shop-menu-area"] li';
    if (isMF) {
      selector += ', [data-js-categories-link], .responsive-header_utility_help, .responsive-header_utility_cart, .responsive-header_utility_logo';
    }
    var actionableElement = el.closest(selector);
    
    if (!actionableElement && (isDrawerMenu || isSubNavFlyout)) {
      actionableElement = el;
    }

    if (!actionableElement) {
      return;
    }
    
    // 4. Extract data
   // var tagName = (actionableElement.tagName || "").toLowerCase();
    
    var role = actionableElement.getAttribute && 	 actionableElement.getAttribute('role');
	var elementHref = actionableElement.getAttribute ? actionableElement.getAttribute('href') || '' : '';

	var elementType = role === 'button' ? 'Button' : (elementHref && elementHref !== '#' ? 'Link' : 'Button');
    var navLabel = "";
    var rawText = actionableElement.textContent || "";
    
    if (isHamburger) {
      navLabel = "Hamburger Icon";
    } else if (rawText.trim()) {
      navLabel = rawText.trim().split('\n')[0].replace(/\s+/g, ' ');
      
      if (navLabel.toLowerCase().indexOf('back') === 0 && navLabel.length < 15) {
        navLabel = "Back Button";
      }
    } else {
      navLabel = (actionableElement.getAttribute && (actionableElement.getAttribute('aria-label') || actionableElement.getAttribute('title'))) || 
                 (actionableElement.querySelector && actionableElement.querySelector('[aria-label]') && actionableElement.querySelector('[aria-label]').getAttribute('aria-label')) || 
                 "";
    }

    // 5. Fire Tags and QM Events
    if (navLabel && navLabel !== "") {
      // GTM DataLayer Push
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({
        'event': 'Web - Nav Click',
        'nav_interaction': {
          'type': navType,
          'label': navLabel,
          'interaction_type': elementType,
          'url': elementHref
        }
      });

      // Quantum Metric Event (ID 241)
      if (window.QuantumMetricAPI && typeof window.QuantumMetricAPI.sendEvent === 'function') {
        var qmPayload = {
          navType: navType,
          itemLabel: navLabel,
          interactionType: elementType,
          url: elementHref
        };
        window.QuantumMetricAPI.sendEvent(241, 0, navLabel, qmPayload);
      }
      
      console.log('[GTM/QM NAV] ' + navType + ' Click: ' + navLabel + ' (' + elementType + ')');
     }
  }, true);

  window.gtmNavClickInitialized = true;
  window.qm241GcMainNavListenerSet = true;
})();}}]},{"t":"V","v":[""]},{"t":"JSValue","v":[{"fn":function () {}}]}]},{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {// Click Event: GC Side Nav (Flyout) - Fires QM Event 241
// Payload (stringified JSON):
// { navType: "Side Nav", navButton: "Solid Body", navSubCategory: "Electric Guitars" }
/*
try {
  if (window.qm241GcSideNavListenerSet) {
    return;
  }

  document.addEventListener("click", function (event) {
    var target = event.target;

    if (target && target instanceof Element) {

      // 1) Only proceed if click is inside the flyout content areas
      var flyoutRoot = target.closest(
        '.sub-category-content, [class*="sub-category-content"], .links-area, [class*="links-area"], [class*="subCategories"], [class*="subCategory"]'
      );
      if (!flyoutRoot) {
        return;
      }

      // 2) Side nav items are <a> links
      var link = target.closest("a[href]");
      if (!link) {
        return;
      }

      var navButton = (link.textContent || "").replace(/^\s+|\s+$/g, "");
      if (!navButton) {
        return;
      }

      // 3) Try to get navSubCategory (column heading)
      var navSubCategory = "";

      // 3a) Normal flyout: find the UL, then look for text right before it in the same parent
      var ul = link.closest("ul");
      if (ul && ul.parentNode && ul.parentNode.children) {
        var kids = ul.parentNode.children;
        var headingText = "";
        for (var i = 0; i < kids.length; i++) {
          if (kids[i] === ul) break;

          var tag = (kids[i].tagName || "").toLowerCase();
          if (tag !== "ul" && tag !== "li" && tag !== "a") {
            var t = (kids[i].textContent || "").replace(/^\s+|\s+$/g, "");
            if (t) headingText = t;
          }
        }
        navSubCategory = headingText;
      }

      // 3b) "More" flyout fallback: read active left menu item
      // left menu wrapper exists only on the More flyout layout
      if (!navSubCategory) {
        var leftMenu = document.querySelector('[data-testid="left-menu"]');
        if (leftMenu) {
          // active left item has border-std-red-200 in your DOM
          var active =
            leftMenu.querySelector('a[class*="border-std-red-200"]') ||
            leftMenu.querySelector('a[class*="border-std-red"]');

          if (active) {
            navSubCategory = (active.textContent || "").replace(/^\s+|\s+$/g, "");
          }
        }
      }

      // 4) Build payload
      var payloadObj = {
        navType: "Side Nav",
        navButton: navButton
      };
      if (navSubCategory) {
        payloadObj.navSubCategory = navSubCategory;
      }

      // 5) Fire QM event (store as Event Details)
      if (window.QuantumMetricAPI && window.QuantumMetricAPI.sendEvent) {
        QuantumMetricAPI.sendEvent(241, 0, payloadObj.navtype , payloadObj);
      }
    }
  });

  window.qm241GcSideNavListenerSet = true;

} catch (error) {
  if (window.handleQMError) {
    window.handleQMError("241-gc-side-nav", error);
  }
  return false;
}
*/}}]},{"t":"V","v":[""]},{"t":"JSValue","v":[{"fn":function () {}}]}]},{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {// QM Nav: Hamburger + Shop Menu + Main + Side (Levels 1-5)
// Fires QM Event 241 with JSON stringified payload
// Safe ES5, defensive selectors, prevents duplicate listeners
/*
try {
  if (window.qm241HamburgerNavListenerSet) {
    return;
  }

  // helpers
  function trim(s) { return (s || "").replace(/^\s+|\s+$/g, ""); }
  function safeClosest(el, sel) { try { return el && el.closest ? el.closest(sel) : null; } catch(e){ return null; } }
  function sendQM(obj) {
    if (window.QuantumMetricAPI && window.QuantumMetricAPI.sendEvent) {
      try {
        QuantumMetricAPI.sendEvent(241, 0, JSON.stringify(obj));
      } catch (e) {
        if (window.handleQMError) window.handleQMError("241-qm-send", e);
      }
    }
  }

  // Candidate hamburger selectors (lots of fallbacks to match variations)
  var hamburgerSelectors = [
    'button[aria-label*="menu"]',
    'button[aria-label*="Menu"]',
    'button[aria-label*="open menu"]',
    'button[class*="menu"]',
    'button[class*="hamburger"]',
    'button[class*="gc-icon"]',
    '.gc-icon-menu',
    '.header-menu-button',
    '#drawer-toggle' // any specific ID you might have
  ];

  // Drawer wrapper selectors (the left-shop menu Drawer)
  var drawerRootSelectors = [
    '#drawer-root',
    '.Drawer_drawerContainer',
    '.Drawer_drawer',
    '.Drawer_drawerLeftOpened',
    'div[role="dialog"] .Drawer_drawer' // fallback
  ];

  // Flyout / side-list selectors inside desktop flyouts (if they exist)
  var flyoutContentSelectors = [
    '.sub-category-content',
    '.links-area',
    '[class*="subCategories"]',
    '[class*="subCategory"]',
    '.sub-categories',
    '.subCategories'
  ];

  // Utility: returns true if el is inside any of selector list
  function insideAny(el, list) {
    if (!el) return false;
    for (var i = 0; i < list.length; i++) {
      if (safeClosest(el, list[i])) return true;
    }
    return false;
  }

  // Determine column/heading for a clicked link (best-effort)
  function findColumnHeading(linkEl) {
    if (!linkEl) return "";
    // Try: heading inside nearest parent column
    var col = safeClosest(linkEl, '.subCategory, .sub-category, .sub-categories, .subCategories, .links-area, [class*="subCategories"]');
    if (col) {
      // common heading tags
      var h = col.querySelector('h1,h2,h3,h4,[role="heading"],.title,.heading');
      if (h && (h.textContent || "").trim()) return trim(h.textContent);
      // fallback: look for the first non-empty text block before lists
      var children = col.children;
      for (var j = 0; j < children.length; j++) {
        var tag = (children[j].tagName || "").toLowerCase();
        if (tag !== "ul" && tag !== "li" && tag !== "a") {
          var t = trim(children[j].textContent);
          if (t) return t;
        }
      }
    }

    // Another fallback: nearest ancestor with a visible text label
    var ancestor = linkEl.parentNode;
    var climb = 0;
    while (ancestor && climb < 6) {
      var txt = trim(ancestor.getAttribute && ancestor.getAttribute('data-category-name') || "");
      if (txt) return txt;
      var content = trim(ancestor.textContent || "");
      if (content && content.length < 40 && content.indexOf('\n') === -1) {
        // prefer short heading-like texts
        return content;
      }
      ancestor = ancestor.parentNode;
      climb++;
    }

    return "";
  }

  // Top-level drawer list item detection (left menu)
  function isDrawerTopItem(el) {
    // Many of the top items are <button> or <li> with span text inside the drawer
    if (!el) return false;
    var btn = safeClosest(el, '.Drawer_content button, .Drawer_content .sub-categories button, #drawer-root button, .Drawer_drawer button, .sub-categories button');
    if (btn) return true;
    // also li>span pattern
    if (safeClosest(el, '#drawer-root li, .Drawer_content li, .Drawer_drawer li')) return true;
    return false;
  }

  // Determine if clicked element is a "final" link inside side list (desktop flyout or mobile sublist)
  function isFinalSubItem(el) {
    // Links (<a>) inside flyout ULs are typically the final items
    if (!el) return false;
    if (safeClosest(el, 'a[href]') && insideAny(el, flyoutContentSelectors)) return true;
    if (safeClosest(el, '.sub-categories a, .subCategory a, .links-area a')) return true;
    // mobile case: li items in sublist
    if (safeClosest(el, '.Drawer_content ul li a, .Drawer_content ul li')) return true;
    return false;
  }

  // Listener
  document.addEventListener('click', function (event) {
    var target = event.target;
    if (!(target && target instanceof Element)) return;

    // 1) HAMBURGER button clicked -> Level 1
    // Match any of the hamburger selectors
    for (var i = 0; i < hamburgerSelectors.length; i++) {
      var sel = hamburgerSelectors[i];
      if (safeClosest(target, sel)) {
        sendQM({
          navType: "Hamburger",
          navButton: "Hamburger Icon"
        });
        return; // done
      }
    }

    // 2) Clicks INSIDE drawer (mobile hamburger shop menu)
    if (insideAny(target, drawerRootSelectors) || safeClosest(target, '#drawer-root, .Drawer_drawer, .Drawer_drawerContainer, .Drawer_drawerLeftOpened')) {

      // If the click is a top-level drawer item (level 2)
      if (isDrawerTopItem(target)) {
        var topText = "";
        // try to find a button/span text first
        var topBtn = safeClosest(target, '.Drawer_content button, #drawer-root button, .Drawer_drawer button, .sub-categories button');
        if (topBtn) topText = trim(topBtn.textContent || "");
        if (!topText) {
          // fallback: li>span
          var li = safeClosest(target, '.Drawer_content li, #drawer-root li, .Drawer_drawer li');
          if (li) topText = trim(li.textContent || "");
        }
        if (topText) {
          sendQM({
            navType: "Hamburger Shop Menu",
            navButton: topText || "Hamburger Icon"
          });
          return;
        }
      }

      // 3) If user clicked a category inside the drawer that should be treated as "Main Nav" (Level 3)
      // Example: clicking "Guitars" inside the mobile drawer categories list
      var clickedLi = safeClosest(target, '.Drawer_content li, #drawer-root li, .Drawer_drawer li');
      if (clickedLi) {
        // check if this li contains an inner arrow or expands to subcategories; if it is a plain category link it is likely a Main Nav click
        var span = clickedLi.querySelector('span, a, button');
        var buttonText = span ? trim(span.textContent || "") : trim(clickedLi.textContent || "");
        if (buttonText) {
          // heuristics for main nav: the mobile drawer uses a top-level list of categories
          // treat these as Main Nav clicks (Level 3)
          sendQM({
            navType: "Main Nav",
            navButton: buttonText
          });
          return;
        }
      }

      // 4) If user clicked on a subcategory list item (Level 4 or 5)
      // Mobile: after clicking a top-level category the drawer shows "Categories" header + a list (see screenshots)
      // Desktop: final links are <a> inside flyoutContentSelectors
      if (isFinalSubItem(target)) {
        var linkEl = safeClosest(target, 'a[href]') || safeClosest(target, 'li') || target;
        var navButton = trim((linkEl && (linkEl.textContent || "")) || "");
        // Try to find navSubCategory (column heading or parent title)
        var navSubCategory = findColumnHeading(linkEl);

        // If navSubCategory empty for mobile drawer, try the parent header in the drawer content
        if (!navSubCategory) {
          var header = safeClosest(linkEl, '.Drawer_content') || safeClosest(linkEl, '#drawer-root');
          if (header) {
            // Try to find the strong/heading inside drawer
            var h = header.querySelector('h1,h2,h3,h4,.title,.heading,.department-detail-title');
            if (h) navSubCategory = trim(h.textContent || "");
          }
        }

        // If still empty, attempt to use the last top-level drawer selection as navSubCategory:
        // (We can't persist state across clicks reliably here, but we attempt to read the visible "back" header)
        if (!navSubCategory) {
          var backHeader = document.querySelector('.Drawer_content .department-detail, .Drawer_content .department-detail-title, .department-detail-title');
          if (backHeader) navSubCategory = trim(backHeader.textContent || "");
        }

        // Determine final payload type: Side Nav (levels 4/5)
        var payload = {
          navType: "Side Nav",
          navButton: navButton || "Unknown"
        };
        if (navSubCategory) payload.navSubCategory = navSubCategory;

        sendQM(payload);
        return;
      }

      // if no special case matched, ignore drawer click
      return;
    } // end drawer handling

    // 5) Desktop flyout: clicks inside flyoutContentSelectors should be treated as Side Nav / Main Nav accordingly
    if (insideAny(target, flyoutContentSelectors)) {

      // If user clicked a link in the flyout (final item)
      var a = safeClosest(target, 'a[href]');
      if (a) {
        var linkText = trim(a.textContent || "");
        var colHeading = findColumnHeading(a) || "";
        var payload2 = {
          navType: "Side Nav",
          navButton: linkText || "Unknown"
        };
        if (colHeading) payload2.navSubCategory = colHeading;
        sendQM(payload2);
        return;
      }

      // If user clicked a large flyout title or top-level header, treat as Main Nav (desktop)
      var titleEl = safeClosest(target, 'h1, h2, [role="heading"]');
      if (titleEl && titleEl.textContent) {
        sendQM({
          navType: "Main Nav",
          navButton: trim(titleEl.textContent)
        });
        return;
      }
    }

    // no match -> do nothing
  });

  window.qm241HamburgerNavListenerSet = true;

} catch (err) {
  if (window.handleQMError) window.handleQMError("241-hamburger-nav", err);
  return false;
}
*/}}]},{"t":"V","v":[""]},{"t":"JSValue","v":[{"fn":function () {}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":242,"f":0,"m":1,"s":1,"u":"\\/cart","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {// it was previously set to "selector present" with this selector:
// div:has(>[for="ma-coupon-code"]) > p
// but it was overcounting so we did it via the tag manager
return false;}}]},{"t":"JSValue","v":[{"fn":function () {// this is what was set previously for the "selector present" config
// css selector: div:has(>[for="ma-coupon-code"]) > p
return false;}}]},{"t":"JSValue","v":[{"fn":function () {// this is what was set previously for the "selector present" config
/*
try{
  var obj = {
    analyticsData: {},
    formExceptions: {}
  };
  if(window.location.hostname.match(/musicarts\.com/)) {
    obj.analyticsData.couponCode = window.document.querySelector('input#ma-coupon-code').value;
    obj.analyticsData.pageType = "shopping cart";
    obj.formExceptions.localizedMessage = window.document.querySelector('div:has(>[for="ma-coupon-code"]) > p').innerText;
  	return obj;
  }
}catch(err){}
*/
return false;}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":243,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {try {
  var hasMidiPlayer = function() {
    return !!(
      document.querySelector('[data-midi-player]') ||
      document.querySelector('#power-btn') ||
      document.querySelector('[data-gc-midi-player]')
    );
  };

  var sendToQM = function(payload) {
    if (!window.QuantumMetricAPI || typeof window.QuantumMetricAPI.sendEvent !== 'function') return;
    var action = payload.action || '';
    var state = payload.state || '';
    var primaryValue = (action && state) ? action + '|' + state : (action || state || 'midi-player-action');
    var attrs = {};
    if (payload.feature) attrs.feature = payload.feature;
    if (payload.action) attrs.action = payload.action;
    if (payload.state) attrs.state = payload.state;
    // Replace 0 with actual QM event ID after creation in Quantum Metric
    window.QuantumMetricAPI.sendEvent(243, 0, primaryValue, attrs);
  };

  if (!window._midiPlayerActionsListenerSet) {
    window._midiPlayerActionsListenerSet = true;
    window.addEventListener('dlUpdateEvent', function(e) {
      try {
        if (e.detail && e.detail.event === 'midiPlayerAction' && e.detail.midiPlayerAction) {
          if (hasMidiPlayer()) {
            sendToQM(e.detail.midiPlayerAction);
          }
        }
      } catch (err) {}
    });
  }

  return false;
} catch (err) {
  return false;
}}}]},{"t":"V","v":[""]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"f":0,"i":244,"evalAlways":false,"m":0,"s":1,"u":"guitarcenter\\.com\\/","v":{"t":"E","v":[{"t":"SelectorPresent","v":["body:not(:has(div[data-testid=\"responsive-menu\"])):not(:has(#newHeaderBottom))"]},{"t":"JSValueEx","v":[{"fn":function () {try {
  return window.location.href;
}catch(err){
  if (window.handleQMError) {
    window.handleQMError("244", err);
  }
}}}]}]},"x":"QCC","sessionInfoReq":false,"excludeBlank":true},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":245,"f":0,"m":0,"s":0,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {// QM Event: Web - Checkout - Payment Type
// Listens for applyPayment via dlUpdateEvent. Stores multiplePaymentType in localStorage.
// Only runs on payment page.

try {
  var pageLocation = window.dataLayer &&
    window.dataLayer._state &&
    window.dataLayer._state.pageLocation;
  if (pageLocation !== 'payment') {
    return;
  }

  if (!window._applyPaymentListenerSet) {
    window._applyPaymentListenerSet = true;
    window.addEventListener('dlUpdateEvent', function(e) {
      try {

        var evt = /** @type {CustomEvent} */ (e);
        var d = evt ? evt.detail : null;
        if (!d) {
          return;
        }
        if ((d.eventName || d.event) !== 'applyPayment') {
          return;
        }
        if (d.applyPayment && d.applyPayment.multiplePaymentType) {
          var value = d.applyPayment.multiplePaymentType;
          if (value && typeof value === 'string') {
            try {
              localStorage.setItem('applyPaymentTypes', value.trim());
            } catch (lsErr) {}
          }
        }
      } catch (err) {}
    });
  }
} catch (err) {}}}]},{"t":"V","v":[""]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":true,"i":246,"f":64,"m":0,"s":2,"u":"musiciansfriend\\.com","x":"QCC","v":{"t":"E","v":[{"t":"SelectorPresent","v":["#cartValueRR"]},{"t":"CV","v":[{"t":"JSValueEx","v":[{"fn":function () {try {
  var stringTotal = window.document.querySelector('#cartValueRR').innerText;
  var subtotal = parseFloat(stringTotal.replace(/\,/g,''));
  return subtotal;
}catch(err){
  
}}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":247,"f":0,"m":1,"s":1,"u":"musicarts\\.com","x":"QXJ","v":{"t":"MDE","v":[{"t":"ObjSearch","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["api\\/graphql?"]},{"t":"XFJPar","v":[]}]},"/data",{"t":"Not","v":[{"t":"Is","v":["null"]}]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var qUrl = QuantumMetricAPI.lastXHR.qurl;
  var qUrlParameters = {};
  var queries = [];
  var queryStringIndex = qUrl.indexOf("?");
  if (queryStringIndex !== -1) {
    var queryString = qUrl.substring(queryStringIndex + 1);
    var hashIndex = queryString.indexOf("#");
    var actualQueryString =
      hashIndex !== -1 ? queryString.substring(0, hashIndex) : queryString;
    actualQueryString.split("&").forEach(function (pair) {
      var qObj = {};
      qObj.combined = pair;
      var parts = pair.split("=");
      if (parts.length === 2) {
        qUrlParameters[decodeURIComponent(parts[0])] = decodeURIComponent(
          parts[1] || ""
        );
        qObj.qParam = decodeURIComponent(parts[0]);
        qObj.qString = decodeURIComponent(parts[1] || "");
      }
      queries.push(qObj);
    });
  }
  var obj = {};
  obj.queryString = JSON.stringify(qUrlParameters);
  obj.responseCode = QuantumMetricAPI.lastXHR.status;
  var prtEntries = window.performance.getEntriesByType('resource').filter(function (prt) {
    return prt.name === QuantumMetricAPI.lastXHR.qurl;
  });
  var prtEntry = prtEntries[prtEntries.length - 1];
  obj.responseTime = prtEntry && prtEntry.duration;
  obj.responseSize = QuantumMetricAPI.lastXHR.qresponse.length;
  QuantumMetricAPI.setSessionVar("obj", obj);
  return qUrl;
} catch (err) {}}}]},{"t":"VXF","v":[{"t":"XHR","v":["api\\/graphql?"]},{"t":"XFPK","v":[["qurl","url"],["qstatus","statusCode"]]},{"t":"XFMG","v":[{"t":"JSValueEx","v":[{"fn":function () {try {
  var obj = QuantumMetricAPI.getSessionVar("obj", {});
  return obj;
}catch(err){}}}]}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":248,"f":0,"m":0,"s":1,"u":"musicarts\\.com","x":"QCC,QPC","v":{"t":"MAE","v":[0,0,{"t":"E","v":[{"t":"SelectorPresent","v":[".ReactModalPortal div div[aria-label=\"Sign In or Join\"]"]},{"t":"V","v":[""]}]},{"t":"E","v":[{"t":"ValueClause","v":[{"t":"SelectorText","v":["body"]},{"t":"Contains","v":["Login to Account"]}]},{"t":"V","v":[""]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":249,"f":0,"m":1,"s":1,"u":"/cart","x":"QCE","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"KeyValue","v":["value","Apply"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  return document.querySelector("#ma-coupon-code").value;
} catch(err) {
  
}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":251,"f":0,"m":0,"s":1,"u":"musicarts\\.com/cart","x":"QXJ,QJS","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["/api/graphql"]},{"t":"XFJPar","v":[]}]},"/data/updateCart/discountCodes",{"t":"Not","v":[{"t":"Is","v":["null"]}]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var response = JSON.parse(this.api.lastXHR.qresponse);
  var code = response.data.updateCart.discountCodes[0].discountCode.code;
  return code;
}
catch (err){}}}]}]},{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
  if (
    QuantumMetricAPI.lastXHR &&
    QuantumMetricAPI.lastXHR.qurl &&
    QuantumMetricAPI.lastXHR.qurl.indexOf('updateCart') > -1 &&
    QuantumMetricAPI.lastXHR.qresponse &&
    QuantumMetricAPI.lastXHR.qresponse.data &&
    QuantumMetricAPI.lastXHR.qresponse.data.updateCart &&
    QuantumMetricAPI.lastXHR.qresponse.data.updateCart.discountCodes
  ) {
    return true;
  }
} catch (err) {
}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var response = JSON.parse(this.api.lastXHR.qresponse);
  var code = response.data.updateCart.discountCodes[0].discountCode.code;
  return code;
}
catch (err){}}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":252,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return true;}}]},{"t":"JSValue","v":[{"fn":function () {// Listens for dlUpdateEvent (any event name). Looks for sfData.sfCampaignName and sfData.sfEventType
// and sends to Quantum Metric (Event 197) as JSON. Supports multiple SF test types.
// Expected dataLayer push:
//   window.dataLayer.push({
//     eventName: 'sfEvent',
//     sfData: { sfCampaignName: 'exitIntentPopup', sfEventType: 'formSubmit' }
//   });
// Schema: Web - Salesforce - CampaignQM - Schema.json

if (!window._salesforceQMCampaignHelperInitialized) {
  window._salesforceQMCampaignHelperInitialized = true;

  try {
    var _sfEventsSentQM = window._sfEventsSentQM = window._sfEventsSentQM || {};

    var sendSfEventToQM = function(payload) {
      if (!payload || !payload.sfCampaignName) {
        return;
      }
      var dedupeKey = (payload.sfEventType || '') + '|' + payload.sfCampaignName;
      if (_sfEventsSentQM[dedupeKey]) {
        return;
      }
      try {
        if (window.QuantumMetricAPI && typeof window.QuantumMetricAPI.sendEvent === 'function') {
          window.QuantumMetricAPI.sendEvent(253, 0, payload.sfCampaignName, payload);
          _sfEventsSentQM[dedupeKey] = true;
        }
      } catch (err) {}
    };

    // Recursively find sfData (object with sfCampaignName and sfEventType) in payload
    var findSfData = function(obj) {
      if (!obj || typeof obj !== 'object') {
        return null;
      }
      if (obj.sfData && obj.sfData.sfCampaignName) {
        return {
          sfCampaignName: String(obj.sfData.sfCampaignName).trim(),
          sfEventType: obj.sfData.sfEventType ? String(obj.sfData.sfEventType).trim() : ''
        };
      }
      if (obj.sfCampaignName) {
        return {
          sfCampaignName: String(obj.sfCampaignName).trim(),
          sfEventType: obj.sfEventType ? String(obj.sfEventType).trim() : ''
        };
      }
      for (var key in obj) {
        if (Object.prototype.hasOwnProperty.call(obj, key)) {
          var found = findSfData(obj[key]);
          if (found) {
            return found;
          }
        }
      }
      return null;
    };

    var processSfEvent = function(eventData) {
      var payload = findSfData(eventData);
      if (payload && payload.sfCampaignName) {
        sendSfEventToQM(payload);
      }
    };

    // Process historical dataLayer entries
    if (window.dataLayer && Array.isArray(window.dataLayer)) {
      for (var i = 0; i < window.dataLayer.length; i++) {
        var entry = window.dataLayer[i];
        if (entry && typeof entry === 'object') {
          processSfEvent(entry);
        }
      }
    }

    // Listen for future dlUpdateEvent (generic - any event with sfCampaignName)
    if (typeof window.addEventListener === 'function') {
      window.addEventListener('dlUpdateEvent', function(e) {
        try {
          if (e.detail) {
            processSfEvent(e.detail);
          }
        } catch (listenerErr) {}
      });
    }
  } catch (e) {}
}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":253,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":255,"f":0,"m":1,"s":1,"u":".*","x":"QCC","v":{"t":"E","v":[{"t":"SelectorPresent","v":["#ae-error-message0"]},{"t":"SelectorText","v":["#ae-error-message0"]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":256,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":257,"f":0,"m":0,"s":0,"u":".*\\/rigadvisor(\\/|\\?|$)","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {(function () {
  if (window.rigAdvisorQMHelperInitialized) {
    return;
  }
  window.rigAdvisorQMHelperInitialized = true;

  var QM_RIG_ADVISOR_LOG = '[QM Rig Advisor / Event 256]';

  // Tracks the most recent search per thread so productImpression can carry it
  var lastSearchByThread = {};

  var sendToQM = function (primaryValue, attributes) {
    if (!primaryValue) {
      return;
    }
    try {
      if (window.QuantumMetricAPI && typeof window.QuantumMetricAPI.sendEvent === 'function') {
        window.QuantumMetricAPI.sendEvent(256, 0, String(primaryValue), attributes);
      }
    } catch (err) {
      console.error(QM_RIG_ADVISOR_LOG, 'sendEvent error', err);
      if (window.handleQMError) {
        window.handleQMError('rig-advisor-qm', err);
      }
    }
  };

  var isRigAdvisorEvent = function (detail) {
    return !!(detail && detail.pageLocation === 'chat_drawer' && detail.eventName);
  };

  var processDetail = function (detail) {
    if (!detail || !detail.event || !isRigAdvisorEvent(detail)) {
      return;
    }

    // Remember this search so a later productImpression in the same thread can reference it
    if (detail.event === 'search' && detail.threadId) {
      lastSearchByThread[detail.threadId] = {
        searchQuery: detail.searchQuery,
        searchType: detail.searchType
      };
    }

    var attributes = {
      event: detail.event,
      eventName: detail.eventName,
      pageLocation: detail.pageLocation,
      threadId: detail.threadId,
      userId: detail.userId,
      isNewThread: detail.isNewThread,
      searchQuery: detail.searchQuery,
      searchType: detail.searchType,
      pfm: detail.pfm,
      responseTime: detail.responseTime,
      hasResults: detail.hasResults,
      products: detail.products,
      productName: detail.productName,
      productPosition: detail.productPosition,
      productUrl: detail.productUrl,
      conversationTitle: detail.conversationTitle,
      categoryName: detail.categoryName,
      storeOnlyEnabled: detail.storeOnlyEnabled
    };

    // Attach the triggering search's query/type onto productImpression
    if (detail.event === 'productImpression' && detail.threadId && lastSearchByThread[detail.threadId]) {
      attributes.searchQuery = attributes.searchQuery || lastSearchByThread[detail.threadId].searchQuery;
      attributes.searchType = attributes.searchType || lastSearchByThread[detail.threadId].searchType;
    }

    sendToQM(detail.eventName, attributes);
  };

  try {
    window.dataLayer = window.dataLayer || [];
    var originalPush = window.dataLayer.push;
    window.dataLayer.push = function () {
      var result = originalPush.apply(window.dataLayer, arguments);
      for (var i = 0; i < arguments.length; i++) {
        try {
          processDetail(arguments[i]);
        } catch (pushErr) {
          console.error(QM_RIG_ADVISOR_LOG, 'processDetail error', pushErr);
          if (window.handleQMError) {
            window.handleQMError('rig-advisor-qm-push', pushErr);
          }
        }
      }
      return result;
    };
  } catch (e) {
    console.error(QM_RIG_ADVISOR_LOG, 'init error', e);
    if (window.handleQMError) {
      window.handleQMError('rig-advisor-qm-init', e);
    }
  }
})();}}]},{"t":"V","v":[""]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":258,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {// QM Event: Web - Cart Updates (additions/removals/qty/save-for-later context)
// GC: dlUpdateEvent — removeItemFromCart | changeItemQuantityForCart | saveCartItemForLater |
//     moveCartItemFromSaveLater (saved item moved back to cart)
// GC: also listens for removeItemDetail (GTM-pushed, flat product detail) to attach
//     removedItemDetails (array) onto the native remove event's payload
// GC: also listens for saveForLaterItemDetail (GTM-pushed, flat product detail) — GC has
//     no native dlUpdateEvent trigger for Save for Later, so this push fires the event
//     directly, attaching saveForLaterItemDetails (array) onto the payload
// MF: after remove, page refresh — read dataLayer._state.removeFromCart once on load
// MF: dlUpdateEvent — quantityChangedInCart
//
// Payload schema + primary key: Web - Cart Updates - QM Schema.json (orderId|cartAction when order id exists)
// Register event ID in Quantum Metric before go-live (placeholder below).
try {
  var QM_EVENT_WEB_CART_UPDATES = 258; 

  var isMusiciansFriend = function () {
    var h = (window.location && window.location.hostname) || '';
    return h.indexOf('musiciansfriend') !== -1 || h.indexOf('mf.') !== -1;
  };

  var isGuitarCenter = function () {
    var h = (window.location && window.location.hostname) || '';
    return h.indexOf('guitarcenter') !== -1;
  };

  var getOrder = function () {
    try {
      var gci = window.GCI && window.GCI.digitalData && window.GCI.digitalData.siteVars;
      return gci && gci.order ? gci.order : null;
    } catch (e) {
      return null;
    }
  };

  var parseMoney = function (v) {
    if (v === null || v === undefined) {
      return undefined;
    }
    if (typeof v === 'number' && !isNaN(v)) {
      return v;
    }
    var s = String(v).replace(/[^0-9.-]/g, '');
    var n = parseFloat(s);
    return isNaN(n) ? undefined : n;
  };

  /**
   * GC: order.subtotal — MF: order.subTotal (already numeric from GCI)
   */
  var getOrderSubtotal = function (order) {
    if (!order) {
      return undefined;
    }

    var firstSecond;
    if (isGuitarCenter()) {
      firstSecond = ['subtotal', 'subTotal'];
    } else if (isMusiciansFriend()) {
      firstSecond = ['subTotal', 'subtotal'];
    } else {
      firstSecond = ['subtotal', 'subTotal'];
    }

    var j;
    for (j = 0; j < firstSecond.length; j++) {
      var key = firstSecond[j];
      var val = order[key];
      if (val !== undefined && val !== null) {
        return val;
      }
    }

    var fallbacks = [
      order.total,
      order.orderTotal,
      order.priceInfo && order.priceInfo.subtotal,
      order.priceInfo && order.priceInfo.subTotal,
      order.priceInfo && order.priceInfo.orderTotal
    ];
    for (j = 0; j < fallbacks.length; j++) {
      var n = fallbacks[j];
      if (n !== undefined && n !== null) {
        return n;
      }
    }
    return undefined;
  };

  /** Cart/Checkout - Cart ID aligned line shape (QM) */
  var mapRowToCartIdItem = function (row, isGc) {
    if (isGc) {
      var lineTotal =
        row.discountedPrice !== undefined && row.discountedPrice !== null
          ? row.discountedPrice
          : row.total;
      var disc =
        row.discountedPrice !== undefined && row.discountedPrice !== null
          ? row.discountedPrice
          : lineTotal;
      return {
        displayId:
          row.displayId !== undefined && row.displayId !== null
            ? String(row.displayId)
            : '',
        displayName: row.displayName || row.skuDisplayName || '',
        salePrice: row.salePrice,
        quantity: row.quantity,
        total: lineTotal,
        productId: row.productId || '',
        catalogRefId: row.catalogRefId || '',
        brandName: row.brandName || '',
        image: row.image || '',
        skuSeoUrl: row.skuSeoUrl || '',
        demoGearMessageTitle: row.demoGearMessageTitle || '',
        discountedPrice: disc,
        listPrice: row.listPrice,
        commerceType: row.commerceType || ''
      };
    }

    // MF order.items — same keys; parse string prices where needed
    var salePrice = parseMoney(row.price);
    var itemTotal = parseMoney(row.itemTotal);
    var listP = parseMoney(row.listPrice);
    return {
      displayId:
        row.displayId !== undefined && row.displayId !== null
          ? String(row.displayId)
          : String(row.id || ''),
      displayName: row.name || '',
      salePrice: salePrice !== undefined ? salePrice : row.salePrice,
      quantity: row.quantity,
      total: itemTotal !== undefined ? itemTotal : row.total,
      productId: row.productId || '',
      catalogRefId: row.catalogRefId || row.id || '',
      brandName: row.brandName || '',
      image: row.image || '',
      skuSeoUrl: row.url || '',
      demoGearMessageTitle: '',
      discountedPrice: itemTotal !== undefined ? itemTotal : row.discountedPrice,
      listPrice: listP !== undefined ? listP : salePrice,
      commerceType: row.commerceType || ''
    };
  };

  /** Normalize MF order.items[] */
  var mapMfItems = function (items) {
    if (!items || !items.length) {
      return [];
    }
    return items.map(function (row) {
      return mapRowToCartIdItem(row, false);
    });
  };

  /** Normalize GC order.commerceItems[] */
  var mapGcCommerceItems = function (items) {
    if (!items || !items.length) {
      return [];
    }
    return items.map(function (row) {
      return mapRowToCartIdItem(row, true);
    });
  };

  var getNormalizedItems = function (order) {
    if (!order) {
      return [];
    }
    if (order.commerceItems && order.commerceItems.length) {
      return mapGcCommerceItems(order.commerceItems);
    }
    if (order.items && order.items.length) {
      return mapMfItems(order.items);
    }
    return [];
  };

  // Normalize a flat removeItemDetail / saveForLaterItemDetail push into a clean object.
  // Returns null if nothing usable is present.
  var normalizeFlatItemDetail = function (detail) {
    if (!detail || typeof detail !== 'object') {
      return null;
    }
    if (
      detail.item_id === undefined &&
      detail.item_name === undefined &&
      detail.price === undefined &&
      detail.quantity === undefined &&
      detail.discount === undefined
    ) {
      return null;
    }
    return {
      item_id: detail.item_id,
      item_name: detail.item_name,
      price: detail.price,
      quantity: detail.quantity,
      discount: detail.discount
    };
  };

  // Holds the most recent removeItemDetail push until the native remove event
  // (removeFromCart / removeItemFromCart) consumes it. No caching/expiry window —
  // just remember the last one and clear it once used.
  var lastRemoveItemDetail = null;

  var buildPayload = function (cartAction, detailPayload, removedItemDetails, saveForLaterItemDetails) {
    var order = getOrder();
    var payload = {
      cartAction: cartAction,
      sendEventLocation: 'Quantum'
    };

    // Append as arrays of objects, matching the items[] pattern.
    // Only added when a real detail object is present — never sent empty.
    if (removedItemDetails) {
      payload.removedItemDetails = [removedItemDetails];
    }

    if (saveForLaterItemDetails) {
      payload.saveForLaterItemDetails = [saveForLaterItemDetails];
    }

    if (detailPayload && typeof detailPayload === 'object') {
      payload.dataLayerContext = detailPayload;
    }

    var sub = getOrderSubtotal(order);
    if (sub !== undefined) {
      payload.subtotal = sub;
      payload.cartSubtotal = sub;
    }

    if (order && order.id) {
      payload.orderId = order.id;
    }

    payload.items = getNormalizedItems(order);
    payload.itemCount = payload.items.length;

    return payload;
  };

  /** QM primary key: orderId|cartAction when order id is present; otherwise cartAction only. */
  var buildPrimaryKey = function (payload) {
    var oid = payload.orderId;
    if (oid !== undefined && oid !== null && String(oid) !== '') {
      return String(oid);
    }
  };

  var sendCartUpdatesEvent = function (cartAction, detailPayload, removedItemDetails, saveForLaterItemDetails) {
    if (
      !window.QuantumMetricAPI ||
      typeof window.QuantumMetricAPI.sendEvent !== 'function'
    ) {
      return;
    }
    var payload = buildPayload(cartAction, detailPayload, removedItemDetails, saveForLaterItemDetails);
    var sig =
      cartAction +
      '|' +
      (payload.orderId || '') +
      '|' +
      (payload.cartSubtotal || '') +
      '|' +
      payload.itemCount +
      '|' +
      JSON.stringify(payload.items || []).slice(0, 200) +
      '|' +
      (payload.removedItemDetails ? JSON.stringify(payload.removedItemDetails) : '') +
      '|' +
      (payload.saveForLaterItemDetails ? JSON.stringify(payload.saveForLaterItemDetails) : '');

    if (window.__qmCartUpdatesLastSig === sig) {
      return;
    }

    window.__qmCartUpdatesLastSig = sig;

    try {
      var primaryKey = buildPrimaryKey(payload);
      window.QuantumMetricAPI.sendEvent(
        QM_EVENT_WEB_CART_UPDATES,
        0,
        primaryKey,
        payload
      );
    } catch (e) {
      if (window.handleQMError) {
        window.handleQMError('cart-updates', e);
      }
    }
  };

  // ----- MF: remove flow (full page reload) -----
  var tryMfRemoveFromCartState = function () {
    if (!isMusiciansFriend()) {
      return;
    }
    if (window.__qmMfRemoveFromCartHandled) {
      return;
    }

    var state = window.dataLayer && window.dataLayer._state;
    if (!state || !state.removeFromCart) {
      return;
    }

    var raw = state.removeFromCart;
    var inner = raw.removeFromCart || raw;
    var detail = inner && typeof inner === 'object' ? inner : raw;

    window.__qmMfRemoveFromCartHandled = true;

      // Normalize MF's raw removeFromCart fields (sku/productName/price string/quantity string)
    // into the same shape GC's removedItemDetails uses.
    var removedItemDetails = null;
    if (detail && (detail.sku || detail.productName)) {
      var parsedPrice = parseMoney(detail.price);
      var parsedQuantity = parseInt(detail.quantity, 10);
      removedItemDetails = {
        item_id: detail.sku,
        item_name: detail.productName,
        price: parsedPrice !== undefined ? parsedPrice : null,
        quantity: isNaN(parsedQuantity) ? null : parsedQuantity,
        discount: 0
      };
    }

    sendCartUpdatesEvent('remove', detail, removedItemDetails);
  };

  // ----- MF: quantity change flow (full page reload) -----
  var tryMfQuantityChangedInCartState = function () {
    if (!isMusiciansFriend()) {
      return;
    }
    if (window.__qmMfQuantityChangedInCartHandled) {
      return;
    }

    var state = window.dataLayer && window.dataLayer._state;
    if (!state || !state.quantityChangedInCart) {
      return;
    }

    var raw = state.quantityChangedInCart;
    var inner = raw.quantityChangedInCart || raw;
    var detail = inner && typeof inner === 'object' ? inner : raw;

    window.__qmMfQuantityChangedInCartHandled = true;
    sendCartUpdatesEvent('quantityChange', detail);
  };

  // ----- GC: dlUpdateEvent -----
  var onDlUpdate = function (event) {
    var isGc = isGuitarCenter();
    var isMf = isMusiciansFriend();
    if (!isGc && !isMf) {
      return;
    }

    var d = event && event.detail;
    if (!d) {
      return;
    }

    var name = d.eventName || d.event;
    if (!name) {
      return;
    }

    // Remember the most recent removeItemDetail push. The native remove event
    // below will pick it up and attach it, then clear it.
    if (name === 'removeItemDetail') {
      lastRemoveItemDetail = normalizeFlatItemDetail(d);
      return;
    }

    // No native dlUpdateEvent trigger exists for Save for Later on GC, so this
    // push is the sole trigger — build and send the payload directly here.
    if (name === 'saveForLaterItemDetail') {
      console.log('[CART-UPDATES-DEBUG] saveForLaterItemDetail branch entered');
      var saveForLaterItemDetails = normalizeFlatItemDetail(d);
      console.log('[CART-UPDATES-DEBUG] normalized saveForLaterItemDetails =', saveForLaterItemDetails);
      if (!saveForLaterItemDetails) {
        console.log('[CART-UPDATES-DEBUG] bailed: normalizeFlatItemDetail returned null');
        return;
      }
      console.log('[CART-UPDATES-DEBUG] calling sendCartUpdatesEvent for saveForLater');
      sendCartUpdatesEvent('saveForLater', null, null, saveForLaterItemDetails);
      return;
    }

    var payload = null;
    var action = null;

    if (name === 'quantityChangedInCart' && d.quantityChangedInCart) {
      action = 'quantityChange';
      payload = d.quantityChangedInCart;
    } else if (name === 'removeFromCart' && d.removeFromCart) {
      action = 'remove';
      payload = d.removeFromCart;
    } else if (name === 'removeItemFromCart' && d.removeItemFromCart) {
      action = 'remove';
      payload = d.removeItemFromCart;
    } else if (name === 'changeItemQuantityForCart' && d.changeItemQuantityForCart) {
      action = 'quantityChange';
      payload = d.changeItemQuantityForCart;
    } else if (name === 'saveCartItemForLater' && d.saveCartItemForLater) {
      action = 'saveForLater';
      payload = d.saveCartItemForLater;
    } else if (name === 'moveCartItemFromSaveLater' && d.moveCartItemFromSaveLater) {
      action = 'moveCartItemFromSaveLater';
      payload = d.moveCartItemFromSaveLater;
    }

    if (!action) {
      return;
    }

    // De-dupe rapid double dispatches
    var dedupeKey = action + '|' + JSON.stringify(payload);
    if (window.__qmGcCartUpdatesDedupe === dedupeKey) {
      return;
    }
    window.__qmGcCartUpdatesDedupe = dedupeKey;
    setTimeout(function () {
      if (window.__qmGcCartUpdatesDedupe === dedupeKey) {
        window.__qmGcCartUpdatesDedupe = '';
      }
    }, 2000);

    // Attach and clear the cached removeItemDetail, only for remove actions.
    var removedItemDetails = null;
    if (action === 'remove' && lastRemoveItemDetail) {
      removedItemDetails = lastRemoveItemDetail;
      lastRemoveItemDetail = null;
    }

    sendCartUpdatesEvent(action, payload, removedItemDetails);
  };

  if (!window._qmCartUpdatesListenerSet) {
    window._qmCartUpdatesListenerSet = true;

    window.addEventListener('dlUpdateEvent', onDlUpdate);

    // MF: run immediate state checks on load; rely on dlUpdateEvent for subsequent pushes
    if (isMusiciansFriend()) {
      tryMfRemoveFromCartState();
      tryMfQuantityChangedInCartState();
    }
  }

  return false;
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError('cart-updates-setup', err);
  }
  return false;
}}}]},{"t":"V","v":[""]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":259,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return {};}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":261,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"f":0,"i":263,"evalAlways":false,"m":0,"s":1,"u":".*","v":{"t":"MDE","v":[{"t":"JSValue","v":["\n\n\ntry {\n  (function () {\n    if (window.__qmSdotdAtcListenerInstalled) {\n      return;\n    }\n    window.__qmSdotdAtcListenerInstalled = true;\n\n    function parsePrice(value) {\n      var parsed = parseFloat(String(value || '').replace(/[^0-9.]/g, ''));\n      return isNaN(parsed) ? null : parsed;\n    }\n\n    function getProductDataFromCard(card) {\n      var productData = {};\n      var dataProductEl = card\n        ? card.querySelector('.product-card-price[data-product]')\n        : null;\n\n      if (dataProductEl) {\n        try {\n          var jsonStr = dataProductEl.getAttribute('data-product');\n          if (jsonStr) {\n            productData = JSON.parse(jsonStr);\n          }\n        } catch (e) {}\n      }\n\n      return productData;\n    }\n\n    function buildPayload(card, clickType) {\n      var productData = getProductDataFromCard(card);\n\n      var productId = productData.id || '';\n      var productName = productData.title || '';\n      var price = parsePrice(productData.price);\n      var salePrice = parsePrice(productData.salePrice);\n      var productUrl = productData.link || '';\n\n      return {\n        pfm: 'SDOTD add to cart ad',\n        clickType: clickType,\n        productName: productName,\n        price: price,\n        salePrice: salePrice,\n        productUrl: productUrl,\n        productId: productId,\n        catalogRefId: productId\n      };\n    }\n\n    document.addEventListener(\n      'click',\n      function (event) {\n        try {\n          var target = event.target;\n          if (!target || !target.closest) {\n            return;\n          }\n\n          var card = target.closest(\n            '[data-mf-sdotd=\"true\"], .mf-sdotd-card, .product-card.mf-sdotd-card'\n          );\n          if (!card) {\n            return;\n          }\n\n          var isAtcButton = !!target.closest('button.mf-sdotd-cta');\n          var clickType = isAtcButton\n            ? 'add_to_cart_button_click'\n            : 'link_click';\n\n          var payload = buildPayload(card, clickType);\n\t\t  var primaryValue = 'SDOTD PLP Ad click | ' + clickType ;  \n          if (\n            window.QuantumMetricAPI &&\n            typeof window.QuantumMetricAPI.sendEvent === 'function'\n          ) {\n            window.QuantumMetricAPI.sendEvent(\n              263,\n              0,\n              primaryValue,\n              payload\n            );\n          }\n        } catch (e) {\n          console.error('QM SDOTD click error:', e);\n          if (window.handleQMError) {\n            window.handleQMError(e);\n          }\n        }\n      },\n      true\n    );\n  })();\n} catch (e) {\n  console.error('QM SDOTD listener setup error:', e);\n  if (window.handleQMError) {\n    window.handleQMError(e);\n  }\n}"]},{"t":"V","v":[""]},{"t":"JSValue","v":[{"fn":function () {}}]}]},"x":"QJS","sessionInfoReq":false,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":264,"f":0,"m":1,"s":1,"u":"musicarts\\.com","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]}]}},{"sessionInfoReq":true,"evalAlways":true,"excludeBlank":true,"i":265,"f":0,"m":1,"s":2,"u":"musicarts\\.com\\/cart","x":"QCC","v":{"t":"E","v":[{"t":"SelectorPresent","v":["form[data-gtm-form-interact-id] > div > div~div.text-m-a.text-xs"]},{"t":"SelectorText","v":["form[data-gtm-form-interact-id] > div > div~div.text-m-a.text-xs"]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":266,"f":0,"m":0,"s":1,"u":"musicarts\\.com","x":"QCE","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"KeyValue","v":["value","Create Account"]}]},{"t":"V","v":[""]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":true,"i":267,"f":0,"m":1,"s":2,"u":"musicarts\\.com","x":"QCE,QCE","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"KeyValue","v":["value","Log In"]}]},{"t":"V","v":["Log In Clicked"]}]},{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"KeyValue","v":["value","Sign in with Google"]}]},{"t":"V","v":["Sign in with Google Clicked"]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":268,"f":0,"m":0,"s":1,"u":".*","x":"QXJ,QJS","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["\\/api\\/graphql"]},{"t":"XFJPar","v":[]}]},"/data/customerSignMeIn/customer/email",{"t":"Not","v":[{"t":"Is","v":["null"]}]}]},{"t":"V","v":["Successful Log In (API)"]}]},{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
  if (
    QuantumMetricAPI.lastXHR &&
    QuantumMetricAPI.lastXHR.qurl &&
    QuantumMetricAPI.lastXHR.qurl.indexOf('SignMeIn') > -1 &&
    QuantumMetricAPI.lastXHR.qresponse &&
    QuantumMetricAPI.lastXHR.qresponse.data &&
    QuantumMetricAPI.lastXHR.qresponse.data.customerSignMeIn &&
    QuantumMetricAPI.lastXHR.qresponse.data.customerSignMeIn.customer &&
    QuantumMetricAPI.lastXHR.qresponse.data.customerSignMeIn.customer.email
  ) {
    return true;
  }
} catch (err) {
}}}]},{"t":"V","v":["Successful Log In (JS)"]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":269,"f":0,"m":0,"s":1,"u":".*","x":"QXJ,QJS","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["\\/api\\/graphql"]},{"t":"XFJPar","v":[]}]},"/data/customerSignMeUp/customer/email",{"t":"Not","v":[{"t":"Is","v":["null"]}]}]},{"t":"V","v":["Account Created (API)"]}]},{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
  if (
    QuantumMetricAPI.lastXHR &&
    QuantumMetricAPI.lastXHR.qurl &&
    QuantumMetricAPI.lastXHR.qurl.indexOf('SignMeUp') > -1 &&
    QuantumMetricAPI.lastXHR.qresponse &&
    QuantumMetricAPI.lastXHR.qresponse.data &&
    QuantumMetricAPI.lastXHR.qresponse.data.customerSignMeUp &&
    QuantumMetricAPI.lastXHR.qresponse.data.customerSignMeUp.customer &&
    QuantumMetricAPI.lastXHR.qresponse.data.customerSignMeUp.customer.email
  ) {
    return true;
  }
} catch (err) {
}}}]},{"t":"V","v":["Account Created (JS)"]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":270,"f":0,"m":1,"s":1,"u":"musicarts\\.com\\/educator","x":"QCE","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".checkbox-group .checkbox-item,.checkbox-group .checkbox-item *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
    var clickedEl = window.QuantumMetricAPI.lastClicked.closest(".checkbox-item");
    var inputChecked = "";
    if (clickedEl.querySelector("input[name='WhatDoYouTeach']:checked")) {
        inputChecked = clickedEl.querySelector("input") && clickedEl.querySelector("input").value || clickedEl.innerText;
    }
    return inputChecked;
} catch (err) {}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":272,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {try {
  var QM_EVENT_ID = 272;

  var sendPDPAISuggestionClick = function(payload, source) {
    try {
      if (
        !payload ||
        payload.event !== 'pdpAI' ||
        !payload.pdpAI 
      ) {
        return;
      }

      var pdpAIData = {
        action: payload.pdpAI.action,
        conversationTurn: payload.pdpAI.conversationTurn,
        productId: payload.pdpAI.productId,
        question: payload.pdpAI.question,
        skuId: payload.pdpAI.skuId,
        displayId: payload.pdpAI.skuId.split('site5')[1]
      };

      if (window.QuantumMetricAPI && window.QuantumMetricAPI.sendEvent) {
        window.QuantumMetricAPI.sendEvent(
          QM_EVENT_ID,
          0,
          pdpAIData.question,
          pdpAIData
        );
      }
    } catch (e) {
      if (window.handleQMError) {
        window.handleQMError(String(QM_EVENT_ID), e);
      }
    }
  };

  var scanExistingDataLayer = function() {
    if (!window.dataLayer || !Array.isArray(window.dataLayer)) return;

    for (var i = 0; i < window.dataLayer.length; i++) {
      sendPDPAISuggestionClick(window.dataLayer[i], 'existingDataLayer');
    }
  };

  scanExistingDataLayer();

  if (!window._pdpAISuggestionClickListenerSet) {
    window._pdpAISuggestionClickListenerSet = true;

    var originalPush = window.dataLayer && window.dataLayer.push;

    window.dataLayer = window.dataLayer || [];

    window.dataLayer.push = function() {
      var result = originalPush.apply(window.dataLayer, arguments);

      try {
        for (var i = 0; i < arguments.length; i++) {
          sendPDPAISuggestionClick(arguments[i], 'dataLayerPush');
        }
      } catch (e) {
        if (window.handleQMError) {
          window.handleQMError(String(QM_EVENT_ID), e);
        }
      }

      return result;
    };
  }

  return undefined;

} catch (err) {
  if (window.handleQMError) {
    window.handleQMError('PDP AI Suggestion Click', err);
  }
  return undefined;
}}}]},{"t":"V","v":[""]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":273,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try{
  return false;
}catch(e){}}}]},{"t":"JSValue","v":[{"fn":function () {try{
  return false;
}catch(e){}}}]}]}},{"f":0,"i":274,"evalAlways":false,"m":0,"s":0,"u":".*","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
  var agent = window.navigator.userAgent;
  var agentType = agent.includes('Macintosh') || agent.includes('Mozilla/5.0 (windows NT');
  var mobile = (/Android|Mobi|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(agent));
  return window.screen.height === 812 && window.screen.width === 375 && !mobile && agent.includes('Chrome/') && agentType;
}catch(err){
  
}}}]},{"t":"V","v":[""]}]},"x":"QJS","sessionInfoReq":false,"excludeBlank":false},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":275,"f":0,"m":1,"s":1,"u":"musicarts\\.com","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":false,"i":276,"f":0,"m":0,"s":2,"u":"musicarts\\.com","x":"QUR","v":{"t":"E","v":[{"t":"ValueClause","v":[{"t":"URLParamsValue","v":[{"t":"ObjPathValue","v":[{"t":"WV","v":[]},"/location/href"]},"schoolId"]},{"t":"Exists","v":[]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  return new URLSearchParams(window.location.search).get('schoolId');
} catch (e) {
  return null;
}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":277,"f":0,"m":1,"s":1,"u":".*","x":"QXJ","v":{"t":"MDE","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["/api/graphql?"]},{"t":"XFJPar","v":[]}]},"/errors/0/path/0",{"t":"Is","v":["customerSignMeUp"]}]},{"t":"ObjPathValue","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["/api/graphql?"]},{"t":"XFJPar","v":[]}]},"/errors/0/message"]},{"t":"VXF","v":[{"t":"XHR","v":["/api/graphql?"]},{"t":"XFPK","v":[["qurl","url"],["qstatus","statusCode"]]},{"t":"XFMG","v":[{"t":"JSValueEx","v":[{"fn":function () {var parsedResponse = JSON.parse(this.api.lastXHR.qresponse);
var resp = parsedResponse.errors[0];
var errorCode = resp.extensions.errorCode;
var errorMessage = resp.extensions.errorMessageMap["atg.droplet.DropletException"];
var path = resp.path[0];
var classification = resp.extensions.classification;

return {
  errorCode: errorCode,
  errorMessage: errorMessage,
  path: path,
  classification: classification
};}}]}]}]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":true,"i":278,"f":0,"m":1,"s":2,"u":"\\/Services\\/Lessons","x":"QCC","v":{"t":"MDE","v":[{"t":"SelectorPresent","v":["[id=\"lessonFlyout\"][aria-hidden=\"false\"]"]},{"t":"SelectorText","v":["[id=\"lessonFlyout\"][aria-hidden=\"false\"] #lessonFlyoutTitle"]},{"t":"JSValue","v":[{"fn":function () {try {
  var obj = {};
  obj.page_name = window.GCI?.digitalData?.siteVars?.pageLocation;
  obj.instrument_name = window.document.querySelector('[id="lessonFlyout"][aria-hidden="false"] #lessonFlyoutTitle').innerText.toLowerCase();
  obj.trigger_location = 'instruments';
  return obj;
}catch(err){
  
}}}]}]}},{"f":0,"i":279,"evalAlways":false,"m":1,"s":1,"u":"\\/Services\\/Lessons","v":{"t":"MAE","v":[1,0,{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["a[href=\"/Services/Lessons/Free-Trial/\"]:has(img[src*=\"gc-md-dp-lessons-001.jpg\"]) > div > div [class],a[href=\"/Services/Lessons/Free-Trial/\"]:has(img[src*=\"gc-md-dp-lessons-001.jpg\"]) > div > div [class] *"]}]},{"t":"V","v":["header_primary_free_trial"]},{"t":"JSValue","v":[{"fn":function () {try {
  var obj = {
  "cta_id": "header_primary_free_trial",
  "cta_priority": "primary",
  "cta_location": "header",
  "cta_section": "header",
  "destination_type": "free_trial",
  "destination_url": "/lessons-sign-up",
  "lesson_duration_minutes": null,
};
  
  return obj;

}catch(err){
  
}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["article:nth-child(1) a[href=\"/Services/Lessons/Purchase-Lessons.gc\"],article:nth-child(1) a[href=\"/Services/Lessons/Purchase-Lessons.gc\"] *"]}]},{"t":"V","v":["pricing_30_subscription"]},{"t":"JSValue","v":[{"fn":function () {try {
  var obj = {
  "cta_id": "pricing_30_subscription",
  "cta_priority": "secondary",
  "cta_location": "pricing_box",
  "destination_type": "subscription",
  "destination_url": "/lessons-purchase",
  "lesson_duration_minutes": 30,
};
  
  return obj;
  
}catch(err){
  
}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["article:nth-child(2) a[href=\"/Services/Lessons/Purchase-Lessons.gc\"],article:nth-child(2) a[href=\"/Services/Lessons/Purchase-Lessons.gc\"] *"]}]},{"t":"V","v":["pricing_60_subscription"]},{"t":"JSValue","v":[{"fn":function () {try {
  var obj = {
  "cta_id": "pricing_60_subscription",
  "cta_priority": "secondary",
  "cta_location": "pricing_box",
  "destination_type": "subscription",
  "destination_url": "/lessons-purchase",
  "lesson_duration_minutes": 60
};
  return obj;
}catch(err){
  
}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["section.lessons-divider a[href=\"/Services/Lessons/Free-Trial/\"] [class],section.lessons-divider a[href=\"/Services/Lessons/Free-Trial/\"] [class] *"]}]},{"t":"V","v":["next_steps_primary_free_trial"]},{"t":"JSValue","v":[{"fn":function () {try {
  var obj = {
  "cta_id": "next_steps_primary_free_trial",
  "cta_priority": "primary",
  "cta_location": "next_steps",
  "destination_type": "free_trial",
  "destination_url": "/lessons-sign-up",
  "lesson_duration_minutes": null,
};
  return obj;
}catch(err){
  
}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["a[href=\"/Lessons-Open-House.gc\"] > section [class],a[href=\"/Lessons-Open-House.gc\"] > section [class] *"]}]},{"t":"V","v":["open_house_tertiary"]},{"t":"JSValue","v":[{"fn":function () {try {
  var obj = {
  "cta_id": "open_house_tertiary",
  "cta_priority": "tertiary",
  "cta_location": "open_house",
  "destination_type": "open_house",
  "destination_url": "/Lessons-Open-House.gc",
  "lesson_duration_minutes": null,
};
  return obj;
}catch(err){
  
}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["#lessonFlyout a[href=\"/Services/Lessons/Free-Trial/\"],#lessonFlyout a[href=\"/Services/Lessons/Free-Trial/\"] *"]}]},{"t":"V","v":["instrument_slideout_free_trial"]},{"t":"JSValue","v":[{"fn":function () {try {
  var obj = {
  "cta_id": "instrument_slideout_free_trial",
  "cta_priority": "primary",
  "cta_location": "instrument_slideout",
  "destination_type": "free_trial",
  "destination_url": "/lessons-sign-up",
  "lesson_duration_minutes": null,
  "instrument_name": window.document.querySelector('[id="lessonFlyout"][aria-hidden="false"] #lessonFlyoutTitle').innerText.toLowerCase()
};
  return obj;
}catch(err){
  
}}}]}]}]},"x":"QCE,QCE,QCE,QCE,QCE,QCE","sessionInfoReq":false,"excludeBlank":true},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":280,"f":0,"m":1,"s":1,"u":".*","x":"QCE,QJS","v":{"t":"MAE","v":[1,0,{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".gc-addon-interstitial__addon-card,.gc-addon-interstitial__addon-card [class],.gc-addon-interstitial__addon-card *,.gc-addon-interstitial__addon-card [class] *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var dl = window.dataLayer || [];
  var foundInDL = false;
  for (var i = dl.length - 1; i >= 0; i--) {
    if (dl[i].event === 'gc_addon_interstitial_accessory_click') {
      var accessory = dl[i].accessory;
      var obj = {};
      obj.productName = accessory.name;
      obj.productPrice = accessory.price;
      obj.productSku = accessory.sku;
      obj.slotIndex = accessory.slot_index;
      obj.commerceType = accessory.commerce_type;
      window.QuantumMetricAPI.setSessionVar('intProData', obj);
      foundInDL = true;
      return obj.productName;
    }
  }
  if (!foundInDL) {
    var button = QuantumMetricAPI.lastClicked.closest('label');
    var obj = {};
    obj.productName = button.querySelector('.gc-addon-interstitial__addon-name').innerText;
    obj.productPrice = button.querySelector('.gc-addon-interstitial__addon-price').innerText;
    window.QuantumMetricAPI.setSessionVar('intProData', obj);
    return obj.productName;
  }
} catch (err) {}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  return window.QuantumMetricAPI.getSessionVar('intProData');
} catch (err) {}}}]}]},{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {try {
  var dl = window.dataLayer || [];
  var foundInDL = false;
  for (var i = dl.length - 1; i >= 0; i--) {
    if (dl[i].event === 'gc_addon_interstitial_accessory_click') {
      var accessory = dl[i].accessory;
      var obj = {};
      obj.productName = accessory.name;
      obj.productPrice = accessory.price;
      obj.productSku = accessory.sku;
      obj.slotIndex = accessory.slot_index;
      obj.commerceType = accessory.commerce_type;
      window.QuantumMetricAPI.setSessionVar('intProData', obj);
      foundInDL = true;
      return obj.productName;
    }
  }
  if (!foundInDL) {
    var button = QuantumMetricAPI.lastClicked.closest('label');
    var obj = {};
    obj.productName = button.querySelector('.gc-addon-interstitial__addon-name').innerText;
    obj.productPrice = button.querySelector('.gc-addon-interstitial__addon-price').innerText;
    window.QuantumMetricAPI.setSessionVar('intProData', obj);
    return obj.productName;
  }
} catch (err) {}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  return window.QuantumMetricAPI.getSessionVar('intProData');
} catch (err) {}}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":281,"f":0,"m":1,"s":1,"u":".*","x":"QCE,QJS","v":{"t":"MAE","v":[1,0,{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".gc-addon-interstitial__coverage-card,.gc-addon-interstitial__coverage-card [class],.gc-addon-interstitial__coverage-card *,.gc-addon-interstitial__coverage-card [class] *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var dl = window.dataLayer || [];
  for (var i = dl.length - 1; i >= 0; i--) {
    if (dl[i].event === 'gc_addon_interstitial_coverage_click') {
      var coverage = dl[i].coverage;
      var obj = {};
      obj.coverageTerm = coverage.label;
      obj.coveragePrice = coverage.price;
      obj.coverageType = coverage.description;
      obj.warrantyId = coverage.warranty_id;
      obj.bestValue = coverage.best_value;
      window.QuantumMetricAPI.setSessionVar('intCovObj', obj);
      return obj.coverageTerm;
    }
  }
} catch (err) {}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  return window.QuantumMetricAPI.getSessionVar('intCovObj');
} catch (err) {}}}]}]},{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {try {
  var dl = window.dataLayer || [];
  for (var i = dl.length - 1; i >= 0; i--) {
    if (dl[i].event === 'gc_addon_interstitial_coverage_click') {
      return true;
    }
  }
  return false;
} catch (err) {
  return false;
}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var dl = window.dataLayer || [];
  for (var i = dl.length - 1; i >= 0; i--) {
    if (dl[i].event === 'gc_addon_interstitial_coverage_click') {
      var coverage = dl[i].coverage;
      var obj = {};
      obj.coverageTerm = coverage.label;
      obj.coveragePrice = coverage.price;
      obj.coverageType = coverage.description;
      obj.warrantyId = coverage.warranty_id;
      obj.bestValue = coverage.best_value;
      window.QuantumMetricAPI.setSessionVar('intCovObj', obj);
      return obj.coverageTerm;
    }
  }
} catch (err) {}}}]},{"t":"JSValue","v":[{"fn":function () {}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":282,"f":0,"m":1,"s":1,"u":".*","x":"QCE,QCE,QJS,QJS","v":{"t":"MAE","v":[1,0,{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".gc-addon-interstitial__close,[data-gc-addon-close],.gc-addon-interstitial__close *,[data-gc-addon-close] *"]}]},{"t":"V","v":["Close"]}]},{"t":"E","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":[".gc-addon-interstitial__button,.gc-addon-interstitial__button *"]}]},{"t":"V","v":["Continue to Cart"]}]},{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
  var dl = window.dataLayer || [];
  for (var i = dl.length - 1; i >= 0; i--) {
    if (dl[i].event === 'gc_addon_interstitial_close') {
      return true;
    }
  }
  return false;
} catch (err) {
  return false;
}}}]},{"t":"V","v":["Close"]}]},{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
  var dl = window.dataLayer || [];
  for (var i = dl.length - 1; i >= 0; i--) {
    if (dl[i].event === 'gc_addon_interstitial_continue') {
      return true;
    }
  }
  return false;
} catch (err) {
  return false;
}}}]},{"t":"V","v":["Continue to Cart"]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":284,"f":0,"m":0,"s":1,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {try {
  window.dataLayer = window.dataLayer || [];
  window.dataLayer._state = window.dataLayer._state || {};

  var isDataLayerObject = function(obj) {
    return obj && typeof obj === 'object' && !Array.isArray(obj);
  };

  var updateDataLayerState = function(obj) {
    if (!isDataLayerObject(obj)) {
      return false;
    }

    if (obj.eventName && !obj.event) {
      obj.event = obj.eventName;
    }

    if (obj.eventName) {
      window.dataLayer._state[obj.eventName] = obj;
    }

    for (var key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key) &&
          key.indexOf('gtm.') === -1 &&
          key !== 'event' &&
          key !== 'eventName') {
        window.dataLayer._state[key] = (obj[key] === null) ? '' : obj[key];
      }
    }

    return true;
  };

  var dispatchDataLayerUpdate = function(obj) {
    try {
      if (typeof window.CustomEvent === 'function') {
        window.dispatchEvent(new CustomEvent('dlUpdateEvent', { detail: obj }));
      } else if (document && document.createEvent) {
        var event = document.createEvent('CustomEvent');
        event.initCustomEvent('dlUpdateEvent', false, false, obj);
        window.dispatchEvent(event);
      }
    } catch (dispatchErr) {
      if (window.handleQMError) {
        window.handleQMError('qm-datalayer-listener-dispatch', dispatchErr);
      }
    }
  };

  if (!window._qmDataLayerStateNormalizerSet) {
    window._qmDataLayerStateNormalizerSet = true;
    window.addEventListener('dlUpdateEvent', function(event) {
      updateDataLayerState(event && (event.detail || event));
    });
  }

  var currentPush = window.dataLayer.push || Array.prototype.push;
  var pushSource = '';
  try {
    pushSource = Function.prototype.toString.call(currentPush);
  } catch (sourceErr) {}

  var pushAlreadyDispatches = currentPush && (
    currentPush._qmDataLayerBridge ||
    pushSource.indexOf('dlUpdateEvent') !== -1 ||
    pushSource.indexOf('processPush(arguments[i])') !== -1 ||
    pushSource.indexOf('processPush(arguments[0])') !== -1
  );

  var oldPush = currentPush;

  if (!window._qmDataLayerBridgeReady && !pushAlreadyDispatches) {
    window.dataLayer.push = function() {
      for (var i = 0; i < arguments.length; i++) {
        if (updateDataLayerState(arguments[i])) {
          dispatchDataLayerUpdate(arguments[i]);
        }
      }
      return oldPush.apply(window.dataLayer, arguments);
    };
    window.dataLayer.push._qmDataLayerBridge = true;
  }

  window._qmDataLayerBridgeReady = true;

  for (var j = 0; j < window.dataLayer.length; j++) {
    updateDataLayerState(window.dataLayer[j]);
  }
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError('qm-datalayer-listener', err);
  }
}}}]},{"t":"V","v":[""]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":285,"f":0,"m":1,"s":1,"u":"musicarts\\.com","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]},{"t":"JSValue","v":[{"fn":function () {return false;}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":286,"f":0,"m":1,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {// QM Event 286: Web - Klarna Messaging
// Page load: dataLayer._state on each eval (SPA-safe). Live: dlUpdateEvent.

try {
  var QM_EVENT_ID = 286;

  var getPageType = function() {
    var pageType = window.dataLayer &&
      window.dataLayer._state &&
      window.dataLayer._state.omnitureLoaded &&
      window.dataLayer._state.omnitureLoaded.omnitureData &&
      window.dataLayer._state.omnitureLoaded.omnitureData.pageType;
    return pageType ? String(pageType).trim() : '';
  };

  var sendToQM = function(action, price, messageVariant) {
    var pageType = getPageType();
    if (!pageType || !window.QuantumMetricAPI || !window.QuantumMetricAPI.sendEvent) {
      return;
    }
    if (action === 'impression') {
      var sent = window._klarnaImpressionSentQM =
        window._klarnaImpressionSentQM || {};
      if (sent[pageType]) {
        return;
      }
      sent[pageType] = true;
    }
    if (action === 'click') {
      if (window._klarnaClickSendingQM) {
        return;
      }
      window._klarnaClickSendingQM = true;
    }
    var payload = { klarnaAction: action, pageType: pageType, price: price };
    if (messageVariant) {
      payload.messageVariant = messageVariant;
    }
    var primary = action === 'click'
      ? pageType + '|click|' + (messageVariant || 'unknown')
      : pageType + '|impression';
    window.QuantumMetricAPI.sendEvent(QM_EVENT_ID, 0, primary, payload);
    if (action === 'click') {
      setTimeout(function() {
        window._klarnaClickSendingQM = false;
      }, 0);
    }
  };

  var processEvent = function(d) {
    if (!d) {
      return;
    }
    var name = d.eventName || d.event;
    if (name === 'klarna_messaging_impression') {
      var src = d.klarna_messaging_impression || d;
      sendToQM('impression', src.price, src.messageVariant);
    } else if (name === 'klarna_messaging_click') {
      sendToQM('click', d.price, d.messageVariant);
    }
  };

  if (!window._klarnaMessagingQMListenerSet) {
    window._klarnaMessagingQMListenerSet = true;
    window.addEventListener('dlUpdateEvent', function(event) {
      try {
        processEvent(event.detail);
      } catch (err) {
        if (window.handleQMError) {
          window.handleQMError('286', err);
        }
      }
    });
  }

  var state = window.dataLayer && window.dataLayer._state;
  if (state && state.klarna_messaging_impression) {
    var imp = state.klarna_messaging_impression;
    processEvent(imp.event || imp.eventName ? imp : {
      event: 'klarna_messaging_impression',
      klarna_messaging_impression: imp
    });
  }

  return false;
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError('286', err);
  }
  return false;
}}}]},{"t":"V","v":[""]},{"t":"JSValue","v":[{"fn":function () {}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":287,"f":0,"m":1,"s":1,"u":"musicarts\\.com","x":"QCE,QCE,QCE","v":{"t":"MAE","v":[1,0,{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["div[role=\"navigation\"] [id=\"home_shop\"] ul li[role=\"menuitem\"],div[role=\"navigation\"] [id=\"home_shop\"] ul li[role=\"menuitem\"] [class],div[role=\"navigation\"] [id=\"home_shop\"] ul li[role=\"menuitem\"] svg,div[role=\"navigation\"] [id=\"home_shop\"] ul li[role=\"menuitem\"] *,div[role=\"navigation\"] [id=\"home_shop\"] ul li[role=\"menuitem\"] [class] *,div[role=\"navigation\"] [id=\"home_shop\"] ul li[role=\"menuitem\"] svg *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var obj = {};
  obj.linkName = window.QuantumMetricAPI?.lastClicked?.closest('li')?.querySelector('span').innerText;
  obj.linkLevel = 1;
  obj.L1 = window.QuantumMetricAPI?.lastClicked?.closest('li')?.querySelector('span').innerText;
  obj.L2 = "N/A";
  obj.L3 = "N/A";
  window.QuantumMetricAPI?.setSessionVar('maNav', obj);
  return obj.linkName;
}catch(err){
  
}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var obj = window.QuantumMetricAPI?.getSessionVar('maNav');
  return obj;
}catch(err){
  
}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["div[role=\"navigation\"] [id=\"home_shop\"] ul>li:not([role=\"menuitem\"]) a div,div[role=\"navigation\"] [id=\"home_shop\"] [id=\"ma-shop-all-btn\"],div[role=\"navigation\"] [id=\"home_shop\"] ul>li:not([role=\"menuitem\"]) a div *,div[role=\"navigation\"] [id=\"home_shop\"] [id=\"ma-shop-all-btn\"] *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var obj = {};
  obj.linkName = window.QuantumMetricAPI?.lastClicked?.innerText;
  obj.linkLevel = 2;
  obj.L1 = window.document?.querySelector('div[role="navigation"] [id="home_shop"] [id="ma-shop-all-btn"]')?.innerText.split('SHOP ALL ')[1];
  obj.L2 = window.QuantumMetricAPI?.lastClicked?.innerText;
  obj.L3 = "N/A";
   window.QuantumMetricAPI?.setSessionVar('maNav', obj);
  return obj.linkName;
}catch(err){
  
}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var obj = window.QuantumMetricAPI?.getSessionVar('maNav');
  return obj;
}catch(err){
  
}}}]}]},{"t":"MDE","v":[{"t":"ValueClause","v":[{"t":"ElementClickedNode","v":[]},{"t":"Matches","v":["div[role=\"navigation\"] [id=\"home_shop\"] ul li:not([role=\"menuitem\"]) li,div[role=\"navigation\"] [id=\"home_shop\"] ul li:not([role=\"menuitem\"]) li *"]}]},{"t":"JSValueEx","v":[{"fn":function () {try {
  var obj = {};
  obj.linkName = window.QuantumMetricAPI?.lastClicked?.innerText;
  obj.linkLevel = 3;
  obj.L1 = window.document?.querySelector('div[role="navigation"] [id="home_shop"] [id="ma-shop-all-btn"]')?.innerText.split('SHOP ALL ')[1];
  obj.L2 = window.QuantumMetricAPI?.lastClicked?.closest('ul')?.parentElement?.querySelector('a>div')?.innerText;
  obj.L3 = window.QuantumMetricAPI?.lastClicked?.innerText;
  window.QuantumMetricAPI?.setSessionVar('maNav', obj);
  return obj.linkName;
}catch(err){
  
}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var obj = window.QuantumMetricAPI?.getSessionVar('maNav');
  return obj;
}catch(err){
  
}}}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":false,"i":288,"f":0,"m":0,"s":1,"u":"\\/rentals","x":"QCK","v":{"t":"MDE","v":[{"t":"CookiePresent","v":["aid_sid"]},{"t":"VXF","v":[{"t":"CookieValue","v":["aid_sid"]},{"t":"XFRR","v":[{"p":".*\"(sid|aid)\":\"([^\"]+)\".*","f":""},"$1:$2"]}]},{"t":"JSValue","v":[{"fn":function () {var cookies = document.cookie.split('; ');
var match = null;

for (var i = 0; i < cookies.length; i++) {
  if (cookies[i].indexOf('aid_sid=') === 0) {
    match = cookies[i];
    break;
  }
}

if (!match) {
  return {};
}

try {
  var raw = match.substring('aid_sid='.length);
  var data = JSON.parse(decodeURIComponent(raw));

  if (data.sid) {
    return {
      locationType: 'sid',
      locationId: data.sid
    };
  }

  if (data.aid) {
    return {
      locationType: 'aid',
      locationId: data.aid
    };
  }

  return {};
} catch (e) {
  return {};
}}}]}]}},{"sessionInfoReq":true,"evalAlways":false,"excludeBlank":true,"i":289,"f":0,"m":0,"s":2,"u":"\\/rentals","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {try {
  return window.document.cookie.includes('sid');
}catch(err){}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var cookiesList = [];
  var cookieString = "";
  var cookies = window.document.cookie.split(";");
  for (var i = 0; i < cookies.length; i++) {
    var cookieObj = {};
    var cookie = cookies[i].trim();
    if (cookie.toLowerCase().includes("sid")) {
      cookieObj.name = cookie.split("=")[0];
      cookieObj.value = cookie.split("=")[1];
      cookiesList.push(cookieObj);
      cookieString += cookie;
    }
  }
  
  window.QuantumMetricAPI.setSessionVar('cookiesList', cookiesList);
  return cookieString;
} catch (err) {
    if (window.handleQMError) {
    window.handleQMError('269 - ', err);
  }
}}}]},{"t":"JSValue","v":[{"fn":function () {try {
  var obj = {};
  obj.cookieList = window.QuantumMetricAPI.getSessionVar('cookiesList');
  return obj;
}catch(err){
      if (window.handleQMError) {
    window.handleQMError('269 - ', err);
  }
}}}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":290,"f":0,"m":0,"s":0,"u":".*","x":"QJS","v":{"t":"E","v":[{"t":"JSValue","v":[{"fn":function () {return false}}]},{"t":"V","v":[""]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":291,"f":0,"m":0,"s":1,"u":"musicarts\\.com\\/cart\\/checkout|musicarts\\.com\\/cart","x":"QXJ,QXJ","v":{"t":"MAE","v":[1,0,{"t":"MDE","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["api\\/graphql"]},{"t":"XFJPar","v":[]}]},"/data/me/checkoutActiveCart/id",{"t":"Not","v":[{"t":"Is","v":["null"]}]}]},{"t":"JSValueEx","v":[{"fn":function () {/*jshint esversion: 11 */
try {
  var resp = JSON.parse(this.api.lastXHR.response);
  var cartObj = resp.data.me.checkoutActiveCart;
  window.QuantumMetricAPI.setSessionVar('cartObj', cartObj);
  return resp.data?.me?.checkoutActiveCart?.id;
} catch (err) {
  window.QuantumMetricAPI.sendEvent(224, 0, '291 - ' + err);
}}}]},{"t":"VXF","v":[{"t":"XHR","v":["api\\/graphql"]},{"t":"XFPK","v":[["qurl","url"],["qstatus","statusCode"]]},{"t":"XFMG","v":[{"t":"JSValueEx","v":[{"fn":function () {try {
  var cartObj = QuantumMetricAPI.getSessionVar('cartObj');
  return cartObj;
} catch (err) {
  window.QuantumMetricAPI.sendEvent(224, 0, '291 - ' + err);
}}}]}]}]}]},{"t":"MDE","v":[{"t":"ObjPath","v":[{"t":"VXF","v":[{"t":"XHRResponse","v":["api\\/graphql"]},{"t":"XFJPar","v":[]}]},"/data/me/activeCart/id",{"t":"Not","v":[{"t":"Is","v":["null"]}]}]},{"t":"JSValueEx","v":[{"fn":function () {/*jshint esversion: 11 */
try {
  var resp = JSON.parse(this.api.lastXHR.response);
  var cartObj = resp.data.me.activeCart;
  window.QuantumMetricAPI.setSessionVar('cartObj', cartObj);
  return resp.data?.me?.activeCart?.id;
} catch (err) {
  window.QuantumMetricAPI.sendEvent(224, 0, '291 - ' + err);
}}}]},{"t":"VXF","v":[{"t":"XHR","v":["api\\/graphql"]},{"t":"XFPK","v":[["qurl","url"],["qstatus","statusCode"]]},{"t":"XFMG","v":[{"t":"JSValueEx","v":[{"fn":function () {try {
  var cartObj = QuantumMetricAPI.getSessionVar('cartObj');
  return cartObj;
} catch (err) {
  window.QuantumMetricAPI.sendEvent(224, 0, '291 - ' + err);
}}}]}]}]}]}]}},{"sessionInfoReq":false,"evalAlways":false,"excludeBlank":true,"i":292,"f":0,"m":0,"s":1,"u":".*","x":"QJS","v":{"t":"MDE","v":[{"t":"JSValue","v":[{"fn":function () {try {
  var EVENT_ID = 292;
  
  if (!window._proCoverageATCListenerSet) {
    window._proCoverageATCListenerSet = true;
    window.addEventListener('dlUpdateEvent', function(event) {
      var eventData = event.detail || event;
      
      if (eventData &&
          eventData.eventName === 'userAddItemToCart' &&
          eventData.userAddItemToCart) {
        
        try {
          var cartData = eventData.userAddItemToCart;
          
          if (!cartData.warrantyCatalogRefIdSPA) {
            return;
          }
          
          var warrantyId = cartData.warrantyCatalogRefIdSPA || '';
          var warrantyTerm = cartData.warrantyName || '';
          var warrantyPrice = parseFloat(cartData.warrantyPrice) || 0;
          var cleanWarrantyId = warrantyId.replace(/^site5/, '');
          
          var payload = {
            coverageTerm: warrantyTerm,
            coveragePrice: warrantyPrice
          };
          
          if (window.QuantumMetricAPI && window.QuantumMetricAPI.sendEvent) {
            window.QuantumMetricAPI.sendEvent(
              EVENT_ID,
              0,
              cleanWarrantyId,
              payload
            );
          }
        } catch (e) {
          if (window.handleQMError) {
            window.handleQMError('warranty-atc', e);
          }
        }
      }
    });
  }
} catch (err) {
  if (window.handleQMError) {
    window.handleQMError('listener-init', err);
  }
}}}]},{"t":"V","v":[""]},{"t":"JSValue","v":[{"fn":function () {}}]}]}}]},"publicKeyString":"WyJsT1R2aHcvRFROa3R4ckxOa2tQaTZhK1VNOENSK29uMDZ6MEJqd09ZZHZIV2JVOXRBS1lOTkVYYXhKV1gzdy8wTTAvT216WVZzREJJRURneG9jZWZ5ZzAxUzEvYXB3ZTM4Ync2bS92VVpMUjNoMnRGWHNuWnkyUDljR3pxVlVMdlZ2dXk0OTU1QnVIWlZtemY3YVh4WWlvZWNRK1lGSkwrWE5xZ3R1ZDlqNTM1ZWNkUFVSODNzc2NYbldycEdxNDd2UWt3Njg2V2wvZ2NWOWRzMVNYeWhOVm9NcytLSk9rclY4ZVFzRHgvZjQzTXcxcmpDUU5yTHBSN1NVWFVINjZNakN5ZHovRTVhRkRvSlIxRFloVDlLbG5Vd0dwZnBLai9EeHNBQVRpNFAvTWo0enVjZHFqc1NubnA1QU9oT1hHZkFLYTlIM3JHMFF2c3F2ZWtDbm1vcXc9PSIsIkFRQUIiXQ==","sub":"guitarcenter"}); function getUrlParams(t){var e={},n=t.indexOf("?");if(-1!==n){var a=t.substring(n+1),i=a.indexOf("#");(-1!==i?a.substring(0,i):a).split("&").forEach((function(t){var n=t.split("=");2===n.length&&(e[decodeURIComponent(n[0])]=decodeURIComponent(n[1]||""))}))}var r=t.indexOf("#");-1!==r&&t.substring(r+1).split("&").forEach((function(t){var n=t.split("=");2===n.length&&(e[decodeURIComponent(n[0])]=decodeURIComponent(n[1]||""))}));return e}function logQMError(t){window.QuantumMetricAPI&&QuantumMetricAPI.sendEvent(224,0,t)}window.qmUrlParameters=getUrlParams(document.location.href),window.addEventListener("onEmbeddedMessagingConversationParticipantChanged",(function(t){try{var e=JSON.parse(t.detail.conversationEntry.entryPayload);e.entries&&e.entries.forEach((function(t){var e={operation:t.operation,role:t.participant&&t.participant.role,displayName:t.displayName,agentId:t.participant&&t.participant.subject,appType:t.participant&&t.participant.appType};"add"===t.operation&&t.participant&&"Agent"===t.participant.role&&window.QuantumMetricAPI.sendEvent(222,0,"AGENT ACCEPTED CHAT",e),"remove"===t.operation&&t.participant&&"Agent"===t.participant.role&&window.QuantumMetricAPI.sendEvent(222,0,"AGENT LEFT CHAT",e)}))}catch(t){logQMError("Error parsing participant change payload: "+t)}})),window.addEventListener("onEmbeddedMessagingConversationStarted",(function(t){window.QuantumMetricAPI.sendEvent(225,0,t.detail.conversationId,t.detail)})),window.addEventListener("onEmbeddedMessagingSessionStatusUpdate",(function(t){try{var e=JSON.parse(t.detail.conversationEntry.entryPayload),n={status:e.sessionStatus,previousStatus:e.sessionStatusPrev,endedBy:e.sessionEndedByRole,sessionId:e.sessionId};"Active"===e.sessionStatus&&"Waiting"===e.sessionStatusPrev&&window.QuantumMetricAPI.sendEvent(222,0,"AGENT ACCEPTED - Chat is now Active",n),"Ended"===e.sessionStatus&&window.QuantumMetricAPI.sendEvent(222,0,"CHAT ENDED by: "+e.sessionEndedByRole,n)}catch(t){logQMError("Error parsing session status payload: "+t)}})),window.handleQMError=function(t,e){try{window.QuantumMetricAPI.sendEvent(15,0,t+" - "+e)}catch(t){}},document.querySelector("body").addEventListener("submit",(function(t){try{var e=t.target;e&&e.classList.contains("email-capture-form")&&window.QuantumMetricAPI.sendEvent(142,0)}catch(t){}}),!0),function(){function t(t){for(var e=window.dataLayer.length-1;e>=t;e--)if(window.dataLayer[e]){var n=window.dataLayer[e];if(n.event&&"monetate campaign"===n.event){var a=n.key||"",i=n.id||"",r=n.split||"";o=199,s=i+"|"+a+"|"+r,window.QuantumMetricAPI&&(null===s&&(s=""),QuantumMetricAPI.sendEvent(o,0,s))}}var o,s}try{window.QuantumMetricAPI&&QuantumMetricAPI.addEventListener(198,(function(){var e;QuantumMetricAPI.getPrevEventData(198)&&(e=QuantumMetricAPI.getPrevEventData(198).value);var n=window.dataLayer.length;if(localStorage.getItem("QM_DL_hash")){if(e!==localStorage.getItem("QM_DL_hash")){localStorage.setItem("QM_DL_hash",e);var a=parseInt(localStorage.getItem("QM_DL_len"));t(n<a?0:a),localStorage.setItem("QM_DL_len",n)}}else e&&(localStorage.setItem("QM_DL_hash",e),t(0),localStorage.setItem("QM_DL_len",n))}))}catch(t){}}(),"guitarcenter.com"===document.domain&&window.QuantumMetricAPI.addEventListener("api",(function(t){try{if(t.url&&t.url.indexOf("/iamessage/v1/conversation/")>-1&&"DELETE"===QuantumMetricAPI.lastXHR.akCopiedArguments[0])return QuantumMetricAPI.sendEvent(221,0,"")}catch(t){}}));;
(function(){if(window.QuantumMetricAPI) window.QuantumMetricAPI.conversionRates = {"AED":3.6725,"AFN":63.999991,"ALL":80.712088,"AMD":364.394864,"ANG":1.79,"AOA":913,"ARS":1524.7391,"AUD":1.424425,"AWG":1.8,"AZN":1.7,"BAM":1.717716,"BBD":2,"BDT":123.177078,"BGN":1.718494,"BHD":0.377383,"BIF":3014.933219,"BMD":1,"BND":1.278905,"BOB":11.0172,"BRL":5.1805,"BSD":1,"BTC":0.000012047901,"BTN":95.858473,"BWP":13.630595,"BYN":3.024376,"BZD":2.013235,"CAD":1.41546,"CDF":2312.534212,"CHF":0.830447,"CLF":0.024352,"CLP":961.538462,"CNH":6.715822,"CNY":6.7135,"COP":3351.545918,"CRC":455.108274,"CUC":1,"CUP":25.75,"CVE":96.842613,"CZK":21.418674,"DJF":178.251656,"DKK":6.56714,"DOP":59.527677,"DZD":133.817732,"EGP":51.8823,"ERN":15,"ETB":162.384616,"EUR":0.878524,"FJD":2.2372,"FKP":0.753892,"GBP":0.753892,"GEL":2.603936,"GGP":0.753892,"GHS":11.626559,"GIP":0.753892,"GMD":73.497201,"GNF":8803.563722,"GTQ":7.644577,"GYD":209.441436,"HKD":7.844405,"HNL":26.866496,"HRK":6.620194,"HTG":131.001238,"HUF":321.923431,"IDR":17963.015697,"ILS":3.0577,"IMP":0.753892,"INR":95.949041,"IQD":1311.328128,"IRR":1374600,"ISK":120.37,"JEP":0.753892,"JMD":158.367829,"JOD":0.709,"JPY":157.22758333,"KES":129.69,"KGS":87.4482,"KHR":4070.749843,"KMF":432.267729,"KPW":900,"KRW":1359.783215,"KWD":0.308748,"KYD":0.834171,"KZT":443.477016,"LAK":22452.752414,"LBP":89642.585605,"LKR":330.532984,"LRD":172.178625,"LSL":16.331596,"LYD":6.399881,"MAD":9.60592,"MDL":17.730591,"MGA":4419.440528,"MKD":54.074583,"MMK":2099.95,"MNT":3599,"MOP":8.087369,"MRU":40.269447,"MUR":47.469999,"MVR":15.4557,"MWK":1735.708326,"MXN":17.772028,"MYR":4.0846,"MZN":63.830001,"NAD":16.332887,"NGN":1328.2,"NIO":36.833899,"NOK":9.509949,"NPR":153.367629,"NZD":1.764594,"OMR":0.384485,"PAB":1,"PEN":3.398193,"PGK":4.459726,"PHP":62.532,"PKR":277.37612,"PLN":3.843447,"PYG":5900.117234,"QAR":3.648779,"RON":4.6377,"RSD":103.255041,"RUB":84.498886,"RWF":1479.424939,"SAR":3.756014,"SBD":8.00052,"SCR":13.906106,"SDG":601.5,"SEK":9.935865,"SGD":1.27822,"SHP":0.753892,"SLE":24.65,"SLL":20969.5,"SOS":572.097967,"SRD":37.6675,"SSP":130.26,"STD":22281.8,"STN":21.516992,"SVC":8.758887,"SYP":13002,"SZL":16.327731,"THB":33.5665,"TJS":9.234444,"TMT":3.51,"TND":2.963376,"TOP":2.40776,"TRY":48.9822,"TTD":6.80881,"TWD":31.7653,"TZS":2648.315,"UAH":44.823666,"UGX":3920.596383,"USD":1,"UYU":40.086349,"UZS":11846.902866,"VES":853.833,"VND":25967.281226,"VUV":118.43,"WST":2.7509,"XAF":576.274135,"XAG":0.01635278,"XAU":0.00024064,"XCD":2.70255,"XCG":1.804034,"XDR":0.732916,"XOF":576.274135,"XPD":0.0008133,"XPF":104.83583,"XPT":0.00057805,"YER":236.622,"ZAR":16.381678,"ZMW":19.526355,"ZWG":26.688,"ZWL":322}})(); 